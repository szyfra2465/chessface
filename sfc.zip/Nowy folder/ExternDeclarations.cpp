//declaration of extern variables and related functions.
//the above objects and functions are now initialized and ready to use globaly
//accross translation units (project files):

bool ANALYZE_MODE = false;
bool EDIT_MODE = false;
bool SHOW_WB_THINKING_OUTPUT = false;
string lin = "";

//game history
unsigned char GameBoard[512][64] = {{13}};
unsigned int GamePV[512][64] = {{0}};
unsigned int GamePVlen[512] = {0}; //better be uints
signed int GameVal[512] = {0};

unsigned int GameMoves[512] = {0};
unsigned short GMI = 0;
unsigned short GameLen = 0;

bool GameWtm[512] = {true};

bool FORCE_MODE = false;
bool ENGINE_PLAYS_WHITE = false;
bool PONDERING = false;
bool THINKING = true;
unsigned char SD_LIMIT = 255;

//current path
string PATH = "";

//int test_m;
//void printTest_m() {
//	std::cout<<"in printTest_m(): "<<test_m<<std::endl;
//};



//board
unsigned char B[65] = {14}; //last must be dummy to handle out of board in move gen.
//theoreticly it would work with index 64 but it doesnt (joined tables in memory?)
//static unsigned char B[65] = {64};


//position of pieces to eval position quickly
static unsigned char WkiPos = 0;
static unsigned char BkiPos = 0;
//number of pieces to eval position quickly
static unsigned char WpaNum = 0;
static unsigned char BpaNum = 0;
static unsigned char WroNum = 0;
static unsigned char BroNum = 0;
static unsigned char WbiNum = 0;
static unsigned char BbiNum = 0;
static unsigned char WknNum = 0;
static unsigned char BknNum = 0;
static unsigned char WquNum = 0;
static unsigned char BquNum = 0;
//material score to calculate score quickly
static signed int MaterialScore = 0;

//some extra terms calculated by EVAL()

//measures number of pieces and attack potential near the king.
//the only the data near the king is updated each time Eval() is used
static unsigned char AttackedWkiAreaCounter[64];
static unsigned char AttackedBkiAreaCounter[64];

//get king safety score to reduce search depth of safe positions
//score is compared in consecutive positions to estimate king safety tendency
//data calculated in EV_SQUARE() and in modified EVAL()
//if this part of code is active the above scores are calculated separately
//and filnaly ev_score += evWkiSafetyScore
//and ev_score -= evBkiSafetyScore

static signed int ev_WkiSafetyScore = 0; //plus score is good for white
static signed int ev_BkiSafetyScore = 0; //plus score is good for black
//king safety[ply] - not used yet
//static signed int ev_WkiSafetyScoreTab[64];
//static signed int ev_BkiSafetyScoreTab[64];


static unsigned char ev_WpaBsqNum; //white pawns on black squares for bishop code
static unsigned char ev_BpaBsqNum; //black pawns on black squares for bishop code
static bool ev_BbiOnBsq;  //black darksquare bishop
static bool ev_WbiOnBsq;  //white darksquare bishop
static bool ev_BbiOnWsq;  //black lightsquare bishop
static bool ev_WbiOnWsq;  //white lightsquare bishop


//globals used by few functions
bool CheckStatus[64] = {false};
unsigned int bki_checked_mask;
unsigned int wki_checked_mask;



