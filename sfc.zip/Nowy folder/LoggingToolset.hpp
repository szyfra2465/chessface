void getTreeLevels(int,int);
void Wait();
// get info about byte order on this machine
bool is_little_endian();
// print info about this machine
void print_machine_info();
void printBinary(unsigned  __int64 num, bool log);
string printPiece(short piece_numeric_symbol);
void printB(string note);
// function printing the chessboard from board table B[]
void printGameBoard(unsigned short idx);
// function prints current move
string printMove(unsigned int mymove);
// function returns PATH
void printPATH(unsigned char start_ply, unsigned char stop_ply);
//function returns PV
void printPV();
// return game principal variation before the move
string printGamePV();
//function loggs ERROR message
void printError();
//code used in SELECTIVE_SEARCH macro
void printResultsTab();
//customizable advanced search stats
void printSearchStats();
//function loggs VALS
void printVals();
//print evals from the tree root to curent tree leave
void printEvals(unsigned char ply);
//prints GameWtm
void printWtm();
//prints GameEnpassant
void printGameEnpassant();
//another customizable output. use this if you dont want to change printSearchStats()
void printExtras(string note);

