/*
Handle time control
////////////////////////////////////////////////////////////////////////
*/


//time management
static bool InfiniteTime;
static double MoveStartTime;
//static double GameStartTime; //unused
static double TimeIncrement = 0; //game related
static double WhiTimeLeft = 0; //game time
static double WhiMovesLeft = 0; //game
static double BlaTimeLeft = 0; //game
static double BlaMovesLeft = 0; //game
//this will be the timer: static int MoveStartTime = 0; //move start time
static double WhiTimePerMove = 0; //time devoted to single white move
static double BlaTimePerMove = 0; //time devoted to single black move
static double ClockBase = 0; //if base is zero- time is based on whole game, else: based on number of moves
static bool ClockExact = false; //exact time per move - st command
static bool restoreTimeSettings = false; //setup true when new or setboard command, false if otim or time comand
static double storedTimeIncrement = 0;
static double storedWhiTimeLeft = 0;
static double storedWhiMovesLeft = 0;
static double storedBlaTimeLeft = 0;
static double storedBlaMovesLeft = 0;
static double storedClockBase = 0;
static bool storedClockExact = false;


#if defined(_WIN32) || defined(_WIN64)
//try queryperformancefrequency() on Windows.
#include <windows.h>
LARGE_INTEGER frequency;
LARGE_INTEGER timestamp;
#else
//try gettimeofday() on Unix
#include <sys/time.h>
#endif

//universal time struct
struct myTimerStruct {
  double seconds;
  double milliseconds;
};

//sets up myTimerStruct instance
inline static void setTimer(myTimerStruct *t)
{
#if defined(_WIN32) || defined(_WIN64)
  QueryPerformanceCounter(&timestamp);
  t->seconds = (double) timestamp.QuadPart / (double) frequency.QuadPart;
  t->milliseconds = (double) timestamp.QuadPart * 1000 / (double) frequency.QuadPart;
#define MY_TIMER_SET_SUCCESS
#else
  struct timeval timeOfDay;
  gettimeofday(&timeOfDay, NULL);
  t->seconds = (double) timeOfDay.tv_sec;
  t->milliseconds = (double) timeOfDay.tv_usec / 1000;
#define MY_TIMER_SET_SUCCESS
#endif //win and unix
#if !defined(MY_TIMER_SET_SUCCESS)
  cout << "telluser Used time functions not available on this system." << endl;
  t->seconds = 0;
  t->milliseconds = 0;
#endif
}

class Timer
{

private:

  myTimerStruct StartTime;

public:
  //constructor
  Timer() {
#if defined(_WIN32) || defined(_WIN64)
    QueryPerformanceFrequency(&frequency);
#endif
    Reset();
  }

  //destructor
  ~Timer() {}

  //reset function is silently called by constructor or used explicitly
  void Reset() {
    setTimer(&StartTime);
  };

  //double getElapsedTimeInCentiseconds(void) {
  double getElapsedTimeInCentiseconds() {
    myTimerStruct nowTime;
    setTimer(&nowTime);
    return ((nowTime.seconds * 100 - StartTime.seconds * 100) +
            (nowTime.milliseconds / 10 - StartTime.milliseconds / 10));
  };
};

Timer myTimer;


//From Beowulf, from Olithink
#if !defined(_WIN32) && !defined(_WIN64)
//Non-windows version
int Bioskey()
{
  fd_set          readfds;
  struct timeval  timeout;
  FD_ZERO(&readfds);
  FD_SET(fileno(stdin), &readfds);
//Set to timeout immediately
  timeout.tv_sec = 0;
  timeout.tv_usec = 0;
  select(16, &readfds, 0, 0, &timeout);
  return (FD_ISSET(fileno(stdin), &readfds));
}

#else
//Windows-version
#include <windows.h>
#include <conio.h>
int Bioskey()
{
  static int      init = 0,
                  pipe;
  static HANDLE   inh;
  DWORD           dw;
//If we're running under XBoard then we can't use _kbhit() as the input
//commands are sent to us directly over the internal pipe
#if defined(FILE_CNT)

  if (stdin->_cnt > 0) {
    return stdin->_cnt;
  }

#endif

  if (!init) {
    init = 1;
    inh = GetStdHandle(STD_INPUT_HANDLE);
    pipe = !GetConsoleMode(inh, &dw);

    if (!pipe) {
      SetConsoleMode(inh, dw & ~(ENABLE_MOUSE_INPUT | ENABLE_WINDOW_INPUT));
      FlushConsoleInputBuffer(inh);
    }
  }

  if (pipe) {
    if (!PeekNamedPipe(inh, NULL, 0, NULL, &dw, NULL)) {
      return 1;
    }

    return dw;
  } else {
    // Count the number of unread input records, including keyboard,
    // mouse, and window-resizing input records.
    GetNumberOfConsoleInputEvents(inh, &dw);

    if (dw <= 0) {
      return 0;
    }

    // Read data from console without removing it from the buffer
    INPUT_RECORD rec[256];
    DWORD recCnt;

    if (dw < 256) {
      if (!PeekConsoleInput(inh, rec, dw, &recCnt)) {
        return 0;
      }
    } else {
      if (!PeekConsoleInput(inh, rec, 256, &recCnt)) {
        return 0;
      }
    };

    // Search for at least one keyboard event
    for (DWORD i = 0; i < recCnt; i++)
      if (rec[i].EventType == KEY_EVENT) {
        return 1;
      }

    return 0;
  }
}
#endif



//reset game timer when new game or new setboard
void setGameStartTime()
{
  myTimer.Reset();
  #ifdef DEBUG_VERSION
  cout << "Timer is being reset." << endl;
  #endif
};

//always save if known
void saveInitialTimeSettings()
{
  storedTimeIncrement = TimeIncrement;
  storedWhiTimeLeft = WhiTimeLeft;
  storedWhiMovesLeft = WhiMovesLeft;
  storedBlaTimeLeft = BlaTimeLeft;
  storedBlaMovesLeft = BlaMovesLeft;
  storedClockBase = ClockBase;
  storedClockExact = ClockExact;
  restoreTimeSettings = false;
  #ifdef DEBUG_VERSION
	cout << "Time settings stored." << endl;
	#endif
};

//use when new or setboard command
void getTimeSettings()   //in go after new command
{
  if (restoreTimeSettings == true) {
    TimeIncrement = storedTimeIncrement;
    WhiTimeLeft = storedWhiTimeLeft;
    WhiMovesLeft = storedWhiMovesLeft;
    BlaTimeLeft = storedBlaTimeLeft;
    BlaMovesLeft = storedBlaMovesLeft;
    ClockBase = storedClockBase;
    ClockExact = storedClockExact;
    restoreTimeSettings = false;
    setGameStartTime();
    #ifdef DEBUG_VERSION
		cout << "Initial time settings restored, new game time starts." << endl;
		#endif
  };
};

//reset move start timer before making "each" move
void setMoveStartTime()
{
  MoveStartTime = myTimer.getElapsedTimeInCentiseconds();
  #ifdef DEBUG_VERSION
  cout << "Time saved into MoveStartTime as value:" << MoveStartTime << " centisecs." << endl;
  #endif
};

//assign proper time to the move.
//function should be used before incremental search
void setWhiTimePerMove()
{
	#ifdef DEBUG_VERSION
  cout << "Setting whi time per move..." << endl;
  #endif

	InfiniteTime = false;

  if ((ANALYZE_MODE == true) || (EDIT_MODE == true) || (FORCE_MODE == true)) {
    //use infinite time
    InfiniteTime = true;
    return;
  };

  //if time is assigned to the given number of moves by level command
  if (WhiMovesLeft > 0) {
    //get average time per move
    WhiTimePerMove = (WhiTimeLeft / WhiMovesLeft);
  }
  //else if time is used for the whole game
  else {
    //suppose the average game has 70 moves
    if (GMI < 50) {
      WhiTimePerMove = (WhiTimeLeft / (70 - GMI));
    } else {
      WhiTimePerMove = WhiTimeLeft / 2;
    };

    //if already 50 moves and moddle game or even game
    //- shorten time per move
  };
};

//assign proper time to the move.
//function should be used before incremental search
void setBlaTimePerMove()
{
	#ifdef DEBUG_VERSION
  cout << "Setting bla time per move..." << endl;
  #endif
	//maximize time
  InfiniteTime = false;

  if ((ANALYZE_MODE == true) || (EDIT_MODE == true) || (FORCE_MODE == true)) {
    InfiniteTime = true;
    return;
  };

//if time is assigned to the given number of moves by level command
  if (BlaMovesLeft > 0) {
    //get average time per move
    BlaTimePerMove = (BlaTimeLeft / BlaMovesLeft);
  }
  //else if time is used for the whole game
  else {
    //suppose the average game has 70 moves
    if (GMI < 50) {
      BlaTimePerMove = (BlaTimeLeft / (70 - GMI));
    } else {
      BlaTimePerMove = BlaTimeLeft / 2;
    };

    //if already 50 moves and moddle game or even game
    //- shorten time per move
  };
};

void setClockBase(double base)
{
  ClockBase = base;
  #ifdef DEBUG_VERSION
  cout << "Setting clock base to " << base << endl;
  #endif
};

void setClockExact(bool st)
{
  ClockExact = st;

  #ifdef DEBUG_VERSION
  if (st == true) {
		cout << "Setting exact clock time flag." << endl;
  } else {
    cout << "Setting NOT exact clock time flag." << endl;
  };
  #endif

};



//update global time variables, measure time used
//function should be just used after the game move
void updateTimeVariables()
{
	#ifdef DEBUG_VERSION
  cout << "Updating time variables..." << endl;
  #endif

  if ((ANALYZE_MODE == true) || (EDIT_MODE == true) || (FORCE_MODE == true)) {
    InfiniteTime = true;
    return;
  };

  //if white has just moved
  if (GameWtm[GMI] == true) {
    if (ClockBase > 0) {//moves-based-clock
      WhiMovesLeft--; //update move number in time control

      if (WhiMovesLeft == 0) { //no moves in the control
        WhiTimeLeft = ClockBase;
      };
    } else { //game-based-clock, base==0, no moves should be in the control WhiMovesLeft
      #ifdef DEBUG_VERSION
      if (WhiMovesLeft < 0) {
        cout << "time error, no whi moves left, WhiMovesLeft: " << WhiMovesLeft << endl;
      };
      #endif
    };

    //if NOT exact time per move (st command)
    if (ClockExact == false) {
      //subtract taken time
      WhiTimeLeft -= (myTimer.getElapsedTimeInCentiseconds() - MoveStartTime);
      //add time increment
      WhiTimeLeft += TimeIncrement;
    };

    #ifdef DEBUG_VERSION
    cout << "WhiTimeLeft (changed) after the move:" << WhiTimeLeft << endl;
    cout << "WhiMovesLeft (changed) after the move: " << WhiMovesLeft << endl;
    cout << "BlaTimeLeft after the move:" << BlaTimeLeft << endl;
    cout << "BlaMovesLeft after the move: " << BlaMovesLeft << endl;
    #endif

  } else {
    //moves-based-clock
    if (ClockBase > 0) {
      BlaMovesLeft--;

      if (BlaMovesLeft == 0) {
        BlaTimeLeft = ClockBase;
      };
    }
    //game-based-clock, base==0
    else {
    	#ifdef DEBUG_VERSION
      if (BlaMovesLeft < 0) {
        cout << "time error, no bla moves left, BlaMovesLeft: " << BlaMovesLeft << endl;
      };
      #endif
    };

    //if not exact time per move (st command)
    if (ClockExact == false) {
      //subtract taken time
      BlaTimeLeft -= (myTimer.getElapsedTimeInCentiseconds() - MoveStartTime);
      //add time increment
      BlaTimeLeft += TimeIncrement;
    };
    #ifdef DEBUG_VERSION
    cout << "WhiTimeLeft after the move:" << WhiTimeLeft << endl;
    cout << "WhiMovesLeft after the move: " << WhiMovesLeft << endl;
    cout << "BlaTimeLeft (changed) after the move:" << BlaTimeLeft << endl;
    cout << "BlaMovesLeft (changed) after the move: " << BlaMovesLeft << endl;
    #endif
  };
};

