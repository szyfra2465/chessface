//new ply globals
unsigned char np_i;
//extern unsigned char np_j;
unsigned char np_offs;
unsigned char np_t;
unsigned char np_c;
unsigned char np_v;
bool np_allow;
unsigned short shifted_np_ply;

//global move data
static unsigned char gl_fs; //fromsquare
static unsigned char gl_ts;
static unsigned char gl_fp; //frompiece
static unsigned char gl_tp;
static unsigned char gl_cp; //captured piece
static unsigned int gl_move; //above are packed into move
#ifdef DEBUG_VERSION
static unsigned int tmp_move; //used in debugging
#endif

//global castle data
static unsigned char castle_data[64] = {0}; //of the ply
static unsigned char castle_dat = 0; //mask
static unsigned char Game_castle_data[512] = {0};
const unsigned char castle_lost_WKK_mask = 1;
const unsigned char castle_lost_WKQ_mask = (1 << 1);
const unsigned char castle_lost_BKK_mask = (1 << 2);
const unsigned char castle_lost_BKQ_mask = (1 << 3);
const unsigned char castle_done_WKK_mask = (1 << 4);
const unsigned char castle_done_WKQ_mask = (1 << 5);
const unsigned char castle_done_BKK_mask = (1 << 6);
const unsigned char castle_done_BKQ_mask = (1 << 7);

//global enpassant data
static unsigned char enpassant = 64; //square num
static unsigned char GameEnpassant[512] = {0};
static unsigned char enp_sq[64]; //of the ply

//global counter [ply] that counts number of previous
//moves without capture or pawn move (used by 3-fold and 50-moves rule)
static unsigned char retract_tab[64] = {0};
static unsigned char retract = 0; //counter
static unsigned char GameRetract[512] = {0};

//global right to move used by eval
//this can affect null move search!
static bool side;

// function converts global POSITION data into son (direct descendant).
// Position consists of B[] table and global position data (kings locations, pieces count)
// it takes global move as argument, castle rights, and retract, it sets enpassant
inline void CHILD(unsigned char ply)
{
	#ifdef DEBUG_VERSION
  if (ply<=qDepth) {nonqs_child_count++;}
  else {qs_child_count++;};
  #endif

  //!!!!! if not defined
  #ifndef DEBUG_VERSION
  total_child_count++;
  #endif

  //cout<<"positions_count: "<< positions_count <<endl;


	/*
  //if check move is being done - set global check depth during search
  if (first_check_depth==0) {
   if ((gl_move==(gl_move|(1<<30))) || (gl_move==(gl_move|(1<<31)))) {
      first_check_depth = ply;
    };
    };
    */
#ifdef NULL_MOVE
  switch (gl_move) {
  	case 0: {
		#ifdef DEBUG_VERSION
		cout<<"bug: passing ZERO-move to CHILD"<<endl; return;}; break;
		#endif
    case
        1: {
        Zkey ^= ZWtm; //Zkey changes due to sidechange
        enpassant = 64; //enpassant square cleared
        enp_sq[ply] = enpassant;
        castle_data[ply] = castle_dat; //castle data set untouched
        Zkey_tab[ply] = Zkey; //Zkey set
        retract = 0;
        retract_tab[ply] = retract; //retractable pos count cleared
        //cout<<"null_move in CHILD()"<<endl;
        //printB("in CHILD():");
        nms_set[ply] = true;
        nms_flag = true;
        nms_qDepth = qDepth;

        #ifdef DEBUG_VERSION
        //debug before adjusting qDepth
        if (ply<nms_min_ply) {cout<<"bug: whi null move ply:"<<ply<<" qDepth:"<<qDepth<<endl;};
        if (ply>=qDepth) {
				  cout<<"bug: whi null move ply:"<<ply<<" qDepth:"<<qDepth<<endl;
				  printB("DEBUGGING in CHILD():");
				};
        #endif

        /*
        switch (ply) {
				  case 0: {;}; break;
				  case 1: {;}; break;
				  case 2: {;}; break;
				  case 3: {;}; break;
				  default: {qDepth=ply;}; break;
				};
        */
				//qDepth = ply + nms_reduction; //just do quiesence search

        //!!!!!!!!!!!!!!!qDepth -= 2;
        qDepth--;
				//qDepth = nms_qDepth-nms_reduction;
        //else
        //if (qDepth-ply>=3)
        //{qDepth=ply+2;};
        return;
      };

      break;
    case
        2: {
        Zkey ^= ZWtm; //Zkey changes due to sidechange
        enpassant = 64; //enpassant square cleared
        enp_sq[ply] = enpassant;
        castle_data[ply] = castle_dat; //castle data set untouched
        Zkey_tab[ply] = Zkey; //Zkey set
        retract = 0;
        retract_tab[ply] = retract; //retractable pos count cleared
        //cout<<"null_move in CHILD()"<<endl;
        //printB("in CHILD():");
        nms_set[ply] = true;
        nms_flag = true;
				nms_qDepth = qDepth;

        #ifdef DEBUG_VERSION
        //debug before adjusting qDepth
        if (ply<nms_min_ply) {cout<<"bug: bla null move ply:"<<ply<<" qDepth:"<<qDepth<<endl;};
        if (ply>=qDepth) {
				  cout<<"bug: bla null move ply:"<<ply<<" qDepth:"<<qDepth<<endl;
				  printB("DEBUGGING in CHILD():");
				};
				#endif
				/*
				switch (ply) {
				  case 0: {;}; break;
				  case 1: {;}; break;
				  case 2: {;}; break;
				  case 3: {;}; break;
				  default: {qDepth=ply;}; break;
				};
        */

				//qDepth = ply + nms_reduction; //just do quiesence search
				qDepth--;
        //!!!!!!!!!!!!!!!!!qDepth -= 2;
        //qDepth = nms_qDepth-nms_reduction;
        //if (qDepth-ply==1) {qDepth=ply;}
        //else if (qDepth-ply==2) {qDepth=ply+1;}
        //else
        //if (qDepth-ply>=3)
        //{qDepth=ply+2;};
        return;
      };

      break;

      /*
      case 3: {
      Zkey ^= ZWtm; //Zkey changes due to sidechange
      enpassant = 64; //enpassant square cleared
      enp_sq[ply] = enpassant;
      castle_data[ply] = castle_dat; //castle data set untouched
      Zkey_tab[ply] = Zkey; //Zkey set
      retract = 0;
      retract_tab[ply] = retract; //retractable pos count cleared
      //cout<<"null_move in CHILD()"<<endl;
      //printB("in CHILD():");
       return;
      }; break;
      case 4: {
      Zkey ^= ZWtm; //Zkey changes due to sidechange
      enpassant = 64; //enpassant square cleared
      enp_sq[ply] = enpassant;
      castle_data[ply] = castle_dat; //castle data set untouched
      Zkey_tab[ply] = Zkey; //Zkey set
      retract = 0;
      retract_tab[ply] = retract; //retractable pos count cleared
      //cout<<"null_move in CHILD()"<<endl;
      //printB("in CHILD():");
       return;
      }; break;
      */
    default
        : {
        ;
      };
  };

#endif
//u  u  u  u  u  u  u  u  c  c  c  c  x  x  x  x  p  p  p  p  t  t  t  t  t  t  f  f  f  f  f  f
//1  2  3  4  5  6  7  8  9  10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32
//32 31 30 29 28 27 26 25 24 23 22 21 20 19 18 17 16 15 14 13 12 11 10 9  8  7  6  5  4  3  2  1

//bit nr 32 - check flag (1 << 31)
//bit nr 31 - check flag (1 << 30)
//bit nr 30 - lmr flag (1 << 29)
//bit nr 29 - forced pos mask (1 << 28)
//bit nr 28 - sr root move flag (1 << 27)
//bit nr 27 - lazy eval mask (1 << 26)
//bit nr 26 - white threat flag (1 << 25)
//bit nr 25 - black threat flag (1 << 24)

#ifdef LATE_MOVE
  //late move in CHILD():
  //if move is marked as lmr move
  if (gl_move == (gl_move | (1 << 29))) {
    lmr_qDepth = qDepth;
		//debug before adjusting qDepth
		//if (ply>5) {cout<<"ok"<<endl;};
		//if (ply<lmr_min_ply) {cout<<"bug: lmr move ply:"<<ply<<" qDepth:"<<qDepth<<endl;};
    //if (ply>=qDepth) {
		  //cout<<"bug: lmr move ply:"<<ply<<" qDepth:"<<qDepth<<endl;
			//printB("DEBUGGING in CHILD():");
		//};
    //printB("lmr move in CHILD():");
    qDepth--;
    lmr_already_used = true;
  };

#endif

#ifdef SEARCH_REORD

//if move is marked as sr root move
  if (gl_move == (gl_move | (1 << 27))) {
    sr_set = true;
    sr_qDepth = qDepth;
    sr_ply = ply;
    qDepth = ply + 1;
  };

#endif
  gl_fs = ((gl_move << 26) >> 26);

  gl_ts = ((gl_move << 20) >> 26);

  gl_fp = ((gl_move << 16) >> 28);

  gl_tp = ((gl_move << 12) >> 28);

  gl_cp = ((gl_move << 8) >> 28);

//last 8 bits used for aditional data and extensions !
//gl_check = ((gl_move<<7)>>31); //u8 bit
//initially turn off enpassant status created by move
  enpassant = 64;

//always xor from_piece on from_square (F)
//and delete from_piece
  switch (gl_fp) {
    case
        1: {
        retract = 0;
        Zkey ^= ZWpa[gl_fs]
                ;

        //update Zkey by enpassant and enpassant table
        if (gl_fs == (gl_ts + 16)) {
          switch (gl_ts + 8) {
            case
                40: {
                Zkey ^= ZWe1;
                enpassant = 40;
              };

              break;
            case
                41: {
                Zkey ^= ZWe2;
                enpassant = 41;
              };

              break;
            case
                42: {
                Zkey ^= ZWe3;
                enpassant = 42;
              };

              break;
            case
                43: {
                Zkey ^= ZWe4;
                enpassant = 43;
              };

              break;
            case
                44: {
                Zkey ^= ZWe5;
                enpassant = 44;
              };

              break;
            case
                45: {
                Zkey ^= ZWe6;
                enpassant = 45;
              };

              break;
            case
                46: {
                Zkey ^= ZWe7;
                enpassant = 46;
              };

              break;
            case
                47: {
                Zkey ^= ZWe8;
                enpassant = 47;
              };

              break;
            default
                : {
                ;
              };
          };
        };
      };

      break;
    case
        2: {
        retract = 0;
        Zkey ^= ZBpa[gl_fs];

        //update Zkey by enpassant always if pawn moves two squares
        if (gl_fs == (gl_ts - 16)) {
          switch (gl_ts - 8) {
            case
                16: {
                Zkey ^= ZBe1;
                enpassant = 16;
              };

              break;
            case
                17: {
                Zkey ^= ZBe2;
                enpassant = 17;
              };

              break;
            case
                18: {
                Zkey ^= ZBe3;
                enpassant = 18;
              };

              break;
            case
                19: {
                Zkey ^= ZBe4;
                enpassant = 19;
              };

              break;
            case
                20: {
                Zkey ^= ZBe5;
                enpassant = 20;
              };

              break;
            case
                21: {
                Zkey ^= ZBe6;
                enpassant = 21;
              };

              break;
            case
                22: {
                Zkey ^= ZBe7;
                enpassant = 22;
              };

              break;
            case
                23: {
                Zkey ^= ZBe8;
                enpassant = 23;
              };

              break;
            default
                : {
                ;
              };
          };
        };
      };

      break;
    case
        3: {
        retract++;
        Zkey ^= ZWro[gl_fs];

        //set castle right loss always if rook moves from its initial sq
        if (gl_fs == 56) {
          castle_dat |= castle_lost_WKQ_mask;//set bit
        } else
          if (gl_fs == 63) {
            castle_dat |= castle_lost_WKK_mask;//set bit
          };
      };

      break;
    case
        4: {
        retract++;
        Zkey ^= ZBro[gl_fs];

        //set castle right loss always if rook moves from its initial sq
        if (gl_fs == 0) {
          castle_dat |= castle_lost_BKQ_mask;//set bit
        } else
          if (gl_fs == 7) {
            castle_dat |= castle_lost_BKK_mask;//set bit
          };
      };

      break;
    case
        5: {
        retract++;
        Zkey ^= ZWbi[gl_fs];
      };

      break;
    case
        6: {
        retract++;
        Zkey ^= ZBbi[gl_fs];
      };

      break;
    case
        7: {
        retract++;
        Zkey ^= ZWkn[gl_fs];
      };

      break;
    case
        8: {
        retract++;
        Zkey ^= ZBkn[gl_fs];
      };

      break;
    case
        9: {
        retract++;
        Zkey ^= ZWki[gl_fs];
        //set castle right loss always if king moves
        castle_dat |= castle_lost_WKQ_mask;//set bit
        castle_dat |= castle_lost_WKK_mask;//set bit
      };

      break;
    case
        10: {
        retract++;
        Zkey ^= ZBki[gl_fs];
        //set castle right always if king moves
        castle_dat |= castle_lost_BKQ_mask;//set bit
        castle_dat |= castle_lost_BKK_mask;//set bit
      };

      break;
    case
        11: {
        retract++;
        Zkey ^= ZWqu[gl_fs];
      };

      break;
    case
        12: {
        retract++;
        Zkey ^= ZBqu[gl_fs];
      };

      break;
    default: cout<<"ERROR wrong from-piece or entire move value"<<endl;
  };

  B[gl_fs] = sEmp;

///////////////////////////////////////////////////////
//always xor captured_piece if any (C)
  switch (gl_cp) {
    case
        1: {
        retract = 0;
        Zkey ^= ZWpa[gl_ts];
        WpaNum--;
        MaterialScore -= evPawnMaterialValue;
      };

      break;
    case
        2: {
        retract = 0;
        Zkey ^= ZBpa[gl_ts];
        BpaNum--;
        MaterialScore += evPawnMaterialValue;
      };

      break;
    case
        3: { //white rook
        retract = 0;
        Zkey ^= ZWro[gl_ts];

        //set castle right loss if white rook captured
        if (gl_ts == 56) {
          castle_dat |= castle_lost_WKQ_mask;//set bit
        }
        //set castle right loss if white rook captured
        else
          if (gl_ts == 63) {
            castle_dat |= castle_lost_WKK_mask;//set bit
          };

        WroNum--;
        MaterialScore -= evRookMaterialValue;
      };

      break;
    case
        4: { //black rook
        retract = 0;
        Zkey ^= ZBro[gl_ts];

        //set castle right loss if black rook captured
        if (gl_ts == 0) {
          castle_dat |= castle_lost_BKQ_mask;//set bit
        }
        //set castle right loss if black rook captured
        else
          if (gl_ts == 7) {
            castle_dat |= castle_lost_BKK_mask;//set bit
          };

        BroNum--;
        MaterialScore += evRookMaterialValue;
      };

      break;
    case
        5: {
        retract = 0;
        Zkey ^= ZWbi[gl_ts];
        WbiNum--;
        MaterialScore -= evBishopMaterialValue;
      };

      break;
    case
        6: {
        retract = 0;
        Zkey ^= ZBbi[gl_ts];
        BbiNum--;
        MaterialScore += evBishopMaterialValue;
      };

      break;
    case
        7: {
        retract = 0;
        Zkey ^= ZWkn[gl_ts];
        WknNum--;
        MaterialScore -= evKnightMaterialValue;
      };

      break;
    case
        8: {
        retract = 0;
        Zkey ^= ZBkn[gl_ts];
        BknNum--;
        MaterialScore += evKnightMaterialValue;
      };

      break;

      //king cant be captured
    case
        11: {
        retract = 0;
        Zkey ^= ZWqu[gl_ts];
        WquNum--;
        MaterialScore -= evQueenMaterialValue;
      };

      break;
    case
        12: {
        retract = 0;
        Zkey ^= ZBqu[gl_ts];
        BquNum--;
        MaterialScore += evQueenMaterialValue;
      };

      break;
  };

// if not promotion and not enpassant
  if (gl_fp == gl_tp) {
    //add to_piece
    switch (gl_tp) {
      case
          1: {
          Zkey ^= ZWpa[gl_ts];
          B[gl_ts] = sWpa;
        };

        break;
      case
          2: {
          Zkey ^= ZBpa[gl_ts];
          B[gl_ts] = sBpa;
        };

        break;
      case
          3: {
          Zkey ^= ZWro[gl_ts];
          B[gl_ts] = sWro;
        };

        break;
      case
          4: {
          Zkey ^= ZBro[gl_ts];
          B[gl_ts] = sBro;
        };

        break;
      case
          5: {
          Zkey ^= ZWbi[gl_ts];
          B[gl_ts] = sWbi;
        };

        break;
      case
          6: {
          Zkey ^= ZBbi[gl_ts];
          B[gl_ts] = sBbi;
        };

        break;
      case
          7: {
          Zkey ^= ZWkn[gl_ts];
          B[gl_ts] = sWkn;
        };

        break;
      case
          8: {
          Zkey ^= ZBkn[gl_ts];
          B[gl_ts] = sBkn;
        };

        break;
      case
          9: {
          Zkey ^= ZWki[gl_ts];
          B[gl_ts] = sWki;
          //////////////////////////////////////
          //set new WkiPos and update global king area board
          WkiArea[WkiPos] = 0;

          for (ev_v = 0; ev_v < 8; ev_v++) {
            WkiArea[Vec[ev_v][WkiPos][0]] = 0;
          };

          WkiPos = gl_ts;

          WkiArea[WkiPos] = 1;

          for (ev_v = 0; ev_v < 8; ev_v++) {
            WkiArea[Vec[ev_v][WkiPos][0]] = 1;
          };

          //////////////////////////////////////
          if (gl_fs == 60) {
            //handle k-side castle rook move
            if (gl_ts == 62) {
              Zkey ^= ZWro[63];
              B[63] = sEmp;
              Zkey ^= ZWro[61];
              B[61] = sWro;
              castle_dat |= castle_done_WKK_mask;
            }
            //handle q-side castle rook move
            else
              if (gl_ts == 58) {
                Zkey ^= ZWro[56];
                B[56] = sEmp;
                Zkey ^= ZWro[59];
                B[59] = sWro;
                castle_dat |= castle_done_WKQ_mask;
              };
          };
        };

        break;
      case
          10: {
          Zkey ^= ZBki[gl_ts];
          B[gl_ts] = sBki;
          //////////////////////////////////////
          //set new BkiPos and update global king area board
          BkiArea[BkiPos] = 0;

          for (ev_v = 0; ev_v < 8; ev_v++) {
            BkiArea[Vec[ev_v][BkiPos][0]] = 0;
          };

          BkiPos = gl_ts;

          BkiArea[BkiPos] = 1;

          for (ev_v = 0; ev_v < 8; ev_v++) {
            BkiArea[Vec[ev_v][BkiPos][0]] = 1;
          };

          //////////////////////////////////////
          if (gl_fs == 4) {
            //handle k-side castle rook move
            if (gl_ts == 6) {
              Zkey ^= ZBro[7];
              B[7] = sEmp;
              Zkey ^= ZBro[5];
              B[5] = sBro;
              castle_dat |= castle_done_BKK_mask;
            }
            //handle q-side castle rook move
            else
              if (gl_ts == 2) {
                Zkey ^= ZBro[0];
                B[0] = sEmp;
                Zkey ^= ZBro[3];
                B[3] = sBro;
                castle_dat |= castle_done_BKQ_mask;
              };
          };
        };

        break;
      case
          11: {
          Zkey ^= ZWqu[gl_ts];
          B[gl_ts] = sWqu;
        };

        break;
      case
          12: {
          Zkey ^= ZBqu[gl_ts];
          B[gl_ts] = sBqu;
        };

        break;
    };
  }
//handle promotion or enpassant capture
  else
    //gl_fp != gl_tp
  {
    //if wpa
    if (gl_fp == 1) {
      //if enpassant capture
      if (gl_tp == 2) {
        Zkey ^= ZWpa[gl_ts];
        B[gl_ts] = sWpa;
        Zkey ^= ZBpa[gl_ts + 8];
        B[gl_ts + 8] = sEmp;
        BpaNum--;
        MaterialScore += evPawnMaterialValue;
      }
      //if promotion
      else {
        //xor to_piece
        if (gl_tp == 11) {
          Zkey ^= ZWqu[gl_ts];
          B[gl_ts] = sWqu;
          WquNum++;
          MaterialScore += evQueenMaterialValue;
        } else
          if (gl_tp == 3) {
            Zkey ^= ZWro[gl_ts];
            B[gl_ts] = sWro;
            WroNum++;
            MaterialScore += evRookMaterialValue;
          } else
            if (gl_tp == 5) {
              Zkey ^= ZWbi[gl_ts];
              B[gl_ts] = sWbi;
              WbiNum++;
              MaterialScore += evBishopMaterialValue;
            } else {
              Zkey ^= ZWkn[gl_ts];
              B[gl_ts] = sWkn;
              WknNum++;
              MaterialScore += evKnightMaterialValue;
            };

        WpaNum--;
        MaterialScore -= evPawnMaterialValue;
      };
    }
    //bpa
    else
      if (gl_fp == 2) {
        if (gl_tp == 1) {
          Zkey ^= ZBpa[gl_ts];
          B[gl_ts] = sBpa;
          Zkey ^= ZWpa[gl_ts - 8];
          B[gl_ts - 8] = sEmp;
          WpaNum--;
          MaterialScore -= evPawnMaterialValue;
        } else {
          if (gl_tp == 12) {
            Zkey ^= ZBqu[gl_ts];
            B[gl_ts] = sBqu;
            BquNum++;
            MaterialScore -= evQueenMaterialValue;
          } else
            if (gl_tp == 4) {
              Zkey ^= ZBro[gl_ts];
              B[gl_ts] = sBro;
              BroNum++;
              MaterialScore -= evQueenMaterialValue;
            } else
              if (gl_tp == 6) {
                Zkey ^= ZBbi[gl_ts];
                B[gl_ts] = sBbi;
                BbiNum++;
                MaterialScore -= evBishopMaterialValue;
              } else {
                Zkey ^= ZBkn[gl_ts];
                B[gl_ts] = sBkn;
                BknNum++;
                MaterialScore -= evKnightMaterialValue;
              };

          BpaNum--;
          MaterialScore += evPawnMaterialValue;
        };
      } else {
      	#ifdef DEBUG_VERSION
        cout << "telluser error456789 in CHILD(). move received: " << flush << printMove(gl_move) << flush;
        printB("after move B[]:");
        cout << endl;
        #endif
      };
  };

//modify Zkey if move changed castle rights
  if (castle_data[ply - 1] != castle_dat) {
    if ((castle_data[ply - 1] & castle_lost_WKK_mask)
        != (castle_dat & castle_lost_WKK_mask)) {
      Zkey ^= ZWkk;
    };

    if ((castle_data[ply - 1] & castle_lost_WKQ_mask)
        != (castle_dat & castle_lost_WKQ_mask)) {
      Zkey ^= ZWkq;
    };

    if ((castle_data[ply - 1] & castle_lost_BKK_mask)
        != (castle_dat & castle_lost_BKK_mask)) {
      Zkey ^= ZBkk;
    };

    if ((castle_data[ply - 1] & castle_lost_BKQ_mask)
        != (castle_dat & castle_lost_BKQ_mask)) {
      Zkey ^= ZBkq;
    };
  };

//handle side on move
  Zkey ^= ZWtm;

//we get here: changed B[], castle_dat, enpassant, Zkey
  enp_sq[ply] = enpassant; //enpassant square set

  castle_data[ply] = castle_dat; //castle data set

  Zkey_tab[ply] = Zkey; //Zkey set

  retract_tab[ply] = retract; //retractable pos count set

//printExtras();
};


// function converts global POSITION data into parent (direct father) using move
// function reverses CHILD() actions. it asumes move is not empty.
inline void PARENT(unsigned char ply)
{
 /*
	//show output if ply-n move changes
	if (tmp_move != MOVES_TREE[((ply-1) << 8) | cur_offs[ply-1]])	{
    tmp_move = MOVES_TREE[((ply-1) << 8) | cur_offs[ply-1]];
    cout<<"Path of legal pos at "<<ply-1<<" ply after change of "<<(ply-1)<<" ply:"<< getPATH(0,ply-1)<<endl;
  };
*/
#ifdef NULL_MOVE
  switch (gl_move) {

  	#ifdef DEBUG_VERSION
  	case 0: {cout<<"bug: passing ZERO-move to PARENT"<<endl; return;}; break;
    #endif

		case 1: {
        castle_dat = castle_data[ply - 1]; //restore castle status
        enpassant = enp_sq[ply - 1]; //restore enpassant status
        Zkey = Zkey_tab[ply - 1]; //restore Zkey
        retract = retract_tab[ply - 1]; //restore retract count
        //cout<<"null_move in PARENT()"<<endl;
        //printB("in PARENT():");
        nms_set[ply] = false;
        nms_flag = false;
        //qDepth = nms_qDepth;
        qDepth--;
        return;
      };

      break;
    case
        2: {
        castle_dat = castle_data[ply - 1]; //restore castle status
        enpassant = enp_sq[ply - 1]; //restore enpassant status
        Zkey = Zkey_tab[ply - 1]; //restore Zkey
        retract = retract_tab[ply - 1]; //restore retract count
        //cout<<"null_move in PARENT()"<<endl;
        //printB("in PARENT():");
        //nms_set[ply-1] = false;
        nms_set[ply] = false;
				nms_flag = false;
				//qDepth = nms_qDepth;
        qDepth--;
				return;
      };

      break;

      /*
      case 3: {
      castle_dat = castle_data[ply-1]; //restore castle status
      enpassant = enp_sq[ply-1]; //restore enpassant status
      Zkey = Zkey_tab[ply-1]; //restore Zkey
      retract = retract_tab[ply-1]; //restore retract count
      //cout<<"null_move in PARENT()"<<endl;
      //printB("in PARENT():");
      return;
      }; break;
      case 4: {
      castle_dat = castle_data[ply-1]; //restore castle status
      enpassant = enp_sq[ply-1]; //restore enpassant status
      Zkey = Zkey_tab[ply-1]; //restore Zkey
      retract = retract_tab[ply-1]; //restore retract count
      //cout<<"null_move in PARENT()"<<endl;
      //printB("in PARENT():");
      return;
      }; break;
      */
    default
        : {
        ;
      };
  };

#endif
#ifdef LATE_MOVE
//late move in PARENT():
//if move is marked as lmr white move
  if (gl_move == (gl_move | (1 << 29))) {
    lmr_already_used = false;
    qDepth = lmr_qDepth;
    //than process move normally
    //cout<<"lmr_move in PARENT()"<<endl;
    //printB("in PARENT():");
    //};
  };

#endif
#ifdef SEARCH_REORD

//if sr root found in Parent - takeback settings
  if (gl_move == (gl_move | (1 << 27))) {
    sr_set = false;
    qDepth = sr_qDepth;
  };

#endif
  gl_fs = ((gl_move << 26) >> 26);

  gl_ts = ((gl_move << 20) >> 26);

  gl_fp = ((gl_move << 16) >> 28);

  gl_tp = ((gl_move << 12) >> 28);

  gl_cp = ((gl_move << 8) >> 28);

//always xor from_piece on from_square (F)
//and add from_piece on it
  switch (gl_fp) {
    case
        1: {
        B[gl_fs]
          = sWpa;
      };

      break;
    case
        2: {
        B[gl_fs] = sBpa;
      };

      break;
    case
        3: {
        B[gl_fs] = sWro;
      };

      break;
    case
        4: {
        B[gl_fs] = sBro;
      };

      break;
    case
        5: {
        B[gl_fs] = sWbi;
      };

      break;
    case
        6: {
        B[gl_fs] = sBbi;
      };

      break;
    case
        7: {
        B[gl_fs] = sWkn;
      };

      break;
    case
        8: {
        B[gl_fs] = sBkn;
      };

      break;
    case
        9: {
        B[gl_fs] = sWki;
        //////////////////////////////////////
        //set new WkiPos and update global king area board
        WkiArea[WkiPos] = 0;

        for (ev_v = 0; ev_v < 8; ev_v++) {
          WkiArea[Vec[ev_v][WkiPos][0]] = 0;
        };

        WkiPos = gl_fs;

        WkiArea[WkiPos] = 1;

        for (ev_v = 0; ev_v < 8; ev_v++) {
          WkiArea[Vec[ev_v][WkiPos][0]] = 1;
        };

        //////////////////////////////////////
        if (gl_fs == 60) {
          //handle backtracking k-side castle
          if (gl_ts == 62) {
            B[63] = sWro;
            B[61] = sEmp;
          }
          //handle backtracking q-side castle
          else
            if (gl_ts == 58) {
              B[56] = sWro;
              B[59] = sEmp;
            };
        };
      };

      break;
    case
        10: {
        B[gl_fs] = sBki;
        //////////////////////////////////////
        //set new BkiPos and update global king area board
        BkiArea[BkiPos] = 0;

        for (ev_v = 0; ev_v < 8; ev_v++) {
          BkiArea[Vec[ev_v][BkiPos][0]] = 0;
        };

        BkiPos = gl_fs;

        BkiArea[BkiPos] = 1;

        for (ev_v = 0; ev_v < 8; ev_v++) {
          BkiArea[Vec[ev_v][BkiPos][0]] = 1;
        };

        //////////////////////////////////////
        if (gl_fs == 4) {
          if (gl_ts == 6) {
            B[7] = sBro;
            B[5] = sEmp;
          } else
            if (gl_ts == 2) {
              B[0] = sBro;
              B[3] = sEmp;
            };
        };
      };

      break;
    case
        11: {
        B[gl_fs] = sWqu;
      };

      break;
    case
        12: {
        B[gl_fs] = sBqu;
      };

      break;
  };

//always xor captured_piece (C)
//and turn back captured_piece or empty square
  switch (gl_cp) {
    case
        1: {
        B[gl_ts]
          = sWpa;
        WpaNum++;
        MaterialScore += evPawnMaterialValue;
      };

      break;
    case
        2: {
        B[gl_ts] = sBpa;
        BpaNum++;
        MaterialScore -= evPawnMaterialValue;
      };

      break;
    case
        3: {
        B[gl_ts] = sWro;
        WroNum++;
        MaterialScore += evRookMaterialValue;
      };

      break;
    case
        4: {
        B[gl_ts] = sBro;
        BroNum++;
        MaterialScore -= evRookMaterialValue;
      };

      break;
    case
        5: {
        B[gl_ts] = sWbi;
        WbiNum++;
        MaterialScore += evBishopMaterialValue;
      };

      break;
    case
        6: {
        B[gl_ts] = sBbi;
        BbiNum++;
        MaterialScore -= evBishopMaterialValue;
      };

      break;
    case
        7: {
        B[gl_ts] = sWkn;
        WknNum++;
        MaterialScore += evKnightMaterialValue;
      };

      break;
    case
        8: {
        B[gl_ts] = sBkn;
        BknNum++;
        MaterialScore -= evKnightMaterialValue;
      };

      break;

      //king cant be captured
    case
        11: {
        B[gl_ts] = sWqu;
        WquNum++;
        MaterialScore += evQueenMaterialValue;
      };

      break;
    case
        12: {
        B[gl_ts] = sBqu;
        BquNum++;
        MaterialScore -= evQueenMaterialValue;
      };

      break;
    default
        : {
        B[gl_ts] = sEmp;
      };
  };

//xor to_piece on to_square
/////////////////////////////////////////
// handle backtracking from enpassant capture and promotion
  if (gl_fp != gl_tp) {
    if (gl_fp == 1) {
      switch (gl_tp) {
          //enpassant
        case
            2: {
            B[gl_ts] = sEmp;
            B[gl_ts + 8] = sBpa;
            BpaNum++;
            MaterialScore -= evPawnMaterialValue;
          };

          break;

          //promotion
        case
            3: {
            WroNum--;
            MaterialScore -= evRookMaterialValue;
            WpaNum++;
            MaterialScore += evPawnMaterialValue;
          };

          break;
        case
            5: {
            WbiNum--;
            MaterialScore -= evBishopMaterialValue;
            WpaNum++;
            MaterialScore += evPawnMaterialValue;
          };

          break;
        case
            7: {
            WknNum--;
            MaterialScore -= evKnightMaterialValue;
            WpaNum++;
            MaterialScore += evPawnMaterialValue;
          };

          break;
        case
            11: {
            WquNum--;
            MaterialScore -= evQueenMaterialValue;
            WpaNum++;
            MaterialScore += evPawnMaterialValue;
          };

          break;
      };
    } else
      if (gl_fp == 2) {
        switch (gl_tp) {
            //enpassant
          case
              1: {
              B[gl_ts] = sEmp;
              B[gl_ts - 8] = sWpa;
              WpaNum++;
              MaterialScore += evPawnMaterialValue;
            };

            break;

            //promotion
          case
              4: {
              BroNum--;
              MaterialScore += evRookMaterialValue;
              BpaNum++;
              MaterialScore -= evPawnMaterialValue;
            };

            break;
          case
              6: {
              BbiNum--;
              MaterialScore += evBishopMaterialValue;
              BpaNum++;
              MaterialScore -= evPawnMaterialValue;
            };

            break;
          case
              8: {
              BknNum--;
              MaterialScore += evKnightMaterialValue;
              BpaNum++;
              MaterialScore -= evPawnMaterialValue;
            };

            break;
          case
              12: {
              BquNum--;
              MaterialScore += evQueenMaterialValue;
              BpaNum++;
              MaterialScore -= evPawnMaterialValue;
            };

            break;
        };
      } else {
      	#ifdef DEBUG_VERSION
        cout << "telluser error1234 in PARENT(). move received: " << flush << printMove(gl_move) << flush;
        printB("after parent B[]:");
        cout << endl;
        #endif
      };
  };

//takeback status change
  castle_dat = castle_data[ply - 1];

  enpassant = enp_sq[ply - 1];

  Zkey = Zkey_tab[ply - 1];

  retract = retract_tab[ply - 1];
};



//function saves gl_move, position data, and insorts score and index of position data
//uses global gl_move, uses global shifted_np_ply created by NEW_PLY
inline void saveWhiPosition(unsigned char offset)
{
//erase check mask
  bki_checked_mask = 0;

#ifdef ATTACKS_MAP
	whi_threat_mask = 0;
	bla_threat_mask = 0;
#endif

#ifdef LAZY_EVAL
  le_mask = 0;
#endif

  //forced_pos = false;
#ifdef HASH_EVAL_FUNC
//HT==
//[Zkey(64bits)]
//[score(20bits)-val(20bits)-ply(6bits)-qDepth(6bits)-BestMovefromto(12bits)]
  Hkey = (Zkey >> (Zkeylen - Hkeylen));

//if Zkey matches
  if (HT[Hkey][0] == Zkey) {
    //if score is not empty (this is necessary if HT is used
    //also for storing other informations - not only score)
    if (((HT[Hkey][1]) >> 44) != (EMPTY_VAL + MAX_SCORE)) {
      //get score from HT
      H_eval_cuttoffs++;
      sv_sc = (((HT[Hkey][1]) >> 44) - MAX_SCORE);
    }
    //else - calculate score using EVAL() and overwrite HT under certain conditions
    else {
      sv_sc = EVAL();

      //overwrite HT with the score if not check in position
      //(overwriting check would produce problem with check masks
      //because they are generated by EVAL()).
      //The same applies to unquiesent positions? (forced_pos_mask)
      if (bki_checked_mask == 0) {

      #ifdef ATTACKS_MAP
      //only if no threat flags used
			if ((whi_threat_mask == 0) && (bla_threat_mask == 0)) {
      #endif

      #ifdef LAZY_EVAL
		  //only if not lazy eval was used
  	  if (le_mask == 0) {
  	  #endif

        //negative score must be converted to positive.
        //saves the score to HT.
				HT[Hkey][1] = (((unsigned __int64) (sv_sc + MAX_SCORE)) << 44);

			#ifdef LAZY_EVAL
      };
     	#endif

     	#ifdef ATTACKS_MAP
			};
			#endif

      };

    };
  }
//if Zkey doesnt match overwrite Zkey and exact score in HT,
//erase val and relative data in given HT entry
  else {
    H_eval_overwrites++;
    sv_sc = EVAL();

    if (bki_checked_mask == 0) {

    	#ifdef ATTACKS_MAP
      //only if no threat flags used
			if ((whi_threat_mask == 0) && (bla_threat_mask == 0)) {
      #endif

      #ifdef LAZY_EVAL
     	if (le_mask == 0) {
      #endif

			HT[Hkey][0] = Zkey;
      HT[Hkey][1] = (((unsigned __int64) (sv_sc + MAX_SCORE)) << 44);

      #ifdef LAZY_EVAL
      };
     	#endif

     	#ifdef ATTACKS_MAP
			};
      #endif

		};
  };

#endif
//if Hash_E.V. not defined
#ifndef HASH_EVAL_FUNC
  sv_sc = EVAL();
#endif

//encode check in the move
  gl_move |= bki_checked_mask;

//encode le_mask in the move
#ifdef LAZY_EVAL
  gl_move |= le_mask;
#endif

//encode threat masks in the move
#ifdef ATTACKS_MAP
	gl_move |= whi_threat_mask;
	gl_move |= bla_threat_mask;
#endif

//encode forced_pos in the move
/*
  if (forced_pos == true) {
    if (gl_move != 1)
      //if null move dont save it - errorprone
    {
      gl_move |= forced_pos_mask;
      //cout<<"forced_pos==false"<<endl;
    };
  };
*/
//insort sv_sc score into grade[256], duplicate is always added in the end
//move grade[] and mymove[] entries
  //cout<<"grade!!! "<<grade[sv_ct - 1]<<endl;
  for (sv_ct = offset; ((sv_ct > 0) && (grade[sv_ct - 1] < sv_sc)); sv_ct--) {
    grade[sv_ct] = grade[sv_ct - 1];
    mymove[sv_ct] = mymove[sv_ct - 1];
		pindex[sv_ct] = pindex[sv_ct - 1];
  };

  grade[sv_ct] = sv_sc;
  mymove[sv_ct] = gl_move;
  //insort position natural (unsorted) index into sorted table
  pindex[sv_ct] = offset;

  //save unsorted big position data only once into the tree into natural position
	UnsPosTree[shifted_np_ply| offset].lastMove = gl_move;


//speedup?
//if (sv_sc==MAX_SCORE) {cout<<"w mates"<<endl; np_i = 64;};
  /*insort by active move type, if moves even - insort by evals
  for (sv_ct=offset;
      (
    (sv_ct>0)
    &&
    (move_eval(mymove[sv_ct-1]) < (move_eval(mymove[sv_ct]))) //decisive move eval difference
    ||                            //or
    (
    (move_eval(mymove[sv_ct-1]) == (move_eval(mymove[sv_ct])))//equal move evals but better score
    &&
    (grade[sv_ct-1] < sv_sc)));
    sv_ct--) {
    };
    */
#ifdef LVAMVV_ORDERING

///////////////////////////////////////////////////////////////////
//use LEAST_VALUABLE_ATTACKER_MOST_VALUABLE_VICTIM captures ordering
//while loop: if curent move is capture
  while ((gl_cp != 0) &&
         //and curent move is not first
         (sv_ct > 0) &&
         //and mat. value of curent move cp equals value of previous move captured piece
         (UnsignedMaterialValue[gl_cp] ==
          UnsignedMaterialValue[(((mymove[sv_ct - 1]) << 8) >> 28) ])
         &&
         //and value of curent move attacker is less than value of previous move attacker
         (UnsignedMaterialValue[gl_fp] <
          UnsignedMaterialValue[(((mymove[sv_ct - 1]) << 16) >> 28) ])
        ) {
    //swap curent move with previous and continue checking curent move in the loop
    sv_tmp_mv = mymove[sv_ct - 1];
    sv_tmp_gr = grade[sv_ct - 1];
    mymove[sv_ct - 1] = gl_move;
    grade[sv_ct - 1] = sv_sc;
    mymove[sv_ct] = sv_tmp_mv;
    grade[sv_ct] = sv_tmp_gr;
    sv_ct--;
    //printB("captures reordering"); cout<<printMove(mymove[sv_ct])<<" scored "<<grade[sv_ct]<<
    //" went before "<<printMove(mymove[sv_ct+1])<<
    //" scored "<<grade[sv_ct+1]<<endl;
  };

#endif
};

//uses global gl_move, uses global shifted_np_ply created by NEW_PLY
inline void saveBlaPosition(unsigned char offset)
{
//erase check mask
  wki_checked_mask = 0;

#ifdef ATTACKS_MAP
	whi_threat_mask = 0;
	bla_threat_mask = 0;
#endif

#ifdef LAZY_EVAL
  le_mask = 0;
#endif

#ifdef HASH_EVAL_FUNC
//HT==
//[Zkey(64bits)]
//[score(20bits)-val(20bits)-ply(6bits)-qDepth(6bits)-BestMovefromto(12bits)]
  Hkey = (Zkey >> (Zkeylen - Hkeylen));

//if Zkey matches
  if (HT[Hkey][0] == Zkey) {
    //if score is not empty (this is necessary if HT is used
    //also for storing other informations - not only score)
    if (((HT[Hkey][1]) >> 44) != (EMPTY_VAL + MAX_SCORE)) {
      //get score from HT
      H_eval_cuttoffs++;
      sv_sc = (((HT[Hkey][1]) >> 44) - MAX_SCORE);
    }
    //else - calculate score using EVAL() and overwrite HT under certain conditions
    else {
      sv_sc = EVAL();

      //overwrite HT with the score if not check in position
      //(overwriting check would produce problem with check masks
      //because they are generated by EVAL()).

      if (wki_checked_mask == 0) {

        #ifdef ATTACKS_MAP
        //only if no threat flags used
			  if ((whi_threat_mask == 0) && (bla_threat_mask == 0)) {
        #endif

				#ifdef LAZY_EVAL
      	if (le_mask == 0) {
      	#endif

				//negative score must be converted to positive
				HT[Hkey][1] = (((unsigned __int64) (sv_sc + MAX_SCORE)) << 44);

				#ifdef LAZY_EVAL
        };
      	#endif

      	#ifdef ATTACKS_MAP
				};
        #endif

      };
    };
  }
//if Zkey doesnt match overwrite Zkey and exact score in HT,
//erase val and relative data
  else {
    H_eval_overwrites++;
    sv_sc = EVAL();

    if (wki_checked_mask == 0) {

    	#ifdef ATTACKS_MAP
      //only if no threat flags used
		  if ((whi_threat_mask == 0) && (bla_threat_mask == 0)) {
      #endif

    	#ifdef LAZY_EVAL
     	if (le_mask == 0) {
      #endif

      HT[Hkey][0] = Zkey;
      HT[Hkey][1] = (((unsigned __int64) (sv_sc + MAX_SCORE)) << 44);

      #ifdef LAZY_EVAL
      };
      #endif

      #ifdef ATTACKS_MAP
			};
			#endif

    };
  };

#endif
//if HEF not defined
#ifndef HASH_EVAL_FUNC
  sv_sc = EVAL();

#endif
//encode check in the move
  gl_move |= wki_checked_mask;

  #ifdef LAZY_EVAL
 	gl_move |= le_mask;
  #endif

  //encode threat masks in the move
  #ifdef ATTACKS_MAP
	gl_move |= whi_threat_mask;
	gl_move |= bla_threat_mask;
  #endif

/*
//encode forced_pos in the move
  if (forced_pos == true) {
    if (gl_move != 2)
      //errorprone
    {
      gl_move |= forced_pos_mask;
      //cout<<"forced_pos==false"<<endl;
    };
  };
*/
  for (sv_ct = offset; ((sv_ct > 0) && (grade[sv_ct - 1] > sv_sc)); sv_ct--) {
    grade[sv_ct] = grade[sv_ct - 1];
    mymove[sv_ct] = mymove[sv_ct - 1];
    pindex[sv_ct] = pindex[sv_ct - 1];
  };

  grade[sv_ct] = sv_sc;
  mymove[sv_ct] = gl_move;
  //insort position natural (unsorted) index into sorted table
  pindex[sv_ct] = offset;

  //save unsorted big position data only once into the tree into natural position
	UnsPosTree[shifted_np_ply | offset].lastMove = gl_move;


//speedup?
//if (sv_sc==MIN_SCORE) {cout<<"b mates"<<endl; np_i = 64;};
#ifdef LVAMVV_ORDERING

///////////////////////////////////////////////////////////////////
//use LEAST_VALUABLE_ATTACKER_MOST_VALUABLE_PIECE captures ordering
//while curent move is capture
  while ((gl_cp != 0) &&
         //and curent move is not first
         (sv_ct > 0) &&
         //and mat. value of curent move cp equals value of previous move captured piece
         (UnsignedMaterialValue[gl_cp] ==
          UnsignedMaterialValue[(((mymove[sv_ct - 1]) << 8) >> 28) ])
         &&
         //and value of curent move attacker is less than value of previous move attacker
         (UnsignedMaterialValue[gl_fp] <
          UnsignedMaterialValue[(((mymove[sv_ct - 1]) << 16) >> 28) ])
        ) {
    //swap curent move with previous and continue checking curent move in the loop
    sv_tmp_mv = mymove[sv_ct - 1];
    sv_tmp_gr = grade[sv_ct - 1];
    mymove[sv_ct - 1] = gl_move;
    grade[sv_ct - 1] = sv_sc;
    mymove[sv_ct] = sv_tmp_mv;
    grade[sv_ct] = sv_tmp_gr;
    sv_ct--;
    //printB("captures reordering"); cout<<printMove(mymove[sv_ct])<<" scored "<<(grade[sv_ct])<<
    //" went before "<<printMove(mymove[sv_ct+1])<<
    //" scored "<<(grade[sv_ct+1])<<endl;
  };

////////////////////////////////////////////////////////////////
#endif
};

//helper function used to save sorted data into the TREEs in the end of ..ply()
//function. this is is not done in saveWhiPosition, saveBlaPosition for performance
//reasons (local tables with simple indexes are usen in data sort)

inline void finishSavePositionInNewPly() {

  np_i = 0;

  while (np_i < np_offs) {
    MOVES_TREE[shifted_np_ply | np_i] = mymove[np_i]; //assign move to the TREE
    VALS_TREE[shifted_np_ply | np_i] = grade[np_i]; //assign grade to the TREE
    SortedIdxTree[shifted_np_ply | np_i] = pindex[np_i]; //assign Pos indexes to the tree (pos data assigned earlier)

    //cout<<" data debug1 ["<<np_i<<"]"<<" "<<printMove(mymove[np_i])<<" score:"<<grade[np_i]<<endl;
    //cout<<" data debug2 ["<<np_i<<"]"<<" "
		//<<printMove(UnsPosTree[shifted_np_ply | pindex[np_i]].lastMove)<<" "
		//<<"unshifted ply: "<< (shifted_np_ply>>8)
		//<<" score:"<<grade[np_i]<<endl;

    np_i++;
  };
};

// access ply to save moves properly in the tree
unsigned char FULL_WHI_PLY(unsigned char ply)
{
//set side to properly eval
  side = false;


//set initial data tables of this ply before CHILD() action
  enpassant = enp_sq[ply - 1];

  castle_dat = castle_data[ply - 1];

  Zkey = Zkey_tab[ply - 1];

  retract = retract_tab[ply - 1];

  shifted_np_ply = (ply<<8); //static used in saving position data


//loop board
  np_offs = 0;

/*
#ifdef NULL_MOVE
//insert null-move into the ply if allowed -
//the move would not be insorted after mating move
//(mate is always first and only move in the ply)
//move will not be later saved if mate was found (restricted offset)
//or if not position under check (this would lead to illegal position)

//IF NODE IS NOT PV NODE
//if no null move set upper
  if (nms_set[ply-1] == false) {
    //if proper max ply
    //if (ply<qDepth-nms_reduction) {
    if (ply < qDepth) {
      //if (MOVES_TREE[((ply-1)<<8)|cur_offs[ply-1]]>2) {
      //if self move not in check
      if (CheckStatus[ply - 1] == false) {
        //if no check in the path
        //if (first_check_depth==0) {
        //if enough self material /little chance for zugzwang
        if ((WquNum > 0) || (WroNum > 0)) {
          //if proper min ply
          if (ply >= nms_min_ply) {
            //suitable move for white
            gl_move = 1;
            CHILD(ply);
            //if (isAttByBla(WkiPos)==false) {saveWhiPosition(np_offs); np_offs++;};
            saveWhiPosition(np_offs);
            np_offs++;
            PARENT(ply);
          };
        };
      };
    };
  };

#endif
*/

	for (np_i = 0; np_i < 64; np_i++) {
    switch (B[np_i]) {
      case
          sWpa: {
          if (np_i > 47)
            //handle nonpromotion move
          {
            np_t = LWPCaps[np_i];

            switch (B[np_t]) {
              case
                  sBpa: { //analyse {np_i,np_t,sWpa,sWpa,sBpa};
                  gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (2 << 20));
                  //est_move = PawnPawnCap;
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBro: { //analyse {np_i, np_t, sWpa, sWpa, sBro};
                  gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (4 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBbi: { //analyse {np_i, np_t, sWpa, sWpa, sBbi};
                  gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (6 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBkn: { //analyse {np_i, np_t, sWpa, sWpa, sBkn};
                  gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (8 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBqu: { //analyse {np_i, np_t, sWpa, sWpa, sBqu};
                  gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (12 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
            };

            np_t = RWPCaps[np_i];

            switch (B[np_t]) {
              case
                  sBpa: { //analyse {np_i, np_t, sWpa, sWpa, sBpa};
                  gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (2 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBro: { //analyse {np_i, np_t, sWpa, sWpa, sBro};
                  gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (4 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBbi: { //analyse {np_i, np_t, sWpa, sWpa, sBbi};
                  gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (6 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBkn: { //analyse {np_i, np_t, sWpa, sWpa, sBkn};
                  gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (8 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBqu: { //analyse {np_i, np_t, sWpa, sWpa, sBqu};
                  gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (12 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
            };

            // check if white pawn can move ONE SQUARE AHEAD
            np_t = np_i - 8;

            if (B[np_t] == sEmp)
              // {np_i, np_i-8, sWpa, sWpa, '0'};
            {
              gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16));
              CHILD(ply);

              if (isAttByBla(WkiPos) == false) {
                saveWhiPosition(np_offs);
                np_offs++;
              };

              PARENT(ply);

              // now check if pawn can move TWO SQUARES AHEAD
              np_t -= 8;

              if (B[np_t] == sEmp)
                // {np_i, np_i-16, sWpa, sWpa, '0'};
              {
                gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16));
                CHILD(ply);

                if (isAttByBla(WkiPos) == false) {
                  saveWhiPosition(np_offs);
                  np_offs++;
                };

                PARENT(ply);
              };
            };
          }
          // IF PAWN IS IN THE MIDDLEBOARD
          else
            if (np_i > 15) {
              np_t = LWPCaps[np_i];

              switch (B[np_t]) {
                case
                    sEmp: { //analyse enpassant capture
                    if ((enpassant == np_t) && (np_t != 64)) {
                      //analyse {np_i, np_t, sWpa, sBpa};
                      gl_move = (np_i | (np_t << 6) | (1 << 12) | (2 << 16));
                      CHILD(ply);

                      if (isAttByBla(WkiPos) == false) {
                        saveWhiPosition(np_offs);
                        np_offs++;
                      };

                      PARENT(ply);
                    };
                  };

                  break;
                case
                    sBpa: { //analyse {np_i, np_t, sWpa, sWpa, sBpa};
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (2 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sBro: { //analyse {np_i, np_t, sWpa, sWpa, sBro};
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (4 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sBbi: { //analyse {np_i, np_t, sWpa, sWpa, sBbi};
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (6 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sBkn: { //analyse {np_i, np_t, sWpa, sWpa, sBkn};
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (8 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sBqu: { //analyse {np_i, np_t, sWpa, sWpa, sBqu};
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (12 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
              };

              np_t = RWPCaps[np_i];

              switch (B[np_t]) {
                case
                    sEmp: { //analyse enpassant capture
                    if ((enpassant == np_t) && (np_t != 64)) {
                      //{np_i, np_t, sWpa, sBpa};
                      gl_move = (np_i | (np_t << 6) | (1 << 12) | (2 << 16));
                      CHILD(ply);

                      if (isAttByBla(WkiPos) == false) {
                        saveWhiPosition(np_offs);
                        np_offs++;
                      };

                      PARENT(ply);
                    };
                  };

                  break;
                case
                    sBpa: { //analyse {np_i,np_t,sWpa,sWpa,sBpa};
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (2 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sBro: { //analyse {np_i, np_t, sWpa, sWpa, sBro};
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (4 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sBbi: { //analyse {np_i, np_t, sWpa, sWpa, sBbi};
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (6 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sBkn: { //analyse {np_i, np_t, sWpa, sWpa, sBkn};
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (8 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sBqu: { //analyse {np_i, np_t, sWpa, sWpa, sBqu};
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (12 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
              };

              // check if white pawn can move ONE SQUARE AHEAD
              np_t = np_i - 8;

              if (B[np_t] == sEmp)
                //{np_i, np_i-8, sWpa, sWpa, '0'};
              {
                gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16));
                CHILD(ply);

                if (isAttByBla(WkiPos) == false) {
                  saveWhiPosition(np_offs);
                  np_offs++;
                };

                PARENT(ply);
              };
            }
          // ELSE IF PAWN IS IN THE SEVENTH ROW
          // handle PROMOTION if PAWN CAN MOVE AHEAD
            else {
              np_t = np_i - 8;
              np_allow = false;

              if (B[np_t] == sEmp) {
                gl_move = (np_i | (np_t << 6) | (1 << 12) | (11 << 16));
                CHILD(ply);

                if (isAttByBla(WkiPos) == false) {
                  np_allow = true;
                  saveWhiPosition(np_offs);
                  np_offs++;
                }

                PARENT(ply);
                gl_move = (np_i | (np_t << 6) | (1 << 12) | (3 << 16));
                CHILD(ply);

                if (np_allow == true) {
                  saveWhiPosition(np_offs);
                  np_offs++;
                };

                PARENT(ply);

                gl_move = (np_i | (np_t << 6) | (1 << 12) | (5 << 16));

                CHILD(ply);

                if (np_allow == true) {
                  saveWhiPosition(np_offs);
                  np_offs++;
                };

                PARENT(ply);

                gl_move = (np_i | (np_t << 6) | (1 << 12) | (7 << 16));

                CHILD(ply);

                if (np_allow == true) {
                  saveWhiPosition(np_offs);
                  np_offs++;
                };

                PARENT(ply);
              };

              // handle PROMOTION if PAWN CAPTURED
              np_t = LWPCaps[np_i];

              switch (B[np_t]) {
                  // if opponent rook is captured - memorize the possible promotions
                case
                    sBro: {
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (11 << 16) | (4 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      np_allow = true;
                      saveWhiPosition(np_offs);
                      np_offs++;
                    }

                    PARENT(ply);
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (3 << 16) | (4 << 20));
                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (5 << 16) | (4 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (7 << 16) | (4 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;

                  // if opponent bishop is captured - memorize the possible promotions
                case
                    sBbi: {
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (11 << 16) | (6 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      np_allow = true;
                      saveWhiPosition(np_offs);
                      np_offs++;
                    }

                    PARENT(ply);
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (3 << 16) | (6 << 20));
                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (5 << 16) | (6 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (7 << 16) | (6 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;

                  // if opponent knight is captured - memorize the possible promotions
                case
                    sBkn: {
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (11 << 16) | (8 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      np_allow = true;
                      saveWhiPosition(np_offs);
                      np_offs++;
                    }

                    PARENT(ply);
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (3 << 16) | (8 << 20));
                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (5 << 16) | (8 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (7 << 16) | (8 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;

                  // if opponent queen is captured - memorize the move
                case
                    sBqu: {
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (11 << 16) | (12 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      np_allow = true;
                      saveWhiPosition(np_offs);
                      np_offs++;
                    }

                    PARENT(ply);
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (3 << 16) | (12 << 20));
                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (5 << 16) | (12 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (7 << 16) | (12 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
              };

              np_t = RWPCaps[np_i];

              switch (B[np_t]) {
                  // if opponent rook is captured - memorize the possible promotions
                case
                    sBro: {
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (11 << 16) | (4 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      np_allow = true;
                      saveWhiPosition(np_offs);
                      np_offs++;
                    }

                    PARENT(ply);
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (3 << 16) | (4 << 20));
                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (5 << 16) | (4 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (7 << 16) | (4 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;

                  // if opponent bishop is captured - memorize the possible promotions
                case
                    sBbi: {
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (11 << 16) | (6 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      np_allow = true;
                      saveWhiPosition(np_offs);
                      np_offs++;
                    }

                    PARENT(ply);
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (3 << 16) | (6 << 20));
                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (5 << 16) | (6 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (7 << 16) | (6 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;

                  // if opponent knight is captured - memorize the possible promotions
                case
                    sBkn: {
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (11 << 16) | (8 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      np_allow = true;
                      saveWhiPosition(np_offs);
                      np_offs++;
                    }

                    PARENT(ply);
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (3 << 16) | (8 << 20));
                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (5 << 16) | (8 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (7 << 16) | (8 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;

                  // if opponent queen is captured - memorize the move
                case
                    sBqu: {
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (11 << 16) | (12 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      np_allow = true;
                      saveWhiPosition(np_offs);
                      np_offs++;
                    }

                    PARENT(ply);
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (3 << 16) | (12 << 20));
                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (5 << 16) | (12 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (7 << 16) | (12 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
              };
            };
        };

        break;
      case
          sWro: {
          for (np_v = 4; np_v < 8; np_v++) {
            for (np_c = 0; np_c < 8; np_c++) {
              np_t = Vec[np_v][np_i][np_c];

              switch (B[np_t]) {
                case
                    sEmp: { //move m = {np_i, np_t, sWro, sWro, '0'};
                    gl_move = (np_i | (np_t << 6) | (3 << 12) | (3 << 16));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sBpa: { //move m = {np_i, np_t, sWro, sWro, sBpa};
                    gl_move = (np_i | (np_t << 6) | (3 << 12) | (3 << 16) | (2 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sBro: { //move m = {np_i, np_t, sWro, sWro, sBro};
                    gl_move = (np_i | (np_t << 6) | (3 << 12) | (3 << 16) | (4 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sBbi: { //move m = {np_i, np_t, sWro, sWro, sBbi};
                    gl_move = (np_i | (np_t << 6) | (3 << 12) | (3 << 16) | (6 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sBkn: { //move m = {np_i, np_t, sWro, sWro, sBkn};
                    gl_move = (np_i | (np_t << 6) | (3 << 12) | (3 << 16) | (8 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sBqu: { //move m = {np_i, np_t, sWro, sWro, sBqu};
                    gl_move = (np_i | (np_t << 6) | (3 << 12) | (3 << 16) | (12 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                default
                    : {
                    np_c = 8;
                  };//handle out of board vector
              };
            };
          };
        };

        break;
      case
          sWbi: {
          for (np_v = 0; np_v < 4; np_v++) {
            for (np_c = 0; np_c < 8; np_c++) {
              np_t = Vec[np_v][np_i][np_c];

              switch (B[np_t]) {
                case
                    sEmp: { //move m = {np_i, np_t, sWbi, sWbi, '0'};
                    gl_move = (np_i | (np_t << 6) | (5 << 12) | (5 << 16));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sBpa: { //move m = {np_i, np_t, sWbi, sWbi, sBpa};
                    gl_move = (np_i | (np_t << 6) | (5 << 12) | (5 << 16) | (2 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sBro: { //move m = {np_i, np_t, sWbi, sWbi, sBro};
                    gl_move = (np_i | (np_t << 6) | (5 << 12) | (5 << 16) | (4 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sBbi: { //move m = {np_i, np_t, sWbi, sWbi, sBbi};
                    gl_move = (np_i | (np_t << 6) | (5 << 12) | (5 << 16) | (6 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sBkn: { //move m = {np_i, np_t, sWbi, sWbi, sBkn};
                    gl_move = (np_i | (np_t << 6) | (5 << 12) | (5 << 16) | (8 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sBqu: { //move m = {np_i, np_t, sWbi, sWbi, sBqu};
                    gl_move = (np_i | (np_t << 6) | (5 << 12) | (5 << 16) | (12 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                default
                    : {
                    np_c = 8;
                  };
              };
            };
          };
        };

        break;

        // analyse self knight
      case
          sWkn: {
          for (np_c = 0; np_c < 8; np_c++) {
            np_t = decreasingKnightMap[np_i][np_c];

            switch (B[np_t]) {
              case
                  sEmp: { //move m = {np_i, np_t, sWkn, sWkn, '0'};
                  gl_move = (np_i | (np_t << 6) | (7 << 12) | (7 << 16));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBpa: { //move m = {np_i, np_t, sWkn, sWkn, sBpa};
                  gl_move = (np_i | (np_t << 6) | (7 << 12) | (7 << 16) | (2 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBro: { //move m = {np_i, np_t, sWkn, sWkn, sBro};
                  gl_move = (np_i | (np_t << 6) | (7 << 12) | (7 << 16) | (4 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBbi: { //move m = {np_i, np_t, sWkn, sWkn, sBbi};
                  gl_move = (np_i | (np_t << 6) | (7 << 12) | (7 << 16) | (6 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBkn: { //move m = {np_i, np_t, sWkn, sWkn, sBkn};
                  gl_move = (np_i | (np_t << 6) | (7 << 12) | (7 << 16) | (8 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBqu: { //move m = {np_i, np_t, sWkn, sWkn, sBqu};
                  gl_move = (np_i | (np_t << 6) | (7 << 12) | (7 << 16) | (12 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };
                break;
              case
							  sOut: {break;}; break;
            };
          };
        };

        break;
      case
          sWki: {
          // if positive k-side castle status
          if (castle_dat != (castle_dat | castle_lost_WKK_mask)) {
            //if king not in check
            if (CheckStatus[ply - 1] == false) {
              //if empty two squares on the right side of the king
              if (B[61] == sEmp) {
                if (B[62] == sEmp) {
                  //if empty squares are not in check
                  if (isAttByBla(61) == false) {
                    if (isAttByBla(62) == false) {
                      //add k-side castle move
                      //move m = {60, 62, sWki, sWki, '0'}; and move m = {63, 61, sWro, sWro, '0'};
                      gl_move = (60 | (62 << 6) | (9 << 12) | (9 << 16));
                      CHILD(ply);
                      saveWhiPosition(np_offs);
                      np_offs++;
                      PARENT(ply);
                    };
                  };
                };
              };
            };
          };

          // if positive q-side castle status
          if (castle_dat != (castle_dat | castle_lost_WKQ_mask)) {
            //if king not in check
            if (CheckStatus[ply - 1] == false) {
              //if THREE empty squares on the left side of the king
              if (B[59] == sEmp) {
                if (B[58] == sEmp) {
                  if (B[57] == sEmp) {
                    //if TWO empty squares and king are not in check
                    if (isAttByBla(59) == false) {
                      if (isAttByBla(58) == false) {
                        gl_move = (60 | (58 << 6) | (9 << 12) | (9 << 16));
                        CHILD(ply);
                        saveWhiPosition(np_offs);
                        np_offs++;
                        PARENT(ply);
                      };
                    };
                  };
                };
              };
            };
          };

          //handle normal king moves
          for (np_v = 0; np_v < 8; np_v++) {
            np_t = Vec[np_v][np_i][0];

            switch (B[np_t]) {
              case
                  sEmp: { //move m = {np_i, np_t, sWki, sWki, '0'};
                  gl_move = (np_i | (np_t << 6) | (9 << 12) | (9 << 16));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBpa: { //move m = {np_i, np_t, sWki, sWki, sBpa};
                  gl_move = (np_i | (np_t << 6) | (9 << 12) | (9 << 16) | (2 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBro: { //move m = {np_i, np_t, sWki, sWki, sBro};
                  gl_move = (np_i | (np_t << 6) | (9 << 12) | (9 << 16) | (4 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBbi: { //move m = {np_i, np_t, sWki, sWki, sBbi};
                  gl_move = (np_i | (np_t << 6) | (9 << 12) | (9 << 16) | (6 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBkn: { //move m = {np_i, np_t, sWki, sWki, sBkn};
                  gl_move = (np_i | (np_t << 6) | (9 << 12) | (9 << 16) | (8 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBqu: { //move m = {np_i, np_t, sWki, sWki, sBqu};
                  gl_move = (np_i | (np_t << 6) | (9 << 12) | (9 << 16) | (12 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
            };
          };
        };

        break;
      case
          sWqu: {
          for (np_v = 0; np_v < 8; np_v++) {
            for (np_c = 0; np_c < 8; np_c++) {
              np_t = Vec[np_v][np_i][np_c];

              switch (B[np_t]) {
                case
                    sEmp: { //move m = {np_i, np_t, sWqu, sWqu, '0'};
                    gl_move = (np_i | (np_t << 6) | (11 << 12) | (11 << 16));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sBpa: { //move m = {np_i, np_t, sWqu, sWqu, sBpa};
                    gl_move = (np_i | (np_t << 6) | (11 << 12) | (11 << 16) | (2 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sBro: { //move m = {np_i, np_t, sWqu, sWqu, sBro};
                    gl_move = (np_i | (np_t << 6) | (11 << 12) | (11 << 16) | (4 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sBbi: { //move m = {np_i, np_t, sWqu, sWqu, sBbi};
                    gl_move = (np_i | (np_t << 6) | (11 << 12) | (11 << 16) | (6 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sBkn: { //move m = {np_i, np_t, sWqu, sWqu, sBkn};
                    gl_move = (np_i | (np_t << 6) | (11 << 12) | (11 << 16) | (8 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sBqu: { //move m = {np_i, np_t, sWqu, sWqu, sBqu};
                    gl_move = (np_i | (np_t << 6) | (11 << 12) | (11 << 16) | (12 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                default
                    : {
                    np_c = 8;
                  };
              };
            };
          };
        };

        break;
      default
          : {
          ;
        };
    };
  };

//if mate is found: dont save other moves to the tree:
//just one mating move.
//save full ply if this is first one to be able to mate in few ways
//this will reduce tree size in full search and in qs
//save sorted moves to the tree in the right order
  if ((grade[0] == MAX_SCORE) && (np_offs > 0) && (ply > 1)) {
    np_offs = 1;
    MOVES_TREE[(ply << 8) | 0] = mymove[0]; //assign matingmove to the TREE
    UnsPosTree[(ply << 8) | 0].lastMove = mymove[0];
    VALS_TREE[(ply << 8) | 0] = MAX_SCORE; //assign matescore to the TREE
    //cout<<"mating move: "<<printMove(mymove[0])<<endl; printB("MATE:");

		#ifdef DEBUG_VERSION
		fullply_branch_count++;
    mate_fullply_branch_count++;
    if (ply == qDepth) {
      terminal_fullply_branch_count++;
    };
		fullply_positions_count += np_offs;
		#endif

		return np_offs; //return offset==1 mating move

  };

//////////////////////////////////////////
  /*
  now capture moves are sorted only by winned material
  reorder captures also by attacking material if the same piece type is winned:
    if the same captured piece in move B and A
     loop: if (B from piece > A from piece) swap moves and continue swaps until noncap found.
     break if no swap found
  */
#ifdef ATTA_REORD
  if (np_offs > 1)
    //if at least two moves
  {
    goto AR_LOOP;
AR_LOOP: {
      np_i = 1; //take second move index

      while (np_i < np_offs)
        //until offset end
      {
        gl_cp = ((mymove[np_i] << 8) >> 28);    //take second move captured piece

        if (gl_cp != 0)
          //if capture
        {
          if (gl_cp == ((mymove[np_i - 1] << 8) >> 28)
             )
            //if the same captured piece type
          {
            ///if order of attackers to improve
            if ((UnsignedMaterialValue[((mymove[np_i] << 16) >> 28) ])
                <
                (UnsignedMaterialValue[((mymove[np_i - 1] << 16) >> 28) ])) {
              //swap moves and grades
              ar_move = mymove[np_i - 1];
              ar_grade = grade[np_i - 1];
              mymove[np_i - 1] = mymove[np_i];
              grade[np_i - 1] = grade[np_i];
              mymove[np_i] = ar_move;
              grade[np_i] = ar_grade;
              //repeat from beginning
              goto AR_LOOP;
            };
          };
        };

        np_i++;
      };
    };
  };

#endif

/*
#ifdef NULL_MOVE
//reorder null move to first position
  np_i = 0;

  while (np_i < np_offs) {
    if (mymove[np_i] == 1) {
      ar_move = mymove[np_i];
      ar_grade = grade[np_i];

      while (np_i > 0) {
        //just move it ahead and consider previous move
        mymove[np_i] = mymove[np_i - 1];
        grade[np_i] = grade[np_i - 1];
        np_i--;
      };

      mymove[np_i] = ar_move; //index zero

      grade[np_i] = ar_grade;

      break;
    };

    np_i++;
  };

#endif
*/

#ifdef THREAT_REORD
//////////////////////////////////////////
//do another sorting: search moves from the best to the weakest
//if piece threat in the ply is found:
//if the first move is null - continue
//if the move is check - continue
//reorder moves
//analyse only the curent moved piece and reveald pieces vectors
//if the move is direct or revealed attack - it is threat
//(1<<28) marked
#endif
#ifdef CHECK_REORD
//////////////////////////////////////////
//do another sorting: search moves from the best to the weakest
//if check in the ply is found:
//if the first move is null - continue
//if the move is check - continue
//reorder moves
  /*
  np_i = 0;
    cout<<"moves BEFORE check_reord: "<<flush;
  while (np_i<np_offs) {
   cout<<"["<<np_i<<"]:"<<printMove(mymove[np_i])<<" "<<flush;
    np_i++;
  };
    cout<<endl;
    */
//take second move if any
  np_i = 1;

  while (np_i < np_offs) {
    //if the move causes the black king is checked
    if (mymove[np_i] == (mymove[np_i] | (1 << 30))) {
      //save this move
      ar_move = mymove[np_i];
      ar_grade = grade[np_i];
      //move all moves before it
      //which are not null move nor check ahead one step
      np_j = np_i;

      //if we have no null move first in the ply
      if (mymove[0] != 1) {
        //if safe bound
        while (np_j > 0) {
          //if previous move is not check
          if (mymove[np_j - 1] != (mymove[np_j - 1] | (1 << 30))) {
            //just move it ahead and consider previous move
            mymove[np_j] = mymove[np_j - 1];
            grade[np_j] = grade[np_j - 1];
            np_j--;
          }
          //if previous move is check - break at curent index
          else {
            break;
          };
        };

        //move save ar_move and ar grade into curent index
        mymove[np_j] = ar_move;

        grade[np_j] = ar_grade;
      }
      //if we have null move first
      else {
        //if safe bound
        while (np_j > 1) {
          //if previous move is not check
          if (mymove[np_j - 1] != (mymove[np_j - 1] | (1 << 30))) {
            //just move it ahead and consider previous move
            mymove[np_j] = mymove[np_j - 1];
            grade[np_j] = grade[np_j - 1];
            np_j--;
          }
          //if previous move is check - break at curent index
          else {
            break;
          };
        };

        //move save ar_move and ar grade into curent index
        mymove[np_j] = ar_move;

        grade[np_j] = ar_grade;
      };
    };

    np_i++;
  };

//////////////////
  /*
    if (mymove[0]==1) {
    cout<<"moves AFTER reord, whi nm: "<<flush;
  np_i = 0;
    while (np_i<np_offs) {
     cout<<"["<<np_i<<"]:"<<printMove(mymove[np_i])<<" "<<flush;
      np_i++;
    };
    cout<<endl;
    };
    */
///////////////
#endif

  /*
  mark late moves in the ply by checking proper bit in proper moves
  */
/*
#ifdef LATE_MOVE

  //IF NODE IS NOT PV NODE
  //if proper max depth
  //if (ply+lmr_reduction<qDepth) {
  //if (ply+lmr_reduction<qDepth) {
  if (ply == 2) {
	  //if no lmr flag set (upper)
		if (lmr_already_used == false) {

      //if not escaping from check
      if (CheckStatus[ply - 1] == false) {
        //if no check in the path
        //if (first_check_depth==0) {
        //if proper min depth
        //if (ply>=lmr_min_ply) {
        //start from minimum lmr index
        np_i = lmr_min_idx;
        //save value of parent
        ar_grade = VALS_TREE[((ply - 1) << 8) | cur_offs[ply - 1]];

        //if null move at zero index
        //if (mymove[0] < 3) {
          //np_i++;

					// if parent move is not forcing move (marked by null move search)
					//if (MOVES_TREE[((ply - 1) << 8) | cur_offs[ply - 1]]
					//!= ((MOVES_TREE[((ply - 1) << 8) | cur_offs[ply - 1]]) | forced_pos_mask)) {

		        //clear lmr_real_offs
		        //lmr_real_offs = 0;
		    while (np_i < np_offs) {
		          //if static eval after move is worse than that of the parent
		          //or if static eval is little better than the parent (no capture, promotion, enpassant capture occurs)
		      if ((grade[np_i] - evLateMoveMargin) < ar_grade) {

								//if the move is noncapture
		            //if (((mymove[np_i]<<8)>>28)==0) {
		            //if the move generated positive forced_pos
		            //if (mymove[np_i] == (mymove[np_i]|forced_pos_mask)) {
		            //if bki_checked_mask is clear
		        if (mymove[np_i] != (mymove[np_i] | (1 << 30))) {
		              //(mymove[np_i] != (mymove[np_i]|(1<<31)))) {
		              //if the move is not promotion and not enpassant move (static eval difference is minimum about one pawn)
		              //if the move is not pawn promotion threat
		              //lmr_real_offs++;
		              //if (lmr_real_offs<3) {continue;};
		              //set lmr move flag
		          mymove[np_i] |= (1 << 29);
		              //cout<<"lmr offset:"<<np_i<<", move:"<<printMove(mymove[np_i])<<endl;
		        };

		            //};
		      };

		      np_i++;


        };
      };
    };
  };

#endif
*/
  /*
  //////////////////////////////
  cout<<"Whi late moves report (ply:"<<ply<<", qDepth:"<<qDepth<<"):"<<endl;
  np_i = 0;
  while (np_i<np_offs) {
   if (mymove[np_i]==(mymove[np_i] | (1<<29))) {
     cout<<"["<<np_i<<"]"<<printMove(mymove[np_i])<<"-late "<<flush;
   }
   else {
    cout<<"["<<np_i<<"]"<<printMove(mymove[np_i])<<"-norm "<<flush;
    };
   np_i++;
  };
  cout<<endl;
  /////////////////////////////
  */
 //save sorted and marked data into the tree
 finishSavePositionInNewPly();

#ifdef CUTTOFF_MOVE_HASH_REORDER

////////////////////////////////////////////////////////////////////
//reorder the cuttoff move if found in the beginning of the ply
//if Zkey matches and there is available the best move which produced a cuttoff
//HT==
//[Zkey(64bits)]
//[score(20bits)-val(20bits)-ply(6bits)-qDepth(6bits)-BestMovetofrom(12bits)]
  if (ply > 1) {
    Hkey = (Zkey >> (Zkeylen - Hkeylen));

    if (HT[Hkey][0] == Zkey) {
      if (((HT[Hkey][1] << 52) >> 52)
          != 0)
        //if best move available
      {
        //find the best move index
        np_i = 0;

        while (np_i < np_offs) {
          //if the move coords matches insort it into the beginning of the ply
          if (((MOVES_TREE[np_c | np_i] << 20) >> 20)
              == ((HT[Hkey][1] << 52) >> 52)) {
            //cout<<"best move:"<<printMove(MOVES_TREE[np_c|np_i])<<
            //"at idx:"<<np_i<<endl;
            //copy the value of found move
            se_v = VALS_TREE[np_c | np_i];

            //copy all moves and values one move forward to the found move pos
            for (se_j = np_i; se_j > 0; se_j--) {
              MOVES_TREE[np_c | se_j] = MOVES_TREE[np_c | (se_j - 1) ];
              VALS_TREE[np_c | se_j] = VALS_TREE[np_c | (se_j - 1) ];
            };

            //paste found move and its value in the first move pos
            MOVES_TREE[np_c | 0] = MOVES_TREE[np_c | np_i];

            VALS_TREE[np_c | 0] = se_v;

            break;
          };

          np_i++;
        };
      };
    };
  };

#endif

#ifdef DEBUG_VERSION
	fullply_branch_count++;
  if (ply == qDepth) {
    terminal_fullply_branch_count++;
  };
	fullply_positions_count += np_offs;
	if (np_offs==0) {empty_fullply_branch_count++;};
#endif

  return np_offs;
};

