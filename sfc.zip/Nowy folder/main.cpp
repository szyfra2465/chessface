#include <iostream>
#include <sstream>
#include <fstream>
#include <iomanip>
#include <cstdlib>
#ifndef EXTERN_DECLARATIONS_INCL
				#define EXTERN_DECLARATIONS_INCL
				#include "ExternDeclarations.hpp"
#endif

using namespace std;


/*
my fresh ideas:
1) handle advanced UTILITY_PRUNNING:
we decide which position to skip in down proc and jump to quiescence search
We try to indentify positions which are not likely to improve pv score.
-in qDepth-1 nodes (advanced futility)
-in qDepth-2 nodes (advanced razoring)
To make this decision we may compare and investigate parameters along the search path.
We must work out the above parameters
- tendency of opponent king safety
- tendency of self king safety
- tendency of opponent center control
- tendency of self center control
- tendency of opponent material
- tendency of self material
- tendency of opponent space control
- tendency of self space control
- overal tendency of opponent nonmaterial score
- overal tendency of opponent nonmaterial score
- search score of the node
- oppenness of the position (the more open and dynamic poosition the more
probable score change)


	we are not searching positions deeper if
	during search we are losing material and position and king safety
	we are searching position if to_opponent king tropism scores are improving
	and opponent king safety scores are lowering

	*Be careful to make quiesence search independent of qDepth .
	 Wrong code will make search returning to normal from qs to fast.
	*

2) second good idea:
Improve killer moves by not putting captures there.
Only silent moves that cause a cuttoff here, because putting captures here
doesnt improve anything because they are searched in the beginnig anyway.
killer moves may not be effective strategy if move ordering is close to perfect.
This quarantees that cuttoff may be found faster.
Alternatively it is good idea to put here move which is escape from capture.
Such moves may not look strong positionally but they are good because they
prevent material loss , so they should be analysed faster.


*/




//#define DEBUG_VERSION //errorprone!

//dont show variations deeper than qdepth in release version
#ifndef DEBUG_VERSION
  #define TRIM_PV
#endif

#if defined __ANDROID__
	#define __int64 long long
#endif

//////////////////////////////////////////////////////////////////////////////////////////


#define HASH_EVAL_FUNC //speedup

//#define REUSE_EVAL //very little speedup by now: todo:
  //this code works better in restply than qsply. we gain little speed in restply and some new information (SC[table], occupied squares)
	//common table of precalc values for qsply and restply - rather not necessary (seldom conversions from qsply to restply)
	//empty ply prediction to prevent generating full eval precalc - something like this was introduced by restricting of reuse code in qply depending of depth
	//-this code seem to be inefficient below qDepth because a lot of empty or small plies here
	//measure and eventually prevent influencing lazy eval code on reuse eval - no influence
	//measure and eventually prevent influencing hash code on reuse eval - imho prevention impossible without performance loss
	//-hashing little lowers reuse eval performance, generally hashing is more efficient that reusing eval
	//-both codes do work together with best result.
	//eventually add vector check if usesVec returns true for sliding pieces - be careful of pins and threats
  //try to use vector code in is_attacked check or mate detection
  //move poor captures to the end of restply


//#define DEBUG_EVAL

//#define EXTEND_ONLY_MOVE //finds mates faster

//idea in qs:
//if the parent move is check - respond with full ply.
//allow checks without capture till qDepth+6
//and only if all previous moves in qs are checks
//#define EXTEND_CHECK

//#define EXTEND_PAWN_PROMOTION_THREAT

//ENCODE_CHECKS //not implemented/problem with ht/ - high check eval term used instead

//#define LAZY_EVAL


//PARTIAL_PLY: instead of full ply generation only q ply is created
//if max offset of this ply is reached in search and we had no cuttoff - the rest of ply is generated
//in place of qply in normal qDepth
//in this method we gain time because no need to create full ply if we "guess" cuttoff move earlier
//but if no cuttoff occurs  -we need to generate q ply + rest ply and that means some additional overhead:
//Movegen decides which captures are bad trades in rest_ply to omit dupilicate moves in qply and restply.
//Generally speeds up search about one ply and gives additional info about bad trades!

#define PARTIAL_PLY


//#define CHECK_REORD
//#define WEAK_PATH_PRUNNING

//#define SELECTIVE_SEARCH

//#define MAT_POS_PRUNNING
//#define FUTIL_QS_PRUNNING

//code spoiled when using attacks map!
//#define ATTACKS_MAP


//#define ATTA_REORD //little slowdown

//define PRIORITY_REORD
//moves are searched depending on priority of different situations.
//in each position only the highest priprity is taken into account

/*
-mating move
-null move
-good check
-unprotected piece capture
-stronger protected piece capture
-even protected piece capture
-weaker protected piece capture
-attack to unprotected piece
-attack to protected piece which cannot kill attacker
-attack to protected piece which can kill attacker
-move relating to attack map....

*/

//#define SEARCH_REORD

//#define STATIC_POS_PRUNNING

/*
late move reductions
//find out if nodes of poor offset occur often in search
*/

//reduces the depth of restply moves
//#define LATE_MOVE



//#define NULL_MOVE

//null move can be used to detect positions with direct threat
//if we make null move and opponent wins the piece - opponent has threat - we have to do a forced move
//if opponent gives a mate we are also forced
//forced moves should be reserched one ply deeper
//if we make null move and we still generate cuttoff by parent move - we are very strong.
//it means if we would make any other move - cuttoff would have also occured
//it is worth to search only strong (materially?) positions not to waste time for researches


/*
add qs null move to qs ply - it will symbolize weak or average move noncapture
if null move made in qs - go to up proc
if such a move produced a cuttoff we assume that best move from the ply would produce the cuttoff
pretty sure this move would produce a cuttoff if the path would be continued - this occured not effective
because to little positions in qs - usually one move
*/

//measure average number of children in normal search and qs visited before cuttoff

/////////////////////////////////////////////////////////////
////#define OFFSET_PRUNNING

//////////////////////////////////////////

//#define QS_CHECKS //checks in QS. finds some more checks and improves NPS but generally slows down main search about one ply
//#define TOTAL_QS_LIMIT //QS must be sometimes limited if checks and check evasion moves in QS (tree explosion)


//#define QS_MATES //finds all mating moves in QS. the good idea is to precompute the 64-element
//table containing the coordinates of possible attackers of opponent king before we analyse each move
//we use this vectors to discover checks/ speedup mate detection


//#define QS_CHECK_EVASION_EXT //should work well with QS_CHECKS, must be hardly restricted in all cases
//const unsigned int QS_EVASIONS_DEPTH = 1;

//const unsigned int QS_CHECKS_MAX_DEPTH = 99;


///////////////////////////
//#define PRUNE_STATIC_TREE

/////////////////////////////////////////////////


//#define S_E_E //little slowdown, code running well spoiled?

////////////////
//#define HASH_TRANSP_CUTTOFF //slowdown (tested at various depths)
//#define CUTTOFF_MOVE_HASH_REORDER //slowdown
//#define KILLERS //no improvement, unstable performance, killer is only noncapture

//after doing partial ply checkup, try killer move
//#define NEW_KILLERS

//#define LOST_POS_CUTTOFFS_TYPE1 //detects path giving material and positional disproportions, little speedup

//#define LVAMVV_ORDERING //slowdown


//#ifdef QS_CHECKS
//static bool checksearch;
//#endif

// function declarations and definitions /////////////////////////////////////////////////////




////////////////////////////////////////////////////////////////
// access ply to save moves properly in the tree
// get ALL legal moves which are not in qs
int REST_WHI_PLY(int ply)
{
//set side to properly eval
  side = false;

//set initial data tables of this ply before CHILD() action
  enpassant = enp_sq[ply - 1];

  castle_dat = castle_data[ply - 1];

  Zkey = Zkey_tab[ply - 1];

  retract = retract_tab[ply - 1];

	shifted_np_ply = (ply<<8); //static used in saving position data

//loop board
  np_offs = 0;

/*
#ifdef NULL_MOVE
//insert null-move into the ply if allowed -
//the move would not be insorted after mating move
//(mate is always first and only move in the ply)
//move will not be later saved if mate was found (restricted offset)
//or if not position under check (this would lead to illegal position)

//IF NODE IS NOT PV NODE
//if no null move set upper
  //if (nms_set[ply - 1] == false) {
  if (MOVES_TREE[((ply - 1) << 8) | cur_offs[ply - 1]] != 2) {
	  //if proper max ply
    //if (ply<qDepth-nms_reduction) {
    if (ply < qDepth) {
      //if (MOVES_TREE[((ply-1)<<8)|cur_offs[ply-1]]>2) {
      //if self move not in check
      if (CheckStatus[ply - 1] == false) {
        //if no check in the path
        //if (first_check_depth==0) {
        //if enough self material /little chance for zugzwang
        if ((WquNum > 0) || (WroNum > 0)) {
          //if proper min ply
          if (ply >= nms_min_ply) {
            //suitable move for white
            gl_move = 1;
            CHILD(ply);
            //if (isAttByBla(WkiPos)==false) {saveWhiPosition(np_offs); np_offs++;};
            saveWhiPosition(np_offs);
            np_offs++;
            PARENT(ply);
          };
        };
      };
    };
  };

#endif
*/


#ifdef REUSE_EVAL
  //whole preeval table must be generated before the ply,
  //because in each child position we analyse whole board
  for (ev_fs = 0; ev_fs < 64; ev_fs++) {
		EV_SQUARE();
    SC[ev_fs] = ev_score;
  };
  do_reuse_eval = true;
#endif

	for (np_i = 0; np_i < 64; np_i++) {

		switch (B[np_i]) {
      case
          sWpa: {
          if (np_i > 47)
            //handle nonpromotion move
          {
          	/*
            np_t = LWPCaps[np_i];

            switch (B[np_t]) {
              case
                  sBpa: { //analyse {np_i,np_t,sWpa,sWpa,sBpa};
                  gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (2 << 20));
                  //est_move = PawnPawnCap;
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBro: { //analyse {np_i, np_t, sWpa, sWpa, sBro};
                  gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (4 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBbi: { //analyse {np_i, np_t, sWpa, sWpa, sBbi};
                  gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (6 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBkn: { //analyse {np_i, np_t, sWpa, sWpa, sBkn};
                  gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (8 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBqu: { //analyse {np_i, np_t, sWpa, sWpa, sBqu};
                  gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (12 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
            };

            np_t = RWPCaps[np_i];

            switch (B[np_t]) {
              case
                  sBpa: { //analyse {np_i, np_t, sWpa, sWpa, sBpa};
                  gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (2 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBro: { //analyse {np_i, np_t, sWpa, sWpa, sBro};
                  gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (4 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBbi: { //analyse {np_i, np_t, sWpa, sWpa, sBbi};
                  gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (6 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBkn: { //analyse {np_i, np_t, sWpa, sWpa, sBkn};
                  gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (8 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBqu: { //analyse {np_i, np_t, sWpa, sWpa, sBqu};
                  gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (12 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
            };
            */


            /////////

            // check if white pawn can move ONE SQUARE AHEAD
            // (eventual mating move must have been added and executed in qs_ply)

            np_t = np_i - 8;

            if (B[np_t] == sEmp)
              // {np_i, np_i-8, sWpa, sWpa, '0'};
            {
              gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16));
              CHILD(ply);

              if (isAttByBla(WkiPos) == false) {
                saveWhiPosition(np_offs);
                np_offs++;
              };

              PARENT(ply);

              // now check if pawn can move TWO SQUARES AHEAD
              np_t -= 8;

              if (B[np_t] == sEmp)
                // {np_i, np_i-16, sWpa, sWpa, '0'};
              {
                gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16));
                CHILD(ply);

                if (isAttByBla(WkiPos) == false) {
                  saveWhiPosition(np_offs);
                  np_offs++;
                };

                PARENT(ply);
              };
            };

            ////////

          }
          // IF PAWN IS IN THE MIDDLEBOARD
          else
            if (np_i > 15) {
              /*
							np_t = LWPCaps[np_i];

              switch (B[np_t]) {

								case
                    sEmp: {

										//analyse enpassant capture

										if ((enpassant == np_t) && (np_t != 64)) {
                      //analyse {np_i, np_t, sWpa, sBpa};
                      gl_move = (np_i | (np_t << 6) | (1 << 12) | (2 << 16));
                      CHILD(ply);

                      if (isAttByBla(WkiPos) == false) {
                        saveWhiPosition(np_offs);
                        np_offs++;
                      };

                      PARENT(ply);

										};
                  };

                  break;
                case
                    sBpa: { //analyse {np_i, np_t, sWpa, sWpa, sBpa};
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (2 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sBro: { //analyse {np_i, np_t, sWpa, sWpa, sBro};
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (4 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sBbi: { //analyse {np_i, np_t, sWpa, sWpa, sBbi};
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (6 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sBkn: { //analyse {np_i, np_t, sWpa, sWpa, sBkn};
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (8 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sBqu: { //analyse {np_i, np_t, sWpa, sWpa, sBqu};
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (12 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
              };

              np_t = RWPCaps[np_i];

              switch (B[np_t]) {
                case
                  sEmp: { //analyse enpassant capture
                    if ((enpassant == np_t) && (np_t != 64)) {
                      //{np_i, np_t, sWpa, sBpa};
                      gl_move = (np_i | (np_t << 6) | (1 << 12) | (2 << 16));
                      CHILD(ply);

                      if (isAttByBla(WkiPos) == false) {
                        saveWhiPosition(np_offs);
                        np_offs++;
                      };

                      PARENT(ply);
                    };
                  };

                  break;
                case
                    sBpa: { //analyse {np_i,np_t,sWpa,sWpa,sBpa};
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (2 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sBro: { //analyse {np_i, np_t, sWpa, sWpa, sBro};
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (4 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sBbi: { //analyse {np_i, np_t, sWpa, sWpa, sBbi};
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (6 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sBkn: { //analyse {np_i, np_t, sWpa, sWpa, sBkn};
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (8 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sBqu: { //analyse {np_i, np_t, sWpa, sWpa, sBqu};
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (12 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
              };
              */

              // check if white pawn can move ONE SQUARE AHEAD
              np_t = np_i - 8;

              if (B[np_t] == sEmp)
                //{np_i, np_i-8, sWpa, sWpa, '0'};
              {
                gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16));
                CHILD(ply);

                if (isAttByBla(WkiPos) == false) {
                  saveWhiPosition(np_offs);
                  np_offs++;
                };

                PARENT(ply);
              };
            }
          // ELSE IF PAWN IS IN THE SEVENTH ROW
          // handle PROMOTION if PAWN CAN MOVE AHEAD
            else {

              np_t = np_i - 8;
              np_allow = false;

              if (B[np_t] == sEmp) {
                /*
								gl_move = (np_i | (np_t << 6) | (1 << 12) | (11 << 16));
                CHILD(ply);

                if (isAttByBla(WkiPos) == false) {
                  np_allow = true;
                  saveWhiPosition(np_offs);
                  np_offs++;
                }

                PARENT(ply);
                */
                gl_move = (np_i | (np_t << 6) | (1 << 12) | (3 << 16));
                CHILD(ply);

                if (isAttByBla(WkiPos) == false) {
                  np_allow = true;
                  saveWhiPosition(np_offs);
                  np_offs++;
                };

                PARENT(ply);

                gl_move = (np_i | (np_t << 6) | (1 << 12) | (5 << 16));

                CHILD(ply);

                if (np_allow == true) {
                  saveWhiPosition(np_offs);
                  np_offs++;
                };

                PARENT(ply);

                gl_move = (np_i | (np_t << 6) | (1 << 12) | (7 << 16));

                CHILD(ply);

                if (np_allow == true) {
                  saveWhiPosition(np_offs);
                  np_offs++;
                };

                PARENT(ply);
              };

              // handle PROMOTION if PAWN CAPTURED
              np_t = LWPCaps[np_i];


              switch (B[np_t]) {
                  // if opponent rook is captured - memorize the possible promotions
                case
                    sBro: {
                    /*
										np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (11 << 16) | (4 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      np_allow = true;
                      saveWhiPosition(np_offs);
                      np_offs++;
                    }

                    PARENT(ply);
                    */
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (3 << 16) | (4 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      np_allow = true;
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (5 << 16) | (4 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (7 << 16) | (4 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;

                  // if opponent bishop is captured - memorize the possible promotions
                case
                    sBbi: {
                    np_allow = false;
                    /*
										gl_move = (np_i | (np_t << 6) | (1 << 12) | (11 << 16) | (6 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      np_allow = true;
                      saveWhiPosition(np_offs);
                      np_offs++;
                    }

                    PARENT(ply);
                    */
										gl_move = (np_i | (np_t << 6) | (1 << 12) | (3 << 16) | (6 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      np_allow = true;
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (5 << 16) | (6 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (7 << 16) | (6 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;

                  // if opponent knight is captured - memorize the possible promotions
                case
                    sBkn: {
                    np_allow = false;
                    /*
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (11 << 16) | (8 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      np_allow = true;
                      saveWhiPosition(np_offs);
                      np_offs++;
                    }

                    PARENT(ply);
                    */
										gl_move = (np_i | (np_t << 6) | (1 << 12) | (3 << 16) | (8 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      np_allow = true;
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (5 << 16) | (8 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (7 << 16) | (8 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;

                  // if opponent queen is captured - memorize the move
                case
                    sBqu: {
                    np_allow = false;
                    /*
										gl_move = (np_i | (np_t << 6) | (1 << 12) | (11 << 16) | (12 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      np_allow = true;
                      saveWhiPosition(np_offs);
                      np_offs++;
                    }

                    PARENT(ply);
                    */
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (3 << 16) | (12 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      np_allow = true;
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (5 << 16) | (12 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (7 << 16) | (12 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
              };



              np_t = RWPCaps[np_i];

              switch (B[np_t]) {
                  // if opponent rook is captured - memorize the possible promotions
                case
                    sBro: {
                    /*
										np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (11 << 16) | (4 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      np_allow = true;
                      saveWhiPosition(np_offs);
                      np_offs++;
                    }

                    PARENT(ply);
                    */
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (3 << 16) | (4 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      np_allow = true;
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (5 << 16) | (4 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (7 << 16) | (4 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;

                  // if opponent bishop is captured - memorize the possible promotions
                case
                    sBbi: {
                    np_allow = false;
                    /*
										gl_move = (np_i | (np_t << 6) | (1 << 12) | (11 << 16) | (6 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      np_allow = true;
                      saveWhiPosition(np_offs);
                      np_offs++;
                    }

                    PARENT(ply);
                    */
										gl_move = (np_i | (np_t << 6) | (1 << 12) | (3 << 16) | (6 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      np_allow = true;
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (5 << 16) | (6 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (7 << 16) | (6 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;

                  // if opponent knight is captured - memorize the possible promotions
                case
                    sBkn: {
                    np_allow = false;
                    /*
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (11 << 16) | (8 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      np_allow = true;
                      saveWhiPosition(np_offs);
                      np_offs++;
                    }

                    PARENT(ply);
                    */
										gl_move = (np_i | (np_t << 6) | (1 << 12) | (3 << 16) | (8 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      np_allow = true;
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (5 << 16) | (8 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (7 << 16) | (8 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;

                  // if opponent queen is captured - memorize the move
                case
                    sBqu: {
                    np_allow = false;
                    /*
										gl_move = (np_i | (np_t << 6) | (1 << 12) | (11 << 16) | (12 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      np_allow = true;
                      saveWhiPosition(np_offs);
                      np_offs++;
                    }

                    PARENT(ply);
                    */
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (3 << 16) | (12 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      np_allow = true;
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (5 << 16) | (12 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (7 << 16) | (12 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
               };
            };
        };

        break;
      case
          sWro: {
          for (np_v = 4; np_v < 8; np_v++) {
            for (np_c = 0; np_c < 8; np_c++) {
              np_t = Vec[np_v][np_i][np_c];

              switch (B[np_t]) {
                case
                    sEmp: { //move m = {np_i, np_t, sWro, sWro, '0'};
                    gl_move = (np_i | (np_t << 6) | (3 << 12) | (3 << 16));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sBpa: { //move m = {np_i, np_t, sWro, sWro, sBpa};
                    gl_move = (np_i | (np_t << 6) | (3 << 12) | (3 << 16) | (2 << 20));
                    CHILD(ply);

                    if (isAttByBla(np_t) == true) { //bad trade capture
										  if (isAttByBla(WkiPos) == false) {
                        saveWhiPosition(np_offs);
                        np_offs++;
                      };
                    };

                    PARENT(ply);
                    np_c = 8;
                  };

                  break;
                case
                    sBro: { //move m = {np_i, np_t, sWro, sWro, sBro};
                    /*
										gl_move = (np_i | (np_t << 6) | (3 << 12) | (3 << 16) | (4 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                    */

                    np_c = 8;
                  };

                  break;
                case
                    sBbi: { //move m = {np_i, np_t, sWro, sWro, sBbi};
                    gl_move = (np_i | (np_t << 6) | (3 << 12) | (3 << 16) | (6 << 20));
                    CHILD(ply);

										if (isAttByBla(np_t) == true) { //bad trade capture
                      if (isAttByBla(WkiPos) == false) {
                        saveWhiPosition(np_offs);
                        np_offs++;
                      };
                    };

                    PARENT(ply);
                    np_c = 8;
                  };

                  break;
                case
                    sBkn: { //move m = {np_i, np_t, sWro, sWro, sBkn};
                    gl_move = (np_i | (np_t << 6) | (3 << 12) | (3 << 16) | (8 << 20));
                    CHILD(ply);

										if (isAttByBla(np_t) == true) { //bad trade capture
                      if (isAttByBla(WkiPos) == false) {
                        saveWhiPosition(np_offs);
                        np_offs++;
                      };
										};

                    PARENT(ply);
                    np_c = 8;
                  };

                  break;
                case
                    sBqu: { //move m = {np_i, np_t, sWro, sWro, sBqu};
                    /*
										gl_move = (np_i | (np_t << 6) | (3 << 12) | (3 << 16) | (12 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
										*/
                    np_c = 8;
                  };

                  break;
                default
                    : {
                    np_c = 8;
                  };//handle out of board vector
              };
            };
          };
        };

        break;

      case
          sWbi: {
          for (np_v = 0; np_v < 4; np_v++) {
            for (np_c = 0; np_c < 8; np_c++) {
              np_t = Vec[np_v][np_i][np_c];

              switch (B[np_t]) {
                case
                    sEmp: { //move m = {np_i, np_t, sWbi, sWbi, '0'};
                    gl_move = (np_i | (np_t << 6) | (5 << 12) | (5 << 16));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sBpa: { //move m = {np_i, np_t, sWbi, sWbi, sBpa};
                    gl_move = (np_i | (np_t << 6) | (5 << 12) | (5 << 16) | (2 << 20));
                    CHILD(ply);

										if (isAttByBla(np_t) == true) { //bad trade capture
                      if (isAttByBla(WkiPos) == false) {
                        saveWhiPosition(np_offs);
                        np_offs++;
                      };
									  };
                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sBro: { //move m = {np_i, np_t, sWbi, sWbi, sBro};
                    /*
										gl_move = (np_i | (np_t << 6) | (5 << 12) | (5 << 16) | (4 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
										*/
                    np_c = 8;
                  };

                  break;
                case
                    sBbi: { //move m = {np_i, np_t, sWbi, sWbi, sBbi};
                    /*
										gl_move = (np_i | (np_t << 6) | (5 << 12) | (5 << 16) | (6 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
										*/
                    np_c = 8;
                  };

                  break;
                case
                    sBkn: { //move m = {np_i, np_t, sWbi, sWbi, sBkn};
                    /*
										gl_move = (np_i | (np_t << 6) | (5 << 12) | (5 << 16) | (8 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
										*/
                    np_c = 8;
                  };

                  break;
                case
                    sBqu: { //move m = {np_i, np_t, sWbi, sWbi, sBqu};
                    /*
										gl_move = (np_i | (np_t << 6) | (5 << 12) | (5 << 16) | (12 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
										*/
                    np_c = 8;
                  };

                  break;
                default
                    : {
                    np_c = 8;
                  };
              };
            };
          };
        };

        break;

        // analyse self knight
      case
          sWkn: {
          for (np_c = 0; np_c < 8; np_c++) {
            np_t = decreasingKnightMap[np_i][np_c];

            switch (B[np_t]) {
              case
                  sEmp: { //move m = {np_i, np_t, sWkn, sWkn, '0'};
                  gl_move = (np_i | (np_t << 6) | (7 << 12) | (7 << 16));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBpa: { //move m = {np_i, np_t, sWkn, sWkn, sBpa};
                  gl_move = (np_i | (np_t << 6) | (7 << 12) | (7 << 16) | (2 << 20));
                  CHILD(ply);
									if (isAttByBla(np_t) == true) { //bad trade capture
                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };
								  };
                  PARENT(ply);
                };

                break;
              case
                  sBro: { //move m = {np_i, np_t, sWkn, sWkn, sBro};
                  /*
									gl_move = (np_i | (np_t << 6) | (7 << 12) | (7 << 16) | (4 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                  */
                };

                break;
              case
                  sBbi: { //move m = {np_i, np_t, sWkn, sWkn, sBbi};
                  /*
									gl_move = (np_i | (np_t << 6) | (7 << 12) | (7 << 16) | (6 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                  */
                };

                break;
              case
                  sBkn: { //move m = {np_i, np_t, sWkn, sWkn, sBkn};
                  /*
									gl_move = (np_i | (np_t << 6) | (7 << 12) | (7 << 16) | (8 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                  */
                };

                break;
              case
                  sBqu: { //move m = {np_i, np_t, sWkn, sWkn, sBqu};
                  /*
									gl_move = (np_i | (np_t << 6) | (7 << 12) | (7 << 16) | (12 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                  */
                };

                break;
                case
							  sOut: {break;}; break;
            };
          };
        };

        break;
      case
          sWki: {
          // if positive k-side castle status
          if (castle_dat != (castle_dat | castle_lost_WKK_mask)) {
            //if king not in check
            if (CheckStatus[ply - 1] == false) {
              //if empty two squares on the right side of the king
              if (B[61] == sEmp) {
                if (B[62] == sEmp) {
                  //if empty squares are not in check
                  if (isAttByBla(61) == false) {
                    if (isAttByBla(62) == false) {
                      //add k-side castle move
                      //move m = {60, 62, sWki, sWki, '0'}; and move m = {63, 61, sWro, sWro, '0'};
                      gl_move = (60 | (62 << 6) | (9 << 12) | (9 << 16));
                      CHILD(ply);
                      saveWhiPosition(np_offs);
                      np_offs++;
                      PARENT(ply);
                    };
                  };
                };
              };
            };
          };

          // if positive q-side castle status
          if (castle_dat != (castle_dat | castle_lost_WKQ_mask)) {
            //if king not in check
            if (CheckStatus[ply - 1] == false) {
              //if THREE empty squares on the left side of the king
              if (B[59] == sEmp) {
                if (B[58] == sEmp) {
                  if (B[57] == sEmp) {
                    //if TWO empty squares and king are not in check
                    if (isAttByBla(59) == false) {
                      if (isAttByBla(58) == false) {
                        gl_move = (60 | (58 << 6) | (9 << 12) | (9 << 16));
                        CHILD(ply);
                        saveWhiPosition(np_offs);
                        np_offs++;
                        PARENT(ply);
                      };
                    };
                  };
                };
              };
            };
          };

          //handle normal king moves
          for (np_v = 0; np_v < 8; np_v++) {
            np_t = Vec[np_v][np_i][0];

            switch (B[np_t]) {
              case
                  sEmp: { //move m = {np_i, np_t, sWki, sWki, '0'};
                  gl_move = (np_i | (np_t << 6) | (9 << 12) | (9 << 16));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBpa: { //move m = {np_i, np_t, sWki, sWki, sBpa};
                  /*
									gl_move = (np_i | (np_t << 6) | (9 << 12) | (9 << 16) | (2 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                  */
                };

                break;
              case
                  sBro: { //move m = {np_i, np_t, sWki, sWki, sBro};
                  /*
									gl_move = (np_i | (np_t << 6) | (9 << 12) | (9 << 16) | (4 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                  */
								};

                break;
              case
                  sBbi: { //move m = {np_i, np_t, sWki, sWki, sBbi};
                  /*
									gl_move = (np_i | (np_t << 6) | (9 << 12) | (9 << 16) | (6 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                  */
                };

                break;
              case
                  sBkn: { //move m = {np_i, np_t, sWki, sWki, sBkn};
                  /*
									gl_move = (np_i | (np_t << 6) | (9 << 12) | (9 << 16) | (8 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                  */
                };

                break;
              case
                  sBqu: { //move m = {np_i, np_t, sWki, sWki, sBqu};
                  /*
									gl_move = (np_i | (np_t << 6) | (9 << 12) | (9 << 16) | (12 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                  */
                };

                break;
            };
          };
        };

        break;
      case
          sWqu: {
          for (np_v = 0; np_v < 8; np_v++) {
            for (np_c = 0; np_c < 8; np_c++) {
              np_t = Vec[np_v][np_i][np_c];

              switch (B[np_t]) {
                case
                    sEmp: { //move m = {np_i, np_t, sWqu, sWqu, '0'};
                    gl_move = (np_i | (np_t << 6) | (11 << 12) | (11 << 16));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sBpa: { //move m = {np_i, np_t, sWqu, sWqu, sBpa};
                    gl_move = (np_i | (np_t << 6) | (11 << 12) | (11 << 16) | (2 << 20));
                    CHILD(ply);

										if (isAttByBla(np_t) == true) { //bad trade capture
                      if (isAttByBla(WkiPos) == false) {
                        saveWhiPosition(np_offs);
                        np_offs++;
                      };
									  };

										PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sBro: { //move m = {np_i, np_t, sWqu, sWqu, sBro};
                    gl_move = (np_i | (np_t << 6) | (11 << 12) | (11 << 16) | (4 << 20));
                    CHILD(ply);
										if (isAttByBla(np_t) == true) { //bad trade capture
                      if (isAttByBla(WkiPos) == false) {
                        saveWhiPosition(np_offs);
                        np_offs++;
                      };
									  };
                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sBbi: { //move m = {np_i, np_t, sWqu, sWqu, sBbi};
                    gl_move = (np_i | (np_t << 6) | (11 << 12) | (11 << 16) | (6 << 20));
                    CHILD(ply);
										if (isAttByBla(np_t) == true) { //bad trade capture
                      if (isAttByBla(WkiPos) == false) {
                        saveWhiPosition(np_offs);
                        np_offs++;
                      };
									  };
                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sBkn: { //move m = {np_i, np_t, sWqu, sWqu, sBkn};
                    gl_move = (np_i | (np_t << 6) | (11 << 12) | (11 << 16) | (8 << 20));
                    CHILD(ply);
										if (isAttByBla(np_t) == true) { //bad trade capture
                      if (isAttByBla(WkiPos) == false) {
                        saveWhiPosition(np_offs);
                        np_offs++;
                      };
									  };
                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sBqu: { //move m = {np_i, np_t, sWqu, sWqu, sBqu};
                    /*
										gl_move = (np_i | (np_t << 6) | (11 << 12) | (11 << 16) | (12 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
										*/
                    np_c = 8;
                  };

                  break;
                default
                    : {
                    np_c = 8;
                  };
              };
            };
          };
        };

        break;
      default
          : {
          ;
        };
    };
  };

#ifdef REUSE_EVAL
  do_reuse_eval = false;
#endif
/*
//if mate is found: dont save other moves to the tree:
//just one mating move.
//save full ply if this is first one to be able to mate in few ways
//this will reduce tree size in full search and in qs
//save sorted moves to the tree in the right order
  if ((grade[0] == MAX_SCORE) && (np_offs > 0) && (ply > 1)) {
    np_offs = 1;
    MOVES_TREE[(ply << 8) | 0] = mymove[0]; //assign matingmove to the TREE
    VALS_TREE[(ply << 8) | 0] = MAX_SCORE; //assign matescore to the TREE
    //cout<<"mating move: "<<printMove(mymove[0])<<endl; printB("MATE:");

		nonqs_positions_count += np_offs;
		return np_offs; //return offset==1 mating move

  };
*/
//////////////////////////////////////////
  /*
  now capture moves are sorted only by winned material
  reorder captures also by attacking material if the same piece type is winned:
    if the same captured piece in move B and A
     loop: if (B from piece > A from piece) swap moves and continue swaps until noncap found.
     break if no swap found
  */

/*
//inefficient in restply?
#ifdef ATTA_REORD
  if (np_offs > 1)
    //if at least two moves
  {
    goto AR_LOOP;
AR_LOOP: {
      np_i = 1; //take second move index

      while (np_i < np_offs)
        //until offset end
      {
        gl_cp = ((mymove[np_i] << 8) >> 28);    //take second move captured piece

        if (gl_cp != 0)
          //if capture
        {
          if (gl_cp == ((mymove[np_i - 1] << 8) >> 28))
            //if the same captured piece type
          {
            ///if order of attackers to improve
            if ((UnsignedMaterialValue[((mymove[np_i] << 16) >> 28) ])
                <
                (UnsignedMaterialValue[((mymove[np_i - 1] << 16) >> 28) ])) {
              //swap moves and grades
              ar_move = mymove[np_i - 1];
              ar_grade = grade[np_i - 1];
              mymove[np_i - 1] = mymove[np_i];
              grade[np_i - 1] = grade[np_i];
              mymove[np_i] = ar_move;
              grade[np_i] = ar_grade;
              //repeat from beginning
              goto AR_LOOP;
            };
          };
        };

        np_i++;
      };
    };
  };

#endif
*/


#ifdef BAD_TRADE_REORD
//in restply the only captures which are generated are bad trades
//move them to the end of ply in the current order
//count capture moves (n). copy them to memory. move the rest of moves by n squares
//to the left. paste capture moves to the end.
//it seems that these kind of moves shouldnt be reordered in first few plies,
//because some of them may be deep tactical or strategical wins

  @@@
  np_i = 0;
  np_j = 0;
  while (np_i < np_offs) {
	  //if any captured piece
		if (((mymove[np_i] << 8) >> 28) != 0) {
		  np_j++;
		};
	};

#endif

/*
#ifdef NULL_MOVE
//reorder null move to first position
  np_i = 0;

  while (np_i < np_offs) {
    if (mymove[np_i] == 1) {
      nms_move = mymove[np_i];
      nms_grade = grade[np_i];

      while (np_i > 0) {
        //just move it ahead and consider previous move
        mymove[np_i] = mymove[np_i - 1];
        grade[np_i] = grade[np_i - 1];
        np_i--;
      };

      mymove[np_i] = nms_move; //index zero

      grade[np_i] = nms_grade;

      break;
    };

    np_i++;
  };

#endif
*/
#ifdef THREAT_REORD
//////////////////////////////////////////
//do another sorting: search moves from the best to the weakest
//if piece threat in the ply is found:
//if the first move is null - continue
//if the move is check - continue
//reorder moves
//analyse only the curent moved piece and reveald pieces vectors
//if the move is direct or revealed attack - it is threat
//(1<<28) marked
#endif
#ifdef CHECK_REORD
//////////////////////////////////////////
//do another sorting: search moves from the best to the weakest
//if check in the ply is found:
//if the first move is null - continue
//if the move is check - continue
//reorder moves
  /*
  np_i = 0;
    cout<<"moves BEFORE check_reord: "<<flush;
  while (np_i<np_offs) {
   cout<<"["<<np_i<<"]:"<<printMove(mymove[np_i])<<" "<<flush;
    np_i++;
  };
    cout<<endl;
    */
//take second move if any
  np_i = 1;

  while (np_i < np_offs) {
    //if the move causes the black king is checked
    if (mymove[np_i] == (mymove[np_i] | (1 << 30))) {
      //save this move
      ar_move = mymove[np_i];
      ar_grade = grade[np_i];
      //move all moves before it
      //which are not null move nor check ahead one step
      np_j = np_i;

      //if we have no null move first in the ply
      if (mymove[0] != 1) {
        //if safe bound
        while (np_j > 0) {
          //if previous move is not check
          if (mymove[np_j - 1] != (mymove[np_j - 1] | (1 << 30))) {
            //just move it ahead and consider previous move
            mymove[np_j] = mymove[np_j - 1];
            grade[np_j] = grade[np_j - 1];
            np_j--;
          }
          //if previous move is check - break at curent index
          else {
            break;
          };
        };

        //move save ar_move and ar grade into curent index
        mymove[np_j] = ar_move;

        grade[np_j] = ar_grade;
      }
      //if we have null move first
      else {
        //if safe bound
        while (np_j > 1) {
          //if previous move is not check
          if (mymove[np_j - 1] != (mymove[np_j - 1] | (1 << 30))) {
            //just move it ahead and consider previous move
            mymove[np_j] = mymove[np_j - 1];
            grade[np_j] = grade[np_j - 1];
            np_j--;
          }
          //if previous move is check - break at curent index
          else {
            break;
          };
        };

        //move save ar_move and ar grade into curent index
        mymove[np_j] = ar_move;

        grade[np_j] = ar_grade;
      };
    };

    np_i++;
  };

//////////////////
  /*
    if (mymove[0]==1) {
    cout<<"moves AFTER reord, whi nm: "<<flush;
  np_i = 0;
    while (np_i<np_offs) {
     cout<<"["<<np_i<<"]:"<<printMove(mymove[np_i])<<" "<<flush;
      np_i++;
    };
    cout<<endl;
    };
    */
///////////////
#endif


/*
mark late moves in the ply by checking proper bit in proper moves
*/
#ifdef LATE_MOVE
//LATE MOVE IN white RESTPLY
//IF NODE IS NOT PV NODE
//if proper max depth
//if not lmr move upper in the tree
  if (ply < qDepth) {
    //if no lmr flag set (upper)
    if (lmr_already_used == false) {
      //if not escaping from check
      if (CheckStatus[ply - 1] == false) {
        //if no check in the path
        //if (first_check_depth==0) {
        //if proper min depth
        //if (ply>=lmr_min_ply) {
        //start from minimum lmr index
        np_i = lmr_min_idx;
        //save value of parent
        //int ar_grade = VALS_TREE[((ply - 1) << 8) | cur_offs[ply - 1]];


        //if null move at zero index
        //if (mymove[0] < 3) {
          //np_i++;

					// if parent move is not forcing move (marked by null move search)
					//if (MOVES_TREE[((ply - 1) << 8) | cur_offs[ply - 1]]
					//!= ((MOVES_TREE[((ply - 1) << 8) | cur_offs[ply - 1]]) | forced_pos_mask)) {

		        //clear lmr_real_offs
		        //lmr_real_offs = 0;
		    while (np_i < np_offs) {
		          //if static eval after move is worse than that of the parent
		          //or if static eval is little better than the parent (no capture, promotion, enpassant capture occurs)
		      //if ((grade[np_i] - evLateMoveMargin) < ar_grade) {
		            //if the move is noncapture
		            //if (((mymove[np_i]<<8)>>28)==0) {
		            //if the move generated positive forced_pos
		            //if (mymove[np_i] == (mymove[np_i]|forced_pos_mask)) {
		            //if bki_checked_mask is clear
		        if (mymove[np_i] != (mymove[np_i] | (1 << 30))) {
		              //(mymove[np_i] != (mymove[np_i]|(1<<31)))) {
		              //if the move is not promotion and not enpassant move (static eval difference is minimum about one pawn)
		              //if the move is not pawn promotion threat
		              //lmr_real_offs++;
		              //if (lmr_real_offs<3) {continue;};
		              //set lmr move flag
		          mymove[np_i] |= (1 << 29);
		              //cout<<"lmr offset:"<<np_i<<", move:"<<printMove(mymove[np_i])<<endl;
		        };

		            //};
		      //};

		      np_i++;
		    };
		  };
      //};
    };
  };

#endif
  /*
  //////////////////////////////
  cout<<"Whi late moves report (ply:"<<ply<<", qDepth:"<<qDepth<<"):"<<endl;
  np_i = 0;
  while (np_i<np_offs) {
   if (mymove[np_i]==(mymove[np_i] | (1<<29))) {
     cout<<"["<<np_i<<"]"<<printMove(mymove[np_i])<<"-late "<<flush;
   }
   else {
    cout<<"["<<np_i<<"]"<<printMove(mymove[np_i])<<"-norm "<<flush;
    };
   np_i++;
  };
  cout<<endl;
  /////////////////////////////
  */

	//save sorted and marked data into the tree
	finishSavePositionInNewPly();

#ifdef CUTTOFF_MOVE_HASH_REORDER

////////////////////////////////////////////////////////////////////
//reorder the cuttoff move if found in the beginning of the ply
//if Zkey matches and there is available the best move which produced a cuttoff
//HT==
//[Zkey(64bits)]
//[score(20bits)-val(20bits)-ply(6bits)-qDepth(6bits)-BestMovetofrom(12bits)]
  if (ply > 1) {
    Hkey = (Zkey >> (Zkeylen - Hkeylen));

    if (HT[Hkey][0] == Zkey) {
      if (((HT[Hkey][1] << 52) >> 52)
          != 0)
        //if best move available
      {
        //find the best move index
        np_i = 0;

        while (np_i < np_offs) {
          //if the move coords matches insort it into the beginning of the ply
          if (((MOVES_TREE[np_c | np_i] << 20) >> 20)
              == ((HT[Hkey][1] << 52) >> 52)) {
            //cout<<"best move:"<<printMove(MOVES_TREE[np_c|np_i])<<
            //"at idx:"<<np_i<<endl;
            //copy the value of found move
            se_v = VALS_TREE[np_c | np_i];

            //copy all moves and values one move forward to the found move pos
            for (se_j = np_i; se_j > 0; se_j--) {
              MOVES_TREE[np_c | se_j] = MOVES_TREE[np_c | (se_j - 1) ];
              VALS_TREE[np_c | se_j] = VALS_TREE[np_c | (se_j - 1) ];
            };

            //paste found move and its value in the first move pos
            MOVES_TREE[np_c | 0] = MOVES_TREE[np_c | np_i];

            VALS_TREE[np_c | 0] = se_v;

            break;
          };

          np_i++;
        };
      };
    };
  };

#endif

#ifdef DEBUG_VERSION
	restply_positions_count += np_offs;
  restply_branch_count++;
  if (ply == qDepth) {
    terminal_restply_branch_count++;
  };
  if (np_offs==0) {empty_restply_branch_count++;};
#endif

  return np_offs;
};

///////////////////////////////////////////////////////////////////
unsigned char QS_WHI_PLY(unsigned char ply)
{
//set side to move to properly eval
  side = false;

////////////////////////////////////////////////
//find equal or winning caps, eventually checks
//set initial data tables of this ply before CHILD() action
  enpassant = enp_sq[ply - 1];
  castle_dat = castle_data[ply - 1];
  Zkey = Zkey_tab[ply - 1];
  retract = retract_tab[ply - 1];

	shifted_np_ply = (ply<<8); //static used in saving position data

//loop board
  np_offs = 0;

//#ifdef QS_CHECKS

//bool checksearch = false;

//if (ply>10) {checksearch = false;};
//if ply-2 move was check and ply-1 offset>3 : checksearch=false

//if (ply>(100)) {checksearch = false;}
//else {
//if (VALS_TREE[((ply-2)<<8)|cur_offs[(ply-2)]]==(MAX_SCORE-2)) {
//if (max_offs[ply-1]<4) {
//checksearch = true;
//};
//};
//};

//#endif

/*
#ifdef REUSE_EVAL
  //whole preeval table must be generated before the ply,
  //because in each child position we analyse whole board
  if (ply <= qDepth) {
	  for (ev_fs = 0; ev_fs < 64; ev_fs++) {
		  EV_SQUARE();
      SC[ev_fs] = ev_score;
    };
    do_reuse_eval = true;
  };
#endif
*/
  for (np_i = 0; np_i < 64; np_i++) {

		switch (B[np_i]) {
      case
          sWpa: {
          if (np_i > 47)
            //handle nonpromotion move
          {
            np_t = LWPCaps[np_i];

            switch (B[np_t]) {
              case
                  sBpa: { //analyse {np_i,np_t,sWpa,sWpa,sBpa};
                  gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (2 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBro: { //analyse {np_i, np_t, sWpa, sWpa, sBro};
                  gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (4 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBbi: { //analyse {np_i, np_t, sWpa, sWpa, sBbi};
                  gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (6 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBkn: { //analyse {np_i, np_t, sWpa, sWpa, sBkn};
                  gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (8 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBqu: { //analyse {np_i, np_t, sWpa, sWpa, sBqu};
                  gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (12 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
            };

            np_t = RWPCaps[np_i];

            switch (B[np_t]) {
              case
                  sBpa: { //analyse {np_i, np_t, sWpa, sWpa, sBpa};
                  gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (2 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBro: { //analyse {np_i, np_t, sWpa, sWpa, sBro};
                  gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (4 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBbi: { //analyse {np_i, np_t, sWpa, sWpa, sBbi};
                  gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (6 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBkn: { //analyse {np_i, np_t, sWpa, sWpa, sBkn};
                  gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (8 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBqu: { //analyse {np_i, np_t, sWpa, sWpa, sBqu};
                  gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (12 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
            };

            //#ifdef QS_CHECKS
            //save CHECK caused by white pawn moving ONE SQUARE AHEAD from starting pos.
            /*
            if (checksearch==true) {
             np_t = np_i-8;
             if (B[np_t]==sEmp) {// {np_i, np_i-8, sWpa, sWpa, '0'};
               gl_move = (np_i | (np_t<<6) | (1<<12) | (1<<16));
                         CHILD(ply);
                          if (isWhiCheckGood(BkiPos)==true) {
               if (isAttByBla(WkiPos)==false) {
                  saveWhiPosition(np_offs); np_offs++;
               };
                };
                         PARENT(ply);
              // save CHECK caused by pawn moving TWO SQUARES AHEAD
              np_t -= 8;
              if (B[np_t]==sEmp) {// {np_i, np_i-16, sWpa, sWpa, '0'};
                gl_move = (np_i | (np_t<<6) | (1<<12) | (1<<16));
                           CHILD(ply);
                           if (isWhiCheckGood(BkiPos)==true) {
                 if (isAttByBla(WkiPos)==false) {
                  saveWhiPosition(np_offs); np_offs++;
                };
                };
                           PARENT(ply);
              };
             };
            };
            //#endif
            */

            #ifdef QS_MATES
            np_t = np_i-8;
	          if (B[np_t]==sEmp) {// {np_i, np_i-8, sWpa, sWpa, '0'};
	            gl_move = (np_i | (np_t<<6) | (1<<12) | (1<<16));
	            CHILD(ply);
	            if (isAttByWhi(BkiPos)==true) {
	              if (isBkiMated()==true) {
             	    if (isAttByBla(WkiPos)==false) {
								    saveWhiPosition(np_offs); np_offs++;
								    PARENT(ply); goto END;
                  };
                };
              };
	            PARENT(ply);

              np_t -= 8;
	            if (B[np_t]==sEmp) {// {np_i, np_i-16, sWpa, sWpa, '0'};
	              gl_move = (np_i | (np_t<<6) | (1<<12) | (1<<16));
	              CHILD(ply);
		            if (isAttByWhi(BkiPos)==true) {
		              if (isBkiMated()==true) {
	             	    if (isAttByBla(WkiPos)==false) {
									    saveWhiPosition(np_offs); np_offs++;
									    PARENT(ply); goto END;
	                  };
	                };
	              };
		            PARENT(ply);
		          };
		        };
            #endif
          }
          // IF PAWN IS IN THE MIDDLEBOARD
          else
            if (np_i > 15) {
              np_t = LWPCaps[np_i];

              switch (B[np_t]) {
                case
                    sEmp: { //analyse enpassant capture
                    if ((enpassant == np_t) && (np_t != 64)) {
                      //analyse {np_i, np_t, sWpa, sBpa};
                      gl_move = (np_i | (np_t << 6) | (1 << 12) | (2 << 16));
                      CHILD(ply);

                      if (isAttByBla(WkiPos) == false) {
                        saveWhiPosition(np_offs);
                        np_offs++;
                      };

                      PARENT(ply);
                    };
                  };

                  break;
                case
                    sBpa: { //analyse {np_i, np_t, sWpa, sWpa, sBpa};
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (2 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sBro: { //analyse {np_i, np_t, sWpa, sWpa, sBro};
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (4 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sBbi: { //analyse {np_i, np_t, sWpa, sWpa, sBbi};
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (6 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sBkn: { //analyse {np_i, np_t, sWpa, sWpa, sBkn};
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (8 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sBqu: { //analyse {np_i, np_t, sWpa, sWpa, sBqu};
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (12 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
              };

              np_t = RWPCaps[np_i];

              switch (B[np_t]) {
                case
                    sEmp: { //analyse enpassant capture
                    if ((enpassant == np_t) && (np_t != 64)) {
                      //{np_i, np_t, sWpa, sBpa};
                      gl_move = (np_i | (np_t << 6) | (1 << 12) | (2 << 16));
                      CHILD(ply);

                      if (isAttByBla(WkiPos) == false) {
                        saveWhiPosition(np_offs);
                        np_offs++;
                      };

                      PARENT(ply);
                    };
                  };

                  break;
                case
                    sBpa: { //analyse {np_i,np_t,sWpa,sWpa,sBpa};
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (2 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sBro: { //analyse {np_i, np_t, sWpa, sWpa, sBro};
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (4 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sBbi: { //analyse {np_i, np_t, sWpa, sWpa, sBbi};
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (6 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sBkn: { //analyse {np_i, np_t, sWpa, sWpa, sBkn};
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (8 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sBqu: { //analyse {np_i, np_t, sWpa, sWpa, sBqu};
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (1 << 16) | (12 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
              };

              #ifdef QS_MATES
              np_t = np_i-8;
	            if (B[np_t]==sEmp) {// {np_i, np_i-8, sWpa, sWpa, '0'};
	              gl_move = (np_i | (np_t<<6) | (1<<12) | (1<<16));
                CHILD(ply);
                if (isAttByWhi(BkiPos)==true) {
                  if (isBkiMated()==true) {
         	          if (isAttByBla(WkiPos)==false) {
								      saveWhiPosition(np_offs); np_offs++;
                      PARENT(ply); goto END;
										};
                  };
                };
	              PARENT(ply);
              };
              #endif

              /*
                        //#ifdef QS_CHECKS
              if (checksearch==true) {
               // check if white pawn can move ONE SQUARE AHEAD
               np_t = np_i-8;
               if (B[np_t]==sEmp) {//{np_i, np_i-8, sWpa, sWpa, '0'};
                 gl_move = (np_i | (np_t<<6) | (1<<12) | (1<<16));
                           CHILD(ply);
                           if (isWhiCheckGood(BkiPos)==true) {
                 if (isAttByBla(WkiPos)==false) {
                    saveWhiPosition(np_offs); np_offs++;
                 };
                 };
                           PARENT(ply);
               };
              };
              //#endif
                        */
            }
          // ELSE IF PAWN IS IN THE SEVENTH ROW
          // handle PROMOTION if PAWN CAN MOVE AHEAD
            else {
              np_t = np_i - 8;

              np_allow = false;
              if (B[np_t] == sEmp) {
                gl_move = (np_i | (np_t << 6) | (1 << 12) | (11 << 16));
                CHILD(ply);
                if (isAttByBla(WkiPos) == false) {
                  np_allow = true; saveWhiPosition(np_offs);
                  np_offs++;
                }
                PARENT(ply);
                /*
                gl_move = (np_i | (np_t<<6) | (1<<12) | (3<<16));
                CHILD(ply);
                if (np_allow==true) {saveWhiPosition(np_offs); np_offs++;};
                PARENT(ply);

                gl_move = (np_i | (np_t<<6) | (1<<12) | (5<<16));
                CHILD(ply);
                if (np_allow==true) {saveWhiPosition(np_offs); np_offs++;};
                PARENT(ply);

                gl_move = (np_i | (np_t<<6) | (1<<12) | (7<<16));
                CHILD(ply);
                if (np_allow==true) {saveWhiPosition(np_offs); np_offs++;};
                PARENT(ply);
                */
                #ifdef QS_MATES
                //handle knight promotion only if knight mates
                gl_move = (np_i | (np_t<<6) | (1<<12) | (7<<16));
                if (np_allow==true) {
								  CHILD(ply);
                  if (isAttByWhi(BkiPos)==true) {
                    if (isBkiMated()==true) {
								      saveWhiPosition(np_offs); np_offs++;
								      PARENT(ply); goto END;
                    };
                  };
	                PARENT(ply);
                };
								#endif

              };

              // handle PROMOTION if PAWN CAPTURED
              np_t = LWPCaps[np_i];

              switch (B[np_t]) {
                  // if opponent rook is captured - memorize the possible promotions
                case
                    sBro: {
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (11 << 16) | (4 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      np_allow=true; saveWhiPosition(np_offs);
                      np_offs++;
                    }

                    PARENT(ply);
                    /*
                                  gl_move = (np_i | (np_t<<6) | (1<<12) | (3<<16) | (4<<20));
                    CHILD(ply);
                                  if (np_allow==true) {saveWhiPosition(np_offs); np_offs++;};
                                  PARENT(ply);

                                  gl_move = (np_i | (np_t<<6) | (1<<12) | (5<<16) | (4<<20));
                    CHILD(ply);
                                  if (np_allow==true) {saveWhiPosition(np_offs); np_offs++;};
                                  PARENT(ply);

                                  gl_move = (np_i | (np_t<<6) | (1<<12) | (7<<16) | (4<<20));
                             CHILD(ply);
                                  if (np_allow==true) {saveWhiPosition(np_offs); np_offs++;};
                                  PARENT(ply);
                                  */

									  #ifdef QS_MATES
                    //handle knight promotion only if knight mates
                    gl_move = (np_i | (np_t<<6) | (1<<12) | (7<<16) | (4<<20));
                    if (np_allow==true) {
								      CHILD(ply);
                      if (isAttByWhi(BkiPos)==true) {
                        if (isBkiMated()==true) {
								          saveWhiPosition(np_offs); np_offs++;
								          PARENT(ply); goto END;
                        };
                      };
	                    PARENT(ply);
                    };
								    #endif
									};

                  break;

                  // if opponent bishop is captured - memorize the possible promotions
                case
                    sBbi: {
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (11 << 16) | (6 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      np_allow = true; saveWhiPosition(np_offs);
                      np_offs++;
                    }

                    PARENT(ply);
                    /*
                    gl_move = (np_i | (np_t<<6) | (1<<12) | (3<<16) | (6<<20));
                    CHILD(ply);
                    if (np_allow==true) {saveWhiPosition(np_offs); np_offs++;};
                    PARENT(ply);

                    gl_move = (np_i | (np_t<<6) | (1<<12) | (5<<16) | (6<<20));
                    CHILD(ply);
                    if (np_allow==true) {saveWhiPosition(np_offs); np_offs++;};
                    PARENT(ply);

                    gl_move = (np_i | (np_t<<6) | (1<<12) | (7<<16) | (6<<20));
                    CHILD(ply);
                    if (np_allow==true) {saveWhiPosition(np_offs); np_offs++;};
                    PARENT(ply);
                    */
                    #ifdef QS_MATES
                    //handle knight promotion only if knight mates
                    gl_move = (np_i | (np_t<<6) | (1<<12) | (7<<16) | (6<<20));
                    if (np_allow == true) {
								      CHILD(ply);
                      if (isAttByWhi(BkiPos)==true) {
                        if (isBkiMated()==true) {
								          saveWhiPosition(np_offs); np_offs++;
								          PARENT(ply); goto END;
                        };
                      };
	                    PARENT(ply);
                    };
								    #endif
                  };

                  break;

                  // if opponent knight is captured - memorize the possible promotions
                case
                    sBkn: {
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (11 << 16) | (8 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      np_allow = true; saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                    /*
                    gl_move = (np_i | (np_t<<6) | (1<<12) | (3<<16) | (8<<20));
                    CHILD(ply);
                    if (np_allow==true) {saveWhiPosition(np_offs); np_offs++;};
                    PARENT(ply);

                    gl_move = (np_i | (np_t<<6) | (1<<12) | (5<<16) | (8<<20));
                    CHILD(ply);
                    if (np_allow==true) {saveWhiPosition(np_offs); np_offs++;};
                    PARENT(ply);

                    gl_move = (np_i | (np_t<<6) | (1<<12) | (7<<16) | (8<<20));
                    CHILD(ply);
                    if (np_allow==true) {saveWhiPosition(np_offs); np_offs++;};
                    PARENT(ply);
                    */

                    #ifdef QS_MATES
                    //handle knight promotion only if knight mates
                    gl_move = (np_i | (np_t<<6) | (1<<12) | (7<<16) | (8<<20));
                    if (np_allow==true) {
								      CHILD(ply);
                      if (isAttByWhi(BkiPos)==true) {
                        if (isBkiMated()==true) {
								          saveWhiPosition(np_offs); np_offs++;
								          PARENT(ply); goto END;
                        };
                      };
	                    PARENT(ply);
                    };
								    #endif

                  };

                  break;

                  // if opponent queen is captured - memorize the move
                case
                    sBqu: {
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (11 << 16) | (12 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      np_allow = true; saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                    /*
                    gl_move = (np_i | (np_t<<6) | (1<<12) | (3<<16) | (12<<20));
                    CHILD(ply);
                    if (np_allow==true) {saveWhiPosition(np_offs); np_offs++;};
                    PARENT(ply);

                    gl_move = (np_i | (np_t<<6) | (1<<12) | (5<<16) | (12<<20));
                    CHILD(ply);
                    if (np_allow==true) {saveWhiPosition(np_offs); np_offs++;};
                    PARENT(ply);

                    gl_move = (np_i | (np_t<<6) | (1<<12) | (7<<16) | (12<<20));
                    CHILD(ply);
                    if (np_allow==true) {saveWhiPosition(np_offs); np_offs++;};
                    PARENT(ply);
                       */
                    #ifdef QS_MATES
                    //handle knight promotion only if knight mates
                    gl_move = (np_i | (np_t<<6) | (1<<12) | (7<<16) | (12<<20));
                    if (np_allow==true) {
								      CHILD(ply);
                      if (isAttByWhi(BkiPos)==true) {
                        if (isBkiMated()==true) {
								          saveWhiPosition(np_offs); np_offs++;
								          PARENT(ply); goto END;
                        };
                      };
	                    PARENT(ply);
                    };
								    #endif

                  };

                  break;
              };

              np_t = RWPCaps[np_i];

              switch (B[np_t]) {
                  // if opponent rook is captured - memorize the possible promotions
                case
                    sBro: {
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (11 << 16) | (4 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      np_allow=true; saveWhiPosition(np_offs);
                      np_offs++;
                    }

                    PARENT(ply);
                    /*
                                  gl_move = (np_i | (np_t<<6) | (1<<12) | (3<<16) | (4<<20));
                    CHILD(ply);
                                  if (np_allow==true) {saveWhiPosition(np_offs); np_offs++;};
                                  PARENT(ply);

                                  gl_move = (np_i | (np_t<<6) | (1<<12) | (5<<16) | (4<<20));
                    CHILD(ply);
                                  if (np_allow==true) {saveWhiPosition(np_offs); np_offs++;};
                                  PARENT(ply);

                                  gl_move = (np_i | (np_t<<6) | (1<<12) | (7<<16) | (4<<20));
                             CHILD(ply);
                                  if (np_allow==true) {saveWhiPosition(np_offs); np_offs++;};
                                  PARENT(ply);
                                  */

									  #ifdef QS_MATES
                    //handle knight promotion only if knight mates
                    gl_move = (np_i | (np_t<<6) | (1<<12) | (7<<16) | (4<<20));
                    if (np_allow==true) {
								      CHILD(ply);
                      if (isAttByWhi(BkiPos)==true) {
                        if (isBkiMated()==true) {
								          saveWhiPosition(np_offs); np_offs++;
								          PARENT(ply); goto END;
                        };
                      };
	                    PARENT(ply);
                    };
								    #endif
									};

                  break;

                  // if opponent bishop is captured - memorize the possible promotions
                case
                    sBbi: {
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (11 << 16) | (6 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      np_allow = true; saveWhiPosition(np_offs);
                      np_offs++;
                    }

                    PARENT(ply);
                    /*
                    gl_move = (np_i | (np_t<<6) | (1<<12) | (3<<16) | (6<<20));
                    CHILD(ply);
                    if (np_allow==true) {saveWhiPosition(np_offs); np_offs++;};
                    PARENT(ply);

                    gl_move = (np_i | (np_t<<6) | (1<<12) | (5<<16) | (6<<20));
                    CHILD(ply);
                    if (np_allow==true) {saveWhiPosition(np_offs); np_offs++;};
                    PARENT(ply);

                    gl_move = (np_i | (np_t<<6) | (1<<12) | (7<<16) | (6<<20));
                    CHILD(ply);
                    if (np_allow==true) {saveWhiPosition(np_offs); np_offs++;};
                    PARENT(ply);
                    */
                    #ifdef QS_MATES
                    //handle knight promotion only if knight mates
                    gl_move = (np_i | (np_t<<6) | (1<<12) | (7<<16) | (6<<20));
                    if (np_allow == true) {
								      CHILD(ply);
                      if (isAttByWhi(BkiPos)==true) {
                        if (isBkiMated()==true) {
								          saveWhiPosition(np_offs); np_offs++;
								          PARENT(ply); goto END;
                        };
                      };
	                    PARENT(ply);
                    };
								    #endif
                  };

                  break;

                  // if opponent knight is captured - memorize the possible promotions
                case
                    sBkn: {
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (11 << 16) | (8 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      np_allow = true; saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                    /*
                    gl_move = (np_i | (np_t<<6) | (1<<12) | (3<<16) | (8<<20));
                    CHILD(ply);
                    if (np_allow==true) {saveWhiPosition(np_offs); np_offs++;};
                    PARENT(ply);

                    gl_move = (np_i | (np_t<<6) | (1<<12) | (5<<16) | (8<<20));
                    CHILD(ply);
                    if (np_allow==true) {saveWhiPosition(np_offs); np_offs++;};
                    PARENT(ply);

                    gl_move = (np_i | (np_t<<6) | (1<<12) | (7<<16) | (8<<20));
                    CHILD(ply);
                    if (np_allow==true) {saveWhiPosition(np_offs); np_offs++;};
                    PARENT(ply);
                    */

                    #ifdef QS_MATES
                    //handle knight promotion only if knight mates
                    gl_move = (np_i | (np_t<<6) | (1<<12) | (7<<16) | (8<<20));
                    if (np_allow==true) {
								      CHILD(ply);
                      if (isAttByWhi(BkiPos)==true) {
                        if (isBkiMated()==true) {
								          saveWhiPosition(np_offs); np_offs++;
								          PARENT(ply); goto END;
                        };
                      };
	                    PARENT(ply);
                    };
								    #endif

                  };

                  break;

                  // if opponent queen is captured - memorize the move
                case
                    sBqu: {
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (1 << 12) | (11 << 16) | (12 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      np_allow = true; saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                    /*
                    gl_move = (np_i | (np_t<<6) | (1<<12) | (3<<16) | (12<<20));
                    CHILD(ply);
                    if (np_allow==true) {saveWhiPosition(np_offs); np_offs++;};
                    PARENT(ply);

                    gl_move = (np_i | (np_t<<6) | (1<<12) | (5<<16) | (12<<20));
                    CHILD(ply);
                    if (np_allow==true) {saveWhiPosition(np_offs); np_offs++;};
                    PARENT(ply);

                    gl_move = (np_i | (np_t<<6) | (1<<12) | (7<<16) | (12<<20));
                    CHILD(ply);
                    if (np_allow==true) {saveWhiPosition(np_offs); np_offs++;};
                    PARENT(ply);
                       */
                    #ifdef QS_MATES
                    //handle knight promotion only if knight mates
                    gl_move = (np_i | (np_t<<6) | (1<<12) | (7<<16) | (12<<20));
                    if (np_allow==true) {
								      CHILD(ply);
                      if (isAttByWhi(BkiPos)==true) {
                        if (isBkiMated()==true) {
								          saveWhiPosition(np_offs); np_offs++;
								          PARENT(ply); goto END;
                        };
                      };
	                    PARENT(ply);
                    };
								    #endif

                  };

                  break;
               };
            };
        };

        break;
      case
          sWro: {
          for (np_v = 4; np_v < 8; np_v++) {
            for (np_c = 0; np_c < 8; np_c++) {
              np_t = Vec[np_v][np_i][np_c];

              switch (B[np_t]) {
                case
                    sEmp: {
                    ;//move m = {np_i, np_t, sWro, sWro, '0'};
                    /*
                        //#ifdef QS_CHECKS
                        if (checksearch==true) {
                         gl_move = (np_i | (np_t<<6) | (3<<12) | (3<<16));
                        CHILD(ply);
                        if (isWhiCheckGood(BkiPos)==true) {
                            if (isAttByBla(WkiPos)==false) {
                               saveWhiPosition(np_offs); np_offs++;
                          };
                          };
                        PARENT(ply);
                        };
                    //#endif
                    */
                    #ifdef QS_MATES
                    //move m = {np_i, np_t, sWro, sWro, '0'};
                    gl_move = (np_i | (np_t<<6) | (3<<12) | (3<<16));
				            CHILD(ply);
				            if (isAttByWhi(BkiPos)==true) {
		                  if (isBkiMated()==true) {
            	          if (isAttByBla(WkiPos)==false) {
									        saveWhiPosition(np_offs); np_offs++;
									        PARENT(ply); goto END;
                        };
	                    };
			              };
				            PARENT(ply);
										#endif
                  };

                  break;
                case
                    sBpa: { //move m = {np_i, np_t, sWro, sWro, sBpa};
                    gl_move = (np_i | (np_t << 6) | (3 << 12) | (3 << 16) | (2 << 20));
                    CHILD(ply);

                    //if (checksearch==false) {
                    if (isAttByBla(WkiPos) == false) {
										  if (isAttByBla(np_t) == false) {
												saveWhiPosition(np_offs); np_offs++;
                      }
                      else {
                      	#ifdef QS_MATES
				                if (isAttByWhi(BkiPos)==true) {
		                      if (isBkiMated()==true) {
									          saveWhiPosition(np_offs); np_offs++;
									          PARENT(ply); goto END;
									        };
                        };
										    #endif
											};
                    };

                    //}
                    /*
                    else {
                    if (isWhiCheckGood(BkiPos)==true) {
                       if (isAttByBla(WkiPos)==false) {
                         saveWhiPosition(np_offs); np_offs++;
                        };
                      };
                    };
                    */
                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sBro: { //move m = {np_i, np_t, sWro, sWro, sBro};
                    gl_move = (np_i | (np_t << 6) | (3 << 12) | (3 << 16) | (4 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sBbi: { //move m = {np_i, np_t, sWro, sWro, sBbi};
                    gl_move = (np_i | (np_t << 6) | (3 << 12) | (3 << 16) | (6 << 20));
                    CHILD(ply);

                    //if (checksearch==false) {
                    if (isAttByBla(WkiPos) == false) {
										  if (isAttByBla(np_t) == false) {
												saveWhiPosition(np_offs); np_offs++;
                      }
                      else {
                      	#ifdef QS_MATES
				                if (isAttByWhi(BkiPos)==true) {
		                      if (isBkiMated()==true) {
									          saveWhiPosition(np_offs); np_offs++;
									          PARENT(ply); goto END;
									        };
                        };
										    #endif
											};
                    };

                    //}
                    /*
                    else {
                    if (isWhiCheckGood(BkiPos)==true) {
                       if (isAttByBla(WkiPos)==false) {
                         saveWhiPosition(np_offs); np_offs++;
                        };
                      };
                    };
                    */
                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sBkn: { //move m = {np_i, np_t, sWro, sWro, sBkn};
                    gl_move = (np_i | (np_t << 6) | (3 << 12) | (3 << 16) | (8 << 20));
                    CHILD(ply);

                    //if (checksearch==false) {
                    if (isAttByBla(WkiPos) == false) {
										  if (isAttByBla(np_t) == false) {
												saveWhiPosition(np_offs); np_offs++;
                      }
                      else {
                      	#ifdef QS_MATES
				                if (isAttByWhi(BkiPos)==true) {
		                      if (isBkiMated()==true) {
									          saveWhiPosition(np_offs); np_offs++;
									          PARENT(ply); goto END;
									        };
                        };
										    #endif
											};
                    };

                    //}
                    /*
                    else {
                    if (isWhiCheckGood(BkiPos)==true) {
                       if (isAttByBla(WkiPos)==false) {
                         saveWhiPosition(np_offs); np_offs++;
                        };
                      };
                    };
                    */
                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sBqu: { //move m = {np_i, np_t, sWro, sWro, sBqu};
                    gl_move = (np_i | (np_t << 6) | (3 << 12) | (3 << 16) | (12 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                default
                    : {
                    np_c = 8;
                  };//handle out of board vector or self piece or king
              };
            };
          };
        };

        break;
      case
          sWbi: {
          for (np_v = 0; np_v < 4; np_v++) {
            for (np_c = 0; np_c < 8; np_c++) {
              np_t = Vec[np_v][np_i][np_c];

              switch (B[np_t]) {
                case
                    sEmp: {
                    ;//move m = {np_i, np_t, sWbi, sWbi, '0'};
                    /*
                    if (checksearch==true) {
                     gl_move = (np_i | (np_t<<6) | (5<<12) | (5<<16));
                                     CHILD(ply);
                                     if (isWhiCheckGood(BkiPos)==true) {
                        if (isAttByBla(WkiPos)==false) {
                        saveWhiPosition(np_offs); np_offs++;
                      };
                      };
                                     PARENT(ply);
                    };
                    */
                    #ifdef QS_MATES
                    //move m = {np_i, np_t, sWro, sWro, '0'};
                    gl_move = (np_i | (np_t<<6) | (5<<12) | (5<<16));
				            CHILD(ply);
				            if (isAttByWhi(BkiPos)==true) {
		                  if (isBkiMated()==true) {
            	          if (isAttByBla(WkiPos)==false) {
									        saveWhiPosition(np_offs); np_offs++;
									        PARENT(ply); goto END;
                        };
	                    };
			              };
				            PARENT(ply);
										#endif
                  };

                  break;
                case
                    sBpa: { //move m = {np_i, np_t, sWbi, sWbi, sBpa};
                    gl_move = (np_i | (np_t << 6) | (5 << 12) | (5 << 16) | (2 << 20));
                    CHILD(ply);

                    //if (checksearch==false) {
                    if (isAttByBla(WkiPos) == false) {
										  if (isAttByBla(np_t) == false) {
												saveWhiPosition(np_offs); np_offs++;
                      }
                      else {
                      	#ifdef QS_MATES
				                if (isAttByWhi(BkiPos)==true) {
		                      if (isBkiMated()==true) {
									          saveWhiPosition(np_offs); np_offs++;
									          PARENT(ply); goto END;
									        };
                        };
										    #endif
											};
                    };

                    //}
                    /*
                    else {
                    if (isWhiCheckGood(BkiPos)==true) {
                       if (isAttByBla(WkiPos)==false) {
                         saveWhiPosition(np_offs); np_offs++;
                        };
                      };
                    };
                    */
                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sBro: { //move m = {np_i, np_t, sWbi, sWbi, sBro};
                    gl_move = (np_i | (np_t << 6) | (5 << 12) | (5 << 16) | (4 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sBbi: { //move m = {np_i, np_t, sWbi, sWbi, sBbi};
                    gl_move = (np_i | (np_t << 6) | (5 << 12) | (5 << 16) | (6 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sBkn: { //move m = {np_i, np_t, sWbi, sWbi, sBkn};
                    gl_move = (np_i | (np_t << 6) | (5 << 12) | (5 << 16) | (8 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sBqu: { //move m = {np_i, np_t, sWbi, sWbi, sBqu};
                    gl_move = (np_i | (np_t << 6) | (5 << 12) | (5 << 16) | (12 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                default
                    : {
                    np_c = 8;
                  };
              };
            };
          };
        };

        break;

        // analyse self knight
      case
          sWkn: {
          for (np_c = 0; np_c < 8; np_c++) {
            np_t = decreasingKnightMap[np_i][np_c];
            switch (B[np_t]) {
              case
                sEmp: {
                  ;//move m = {np_i, np_t, sWkn, sWkn, '0'};
                  /*
                   if (checksearch==true) {
                                 gl_move = (np_i | (np_t<<6) | (7<<12) | (7<<16));
                                 CHILD(ply);
                                 if (isWhiCheckGood(BkiPos)==true) {
                      if (isAttByBla(WkiPos)==false) {
                       saveWhiPosition(np_offs); np_offs++;
                      };
                    };
                                 PARENT(ply);
                   };
                  */
                  #ifdef QS_MATES
                  //move m = {np_i, np_t, sWkn, sWkn};
                  gl_move = (np_i | (np_t << 6) | (7 << 12) | (7 << 16));
		              CHILD(ply);
		              if (isAttByWhi(BkiPos)==true) {
                    if (isBkiMated()==true) {
        	            if (isAttByBla(WkiPos)==false) {
							          saveWhiPosition(np_offs); np_offs++;
							          PARENT(ply); goto END;
                      };
                    };
	                };
		              PARENT(ply);
								  #endif
                };

                break;
              case
                  sBpa: { //move m = {np_i, np_t, sWkn, sWkn, sBpa};
                  gl_move = (np_i | (np_t << 6) | (7 << 12) | (7 << 16) | (2 << 20));
                  CHILD(ply);


                    //if (checksearch==false) {
                    if (isAttByBla(WkiPos) == false) {
										  if (isAttByBla(np_t) == false) {
												saveWhiPosition(np_offs); np_offs++;
                      }
                      else {
                      	#ifdef QS_MATES
				                if (isAttByWhi(BkiPos)==true) {
		                      if (isBkiMated()==true) {
									          saveWhiPosition(np_offs); np_offs++;
									          PARENT(ply); goto END;
									        };
                        };
										    #endif
											};
                    };

                  //}
                  /*
                  else {
                  if (isWhiCheckGood(BkiPos)==true) {
                     if (isAttByBla(WkiPos)==false) {
                       saveWhiPosition(np_offs); np_offs++;
                      };
                    };
                  };
                  */
                  PARENT(ply);
                };

                break;
              case
                  sBro: { //move m = {np_i, np_t, sWkn, sWkn, sBro};
                  gl_move = (np_i | (np_t << 6) | (7 << 12) | (7 << 16) | (4 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBbi: { //move m = {np_i, np_t, sWkn, sWkn, sBbi};
                  gl_move = (np_i | (np_t << 6) | (7 << 12) | (7 << 16) | (6 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBkn: { //move m = {np_i, np_t, sWkn, sWkn, sBkn};
                  gl_move = (np_i | (np_t << 6) | (7 << 12) | (7 << 16) | (8 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBqu: { //move m = {np_i, np_t, sWkn, sWkn, sBqu};
                  gl_move = (np_i | (np_t << 6) | (7 << 12) | (7 << 16) | (12 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
                case
							  sOut: {break;}; break;
            };
          };
        };

        break;
      case
          sWki: {

         	//todo qs_checks


          //#ifdef QS_CHECKS
          /*
          if (checksearch==true) {
                   // if positive k-side castle status
            if (castle_dat != (castle_dat | castle_lost_WKK_mask)) {
              //if king not in check
            //@ invalid check status in qs
            if (CheckStatus[ply-1]==false) {
              //if empty two squares on the right side of the king
              if (B[61]==sEmp) {
                if (B[62]==sEmp) {
                 //if empty squares are not in check
                if (isAttByBla(61)==false) {
                 if (isAttByBla(62)==false) {
                  //add k-side castle move
                 //move m = {60, 62, sWki, sWki, '0'}; and move m = {63, 61, sWro, sWro, '0'};
                 gl_move = (60 | (62<<6) | (9<<12) | (9<<16));
                 CHILD(ply);
                 if (isWhiCheckGood(BkiPos)==true) {
                    saveWhiPosition(np_offs); np_offs++;
                 };
                 PARENT(ply);
                   };
                 };
               };
              };
            };
                   };
                   // if positive q-side castle status
            if (castle_dat!=(castle_dat | castle_lost_WKQ_mask)) {
            //if king not in check
            if (CheckStatus[ply-1]==false) {
             //if THREE empty squares on the left side of the king
            if (B[59]==sEmp){
              if (B[58]==sEmp){
                  if (B[57]==sEmp){
                      //if TWO empty squares and king are not in check
                    if (isAttByBla(59)==false) {
                    if (isAttByBla(58)==false) {
                       gl_move = (60 | (58<<6) | (9<<12) | (9<<16));
                    CHILD(ply);
                    if (isWhiCheckGood(BkiPos)==true) {
                    saveWhiPosition(np_offs); np_offs++;
                  };
                  PARENT(ply);
                 };
                };
               };
                  };
             };
          };
                  };
               };
                 //#endif
                 */
          //handle normal king moves
          for (np_v = 0; np_v < 8; np_v++) {
            np_t = Vec[np_v][np_i][0];

            switch (B[np_t]) {
              case
                  sEmp: {
                  ;//move m = {np_i, np_t, sWki, sWki, '0'};
                  /*
                  if (checksearch==true) {
                   gl_move = (np_i | (np_t<<6) | (9<<12) | (9<<16));
                                 CHILD(ply);
                    if (isWhiCheckGood(BkiPos)==true) {
                  if (isAttByBla(WkiPos)==false) {
                        saveWhiPosition(np_offs); np_offs++;
                     };
                   };
                                 PARENT(ply);
                  };
                  */

                  #ifdef QS_MATES
                  //move m = {np_i, np_t, sWki, sWki};
                  gl_move = (np_i | (np_t << 6) | (9 << 12) | (9 << 16));
		              CHILD(ply);
		              if (isAttByWhi(BkiPos)==true) {
                    if (isBkiMated()==true) {
        	            if (isAttByBla(WkiPos)==false) {
							          saveWhiPosition(np_offs); np_offs++;
							          PARENT(ply); goto END;
                      };
                    };
	                };
		              PARENT(ply);
								  #endif
                };

                break;
              case
                  sBpa: { //move m = {np_i, np_t, sWki, sWki, sBpa};
                  gl_move = (np_i | (np_t << 6) | (9 << 12) | (9 << 16) | (2 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBro: { //move m = {np_i, np_t, sWki, sWki, sBro};
                  gl_move = (np_i | (np_t << 6) | (9 << 12) | (9 << 16) | (4 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBbi: { //move m = {np_i, np_t, sWki, sWki, sBbi};
                  gl_move = (np_i | (np_t << 6) | (9 << 12) | (9 << 16) | (6 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBkn: { //move m = {np_i, np_t, sWki, sWki, sBkn};
                  gl_move = (np_i | (np_t << 6) | (9 << 12) | (9 << 16) | (8 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sBqu: { //move m = {np_i, np_t, sWki, sWki, sBqu};
                  gl_move = (np_i | (np_t << 6) | (9 << 12) | (9 << 16) | (12 << 20));
                  CHILD(ply);

                  if (isAttByBla(WkiPos) == false) {
                    saveWhiPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
            };
          };
        };

        break;
      case
          sWqu: {
          for (np_v = 0; np_v < 8; np_v++) {
            for (np_c = 0; np_c < 8; np_c++) {
              np_t = Vec[np_v][np_i][np_c];

              switch (B[np_t]) {
                case
                  sEmp: {
                    ;//move m = {np_i, np_t, sWqu, sWqu, '0'};
                    /*
                        if (checksearch==true) {
                         gl_move = (np_i | (np_t<<6) | (11<<12) | (11<<16));
                          CHILD(ply);
                        if (isWhiCheckGood(BkiPos)==true) {
                            if (isAttByBla(WkiPos)==false) {
                             saveWhiPosition(np_offs); np_offs++;
                          };
                          };
                        PARENT(ply);
                         };
                        */

										#ifdef QS_MATES
	                  //move m = {np_i, np_t, sWqu, sWqu};
	                  gl_move = (np_i | (np_t << 6) | (11 << 12) | (11 << 16));
			              CHILD(ply);
			              if (isAttByWhi(BkiPos)==true) {
	                    if (isBkiMated()==true) {
	        	            if (isAttByBla(WkiPos)==false) {
								          saveWhiPosition(np_offs); np_offs++;
								          PARENT(ply); goto END;
	                      };
	                    };
		                };
			              PARENT(ply);
									  #endif

									};

                  break;
                case
                    sBpa: { //move m = {np_i, np_t, sWqu, sWqu, sBpa};
                    gl_move = (np_i | (np_t << 6) | (11 << 12) | (11 << 16) | (2 << 20));
                    CHILD(ply);

                    //if (checksearch==false) {
                    if (isAttByBla(WkiPos) == false) {
										  if (isAttByBla(np_t) == false) {
												saveWhiPosition(np_offs); np_offs++;
                      }
                      else {
                      	#ifdef QS_MATES
				                if (isAttByWhi(BkiPos)==true) {
		                      if (isBkiMated()==true) {
									          saveWhiPosition(np_offs); np_offs++;
									          PARENT(ply); goto END;
									        };
                        };
										    #endif
											};
                    };

                    //}
                    /*
                    else {
                    if (isWhiCheckGood(BkiPos)==true) {
                       if (isAttByBla(WkiPos)==false) {
                         saveWhiPosition(np_offs); np_offs++;
                        };
                      };
                    };
                    */
                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sBro: { //move m = {np_i, np_t, sWqu, sWqu, sBro};
                    gl_move = (np_i | (np_t << 6) | (11 << 12) | (11 << 16) | (4 << 20));
                    CHILD(ply);

                    //if (checksearch==false) {
                    if (isAttByBla(WkiPos) == false) {
										  if (isAttByBla(np_t) == false) {
												saveWhiPosition(np_offs); np_offs++;
                      }
                      else {
                      	#ifdef QS_MATES
				                if (isAttByWhi(BkiPos)==true) {
		                      if (isBkiMated()==true) {
									          saveWhiPosition(np_offs); np_offs++;
									          PARENT(ply); goto END;
									        };
                        };
										    #endif
											};
                    };

                    //}
                    /*
                    else {
                    if (isWhiCheckGood(BkiPos)==true) {
                       if (isAttByBla(WkiPos)==false) {
                         saveWhiPosition(np_offs); np_offs++;
                        };
                      };
                    };
                    */
                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sBbi: { //move m = {np_i, np_t, sWqu, sWqu, sBbi};
                    gl_move = (np_i | (np_t << 6) | (11 << 12) | (11 << 16) | (6 << 20));
                    CHILD(ply);

                    //if (checksearch==false) {
                    if (isAttByBla(WkiPos) == false) {
										  if (isAttByBla(np_t) == false) {
												saveWhiPosition(np_offs); np_offs++;
                      }
                      else {
                      	#ifdef QS_MATES
				                if (isAttByWhi(BkiPos)==true) {
		                      if (isBkiMated()==true) {
									          saveWhiPosition(np_offs); np_offs++;
									          PARENT(ply); goto END;
									        };
                        };
										    #endif
											};
                    };

                    //}
                    /*
                    else {
                    if (isWhiCheckGood(BkiPos)==true) {
                       if (isAttByBla(WkiPos)==false) {
                         saveWhiPosition(np_offs); np_offs++;
                        };
                      };
                    };
                    */
                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sBkn: { //move m = {np_i, np_t, sWqu, sWqu, sBkn};
                    gl_move = (np_i | (np_t << 6) | (11 << 12) | (11 << 16) | (8 << 20));
                    CHILD(ply);

                    //if (checksearch==false) {
                    if (isAttByBla(WkiPos) == false) {
										  if (isAttByBla(np_t) == false) {
												saveWhiPosition(np_offs); np_offs++;
                      }
                      else {
                      	#ifdef QS_MATES
				                if (isAttByWhi(BkiPos)==true) {
		                      if (isBkiMated()==true) {
									          saveWhiPosition(np_offs); np_offs++;
									          PARENT(ply); goto END;
									        };
                        };
										    #endif
											};
                    };

                    //}
                    /*
                    else {
                    if (isWhiCheckGood(BkiPos)==true) {
                       if (isAttByBla(WkiPos)==false) {
                         saveWhiPosition(np_offs); np_offs++;
                        };
                      };
                    };
                    */
                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sBqu: { //move m = {np_i, np_t, sWqu, sWqu, sBqu};
                    gl_move = (np_i | (np_t << 6) | (11 << 12) | (11 << 16) | (12 << 20));
                    CHILD(ply);

                    if (isAttByBla(WkiPos) == false) {
                      saveWhiPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                default
                    : {
                    np_c = 8;
                  };
              };
            };
          };
        };

        break;
      default
          : {
          ;
        };
    };
  };

  END:{;};

/*
//in qs whi ply
#ifdef REUSE_EVAL
  do_reuse_eval = false;
#endif
*/

//if mate is found: dont save other moves to the tree:
//just one mating move.
//this will reduce tree size in full search and in qs
//save sorted moves to the tree in the right order
  if (
	(grade[0] == MAX_SCORE)
	&& (np_offs > 0)
	&& (ply > 1)
	) {
		np_offs = 1;
    MOVES_TREE[(ply << 8) | 0] = mymove[0]; //assign matingmove to the TREE
		UnsPosTree[(ply << 8) | 0].lastMove = mymove[0];
    VALS_TREE[(ply << 8) | 0] = MAX_SCORE; //assign matescore to the TREE
    //cout<<"mating move: "<<printMove(mymove[0])<<endl; printB("WHITE MATES:");

    #ifdef DEBUG_VERSION
    qsply_positions_count += np_offs;
    mate_qsply_branch_count++;
    qsply_branch_count++;
    #endif

		return np_offs; //return offset==1 mating move
  };

//////////////////////////////////////////
  /*
  now capture moves are sorted only by winned material
  reorder them:
    if the same captured piece in move B and A
     endless loop: if (B from piece > A from piece) swap moves and continue swaps until noncap found.
     break if no swap found
  */
#ifdef ATTA_REORD
  if (np_offs > 1)
    //if at least two moves
  {
    goto AR_LOOP;
AR_LOOP: {
      np_i = 1; //take second move index

      while (np_i < np_offs)
        //until offset end
      {
        gl_cp = ((mymove[np_i] << 8) >> 28);    //take second move captured piece

        if (gl_cp != 0)
          //if capture
        {
          if (gl_cp == ((mymove[np_i - 1] << 8) >> 28)
             )
            //if the same captured piece type
          {
            ///if order of attackers to improve
            if ((UnsignedMaterialValue[((mymove[np_i] << 16) >> 28) ])
                <
                (UnsignedMaterialValue[((mymove[np_i - 1] << 16) >> 28) ])) {
              //swap moves and grades
              ar_move = mymove[np_i - 1];
              ar_grade = grade[np_i - 1];
              mymove[np_i - 1] = mymove[np_i];
              grade[np_i - 1] = grade[np_i];
              mymove[np_i] = ar_move;
              grade[np_i] = ar_grade;
              //repeat from beginning
              goto AR_LOOP;
            };
          };
        };

        np_i++;
      };
    };
  };

#endif
//////////////////////////////////////////
#ifdef NULL_MOVE
//insert null-move to the ply if allowed -
//the move would be eventually insorted if no mating move
//(mate is always first and only move in the ply)
//move will not be later saved if mate was found (restricted offset)
//or if not position under check (this would lead to illegal position)

//IF NODE IS NOT PV NODE
//if no null move set upper
  if ((nms_flag==false) && (nms_set[ply-1]==false)) {
    //if proper max ply
    //if (ply<qDepth-nms_reduction) {
    if (ply < qDepth) {
      //if (MOVES_TREE[((ply-1)<<8)|cur_offs[ply-1]]>2) {
      //if self king not in check
      if (CheckStatus[ply - 1] == false) {
        //if no check in the path
        //if (first_check_depth==0) {
        //if enough self material /little chance for zugzwang
        if ((WquNum > 0) || (WroNum > 0)) {
          //if proper min ply
          if (ply >= nms_min_ply) {
            //suitable move for black
            gl_move = 1;
            CHILD(ply);
            //if (isAttByWhi(BkiPos)==false) {saveBlaPosition(np_offs); np_offs++;};
            saveWhiPosition(np_offs);
            np_offs++;
            PARENT(ply);
          };
        };
      };
    };
  };
#endif

#ifdef CHECK_REORD
//////////////////////////////////////////
//do another sorting: search moves from the best to the weakest
//if check in the ply is found:
//if the first move is null - continue
//if the move is check - continue
//reorder moves
  /*
  np_i = 0;
  cout<<"moves BEFORE check_reord: "<<flush;
  while (np_i<np_offs) {
   cout<<"["<<np_i<<"]:"<<printMove(mymove[np_i])<<" "<<flush;
    np_i++;
  };
  cout<<endl;
  */
//take second move if any
  np_i = 1;

  while (np_i < np_offs) {
    //if the move causes the black king is checked
    if (mymove[np_i] == (mymove[np_i] | (1 << 30))) {
      //save this move
      ar_move = mymove[np_i];
      ar_grade = grade[np_i];
      //move all moves before it
      //which are not null move nor check ahead one step
      np_j = np_i;

      //if we have no null move first in the ply
      if (mymove[0] != 1) {
        //if safe bound
        while (np_j > 0) {
          //if previous move is not check
          if (mymove[np_j - 1] != (mymove[np_j - 1] | (1 << 30))) {
            //just move it ahead and consider previous move
            mymove[np_j] = mymove[np_j - 1];
            grade[np_j] = grade[np_j - 1];
            np_j--;
          }
          //if previous move is check - break at curent index
          else {
            break;
          };
        };

        //move save ar_move and ar grade into curent index
        mymove[np_j] = ar_move;

        grade[np_j] = ar_grade;
      }
      //if we have null move first
      else {
        //if safe bound
        while (np_j > 1) {
          //if previous move is not check
          if (mymove[np_j - 1] != (mymove[np_j - 1] | (1 << 30))) {
            //just move it ahead and consider previous move
            mymove[np_j] = mymove[np_j - 1];
            grade[np_j] = grade[np_j - 1];
            np_j--;
          }
          //if previous move is check - break at curent index
          else {
            break;
          };
        };

        //move save ar_move and ar grade into curent index
        mymove[np_j] = ar_move;

        grade[np_j] = ar_grade;
      };
    };

    np_i++;
  };

//////////////////
  /*
  np_i = 0;
    cout<<"moves AFTER check_reord: "<<flush;
  while (np_i<np_offs) {
   cout<<"["<<np_i<<"]:"<<printMove(mymove[np_i])<<" "<<flush;
    np_i++;
  };
    cout<<endl;
    */
///////////////
#endif
//////////////////////////////
//save sorted and marked data into the tree
 finishSavePositionInNewPly();

#ifdef CUTTOFF_MOVE_HASH_REORDER

////////////////////////////////////////////////////////////////////
//reorder the cuttoff move if found in the beginning of the ply
//if Zkey matches and there is available the best move which produced a cuttoff
//HT==
//[Zkey(64bits)]
//[score(20bits)-val(20bits)-ply(6bits)-qDepth(6bits)-BestMovetofrom(12bits)]
  if (ply > 1) {
    Hkey = (Zkey >> (Zkeylen - Hkeylen));

    if (HT[Hkey][0] == Zkey) {
      if (((HT[Hkey][1] << 52) >> 52)
          != 0)
        //if best move available
      {
        //find the best move index
        np_i = 0;

        while (np_i < np_offs) {
          //if the move coords matches insort it into the beginning of the ply
          if (((MOVES_TREE[np_c | np_i] << 20) >> 20)
              == ((HT[Hkey][1] << 52) >> 52)) {
            //cout<<"best move:"<<printMove(MOVES_TREE[np_c|np_i])<<
            //"at idx:"<<np_i<<endl;
            //copy the value of found move
            se_v = VALS_TREE[np_c | np_i];

            //copy all moves and values one move forward to the found move pos
            for (se_j = np_i; se_j > 0; se_j--) {
              MOVES_TREE[np_c | se_j] = MOVES_TREE[np_c | (se_j - 1) ];
              VALS_TREE[np_c | se_j] = VALS_TREE[np_c | (se_j - 1) ];
            };

            //paste found move and its value in the first move pos
            MOVES_TREE[np_c | 0] = MOVES_TREE[np_c | np_i];

            VALS_TREE[np_c | 0] = se_v;

            break;
          };

          np_i++;
        };
      };
    };
  };

//////////////////////////////////////////////
#endif

#ifdef DEBUG_VERSION
//cout<<"QS white offset:"<<np_offs<<endl;
  qsply_positions_count += np_offs;
  qsply_branch_count++;
  if (np_offs==0) {empty_qsply_branch_count++;};
#endif

	return np_offs;

////////////////////////////
};

unsigned char FULL_BLA_PLY(unsigned char ply)
{
//set side to move to properly eval
  side = true;

//set initial data tables of this ply before the move stored in the ply
  castle_dat = castle_data[ply - 1];

  Zkey = Zkey_tab[ply - 1];

  enpassant = enp_sq[ply - 1];

  retract = retract_tab[ply - 1];

	shifted_np_ply = (ply<<8); //static used in saving position data

//loop board
  np_offs = 0;

/*
#ifdef NULL_MOVE
//insert null-move to the ply if allowed -
//the move would be eventually insorted if no mating move
//(mate is always first and only move in the ply)
//move will not be later saved if mate was found (restricted offset)
//or if not position under check (this would lead to illegal position)

//IF NODE IS NOT PV NODE
//if no null move set upper
  if (nms_set[ply-1] == false) {
    //if proper max ply
    //if (ply<qDepth-nms_reduction) {
    if (ply < qDepth) {
      //if (MOVES_TREE[((ply-1)<<8)|cur_offs[ply-1]]>2) {
      //if self king not in check
      if (CheckStatus[ply - 1] == false) {
        //if no check in the path
        //if (first_check_depth==0) {
        //if enough self material /little chance for zugzwang
        if ((BquNum > 0) || (BroNum > 0)) {
          //if proper min ply
          if (ply >= nms_min_ply) {
            //suitable move for black
            gl_move = 2;
            CHILD(ply);
            //if (isAttByWhi(BkiPos)==false) {saveBlaPosition(np_offs); np_offs++;};
            saveBlaPosition(np_offs);
            np_offs++;
            PARENT(ply);
          };
        };
      };
    };
  };

#endif
*/

  for (np_i = 0; np_i < 64; np_i++) {
    switch (B[np_i]) {
      case
          sBpa: {
          if (np_i < 16) {
            np_t = LBPCaps[np_i];

            switch (B[np_t]) {
              case
                  sWpa: { //analyse {np_i, np_t, sBpa, sBpa, sWpa};
                  gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (1 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWro: { //analyse {np_i, np_t, sBpa, sBpa, sWro};
                  gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (3 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWbi: { //analyse {np_i, np_t, sBpa, sBpa, sWbi};
                  gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (5 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWkn: { //analyse {np_i, np_t, sBpa, sBpa, sWkn};
                  gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (7 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWqu: { //analyse {np_i, np_t, sBpa, sBpa, sWqu};
                  gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (11 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
            };

            np_t = RBPCaps[np_i];

            switch (B[np_t]) {
              case
                  sWpa: { //analyse {np_i, np_t, sBpa, sBpa, sWpa};
                  gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (1 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWro: { //analyse {np_i, np_t, sBpa, sBpa, sWro};
                  gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (3 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWbi: { //analyse {np_i, np_t, sBpa, sBpa, sWbi};
                  gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (5 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWkn: { //analyse {np_i, np_t, sBpa, sBpa, sWkn};
                  gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (7 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWqu: { //analyse {np_i, np_t, sBpa, sBpa, sWqu};
                  gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (11 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
            };

            np_t = np_i + 8;

            if (B[np_t] == sEmp) {
              gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16));
              CHILD(ply);

              if (isAttByWhi(BkiPos) == false) {
                saveBlaPosition(np_offs);
                np_offs++;
              };

              PARENT(ply);

              np_t += 8;

              if (B[np_t] == sEmp) {
                gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16));
                CHILD(ply);

                if (isAttByWhi(BkiPos) == false) {
                  saveBlaPosition(np_offs);
                  np_offs++;
                };

                PARENT(ply);
              };
            };
          }
          // IF PAWN IS IN THE MIDDLEBOARD
          else
            if (np_i < 48) {
              np_t = LBPCaps[np_i];

              switch (B[np_t]) {
                case
                    sEmp: { //analyse enpassant capture
                    if ((enp_sq[ply - 1] == np_t) && (np_t != 64)) {
                      //{np_i, np_t, sWpa, sBpa};
                      gl_move = (np_i | (np_t << 6) | (2 << 12) | (1 << 16));
                      CHILD(ply);

                      if (isAttByWhi(BkiPos) == false) {
                        saveBlaPosition(np_offs);
                        np_offs++;
                      };

                      PARENT(ply);
                    };
                  };

                  break;
                case
                    sWpa: { //analyse {np_i, np_t, sBpa, sBpa, sWpa};
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (1 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sWro: { //analyse {np_i, np_t, sBpa, sBpa, sWro};
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (3 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sWbi: { //analyse {np_i, np_t, sBpa, sBpa, sWbi};
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (5 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sWkn: { //analyse {np_i, np_t, sBpa, sBpa, sWkn};
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (7 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sWqu: { //analyse {np_i, np_t, sBpa, sBpa, sWqu};
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (11 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
              };

              np_t = RBPCaps[np_i];

              switch (B[np_t]) {
                case
                    sEmp: { //analyse enpassant capture
                    if ((enp_sq[ply - 1] == np_t) && (np_t != 64)) {
                      //{np_i, np_t, sWpa, sBpa};
                      gl_move = (np_i | (np_t << 6) | (2 << 12) | (1 << 16));
                      CHILD(ply);

                      if (isAttByWhi(BkiPos) == false) {
                        saveBlaPosition(np_offs);
                        np_offs++;
                      };

                      PARENT(ply);
                    };
                  };

                  break;
                case
                    sWpa: { //analyse {np_i, np_t, sBpa, sBpa, sWpa};
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (1 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sWro: { //analyse {np_i, np_t, sBpa, sBpa, sWro};
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (3 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sWbi: { //analyse {np_i, np_t, sBpa, sBpa, sWbi};
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (5 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sWkn: { //analyse {np_i, np_t, sBpa, sBpa, sWkn};
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (7 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sWqu: { //analyse {np_i, np_t, sBpa, sBpa, sWqu};
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (11 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
              };

              np_t = np_i + 8;

              if (B[np_t] == sEmp) {
                gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16));
                CHILD(ply);

                if (isAttByWhi(BkiPos) == false) {
                  saveBlaPosition(np_offs);
                  np_offs++;
                };

                PARENT(ply);
              };
            }
          //  ELSE IF PAWN IS IN THE SECOND ROW
          //  handle PROMOTION IF PAWN CAN MOVE AHEAD
            else {
              np_t = np_i + 8;
              np_allow = false;

              if (B[np_t] == sEmp) {
                gl_move = (np_i | (np_t << 6) | (2 << 12) | (12 << 16));
                CHILD(ply);

                if (isAttByWhi(BkiPos) == false) {
                  np_allow = true;
                  saveBlaPosition(np_offs);
                  np_offs++;
                };

                PARENT(ply);

                gl_move = (np_i | (np_t << 6) | (2 << 12) | (4 << 16));

                CHILD(ply);

                if (np_allow == true) {
                  saveBlaPosition(np_offs);
                  np_offs++;
                };

                PARENT(ply);

                gl_move = (np_i | (np_t << 6) | (2 << 12) | (6 << 16));

                CHILD(ply);

                if (np_allow == true) {
                  saveBlaPosition(np_offs);
                  np_offs++;
                };

                PARENT(ply);

                gl_move = (np_i | (np_t << 6) | (2 << 12) | (8 << 16));

                CHILD(ply);

                if (np_allow == true) {
                  saveBlaPosition(np_offs);
                  np_offs++;
                };

                PARENT(ply);
              };

              // handle PROMOTION if PAWN CAPTURED
              np_t = LBPCaps[np_i];

              switch (B[np_t]) {
                  // if opponent rook is captured - memorize the possible promotions
                case
                    sWro: {
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (12 << 16) | (3 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      np_allow = true;
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (4 << 16) | (3 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (6 << 16) | (3 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (8 << 16) | (3 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;

                  // if opponent bishop is captured - memorize the possible promotions
                case
                    sWbi: {
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (12 << 16) | (5 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      np_allow = true;
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (4 << 16) | (5 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (6 << 16) | (5 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (8 << 16) | (5 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;

                  // if opponent knight is captured - memorize the possible promotions
                case
                    sWkn: {
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (12 << 16) | (7 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      np_allow = true;
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (4 << 16) | (7 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (6 << 16) | (7 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (8 << 16) | (7 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;

                  // if opponent queen is captured - memorize the move
                case
                    sWqu: {
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (12 << 16) | (11 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      np_allow = true;
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (4 << 16) | (11 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (6 << 16) | (11 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (8 << 16) | (11 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
              };

              np_t = RBPCaps[np_i];

              switch (B[np_t]) {
                  // if opponent rook is captured - memorize the possible promotions
                case
                    sWro: {
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (12 << 16) | (3 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      np_allow = true;
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (4 << 16) | (3 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (6 << 16) | (3 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (8 << 16) | (3 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;

                  // if opponent bishop is captured - memorize the possible promotions
                case
                    sWbi: {
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (12 << 16) | (5 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      np_allow = true;
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (4 << 16) | (5 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (6 << 16) | (5 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (8 << 16) | (5 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;

                  // if opponent knight is captured - memorize the possible promotions
                case
                    sWkn: {
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (12 << 16) | (7 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      np_allow = true;
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (4 << 16) | (7 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (6 << 16) | (7 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (8 << 16) | (7 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;

                  // if opponent queen is captured - memorize the move
                case
                    sWqu: {
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (12 << 16) | (11 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      np_allow = true;
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (4 << 16) | (11 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (6 << 16) | (11 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (8 << 16) | (11 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
              };
            };
        };

        break;
      case
          sBro: {
          for (np_v = 4; np_v < 8; np_v++) {
            for (np_c = 0; np_c < 8; np_c++) {
              np_t = Vec[np_v][np_i][np_c];

              switch (B[np_t]) {
                case
                    sEmp: { //move m = {np_i, np_t, sBro, sBro, '0'};
                    gl_move = (np_i | (np_t << 6) | (4 << 12) | (4 << 16));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sWpa: { //move m = {np_i, np_t, sBro, sBro, sWpa};
                    gl_move = (np_i | (np_t << 6) | (4 << 12) | (4 << 16) | (1 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sWro: { //move m = {np_i, np_t, sBro, sBro, sWro};
                    gl_move = (np_i | (np_t << 6) | (4 << 12) | (4 << 16) | (3 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sWbi: { //move m = {np_i, np_t, sBro, sBro, sWbi};
                    gl_move = (np_i | (np_t << 6) | (4 << 12) | (4 << 16) | (5 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sWkn: { //move m = {np_i, np_t, sBro, sBro, sWkn};
                    gl_move = (np_i | (np_t << 6) | (4 << 12) | (4 << 16) | (7 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sWqu: { //move m = {np_i, np_t, sBro, sBro, sWqu};
                    gl_move = (np_i | (np_t << 6) | (4 << 12) | (4 << 16) | (11 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                default
                    : {
                    np_c = 8;
                  };
              };
            };
          };
        };

        break;
      case
          sBbi: {
          for (np_v = 0; np_v < 4; np_v++) {
            for (np_c = 0; np_c < 8; np_c++) {
              np_t = Vec[np_v][np_i][np_c];

              switch (B[np_t]) {
                case
                    sEmp: { //move m = {np_i, np_t, sBbi, sBbi, '0'};
                    gl_move = (np_i | (np_t << 6) | (6 << 12) | (6 << 16));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sWpa: { //move m = {np_i, np_t, sBbi, sBbi, sWpa};
                    gl_move = (np_i | (np_t << 6) | (6 << 12) | (6 << 16) | (1 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sWro: { //move m = {np_i, np_t, sBbi, sBbi, sWro};
                    gl_move = (np_i | (np_t << 6) | (6 << 12) | (6 << 16) | (3 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sWbi: { //move m = {np_i, np_t, sBbi, sBbi, sWbi};
                    gl_move = (np_i | (np_t << 6) | (6 << 12) | (6 << 16) | (5 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sWkn: { //move m = {np_i, np_t, sBbi, sBbi, sWkn};
                    gl_move = (np_i | (np_t << 6) | (6 << 12) | (6 << 16) | (7 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sWqu: { //move m = {np_i, np_t, sBbi, sBbi, sWqu};
                    gl_move = (np_i | (np_t << 6) | (6 << 12) | (6 << 16) | (11 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                default
                    : {
                    np_c = 8;
                  };
              };
            };
          };
        };

        break;

        // analyse self knight
      case
          sBkn: {
          for (np_c = 0; np_c < 8; np_c++) {
            np_t = increasingKnightMap[np_i][np_c];

            switch (B[np_t]) {
              case
                  sEmp: { //move m = {np_i, np_t, sBkn, sBkn, '0'};
                  gl_move = (np_i | (np_t << 6) | (8 << 12) | (8 << 16));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWpa: { //move m = {np_i, np_t, sBkn, sBkn, sWpa};
                  gl_move = (np_i | (np_t << 6) | (8 << 12) | (8 << 16) | (1 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWro: { //move m = {np_i, np_t, sBkn, sBkn, sWro};
                  gl_move = (np_i | (np_t << 6) | (8 << 12) | (8 << 16) | (3 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWbi: { //move m = {np_i, np_t, sBkn, sBkn, sWbi};
                  gl_move = (np_i | (np_t << 6) | (8 << 12) | (8 << 16) | (5 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWkn: { //move m = {np_i, np_t, sBkn, sBkn, sWkn};
                  gl_move = (np_i | (np_t << 6) | (8 << 12) | (8 << 16) | (7 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWqu: { //move m = {np_i, np_t, sBkn, sBkn, sWqu};
                  gl_move = (np_i | (np_t << 6) | (8 << 12) | (8 << 16) | (11 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
							  sOut: {break;}; break;
            };
          };
        };

        break;
      case
          sBki: {
          // if positive k-side castle status
          if (castle_dat != (castle_dat | castle_lost_BKK_mask)) {
            //if king not checked
            if (CheckStatus[ply - 1] == false) {
              //if empty two squares on the right side of the king
              if (B[5] == sEmp) {
                if (B[6] == sEmp) {
                  //if empty squares are not in check
                  if (isAttByWhi(5) == false) {
                    if (isAttByWhi(6) == false) {
                      //add k-side castle move
                      //move m = {4, 6, sBki, sBki, '0'}; and move m = {7, 5, sBro, sBro, '0'};
                      gl_move = (4 | (6 << 6) | (10 << 12) | (10 << 16));
                      CHILD(ply);
                      saveBlaPosition(np_offs);
                      np_offs++;
                      PARENT(ply);
                    };
                  };
                };
              };
            };
          };

          // if positive q-side castle status
          if (castle_dat != (castle_dat | castle_lost_BKQ_mask)) {
            //if king not checked
            if (CheckStatus[ply - 1] == false) {
              //if empty THREE squares on the left side of the king
              if (B[3] == sEmp) {
                if (B[2] == sEmp) {
                  if (B[1] == sEmp) {
                    //if TWO empty squares are not in check
                    if (isAttByWhi(3) == false) {
                      if (isAttByWhi(2) == false) {
                        //add q-side castle move
                        //move m = {4, 2, sBki, sBki, '0'}; and move m = {0, 3, sBro, sBro, '0'};
                        gl_move = (4 | (2 << 6) | (10 << 12) | (10 << 16));
                        CHILD(ply);
                        saveBlaPosition(np_offs);
                        np_offs++;
                        PARENT(ply);
                      };
                    };
                  };
                };
              };
            };
          };

          for (np_v = 0; np_v < 8; np_v++) {
            np_t = Vec[np_v][np_i][0];

            switch (B[np_t]) {
              case
                  sEmp: { //move m = {np_i, np_t, sBki, sBki, '0'};
                  gl_move = (np_i | (np_t << 6) | (10 << 12) | (10 << 16));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWpa: { //move m = {np_i, np_t, sBki, sBki, sWpa};
                  gl_move = (np_i | (np_t << 6) | (10 << 12) | (10 << 16) | (1 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWro: { //move m = {np_i, np_t, sBki, sBki, sWro};
                  gl_move = (np_i | (np_t << 6) | (10 << 12) | (10 << 16) | (3 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWbi: { //move m = {np_i, np_t, sBki, sBki, sWbi};
                  gl_move = (np_i | (np_t << 6) | (10 << 12) | (10 << 16) | (5 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWkn: { //move m = {np_i, np_t, sBki, sBki, sWkn};
                  gl_move = (np_i | (np_t << 6) | (10 << 12) | (10 << 16) | (7 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWqu: { //move m = {np_i, np_t, sBki, sBki, sWqu};
                  gl_move = (np_i | (np_t << 6) | (10 << 12) | (10 << 16) | (11 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
            };
          };
        };

        break;
      case
          sBqu: {
          for (np_v = 0; np_v < 8; np_v++) {
            for (np_c = 0; np_c < 8; np_c++) {
              np_t = Vec[np_v][np_i][np_c];

              switch (B[np_t]) {
                case
                    sEmp: { //move m = {np_i, np_t, sBqu, sBqu, '0'};
                    gl_move = (np_i | (np_t << 6) | (12 << 12) | (12 << 16));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sWpa: { //move m = {np_i, np_t, sBqu, sBqu, sWpa};
                    gl_move = (np_i | (np_t << 6) | (12 << 12) | (12 << 16) | (1 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sWro: { //move m = {np_i, np_t, sBqu, sBqu, sWro};
                    gl_move = (np_i | (np_t << 6) | (12 << 12) | (12 << 16) | (3 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sWbi: { //move m = {np_i, np_t, sBqu, sBqu, sWbi};
                    gl_move = (np_i | (np_t << 6) | (12 << 12) | (12 << 16) | (5 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sWkn: { //move m = {np_i, np_t, sBqu, sBqu, sWkn};
                    gl_move = (np_i | (np_t << 6) | (12 << 12) | (12 << 16) | (7 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sWqu: { //move m = {np_i, np_t, sBqu, sBqu, sWqu};
                    gl_move = (np_i | (np_t << 6) | (12 << 12) | (12 << 16) | (11 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                default
                    : {
                    np_c = 8;
                  };
              };
            };
          };
        };

        break;
      default
          : {
          ;
        };
    };
  };

  //END:{;};

//if mate is found: dont save other moves to the tree:
//just one mating move.
//this will reduce tree size in full search and in qs
//save sorted moves to the tree in the right order
  if ((grade[0] == MIN_SCORE)
	&& (np_offs > 0)
	//&& (ply > 1)
	) {
    np_offs = 1;
    MOVES_TREE[(ply << 8) | 0] = mymove[0]; //assign matingmove to the TREE
    UnsPosTree[(ply << 8) | 0].lastMove = mymove[0];
    VALS_TREE[(ply << 8) | 0] = MIN_SCORE; //assign matescore to the TREE
    //cout<<"mating move: "<<printMove(mymove[0])<<endl; printB("MATE:");

		#ifdef DEBUG_VERSION
		fullply_positions_count += np_offs;
		fullply_branch_count++;
    if (ply == qDepth) {
      terminal_fullply_branch_count++;
    };
    mate_fullply_branch_count++;
		#endif

		return np_offs; //return offset==1 mating move
  };

//////////////////////////////////////////
  /*
  now capture moves are sorted only by winned material
  reorder them:
    if the same captured piece in move B and A
     endless loop: if (B from piece > A from piece) swap moves and continue swaps until noncap found.
     break if no swap found
  */
#ifdef ATTA_REORD
  if (np_offs > 1)
    //if at least two moves
  {
    goto AR_LOOP;
AR_LOOP: {
      np_i = 1; //take second move index

      while (np_i < np_offs)
        //until offset end
      {
        gl_cp = ((mymove[np_i] << 8) >> 28);    //take second move captured piece

        if (gl_cp != 0)
          //if noncap
        {
          if (gl_cp == ((mymove[np_i - 1] << 8) >> 28)
             )
            //if the same captured piece type
          {
            ///if order of attackers to improve
            if ((UnsignedMaterialValue[((mymove[np_i] << 16) >> 28) ])
                <
                (UnsignedMaterialValue[((mymove[np_i - 1] << 16) >> 28) ])) {
              //swap moves and grades
              ar_move = mymove[np_i - 1];
              ar_grade = grade[np_i - 1];
              mymove[np_i - 1] = mymove[np_i];
              grade[np_i - 1] = grade[np_i];
              mymove[np_i] = ar_move;
              grade[np_i] = ar_grade;
              //repeat from beginning
              goto AR_LOOP;
            };
          };
        };

        np_i++;
      };
    };
  };

#endif
//////////////////////////////////////////
/*
#ifdef NULL_MOVE
//reorder null move at first position
  np_i = 0;

  while (np_i < np_offs) {
    if (mymove[np_i] == 2) {
      ar_move = mymove[np_i];
      ar_grade = grade[np_i];

      while (np_i > 0) {
        //just move it ahead and consider previous move
        mymove[np_i] = mymove[np_i - 1];
        grade[np_i] = grade[np_i - 1];
        np_i--;
      };

      mymove[np_i] = ar_move; //index zero

      grade[np_i] = ar_grade;

      break;
    };

    np_i++;
  };

#endif
*/

#ifdef CHECK_REORD
//////////////////////////////////////////
//do another sorting: search moves from the best to the weakest
//if check in the ply is found:
//if the first move is null - continue
//if the move is check - continue
//reorder moves
  /*
  np_i = 0;
  cout<<"moves BEFORE check_reord: "<<flush;
  while (np_i<np_offs) {
   cout<<"["<<np_i<<"]:"<<printMove(mymove[np_i])<<" "<<flush;
    np_i++;
  };
  cout<<endl;
  */
//take second move if any
  np_i = 1;

  while (np_i < np_offs) {
    //if the move causes the white king is checked
    if (mymove[np_i] == (mymove[np_i] | (1 << 31))) {
      //save this move
      ar_move = mymove[np_i];
      ar_grade = grade[np_i];
      //move all moves before it
      //which are not null move nor check ahead one step
      np_j = np_i;

      //if we have no null move first in the ply
      if (mymove[0] != 2) {
        //if safe bound
        while (np_j > 0) {
          //if previous move is not check
          if (mymove[np_j - 1] != (mymove[np_j - 1] | (1 << 31))) {
            //just move it ahead and consider previous move
            mymove[np_j] = mymove[np_j - 1];
            grade[np_j] = grade[np_j - 1];
            np_j--;
          }
          //if previous move is check - break at curent index
          else {
            break;
          };
        };

        //move save ar_move and ar grade into curent index
        mymove[np_j] = ar_move;

        grade[np_j] = ar_grade;
      }
      //if we have null move first
      else {
        //if safe bound
        while (np_j > 1) {
          //if previous move is not check
          if (mymove[np_j - 1] != (mymove[np_j - 1] | (1 << 31))) {
            //just move it ahead and consider previous move
            mymove[np_j] = mymove[np_j - 1];
            grade[np_j] = grade[np_j - 1];
            np_j--;
          }
          //if previous move is check - break at curent index
          else {
            break;
          };
        };

        //move save ar_move and ar grade into curent index
        mymove[np_j] = ar_move;

        grade[np_j] = ar_grade;
      };
    };

    np_i++;
  };

//////////////////
  /*
  if (mymove[0]==2) {
    cout<<"moves AFTER reord, bla nm: "<<flush;
  np_i = 0;
    while (np_i<np_offs) {
     cout<<"["<<np_i<<"]:"<<printMove(mymove[np_i])<<" "<<flush;
      np_i++;
    };
    cout<<endl;
    };
    */
#endif
  /*
  mark late moves in the ply by checking proper bit in proper moves
  */
/*
#ifdef LATE_MOVE
//LATE MOVE IN FULL BLA PLY
//IF NODE IS NOT PV NODE
//if no lmr flag set (upper)
  if (lmr_already_used == false) {
    //if proper max depth
    //if (ply+lmr_reduction<qDepth) {
    if (ply == 2) {
      //if not escaping from check
      if (CheckStatus[ply - 1] == false) {
        //if no check in the path
        //if (first_check_depth==0) {
        //if proper min depth
        //if (ply>=lmr_min_ply) {
        //start from minimum lmr index
        np_i = lmr_min_idx;
        //save value of parent
        ar_grade = VALS_TREE[((ply - 1) << 8) | cur_offs[ply - 1]];

        //if null move at zero index  - increment minimum lmr index
        //if (mymove[0] < 3) {
          //np_i++;
					// if parent move is not forcing move (marked by null move search)
					//if (MOVES_TREE[((ply - 1) << 8) | cur_offs[ply - 1]]
					//!= (MOVES_TREE[((ply - 1) << 8) | cur_offs[ply - 1]] | forced_pos_mask)) {

		        //clear lmr_real_offs
		        //lmr_real_offs = 0;
		    while (np_i < np_offs) {

			        //if static eval after move is worse than that of the parent
			        //or if static eval is little better (no capture, promotion, enpassant capture happened)
			    if (grade[np_i] + evLateMoveMargin > ar_grade) {
			          //if the move is noncapture
			          //if (((mymove[np_i]<<8)>>28)==0) {
			          //if the move generated positive forced_pos
			          //if (mymove[np_i] == (mymove[np_i]|forced_pos_mask)) {
			          //if wki_checked_mask is clear
			      if (mymove[np_i] != (mymove[np_i] | (1 << 31))) {
			            //if the move is not pawn promotion threat
			            //set lmr move flag
			            //lmr_real_offs++;
			            //if (lmr_real_offs<3) {continue;};
			        mymove[np_i] |= (1 << 29);
			            //cout<<"lmr offset:"<<np_i<<", move:"<<printMove(mymove[np_i])<<endl;
			      };

			          //};
			    };

			    np_i++;
        };
      };
    };
  };

#endif
*/
  /*
  //////////////////////////////
    cout<<"Bla late moves report (ply:"<<ply<<", qDepth:"<<qDepth<<"):"<<endl;
    np_i = 0;
  while (np_i<np_offs) {
   if (mymove[np_i]==(mymove[np_i] | (1<<29))) {
     cout<<"["<<np_i<<"]"<<printMove(mymove[np_i])<<"-late "<<flush;
   }
   else {
    cout<<"["<<np_i<<"]"<<printMove(mymove[np_i])<<"-norm "<<flush;
    };
   np_i++;
    };
    cout<<endl;
    /////////////////////////////
  */
//////////////////////////////
//save sorted and marked data into the tree
 finishSavePositionInNewPly();

#ifdef CUTTOFF_MOVE_HASH_REORDER

////////////////////////////////////////////////////////////////////
//reorder the cuttoff move if found in the beginning of the ply
//if Zkey matches and there is available the best move which produced a cuttoff
//HT==
//[Zkey(64bits)]
//[score(20bits)-val(20bits)-ply(6bits)-qDepth(6bits)-BestMovetofrom(12bits)]
  if (ply > 1) {
    Hkey = (Zkey >> (Zkeylen - Hkeylen));

    if (HT[Hkey][0] == Zkey) {
      if (((HT[Hkey][1] << 52) >> 52)
          != 0)
        //if best move available
      {
        //find the best move index
        np_i = 0;

        while (np_i < np_offs) {
          //if the move coords matches insort it into the beginning of the ply
          if (((MOVES_TREE[np_c | np_i] << 20) >> 20)
              == ((HT[Hkey][1] << 52) >> 52)) {
            //cout<<"best move:"<<printMove(MOVES_TREE[np_c|np_i])<<
            //"at idx:"<<np_i<<endl;
            //copy the value of found move
            se_v = VALS_TREE[np_c | np_i];

            //copy all moves and values one move forward to the found move pos
            for (se_j = np_i; se_j > 0; se_j--) {
              MOVES_TREE[np_c | se_j] = MOVES_TREE[np_c | (se_j - 1) ];
              VALS_TREE[np_c | se_j] = VALS_TREE[np_c | (se_j - 1) ];
            };

            //paste found move and its value in the first move pos
            MOVES_TREE[np_c | 0] = MOVES_TREE[np_c | np_i];

            VALS_TREE[np_c | 0] = se_v;

            break;
          };

          np_i++;
        };
      };
    };
  };

//////////////////////////////////////////////
#endif

#ifdef DEBUG_VERSION
  fullply_positions_count += np_offs;
  fullply_branch_count++;
  if (ply == qDepth) {
    terminal_fullply_branch_count++;
  };
  if (np_offs==0) {empty_fullply_branch_count++;};
#endif

	return np_offs;
};


unsigned char REST_BLA_PLY(unsigned char ply)
{
//set side to move to properly eval
  side = true;


//set initial data tables of this ply before the move stored in the ply
  castle_dat = castle_data[ply - 1];

  Zkey = Zkey_tab[ply - 1];

  enpassant = enp_sq[ply - 1];

  retract = retract_tab[ply - 1];

	shifted_np_ply = (ply<<8); //static used in saving position data

//loop board
  np_offs = 0;

/*
#ifdef NULL_MOVE
//insert null-move to the ply if allowed -
//the move would be eventually insorted if no mating move
//(mate is always first and only move in the ply)
//move will not be later saved if mate was found (restricted offset)
//or if not position under check (this would lead to illegal position)

//IF NODE IS NOT PV NODE
//if no null move set upper
  if (MOVES_TREE[((ply - 1) << 8) | cur_offs[ply - 1]] != 1) {
    //if proper max ply
    //if (ply<qDepth-nms_reduction) {
    if (ply < qDepth) {
      //if (MOVES_TREE[((ply-1)<<8)|cur_offs[ply-1]]>2) {
      //if self king not in check
      if (CheckStatus[ply - 1] == false) {
        //if no check in the path
        //if (first_check_depth==0) {
        //if enough self material /little chance for zugzwang
        if ((BquNum > 0) || (BroNum > 0)) {
          //if proper min ply
          if (ply >= nms_min_ply) {
            //suitable move for black
            gl_move = 2;
            CHILD(ply);
            //if (isAttByWhi(BkiPos)==false) {saveBlaPosition(np_offs); np_offs++;};
            saveBlaPosition(np_offs);
            np_offs++;
            PARENT(ply);
          };
        };
      };
    };
  };
#endif
*/

#ifdef REUSE_EVAL
  //whole preeval table must be generated before the ply,
  //because in each child position we analyse whole board
  for (ev_fs = 0; ev_fs < 64; ev_fs++) {
		EV_SQUARE();
    SC[ev_fs] = ev_score;
  };
  do_reuse_eval = true;
#endif


  for (np_i = 0; np_i < 64; np_i++) {

		switch (B[np_i]) {
      case
          sBpa: {
          if (np_i < 16) {
            /*
						np_t = LBPCaps[np_i];

            switch (B[np_t]) {
              case
                  sWpa: { //analyse {np_i, np_t, sBpa, sBpa, sWpa};
                  gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (1 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWro: { //analyse {np_i, np_t, sBpa, sBpa, sWro};
                  gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (3 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWbi: { //analyse {np_i, np_t, sBpa, sBpa, sWbi};
                  gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (5 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWkn: { //analyse {np_i, np_t, sBpa, sBpa, sWkn};
                  gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (7 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWqu: { //analyse {np_i, np_t, sBpa, sBpa, sWqu};
                  gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (11 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
            };

            np_t = RBPCaps[np_i];

            switch (B[np_t]) {
              case
                  sWpa: { //analyse {np_i, np_t, sBpa, sBpa, sWpa};
                  gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (1 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWro: { //analyse {np_i, np_t, sBpa, sBpa, sWro};
                  gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (3 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWbi: { //analyse {np_i, np_t, sBpa, sBpa, sWbi};
                  gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (5 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWkn: { //analyse {np_i, np_t, sBpa, sBpa, sWkn};
                  gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (7 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWqu: { //analyse {np_i, np_t, sBpa, sBpa, sWqu};
                  gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (11 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
            };
            */

            np_t = np_i + 8;

            if (B[np_t] == sEmp) {
              gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16));
              CHILD(ply);

              if (isAttByWhi(BkiPos) == false) {
                saveBlaPosition(np_offs);
                np_offs++;
              };

              PARENT(ply);

              np_t += 8;

              if (B[np_t] == sEmp) {
                gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16));
                CHILD(ply);

                if (isAttByWhi(BkiPos) == false) {
                  saveBlaPosition(np_offs);
                  np_offs++;
                };

                PARENT(ply);
              };
            };
          }
          // IF PAWN IS IN THE MIDDLEBOARD
          else
            if (np_i < 48) {
              /*
							np_t = LBPCaps[np_i];

              switch (B[np_t]) {
                case
                    sEmp: { //analyse enpassant capture
                    if ((enp_sq[ply - 1] == np_t) && (np_t != 64)) {
                      //{np_i, np_t, sWpa, sBpa};
                      gl_move = (np_i | (np_t << 6) | (2 << 12) | (1 << 16));
                      CHILD(ply);

                      if (isAttByWhi(BkiPos) == false) {
                        saveBlaPosition(np_offs);
                        np_offs++;
                      };

                      PARENT(ply);
                    };
                  };

                  break;
                case
                    sWpa: { //analyse {np_i, np_t, sBpa, sBpa, sWpa};
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (1 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sWro: { //analyse {np_i, np_t, sBpa, sBpa, sWro};
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (3 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sWbi: { //analyse {np_i, np_t, sBpa, sBpa, sWbi};
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (5 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sWkn: { //analyse {np_i, np_t, sBpa, sBpa, sWkn};
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (7 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sWqu: { //analyse {np_i, np_t, sBpa, sBpa, sWqu};
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (11 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
              };

              np_t = RBPCaps[np_i];

              switch (B[np_t]) {
                case
                    sEmp: { //analyse enpassant capture
                    if ((enp_sq[ply - 1] == np_t) && (np_t != 64)) {
                      //{np_i, np_t, sWpa, sBpa};
                      gl_move = (np_i | (np_t << 6) | (2 << 12) | (1 << 16));
                      CHILD(ply);

                      if (isAttByWhi(BkiPos) == false) {
                        saveBlaPosition(np_offs);
                        np_offs++;
                      };

                      PARENT(ply);
                    };
                  };

                  break;
                case
                    sWpa: { //analyse {np_i, np_t, sBpa, sBpa, sWpa};
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (1 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sWro: { //analyse {np_i, np_t, sBpa, sBpa, sWro};
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (3 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sWbi: { //analyse {np_i, np_t, sBpa, sBpa, sWbi};
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (5 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sWkn: { //analyse {np_i, np_t, sBpa, sBpa, sWkn};
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (7 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sWqu: { //analyse {np_i, np_t, sBpa, sBpa, sWqu};
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (11 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
              };
              */

              np_t = np_i + 8;

              if (B[np_t] == sEmp) {
                gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16));
                CHILD(ply);

                if (isAttByWhi(BkiPos) == false) {
                  saveBlaPosition(np_offs);
                  np_offs++;
                };

                PARENT(ply);
              };
            }
          //  ELSE IF PAWN IS IN THE SECOND ROW
          //  handle PROMOTION IF PAWN CAN MOVE AHEAD
            else {
              np_t = np_i + 8;
              np_allow = false;

              if (B[np_t] == sEmp) {
                /*
								gl_move = (np_i | (np_t << 6) | (2 << 12) | (12 << 16));
                CHILD(ply);

                if (isAttByWhi(BkiPos) == false) {
                  np_allow = true;
                  saveBlaPosition(np_offs);
                  np_offs++;
                };

                PARENT(ply);
                */

                gl_move = (np_i | (np_t << 6) | (2 << 12) | (4 << 16));

                CHILD(ply);

                if (isAttByWhi(BkiPos) == false) {
                  np_allow = true;
                  saveBlaPosition(np_offs);
                  np_offs++;
                };

                PARENT(ply);


                gl_move = (np_i | (np_t << 6) | (2 << 12) | (6 << 16));

                CHILD(ply);

                if (np_allow == true) {
                  saveBlaPosition(np_offs);
                  np_offs++;
                };

                PARENT(ply);

                gl_move = (np_i | (np_t << 6) | (2 << 12) | (8 << 16));

                CHILD(ply);

                if (np_allow == true) {
                  saveBlaPosition(np_offs);
                  np_offs++;
                };

                PARENT(ply);
              };

              // handle PROMOTION if PAWN CAPTURED
              np_t = LBPCaps[np_i];

              switch (B[np_t]) {
                  // if opponent rook is captured - memorize the possible promotions
                case
                    sWro: {
                    np_allow = false;
                    /*
										gl_move = (np_i | (np_t << 6) | (2 << 12) | (12 << 16) | (3 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      np_allow = true;
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                    */

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (4 << 16) | (3 << 20));

                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      np_allow = true;
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (6 << 16) | (3 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (8 << 16) | (3 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;

                  // if opponent bishop is captured - memorize the possible promotions
                case
                    sWbi: {
                    np_allow = false;
                    /*
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (12 << 16) | (5 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      np_allow = true;
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                    */

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (4 << 16) | (5 << 20));

                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      np_allow = true;
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (6 << 16) | (5 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (8 << 16) | (5 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;

                  // if opponent knight is captured - memorize the possible promotions
                case
                    sWkn: {
                    np_allow = false;
                    /*
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (12 << 16) | (7 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      np_allow = true;
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
										*/
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (4 << 16) | (7 << 20));

                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      np_allow = true;
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (6 << 16) | (7 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (8 << 16) | (7 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;

                  // if opponent queen is captured - memorize the move
                case
                    sWqu: {
                    np_allow = false;
                    /*
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (12 << 16) | (11 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      np_allow = true;
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                    */

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (4 << 16) | (11 << 20));

                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      np_allow = true;
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (6 << 16) | (11 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (8 << 16) | (11 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
              };


              np_t = RBPCaps[np_i];

              np_t = LBPCaps[np_i];

              switch (B[np_t]) {
                  // if opponent rook is captured - memorize the possible promotions
                case
                    sWro: {
                    np_allow = false;
                    /*
										gl_move = (np_i | (np_t << 6) | (2 << 12) | (12 << 16) | (3 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      np_allow = true;
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                    */

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (4 << 16) | (3 << 20));

                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      np_allow = true;
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (6 << 16) | (3 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (8 << 16) | (3 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;

                  // if opponent bishop is captured - memorize the possible promotions
                case
                    sWbi: {
                    np_allow = false;
                    /*
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (12 << 16) | (5 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      np_allow = true;
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                    */

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (4 << 16) | (5 << 20));

                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      np_allow = true;
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (6 << 16) | (5 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (8 << 16) | (5 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;

                  // if opponent knight is captured - memorize the possible promotions
                case
                    sWkn: {
                    np_allow = false;
                    /*
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (12 << 16) | (7 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      np_allow = true;
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
										*/
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (4 << 16) | (7 << 20));

                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      np_allow = true;
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (6 << 16) | (7 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (8 << 16) | (7 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;

                  // if opponent queen is captured - memorize the move
                case
                    sWqu: {
                    np_allow = false;
                    /*
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (12 << 16) | (11 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      np_allow = true;
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                    */

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (4 << 16) | (11 << 20));

                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      np_allow = true;
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (6 << 16) | (11 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (8 << 16) | (11 << 20));

                    CHILD(ply);

                    if (np_allow == true) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
              };
            };
        };

        break;
      case
          sBro: {
          for (np_v = 4; np_v < 8; np_v++) {
            for (np_c = 0; np_c < 8; np_c++) {
              np_t = Vec[np_v][np_i][np_c];

              switch (B[np_t]) {
                case
                    sEmp: { //move m = {np_i, np_t, sBro, sBro, '0'};
                    gl_move = (np_i | (np_t << 6) | (4 << 12) | (4 << 16));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sWpa: { //move m = {np_i, np_t, sBro, sBro, sWpa};
                    gl_move = (np_i | (np_t << 6) | (4 << 12) | (4 << 16) | (1 << 20));
                    CHILD(ply);

										if (isAttByWhi(np_t) == true) { //bad trade
                      if (isAttByWhi(BkiPos) == false) {
                        saveBlaPosition(np_offs);
                        np_offs++;
                      };
                    };

										PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sWro: { //move m = {np_i, np_t, sBro, sBro, sWro};
                    /*
										gl_move = (np_i | (np_t << 6) | (4 << 12) | (4 << 16) | (3 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
										*/
                    np_c = 8;
                  };

                  break;
                case
                    sWbi: { //move m = {np_i, np_t, sBro, sBro, sWbi};
                    gl_move = (np_i | (np_t << 6) | (4 << 12) | (4 << 16) | (5 << 20));
                    CHILD(ply);

										if (isAttByWhi(np_t) == true) { //bad trade
                      if (isAttByWhi(BkiPos) == false) {
                        saveBlaPosition(np_offs);
                        np_offs++;
                      };
										};

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sWkn: { //move m = {np_i, np_t, sBro, sBro, sWkn};
                    gl_move = (np_i | (np_t << 6) | (4 << 12) | (4 << 16) | (7 << 20));
                    CHILD(ply);

										if (isAttByWhi(np_t) == true) { //bad trade
                      if (isAttByWhi(BkiPos) == false) {
                        saveBlaPosition(np_offs);
                        np_offs++;
                      };
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sWqu: { //move m = {np_i, np_t, sBro, sBro, sWqu};
                    /*
										gl_move = (np_i | (np_t << 6) | (4 << 12) | (4 << 16) | (11 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
										*/
                    np_c = 8;
                  };

                  break;
                default
                    : {
                    np_c = 8;
                  };
              };
            };
          };
        };

        break;
      case
          sBbi: {
          for (np_v = 0; np_v < 4; np_v++) {
            for (np_c = 0; np_c < 8; np_c++) {
              np_t = Vec[np_v][np_i][np_c];

              switch (B[np_t]) {
                case
                    sEmp: { //move m = {np_i, np_t, sBbi, sBbi, '0'};
                    gl_move = (np_i | (np_t << 6) | (6 << 12) | (6 << 16));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sWpa: { //move m = {np_i, np_t, sBbi, sBbi, sWpa};
                    gl_move = (np_i | (np_t << 6) | (6 << 12) | (6 << 16) | (1 << 20));
                    CHILD(ply);


										if (isAttByWhi(np_t) == true) { //bad trade
                      if (isAttByWhi(BkiPos) == false) {
                        saveBlaPosition(np_offs);
                        np_offs++;
                      };
										};

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;

                case
                  sWro: { //move m = {np_i, np_t, sBbi, sBbi, sWro};
                    /*
										gl_move = (np_i | (np_t << 6) | (6 << 12) | (6 << 16) | (3 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
										*/
                    np_c = 8;
                  };

                  break;
                case
                    sWbi: { //move m = {np_i, np_t, sBbi, sBbi, sWbi};
                    /*
										gl_move = (np_i | (np_t << 6) | (6 << 12) | (6 << 16) | (5 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
										*/
                    np_c = 8;
                  };

                  break;
                case
                    sWkn: { //move m = {np_i, np_t, sBbi, sBbi, sWkn};
                    /*
										gl_move = (np_i | (np_t << 6) | (6 << 12) | (6 << 16) | (7 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
										*/
                    np_c = 8;
                  };

                  break;
                case
                    sWqu: { //move m = {np_i, np_t, sBbi, sBbi, sWqu};
                    /*
										gl_move = (np_i | (np_t << 6) | (6 << 12) | (6 << 16) | (11 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
										*/
                    np_c = 8;
                  };

                  break;
                default
                    : {
                    np_c = 8;
                  };
              };
            };
          };
        };

        break;

        // analyse self knight
      case
          sBkn: {
          for (np_c = 0; np_c < 8; np_c++) {
            np_t = increasingKnightMap[np_i][np_c];

            switch (B[np_t]) {
              case
                  sEmp: { //move m = {np_i, np_t, sBkn, sBkn, '0'};
                  gl_move = (np_i | (np_t << 6) | (8 << 12) | (8 << 16));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWpa: { //move m = {np_i, np_t, sBkn, sBkn, sWpa};
                  gl_move = (np_i | (np_t << 6) | (8 << 12) | (8 << 16) | (1 << 20));
                  CHILD(ply);

									if (isAttByWhi(np_t) == true) { //bad trade
                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };
								  };
                  PARENT(ply);
                };

                break;
              case
                  sWro: { //move m = {np_i, np_t, sBkn, sBkn, sWro};
                  /*
									gl_move = (np_i | (np_t << 6) | (8 << 12) | (8 << 16) | (3 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                */
								};
                break;
              case
                  sWbi: { //move m = {np_i, np_t, sBkn, sBkn, sWbi};
                  /*
									gl_move = (np_i | (np_t << 6) | (8 << 12) | (8 << 16) | (5 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                */
								};

                break;
              case
                  sWkn: { //move m = {np_i, np_t, sBkn, sBkn, sWkn};
                  /*
									gl_move = (np_i | (np_t << 6) | (8 << 12) | (8 << 16) | (7 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                  */
                };

                break;
              case
                  sWqu: { //move m = {np_i, np_t, sBkn, sBkn, sWqu};
                  /*
									gl_move = (np_i | (np_t << 6) | (8 << 12) | (8 << 16) | (11 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                  */
                };

                break;
                case
							  sOut: {break;}; break;
            };
          };
        };

        break;
      case

          sBki: {
          // if positive k-side castle status
          if (castle_dat != (castle_dat | castle_lost_BKK_mask)) {
            //if king not checked
            if (CheckStatus[ply - 1] == false) {
              //if empty two squares on the right side of the king
              if (B[5] == sEmp) {
                if (B[6] == sEmp) {
                  //if empty squares are not in check
                  if (isAttByWhi(5) == false) {
                    if (isAttByWhi(6) == false) {
                      //add k-side castle move
                      //move m = {4, 6, sBki, sBki, '0'}; and move m = {7, 5, sBro, sBro, '0'};
                      gl_move = (4 | (6 << 6) | (10 << 12) | (10 << 16));
                      CHILD(ply);
                      saveBlaPosition(np_offs);
                      np_offs++;
                      PARENT(ply);
                    };
                  };
                };
              };
            };
          };

          // if positive q-side castle status
          if (castle_dat != (castle_dat | castle_lost_BKQ_mask)) {
            //if king not checked
            if (CheckStatus[ply - 1] == false) {
              //if empty THREE squares on the left side of the king
              if (B[3] == sEmp) {
                if (B[2] == sEmp) {
                  if (B[1] == sEmp) {
                    //if TWO empty squares are not in check
                    if (isAttByWhi(3) == false) {
                      if (isAttByWhi(2) == false) {
                        //add q-side castle move
                        //move m = {4, 2, sBki, sBki, '0'}; and move m = {0, 3, sBro, sBro, '0'};
                        gl_move = (4 | (2 << 6) | (10 << 12) | (10 << 16));
                        CHILD(ply);
                        saveBlaPosition(np_offs);
                        np_offs++;
                        PARENT(ply);
                      };
                    };
                  };
                };
              };
            };
          };

          for (np_v = 0; np_v < 8; np_v++) {
            np_t = Vec[np_v][np_i][0];

            switch (B[np_t]) {
              case
                  sEmp: { //move m = {np_i, np_t, sBki, sBki, '0'};
                  gl_move = (np_i | (np_t << 6) | (10 << 12) | (10 << 16));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWpa: { //move m = {np_i, np_t, sBki, sBki, sWpa};
                  /*
									gl_move = (np_i | (np_t << 6) | (10 << 12) | (10 << 16) | (1 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                  */
                };

                break;
              case
                  sWro: { //move m = {np_i, np_t, sBki, sBki, sWro};
                  /*
									gl_move = (np_i | (np_t << 6) | (10 << 12) | (10 << 16) | (3 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                  */
                };

                break;
              case
                  sWbi: { //move m = {np_i, np_t, sBki, sBki, sWbi};
                  /*
									gl_move = (np_i | (np_t << 6) | (10 << 12) | (10 << 16) | (5 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                  */
                };

                break;
              case
                  sWkn: { //move m = {np_i, np_t, sBki, sBki, sWkn};
                  /*
									gl_move = (np_i | (np_t << 6) | (10 << 12) | (10 << 16) | (7 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                  */
                };

                break;
              case
                  sWqu: { //move m = {np_i, np_t, sBki, sBki, sWqu};
                  /*
									gl_move = (np_i | (np_t << 6) | (10 << 12) | (10 << 16) | (11 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                  */
                };

                break;
            };
          };
        };

        break;
      case
          sBqu: {
          for (np_v = 0; np_v < 8; np_v++) {
            for (np_c = 0; np_c < 8; np_c++) {
              np_t = Vec[np_v][np_i][np_c];

              switch (B[np_t]) {
                case
                    sEmp: { //move m = {np_i, np_t, sBqu, sBqu, '0'};
                    gl_move = (np_i | (np_t << 6) | (12 << 12) | (12 << 16));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sWpa: { //move m = {np_i, np_t, sBqu, sBqu, sWpa};
                    gl_move = (np_i | (np_t << 6) | (12 << 12) | (12 << 16) | (1 << 20));
                    CHILD(ply);

                    if (isAttByWhi(np_t) == true) { //bad trade
										  if (isAttByWhi(BkiPos) == false) {
                        saveBlaPosition(np_offs);
                        np_offs++;
                      };
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sWro: { //move m = {np_i, np_t, sBqu, sBqu, sWro};
                    gl_move = (np_i | (np_t << 6) | (12 << 12) | (12 << 16) | (3 << 20));
                    CHILD(ply);

                    if (isAttByWhi(np_t) == true) { //bad trade
										  if (isAttByWhi(BkiPos) == false) {
                        saveBlaPosition(np_offs);
                        np_offs++;
                      };
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sWbi: { //move m = {np_i, np_t, sBqu, sBqu, sWbi};
                    gl_move = (np_i | (np_t << 6) | (12 << 12) | (12 << 16) | (5 << 20));
                    CHILD(ply);

                    if (isAttByWhi(np_t) == true) { //bad trade
											if (isAttByWhi(BkiPos) == false) {
	                      saveBlaPosition(np_offs);
	                      np_offs++;
	                    };
  									};

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sWkn: { //move m = {np_i, np_t, sBqu, sBqu, sWkn};
                    gl_move = (np_i | (np_t << 6) | (12 << 12) | (12 << 16) | (7 << 20));
                    CHILD(ply);

										if (isAttByWhi(np_t) == true) { //bad trade
                      if (isAttByWhi(BkiPos) == false) {
                        saveBlaPosition(np_offs);
                        np_offs++;
                      };
										};

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sWqu: { //move m = {np_i, np_t, sBqu, sBqu, sWqu};
                    /*
										gl_move = (np_i | (np_t << 6) | (12 << 12) | (12 << 16) | (11 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
										*/
                    np_c = 8;
                  };

                  break;
                default
                    : {
                    np_c = 8;
                  };
              };
            };
          };
        };

        break;
      default
          : {
          ;
        };
    };
  };

  //END:{;};

#ifdef REUSE_EVAL
  do_reuse_eval = false;
#endif

/*
//if mate is found: dont save other moves to the tree:
//just one mating move.
//this will reduce tree size in full search and in qs
//save sorted moves to the tree in the right order
  if ((grade[0] == MIN_SCORE)
	&& (np_offs > 0)
	//&& (ply > 1)
	) {
    np_offs = 1;
    MOVES_TREE[(ply << 8) | 0] = mymove[0]; //assign matingmove to the TREE
    UnsPosTree[(ply << 8) | 0].lastMove = mymove[0];
    VALS_TREE[(ply << 8) | 0] = MIN_SCORE; //assign matescore to the TREE
    //cout<<"mating move: "<<printMove(mymove[0])<<endl; printB("MATE:");
    nonqs_positions_count += np_offs;
		return np_offs; //return offset==1 mating move
  };
*/
//////////////////////////////////////////
  /*
  now capture moves are sorted only by winned material
  reorder them:
    if the same captured piece in move B and A
     endless loop: if (B from piece > A from piece) swap moves and continue swaps until noncap found.
     break if no swap found
  */
/*
//inefficient in restply?
#ifdef ATTA_REORD
  if (np_offs > 1)
    //if at least two moves
  {
    goto AR_LOOP;
AR_LOOP: {
      np_i = 1; //take second move index

      while (np_i < np_offs)
        //until offset end
      {
        gl_cp = ((mymove[np_i] << 8) >> 28);    //take second move captured piece

        if (gl_cp != 0)
          //if noncap
        {
          if (gl_cp == ((mymove[np_i - 1] << 8) >> 28)
             )
            //if the same captured piece type
          {
            ///if order of attackers to improve
            if ((UnsignedMaterialValue[((mymove[np_i] << 16) >> 28) ])
                <
                (UnsignedMaterialValue[((mymove[np_i - 1] << 16) >> 28) ])) {
              //swap moves and grades
              ar_move = mymove[np_i - 1];
              ar_grade = grade[np_i - 1];
              mymove[np_i - 1] = mymove[np_i];
              grade[np_i - 1] = grade[np_i];
              mymove[np_i] = ar_move;
              grade[np_i] = ar_grade;
              //repeat from beginning
              goto AR_LOOP;
            };
          };
        };

        np_i++;
      };
    };
  };

#endif
*/
//////////////////////////////////////////
/*
#ifdef NULL_MOVE
//reorder null move at first position
  np_i = 0;

  while (np_i < np_offs) {
    if (mymove[np_i] == 2) {
      nms_move = mymove[np_i];
      nms_grade = grade[np_i];

      while (np_i > 0) {
        //just move it ahead and consider previous move
        mymove[np_i] = mymove[np_i - 1];
        grade[np_i] = grade[np_i - 1];
        np_i--;
      };

      mymove[np_i] = nms_move; //index zero

      grade[np_i] = nms_grade;

      break;
    };

    np_i++;
  };

#endif
*/
#ifdef CHECK_REORD
//////////////////////////////////////////
//do another sorting: search moves from the best to the weakest
//if check in the ply is found:
//if the first move is null - continue
//if the move is check - continue
//reorder moves
  /*
  np_i = 0;
  cout<<"moves BEFORE check_reord: "<<flush;
  while (np_i<np_offs) {
   cout<<"["<<np_i<<"]:"<<printMove(mymove[np_i])<<" "<<flush;
    np_i++;
  };
  cout<<endl;
  */
//take second move if any
  np_i = 1;

  while (np_i < np_offs) {
    //if the move causes the white king is checked
    if (mymove[np_i] == (mymove[np_i] | (1 << 31))) {
      //save this move
      ar_move = mymove[np_i];
      ar_grade = grade[np_i];
      //move all moves before it
      //which are not null move nor check ahead one step
      np_j = np_i;

      //if we have no null move first in the ply
      if (mymove[0] != 2) {
        //if safe bound
        while (np_j > 0) {
          //if previous move is not check
          if (mymove[np_j - 1] != (mymove[np_j - 1] | (1 << 31))) {
            //just move it ahead and consider previous move
            mymove[np_j] = mymove[np_j - 1];
            grade[np_j] = grade[np_j - 1];
            np_j--;
          }
          //if previous move is check - break at curent index
          else {
            break;
          };
        };

        //move save ar_move and ar grade into curent index
        mymove[np_j] = ar_move;

        grade[np_j] = ar_grade;
      }
      //if we have null move first
      else {
        //if safe bound
        while (np_j > 1) {
          //if previous move is not check
          if (mymove[np_j - 1] != (mymove[np_j - 1] | (1 << 31))) {
            //just move it ahead and consider previous move
            mymove[np_j] = mymove[np_j - 1];
            grade[np_j] = grade[np_j - 1];
            np_j--;
          }
          //if previous move is check - break at curent index
          else {
            break;
          };
        };

        //move save ar_move and ar grade into curent index
        mymove[np_j] = ar_move;

        grade[np_j] = ar_grade;
      };
    };

    np_i++;
  };

//////////////////
  /*
  if (mymove[0]==2) {
    cout<<"moves AFTER reord, bla nm: "<<flush;
  np_i = 0;
    while (np_i<np_offs) {
     cout<<"["<<np_i<<"]:"<<printMove(mymove[np_i])<<" "<<flush;
      np_i++;
    };
    cout<<endl;
    };
    */
#endif
  /*
  mark late moves in the ply by checking proper bit in proper moves
  */
#ifdef LATE_MOVE
//late move in black restply
//IF NODE IS NOT PV NODE
//if proper max depth
//if (ply+lmr_reduction<qDepth) {
  if (ply < qDepth) {
  //if no lmr flag set (upper)
    if (lmr_already_used == false) {
      //if not escaping from check
      if (CheckStatus[ply - 1] == false) {
        //if no check in the path
        //if (first_check_depth==0) {
        //if proper min depth
        //if (ply>=lmr_min_ply) {
        //start from minimum lmr index
        np_i = lmr_min_idx;
        //save value of parent
        //int ar_grade = VALS_TREE[((ply - 1) << 8) | cur_offs[ply - 1]];

        //if null move at zero index  - increment minimum lmr index
        //if (mymove[0] < 3) {
          //np_i++;
					// if parent move is not forcing move (marked by null move search)
					//if (MOVES_TREE[((ply - 1) << 8) | cur_offs[ply - 1]]
					//!= (MOVES_TREE[((ply - 1) << 8) | cur_offs[ply - 1]] | forced_pos_mask)) {

		        //clear lmr_real_offs
		        //lmr_real_offs = 0;
		    while (np_i < np_offs) {

			        //if static eval after move is worse than that of the parent
			        //or if static eval is little better (no capture, promotion, enpassant capture happened)
			    //if (grade[np_i] + evLateMoveMargin > ar_grade) {
			          //if the move is noncapture
			          //if (((mymove[np_i]<<8)>>28)==0) {
			          //if the move generated positive forced_pos
			          //if (mymove[np_i] == (mymove[np_i]|forced_pos_mask)) {
			          //if wki_checked_mask is clear
			      if (mymove[np_i] != (mymove[np_i] | (1 << 31))) {
			            //if the move is not pawn promotion threat
			            //set lmr move flag
			            //lmr_real_offs++;
			            //if (lmr_real_offs<3) {continue;};
			        mymove[np_i] |= (1 << 29);
			            //cout<<"lmr offset:"<<np_i<<", move:"<<printMove(mymove[np_i])<<endl;
			      };
			    //};

			    np_i++;
			  };
			//};
      };
    };
  };

#endif
  /*
  //////////////////////////////
    cout<<"Bla late moves report (ply:"<<ply<<", qDepth:"<<qDepth<<"):"<<endl;
    np_i = 0;
  while (np_i<np_offs) {
   if (mymove[np_i]==(mymove[np_i] | (1<<29))) {
     cout<<"["<<np_i<<"]"<<printMove(mymove[np_i])<<"-late "<<flush;
   }
   else {
    cout<<"["<<np_i<<"]"<<printMove(mymove[np_i])<<"-norm "<<flush;
    };
   np_i++;
    };
    cout<<endl;
    /////////////////////////////
  */
//////////////////////////////
//save sorted and marked data into the tree
  finishSavePositionInNewPly();

#ifdef CUTTOFF_MOVE_HASH_REORDER

////////////////////////////////////////////////////////////////////
//reorder the cuttoff move if found in the beginning of the ply
//if Zkey matches and there is available the best move which produced a cuttoff
//HT==
//[Zkey(64bits)]
//[score(20bits)-val(20bits)-ply(6bits)-qDepth(6bits)-BestMovetofrom(12bits)]
  if (ply > 1) {
    Hkey = (Zkey >> (Zkeylen - Hkeylen));

    if (HT[Hkey][0] == Zkey) {
      if (((HT[Hkey][1] << 52) >> 52)
          != 0)
        //if best move available
      {
        //find the best move index
        np_i = 0;

        while (np_i < np_offs) {
          //if the move coords matches insort it into the beginning of the ply
          if (((MOVES_TREE[np_c | np_i] << 20) >> 20)
              == ((HT[Hkey][1] << 52) >> 52)) {
            //cout<<"best move:"<<printMove(MOVES_TREE[np_c|np_i])<<
            //"at idx:"<<np_i<<endl;
            //copy the value of found move
            se_v = VALS_TREE[np_c | np_i];

            //copy all moves and values one move forward to the found move pos
            for (se_j = np_i; se_j > 0; se_j--) {
              MOVES_TREE[np_c | se_j] = MOVES_TREE[np_c | (se_j - 1) ];
              VALS_TREE[np_c | se_j] = VALS_TREE[np_c | (se_j - 1) ];
            };

            //paste found move and its value in the first move pos
            MOVES_TREE[np_c | 0] = MOVES_TREE[np_c | np_i];

            VALS_TREE[np_c | 0] = se_v;

            break;
          };

          np_i++;
        };
      };
    };
  };

//////////////////////////////////////////////
#endif

#ifdef DEBUG_VERSION
	restply_positions_count += np_offs;
  restply_branch_count++;
  if (ply == qDepth) {
    terminal_restply_branch_count++;
  };
  if (np_offs==0) {empty_restply_branch_count++;};
#endif

	return np_offs;
};



unsigned char QS_BLA_PLY(unsigned char ply)
{
//set side to move to properly eval
  side = true;


//set initial data tables of this ply before CHILD() action
  enpassant = enp_sq[ply - 1];
  castle_dat = castle_data[ply - 1];
  Zkey = Zkey_tab[ply - 1];
  retract = retract_tab[ply - 1];

	shifted_np_ply = (ply<<8); //static used in saving position data

//loop board
  np_offs = 0;

//#ifdef QS_CHECKS

//bool checksearch = false;

//if (ply>10) {checksearch = false;};

//if (ply>100) {checksearch = false;}
//else {
//if ply-2 move was check and ply-1 offset>3 : checksearch=false
//if (VALS_TREE[((ply-2)<<8)|cur_offs[(ply-2)]]==(MIN_SCORE+2)) {
//if (max_offs[ply-1]<4) {
//checksearch = true;
//};
//};
//};

//#endif

/*
#ifdef REUSE_EVAL
  //whole preeval table must be generated before the ply,
  //because in each child position we analyse whole board
  if (ply <= qDepth) {
    for (ev_fs = 0; ev_fs < 64; ev_fs++) {
		  EV_SQUARE();
      SC[ev_fs] = ev_score;
    };
    do_reuse_eval = true;
  };
#endif
*/
  for (np_i = 0; np_i < 64; np_i++) {

    switch (B[np_i]) {
      case
          sBpa: {
          if (np_i < 16) {
            np_t = LBPCaps[np_i];

            switch (B[np_t]) {
              case
                  sWpa: { //analyse {np_i, np_t, sBpa, sBpa, sWpa};
                  gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (1 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWro: { //analyse {np_i, np_t, sBpa, sBpa, sWro};
                  gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (3 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWbi: { //analyse {np_i, np_t, sBpa, sBpa, sWbi};
                  gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (5 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWkn: { //analyse {np_i, np_t, sBpa, sBpa, sWkn};
                  gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (7 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWqu: { //analyse {np_i, np_t, sBpa, sBpa, sWqu};
                  gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (11 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
            };

            np_t = RBPCaps[np_i];

            switch (B[np_t]) {
              case
                  sWpa: { //analyse {np_i, np_t, sBpa, sBpa, sWpa};
                  gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (1 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWro: { //analyse {np_i, np_t, sBpa, sBpa, sWro};
                  gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (3 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWbi: { //analyse {np_i, np_t, sBpa, sBpa, sWbi};
                  gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (5 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWkn: { //analyse {np_i, np_t, sBpa, sBpa, sWkn};
                  gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (7 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWqu: { //analyse {np_i, np_t, sBpa, sBpa, sWqu};
                  gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (11 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
            };

            /*
            //#ifdef QS_CHECKS
            //save CHECK caused by black pawn moving ONE SQUARE AHEAD from starting pos.
                      if (checksearch==true) {
             np_t = np_i+8;
             if (B[np_t]==sEmp) {// {np_i, np_i+8, sBpa, sBpa, '0'};
               gl_move = (np_i | (np_t<<6) | (2<<12) | (2<<16));
                         CHILD(ply);
                         if (isBlaCheckGood(WkiPos)==true) {
               if (isAttByWhi(BkiPos)==false) {
                  saveBlaPosition(np_offs); np_offs++;
               };
                };
                         PARENT(ply);
              // save CHECK caused by pawn moving TWO SQUARES AHEAD
              np_t += 8;
              if (B[np_t]==sEmp) {// {np_i, np_i+16, sBpa, sBpa, '0'};
                gl_move = (np_i | (np_t<<6) | (2<<12) | (2<<16));
                           CHILD(ply);
                           if (isBlaCheckGood(WkiPos)==true) {
                 if (isAttByWhi(BkiPos)==false) {
                  saveBlaPosition(np_offs); np_offs++;
                };
                };
                           PARENT(ply);
              };
             };
            };
            //#endif
            */
            #ifdef QS_MATES
            np_t = np_i+8;
	          if (B[np_t]==sEmp) {// {np_i, np_i+8, sBpa, sBpa, '0'};
	            gl_move = (np_i | (np_t<<6) | (2<<12) | (2<<16));
	            CHILD(ply);
	            if (isAttByBla(WkiPos)==true) {
	              if (isWkiMated()==true) {
             	    if (isAttByWhi(BkiPos)==false) {
								    saveBlaPosition(np_offs); np_offs++;
								    PARENT(ply); goto END;
                  };
                };
              };
	            PARENT(ply);

              np_t += 8;
	            if (B[np_t]==sEmp) {// {np_i, np_i+16, sBpa, sBpa, '0'};
	              gl_move = (np_i | (np_t<<6) | (2<<12) | (2<<16));
	              CHILD(ply);
		            if (isAttByBla(WkiPos)==true) {
		              if (isWkiMated()==true) {
	             	    if (isAttByWhi(BkiPos)==false) {
									    saveBlaPosition(np_offs); np_offs++;
									    PARENT(ply); goto END;
	                  };
	                };
	              };
		            PARENT(ply);
		          };
		        };
            #endif

          }
          // IF PAWN IS IN THE MIDDLEBOARD
          else
            if (np_i < 48) {
              np_t = LBPCaps[np_i];

              switch (B[np_t]) {
                case
                    sEmp: { //analyse enpassant capture
                    if ((enp_sq[ply - 1] == np_t) && (np_t != 64)) {
                      //{np_i, np_t, sBpa, sWpa};
                      gl_move = (np_i | (np_t << 6) | (2 << 12) | (1 << 16));
                      CHILD(ply);

                      if (isAttByWhi(BkiPos) == false) {
                        saveBlaPosition(np_offs);
                        np_offs++;
                      };

                      PARENT(ply);
                    };
                  };

                  break;
                case
                    sWpa: { //analyse {np_i, np_t, sBpa, sBpa, sWpa};
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (1 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sWro: { //analyse {np_i, np_t, sBpa, sBpa, sWro};
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (3 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sWbi: { //analyse {np_i, np_t, sBpa, sBpa, sWbi};
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (5 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sWkn: { //analyse {np_i, np_t, sBpa, sBpa, sWkn};
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (7 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sWqu: { //analyse {np_i, np_t, sBpa, sBpa, sWqu};
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (11 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
              };


              np_t = RBPCaps[np_i];

              switch (B[np_t]) {
                case
                    sEmp: { //analyse enpassant capture
                    if ((enp_sq[ply - 1] == np_t) && (np_t != 64)) {
                      //{np_i, np_t, sBpa, sWpa};
                      gl_move = (np_i | (np_t << 6) | (2 << 12) | (1 << 16));
                      CHILD(ply);

                      if (isAttByWhi(BkiPos) == false) {
                        saveBlaPosition(np_offs);
                        np_offs++;
                      };

                      PARENT(ply);
                    };
                  };

                  break;
                case
                    sWpa: { //analyse {np_i, np_t, sBpa, sBpa, sWpa};
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (1 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sWro: { //analyse {np_i, np_t, sBpa, sBpa, sWro};
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (3 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sWbi: { //analyse {np_i, np_t, sBpa, sBpa, sWbi};
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (5 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sWkn: { //analyse {np_i, np_t, sBpa, sBpa, sWkn};
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (7 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
                case
                    sWqu: { //analyse {np_i, np_t, sBpa, sBpa, sWqu};
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (2 << 16) | (11 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);
                  };

                  break;
              };

              #ifdef QS_MATES
              np_t = np_i+8;
	            if (B[np_t]==sEmp) {// {np_i, np_i+8, sBpa, sBpa, '0'};
	              gl_move = (np_i | (np_t<<6) | (2<<12) | (2<<16));
                CHILD(ply);
                if (isAttByBla(WkiPos)==true) {
                  if (isWkiMated()==true) {
         	          if (isAttByWhi(BkiPos)==false) {
								      saveBlaPosition(np_offs); np_offs++;
                      PARENT(ply); goto END;
										};
                  };
                };
	              PARENT(ply);
              };
              #endif

              /*
                        //#ifdef QS_CHECKS
              if (checksearch==true) {
               np_t = np_i+8;
                         if (B[np_t]==sEmp) {
                gl_move = (np_i | (np_t<<6) | (2<<12) | (2<<16));
                           CHILD(ply);
                           if (isBlaCheckGood(WkiPos)==true) {
                 if (isAttByWhi(BkiPos)==false) {
                     saveBlaPosition(np_offs); np_offs++;
                  };
                };
                           PARENT(ply);
               };
              };
              //#endif
              */
            }
          //  ELSE IF PAWN IS IN THE SECOND ROW
          //  handle PROMOTION IF PAWN CAN MOVE AHEAD
            else {
              np_t = np_i + 8;

              np_allow = false;
              if (B[np_t] == sEmp) {
                gl_move = (np_i | (np_t << 6) | (2 << 12) | (12 << 16));
                CHILD(ply);

                if (isAttByWhi(BkiPos) == false) {
                  np_allow=true; saveBlaPosition(np_offs);
                  np_offs++;
                };

                PARENT(ply);

                /*
                   gl_move = (np_i | (np_t<<6) | (2<<12) | (4<<16));
                CHILD(ply);
                if (np_allow==true) {saveBlaPosition(np_offs); np_offs++;};
                PARENT(ply);
                gl_move = (np_i | (np_t<<6) | (2<<12) | (6<<16));
                CHILD(ply);
                if (np_allow==true) {saveBlaPosition(np_offs); np_offs++;};
                PARENT(ply);
                gl_move = (np_i | (np_t<<6) | (2<<12) | (8<<16));
                CHILD(ply);
                if (np_allow==true) {saveBlaPosition(np_offs); np_offs++;};
                PARENT(ply);
                   */

                #ifdef QS_MATES
                //handle knight promotion only if knight mates
                gl_move = (np_i | (np_t<<6) | (2<<12) | (8<<16));
                if (np_allow==true) {
								  CHILD(ply);
                  if (isAttByBla(WkiPos)==true) {
                    if (isWkiMated()==true) {
								      saveBlaPosition(np_offs); np_offs++;
								      PARENT(ply); goto END;
                    };
                  };
	                PARENT(ply);
                };
								#endif
              };

              // handle PROMOTION if PAWN CAPTURED
              np_t = LBPCaps[np_i];

              switch (B[np_t]) {
                  // if opponent rook is captured - memorize the possible promotions
                case
                    sWro: {
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (12 << 16) | (3 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      np_allow = true; saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    /*
                          gl_move = (np_i | (np_t<<6) | (2<<12) | (4<<16) | (3<<20));
                       CHILD(ply);
                    if (np_allow==true) {saveBlaPosition(np_offs); np_offs++;};
                    PARENT(ply);

                    gl_move = (np_i | (np_t<<6) | (2<<12) | (6<<16) | (3<<20));
                       CHILD(ply);
                    if (np_allow==true) {saveBlaPosition(np_offs); np_offs++;};
                    PARENT(ply);

                    gl_move = (np_i | (np_t<<6) | (2<<12) | (8<<16) | (3<<20));
                       CHILD(ply);
                    if (np_allow==true) {saveBlaPosition(np_offs); np_offs++;};
                    PARENT(ply);
                       */

                    #ifdef QS_MATES
                    //handle knight promotion only if knight mates
                    gl_move = (np_i | (np_t<<6) | (2<<12) | (8<<16) | (3<<20));
                    if (np_allow==true) {
								      CHILD(ply);
                      if (isAttByBla(WkiPos)==true) {
                        if (isWkiMated()==true) {
								          saveBlaPosition(np_offs); np_offs++;
								          PARENT(ply); goto END;
                        };
                      };
	                    PARENT(ply);
                    };
								    #endif

									};

                  break;

                  // if opponent bishop is captured - memorize the possible promotions
                case
                    sWbi: {
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (12 << 16) | (5 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      np_allow = true; saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    /*
                          gl_move = (np_i | (np_t<<6) | (2<<12) | (4<<16) | (5<<20));
                       CHILD(ply);
                    if (np_allow==true) {saveBlaPosition(np_offs); np_offs++;};
                    PARENT(ply);

                    gl_move = (np_i | (np_t<<6) | (2<<12) | (6<<16) | (5<<20));
                       CHILD(ply);
                    if (np_allow==true) {saveBlaPosition(np_offs); np_offs++;};
                    PARENT(ply);

                    gl_move = (np_i | (np_t<<6) | (2<<12) | (8<<16) | (5<<20));
                       CHILD(ply);
                    if (np_allow==true) {saveBlaPosition(np_offs); np_offs++;};
                    PARENT(ply);
                       */

                    #ifdef QS_MATES
                    //handle knight promotion only if knight mates
                    gl_move = (np_i | (np_t<<6) | (2<<12) | (8<<16) | (5<<20));
                    if (np_allow==true) {
								      CHILD(ply);
                      if (isAttByBla(WkiPos)==true) {
                        if (isWkiMated()==true) {
								          saveBlaPosition(np_offs); np_offs++;
								          PARENT(ply); goto END;
                        };
                      };
	                    PARENT(ply);
                    };
								    #endif

									};

                  break;

                  // if opponent knight is captured - memorize the possible promotions
                case
                    sWkn: {
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (12 << 16) | (7 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      np_allow = true; saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    /*
                          gl_move = (np_i | (np_t<<6) | (2<<12) | (4<<16) | (7<<20));
                       CHILD(ply);
                    if (np_allow==true) {saveBlaPosition(np_offs); np_offs++;};
                    PARENT(ply);

                    gl_move = (np_i | (np_t<<6) | (2<<12) | (6<<16) | (7<<20));
                       CHILD(ply);
                    if (np_allow==true) {saveBlaPosition(np_offs); np_offs++;};
                    PARENT(ply);

                    gl_move = (np_i | (np_t<<6) | (2<<12) | (8<<16) | (7<<20));
                       CHILD(ply);
                    if (np_allow==true) {saveBlaPosition(np_offs); np_offs++;};
                    PARENT(ply);
                        */
                    #ifdef QS_MATES
                    //handle knight promotion only if knight mates
                    gl_move = (np_i | (np_t<<6) | (2<<12) | (8<<16) | (7<<20));
                    if (np_allow==true) {
								      CHILD(ply);
                      if (isAttByBla(WkiPos)==true) {
                        if (isWkiMated()==true) {
								          saveBlaPosition(np_offs); np_offs++;
								          PARENT(ply); goto END;
                        };
                      };
	                    PARENT(ply);
                    };
								    #endif
                  };

                  break;

                  // if opponent queen is captured - memorize the move
                case
                    sWqu: {
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (12 << 16) | (11 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      np_allow = true; saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    /*
                          gl_move = (np_i | (np_t<<6) | (2<<12) | (4<<16) | (11<<20));
                       CHILD(ply);
                    if (np_allow==true) {saveBlaPosition(np_offs); np_offs++;};
                    PARENT(ply);

                    gl_move = (np_i | (np_t<<6) | (2<<12) | (6<<16) | (11<<20));
                       CHILD(ply);
                    if (np_allow==true) {saveBlaPosition(np_offs); np_offs++;};
                    PARENT(ply);

                    gl_move = (np_i | (np_t<<6) | (2<<12) | (8<<16) | (11<<20));
                       CHILD(ply);
                    if (np_allow==true) {saveBlaPosition(np_offs); np_offs++;};
                    PARENT(ply);
                    */

                    #ifdef QS_MATES
                    //handle knight promotion only if knight mates
                    gl_move = (np_i | (np_t<<6) | (2<<12) | (8<<16) | (11<<20));
                    if (np_allow==true) {
								      CHILD(ply);
                      if (isAttByBla(WkiPos)==true) {
                        if (isWkiMated()==true) {
								          saveBlaPosition(np_offs); np_offs++;
								          PARENT(ply); goto END;
                        };
                      };
	                    PARENT(ply);
                    };
								    #endif

                  };

                  break;
              };


              np_t = RBPCaps[np_i];

              switch (B[np_t]) {
                  // if opponent rook is captured - memorize the possible promotions
                case
                    sWro: {
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (12 << 16) | (3 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      np_allow = true; saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    /*
                          gl_move = (np_i | (np_t<<6) | (2<<12) | (4<<16) | (3<<20));
                       CHILD(ply);
                    if (np_allow==true) {saveBlaPosition(np_offs); np_offs++;};
                    PARENT(ply);

                    gl_move = (np_i | (np_t<<6) | (2<<12) | (6<<16) | (3<<20));
                       CHILD(ply);
                    if (np_allow==true) {saveBlaPosition(np_offs); np_offs++;};
                    PARENT(ply);

                    gl_move = (np_i | (np_t<<6) | (2<<12) | (8<<16) | (3<<20));
                       CHILD(ply);
                    if (np_allow==true) {saveBlaPosition(np_offs); np_offs++;};
                    PARENT(ply);
                       */
                    #ifdef QS_MATES
                    //handle knight promotion only if knight mates
                    gl_move = (np_i | (np_t<<6) | (2<<12) | (8<<16) | (3<<20));
                    if (np_allow==true) {
								      CHILD(ply);
                      if (isAttByBla(WkiPos)==true) {
                        if (isWkiMated()==true) {
								          saveBlaPosition(np_offs); np_offs++;
								          PARENT(ply); goto END;
                        };
                      };
	                    PARENT(ply);
                    };
								    #endif
                  };

                  break;

                  // if opponent bishop is captured - memorize the possible promotions
                case
                    sWbi: {
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (12 << 16) | (5 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      np_allow = true; saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    /*
                          gl_move = (np_i | (np_t<<6) | (2<<12) | (4<<16) | (5<<20));
                       CHILD(ply);
                    if (np_allow==true) {saveBlaPosition(np_offs); np_offs++;};
                    PARENT(ply);

                    gl_move = (np_i | (np_t<<6) | (2<<12) | (6<<16) | (5<<20));
                       CHILD(ply);
                    if (np_allow==true) {saveBlaPosition(np_offs); np_offs++;};
                    PARENT(ply);

                    gl_move = (np_i | (np_t<<6) | (2<<12) | (8<<16) | (5<<20));
                       CHILD(ply);
                    if (np_allow==true) {saveBlaPosition(np_offs); np_offs++;};
                    PARENT(ply);
                       */

                    #ifdef QS_MATES
                    //handle knight promotion only if knight mates
                    gl_move = (np_i | (np_t<<6) | (2<<12) | (8<<16) | (5<<20));
                    if (np_allow==true) {
								      CHILD(ply);
                      if (isAttByBla(WkiPos)==true) {
                        if (isWkiMated()==true) {
								          saveBlaPosition(np_offs); np_offs++;
								          PARENT(ply); goto END;
                        };
                      };
	                    PARENT(ply);
                    };
								    #endif
                  };

                  break;

                  // if opponent knight is captured - memorize the possible promotions
                case
                    sWkn: {
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (12 << 16) | (7 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      np_allow = true; saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    /*
                          gl_move = (np_i | (np_t<<6) | (2<<12) | (4<<16) | (7<<20));
                       CHILD(ply);
                    if (np_allow==true) {saveBlaPosition(np_offs); np_offs++;};
                    PARENT(ply);

                    gl_move = (np_i | (np_t<<6) | (2<<12) | (6<<16) | (7<<20));
                       CHILD(ply);
                    if (np_allow==true) {saveBlaPosition(np_offs); np_offs++;};
                    PARENT(ply);

                    gl_move = (np_i | (np_t<<6) | (2<<12) | (8<<16) | (7<<20));
                       CHILD(ply);
                    if (np_allow==true) {saveBlaPosition(np_offs); np_offs++;};
                    PARENT(ply);
                        */
                    #ifdef QS_MATES
                    //handle knight promotion only if knight mates
                    gl_move = (np_i | (np_t<<6) | (2<<12) | (8<<16) | (7<<20));
                    if (np_allow==true) {
								      CHILD(ply);
                      if (isAttByBla(WkiPos)==true) {
                        if (isWkiMated()==true) {
								          saveBlaPosition(np_offs); np_offs++;
								          PARENT(ply); goto END;
                        };
                      };
	                    PARENT(ply);
                    };
								    #endif
                  };

                  break;

                  // if opponent queen is captured - memorize the move
                case
                    sWqu: {
                    np_allow = false;
                    gl_move = (np_i | (np_t << 6) | (2 << 12) | (12 << 16) | (11 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      np_allow = true; saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    /*
                          gl_move = (np_i | (np_t<<6) | (2<<12) | (4<<16) | (11<<20));
                       CHILD(ply);
                    if (np_allow==true) {saveBlaPosition(np_offs); np_offs++;};
                    PARENT(ply);

                    gl_move = (np_i | (np_t<<6) | (2<<12) | (6<<16) | (11<<20));
                       CHILD(ply);
                    if (np_allow==true) {saveBlaPosition(np_offs); np_offs++;};
                    PARENT(ply);

                    gl_move = (np_i | (np_t<<6) | (2<<12) | (8<<16) | (11<<20));
                       CHILD(ply);
                    if (np_allow==true) {saveBlaPosition(np_offs); np_offs++;};
                    PARENT(ply);
                    */

										#ifdef QS_MATES
                    //handle knight promotion only if knight mates
                    gl_move = (np_i | (np_t<<6) | (2<<12) | (8<<16) | (11<<20));
                    if (np_allow==true) {
								      CHILD(ply);
                      if (isAttByBla(WkiPos)==true) {
                        if (isWkiMated()==true) {
								          saveBlaPosition(np_offs); np_offs++;
								          PARENT(ply); goto END;
                        };
                      };
	                    PARENT(ply);
                    };
								    #endif

                  };

                  break;
              };
            };
        };

        break;
      case
          sBro: {
          for (np_v = 4; np_v < 8; np_v++) {
            for (np_c = 0; np_c < 8; np_c++) {
              np_t = Vec[np_v][np_i][np_c];

              switch (B[np_t]) {
                case
                    sEmp: {
                    ;//move m = {np_i, np_t, sBro, sBro, '0'};
                    /*
                        //#ifdef QS_CHECKS
                    if (checksearch==true) {
                         gl_move = (np_i | (np_t<<6) | (4<<12) | (4<<16));
                        CHILD(ply);
                        if (isBlaCheckGood(WkiPos)==true) {
                            if (isAttByWhi(BkiPos)==false) {
                               saveBlaPosition(np_offs); np_offs++;
                          };
                          };
                        PARENT(ply);
                         };
                    //#endif
                    */
                    #ifdef QS_MATES
										//move m = {np_i, np_t, sBro, sBro, '0'};
                    gl_move = (np_i | (np_t<<6) | (4<<12) | (4<<16));
				            CHILD(ply);
				            if (isAttByBla(WkiPos)==true) {
		                  if (isWkiMated()==true) {
            	          if (isAttByWhi(BkiPos)==false) {
									        saveBlaPosition(np_offs); np_offs++;
									        PARENT(ply); goto END;
                        };
	                    };
			              };
				            PARENT(ply);
										#endif
                  };

                  break;
                case
                    sWpa: { //move m = {np_i, np_t, sBro, sBro, sWpa};
                    gl_move = (np_i | (np_t << 6) | (4 << 12) | (4 << 16) | (1 << 20));
                    CHILD(ply);


                    //if (checksearch==false) {
                    if (isAttByWhi(BkiPos) == false) {
										  if (isAttByWhi(np_t) == false) {
												saveBlaPosition(np_offs); np_offs++;
                      }
                      else {
                      	#ifdef QS_MATES
				                if (isAttByBla(WkiPos)==true) {
		                      if (isWkiMated()==true) {
									          saveBlaPosition(np_offs); np_offs++;
									          PARENT(ply); goto END;
									        };
                        };
										    #endif
											};
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sWro: { //move m = {np_i, np_t, sBro, sBro, sWro};
                    gl_move = (np_i | (np_t << 6) | (4 << 12) | (4 << 16) | (3 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sWbi: { //move m = {np_i, np_t, sBro, sBro, sWbi};
                    gl_move = (np_i | (np_t << 6) | (4 << 12) | (4 << 16) | (5 << 20));
                    CHILD(ply);

                    //if (checksearch==false) {
                    if (isAttByWhi(BkiPos) == false) {
										  if (isAttByWhi(np_t) == false) {
												saveBlaPosition(np_offs); np_offs++;
                      }
                      else {
                      	#ifdef QS_MATES
				                if (isAttByBla(WkiPos)==true) {
		                      if (isWkiMated()==true) {
									          saveBlaPosition(np_offs); np_offs++;
									          PARENT(ply); goto END;
									        };
                        };
										    #endif
											};
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sWkn: { //move m = {np_i, np_t, sBro, sBro, sWkn};
                    gl_move = (np_i | (np_t << 6) | (4 << 12) | (4 << 16) | (7 << 20));
                    CHILD(ply);

                    //if (checksearch==false) {
                    if (isAttByWhi(BkiPos) == false) {
										  if (isAttByWhi(np_t) == false) {
												saveBlaPosition(np_offs); np_offs++;
                      }
                      else {
                      	#ifdef QS_MATES
				                if (isAttByBla(WkiPos)==true) {
		                      if (isWkiMated()==true) {
									          saveBlaPosition(np_offs); np_offs++;
									          PARENT(ply); goto END;
									        };
                        };
										    #endif
											};
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sWqu: { //move m = {np_i, np_t, sBro, sBro, sWqu};
                    gl_move = (np_i | (np_t << 6) | (4 << 12) | (4 << 16) | (11 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                default
                    : {
                    np_c = 8;
                  };
              };
            };
          };
        };

        break;
      case
          sBbi: {
          for (np_v = 0; np_v < 4; np_v++) {
            for (np_c = 0; np_c < 8; np_c++) {
              np_t = Vec[np_v][np_i][np_c];

              switch (B[np_t]) {
                case
                  sEmp: {
                    ;
										//move m = {np_i, np_t, sBbi, sBbi, '0'};
                    //#ifdef QS_CHECKS
                    /*
                        if (checksearch==true) {
                         gl_move = (np_i | (np_t<<6) | (6<<12) | (6<<16));
                        CHILD(ply);
                        if (isBlaCheckGood(WkiPos)==true) {
                            if (isAttByWhi(BkiPos)==false) {
                               saveBlaPosition(np_offs); np_offs++;
                          };
                          };
                        PARENT(ply);
                         };
                    //#endif
                    */

                    #ifdef QS_MATES
										//move m = {np_i, np_t, sBbi, sBbi, '0'};
                    gl_move = (np_i | (np_t<<6) | (6<<12) | (6<<16));
				            CHILD(ply);
				            if (isAttByBla(WkiPos)==true) {
		                  if (isWkiMated()==true) {
            	          if (isAttByWhi(BkiPos)==false) {
									        saveBlaPosition(np_offs); np_offs++;
									        PARENT(ply); goto END;
                        };
	                    };
			              };
				            PARENT(ply);
										#endif

                  };

                  break;
                case
                    sWpa: { //move m = {np_i, np_t, sBbi, sBbi, sWpa};
                    gl_move = (np_i | (np_t << 6) | (6 << 12) | (6 << 16) | (1 << 20));
                    CHILD(ply);

                    //if (checksearch==false) {
                    if (isAttByWhi(BkiPos) == false) {
										  if (isAttByWhi(np_t) == false) {
												saveBlaPosition(np_offs); np_offs++;
                      }
                      else {
                      	#ifdef QS_MATES
				                if (isAttByBla(WkiPos)==true) {
		                      if (isWkiMated()==true) {
									          saveBlaPosition(np_offs); np_offs++;
									          PARENT(ply); goto END;
									        };
                        };
										    #endif
											};
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sWro: { //move m = {np_i, np_t, sBbi, sBbi, sWro};
                    gl_move = (np_i | (np_t << 6) | (6 << 12) | (6 << 16) | (3 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sWbi: { //move m = {np_i, np_t, sBbi, sBbi, sWbi};
                    gl_move = (np_i | (np_t << 6) | (6 << 12) | (6 << 16) | (5 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sWkn: { //move m = {np_i, np_t, sBbi, sBbi, sWkn};
                    gl_move = (np_i | (np_t << 6) | (6 << 12) | (6 << 16) | (7 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sWqu: { //move m = {np_i, np_t, sBbi, sBbi, sWqu};
                    gl_move = (np_i | (np_t << 6) | (6 << 12) | (6 << 16) | (11 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                default
                    : {
                    np_c = 8;
                  };
              };
            };
          };
        };

        break;

        // analyse self knight
      case
          sBkn: {
          for (np_c = 0; np_c < 8; np_c++) {
            np_t = increasingKnightMap[np_i][np_c];

            switch (B[np_t]) {
              case
                  sEmp: {
                    ;
                  //move m = {np_i, np_t, sBkn, sBkn, '0'};
                  //#ifdef QS_CHECKS
                  /*
                  if (checksearch==true) {
                                 gl_move = (np_i | (np_t<<6) | (8<<12) | (8<<16));
                                 CHILD(ply);
                   if (isBlaCheckGood(WkiPos)==true) {
                                if (isAttByWhi(BkiPos)==false) {
                      saveBlaPosition(np_offs); np_offs++;
                     };
                   };
                                 PARENT(ply);
                  };
                                //#endif
                                */
                    #ifdef QS_MATES
										//move m = {np_i, np_t, sBkn, sBkn, '0'};
                    gl_move = (np_i | (np_t<<6) | (8<<12) | (8<<16));
				            CHILD(ply);
				            if (isAttByBla(WkiPos)==true) {
		                  if (isWkiMated()==true) {
            	          if (isAttByWhi(BkiPos)==false) {
									        saveBlaPosition(np_offs); np_offs++;
									        PARENT(ply); goto END;
                        };
	                    };
			              };
				            PARENT(ply);
										#endif
                };

                break;
              case
                  sWpa: { //move m = {np_i, np_t, sBkn, sBkn, sWpa};
                  gl_move = (np_i | (np_t << 6) | (8 << 12) | (8 << 16) | (1 << 20));
                  CHILD(ply);

                  //if (checksearch==false) {
                  if (isAttByWhi(BkiPos) == false) {
									  if (isAttByWhi(np_t) == false) {
											saveBlaPosition(np_offs); np_offs++;
                    }
                    else {
                    	#ifdef QS_MATES
			                if (isAttByBla(WkiPos)==true) {
	                      if (isWkiMated()==true) {
								          saveBlaPosition(np_offs); np_offs++;
								          PARENT(ply); goto END;
								        };
                      };
									    #endif
										};
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWro: { //move m = {np_i, np_t, sBkn, sBkn, sWro};
                  gl_move = (np_i | (np_t << 6) | (8 << 12) | (8 << 16) | (3 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWbi: { //move m = {np_i, np_t, sBkn, sBkn, sWbi};
                  gl_move = (np_i | (np_t << 6) | (8 << 12) | (8 << 16) | (5 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWkn: { //move m = {np_i, np_t, sBkn, sBkn, sWkn};
                  gl_move = (np_i | (np_t << 6) | (8 << 12) | (8 << 16) | (7 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWqu: { //move m = {np_i, np_t, sBkn, sBkn, sWqu};
                  gl_move = (np_i | (np_t << 6) | (8 << 12) | (8 << 16) | (11 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
                case
							  sOut: {break;}; break;
            };
          };
        };

        break;
      case
          sBki: {

          //todo qs_checks

          /*
          //#ifdef QS_CHECKS
          if (checksearch==true) {
           // if positive k-side castle status
            if (castle_dat != (castle_dat | castle_lost_BKK_mask)) {
            //if king not checked
            if (CheckStatus[ply-1]==false) {
              //if empty two squares on the right side of the king
              if (B[5]==sEmp) {
                if (B[6]==sEmp) {
                    //if empty squares are not in check
                if (isAttByWhi(5)==false) {
                    if (isAttByWhi(6)==false) {
                  //add k-side castle move
                 //move m = {4, 6, sBki, sBki, '0'}; and move m = {7, 5, sBro, sBro, '0'};
                  gl_move = (4 | (6<<6) | (10<<12) | (10<<16));
                 CHILD(ply);
                  if (isBlaCheckGood(WkiPos)==true) {
                   saveBlaPosition(np_offs); np_offs++;
                 };
                 PARENT(ply);
                };
               };
                  };
                };
              };
                   };
                   // if positive q-side castle status
            if (castle_dat != (castle_dat | castle_lost_BKQ_mask)) {
            //if king not checked
            if (CheckStatus[ply-1]==false) {
             //if empty THREE squares on the left side of the king
                if (B[3]==sEmp) {
                  if (B[2]==sEmp) {
                if (B[1]==sEmp) {
                    //if TWO empty squares are not in check
                if (isAttByWhi(3)==false) {
                  if (isAttByWhi(2)==false) {
                      //add q-side castle move
                  //move m = {4, 2, sBki, sBki, '0'}; and move m = {0, 3, sBro, sBro, '0'};
                   gl_move = (4 | (2<<6) | (10<<12) | (10<<16));
                   CHILD(ply);
                   if (isBlaCheckGood(WkiPos)==true) {
                      saveBlaPosition(np_offs); np_offs++;
                  };
                    PARENT(ply);
                 };
                };
                   };
                 };
                };
              };
            };
          };
               //#endif
               */
          for (np_v = 0; np_v < 8; np_v++) {
            np_t = Vec[np_v][np_i][0];

            switch (B[np_t]) {
              case
                  sEmp: {
                  ;//move m = {np_i, np_t, sBki, sBki, '0'};
                  /*
                     //#ifdef QS_CHECKS
                     if (checksearch==true) {
                      gl_move = (np_i | (np_t<<6) | (10<<12) | (10<<16));
                      CHILD(ply);
                       if (isBlaCheckGood(WkiPos)==true) {
                            if (isAttByWhi(BkiPos)==false) {
                           saveBlaPosition(np_offs); np_offs++;
                        };
                      };
                      PARENT(ply);
                     };
                  //#endif
                  */

                  #ifdef QS_MATES
                  //move m = {np_i, np_t, sBki, sBki};
                  gl_move = (np_i | (np_t << 6) | (10 << 12) | (10 << 16));
		              CHILD(ply);
		              if (isAttByBla(WkiPos)==true) {
                    if (isWkiMated()==true) {
        	            if (isAttByWhi(BkiPos)==false) {
							          saveBlaPosition(np_offs); np_offs++;
							          PARENT(ply); goto END;
                      };
                    };
	                };
		              PARENT(ply);
								  #endif
                };

                break;
              case
                  sWpa: { //move m = {np_i, np_t, sBki, sBki, sWpa};
                  gl_move = (np_i | (np_t << 6) | (10 << 12) | (10 << 16) | (1 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWro: { //move m = {np_i, np_t, sBki, sBki, sWro};
                  gl_move = (np_i | (np_t << 6) | (10 << 12) | (10 << 16) | (3 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWbi: { //move m = {np_i, np_t, sBki, sBki, sWbi};
                  gl_move = (np_i | (np_t << 6) | (10 << 12) | (10 << 16) | (5 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWkn: { //move m = {np_i, np_t, sBki, sBki, sWkn};
                  gl_move = (np_i | (np_t << 6) | (10 << 12) | (10 << 16) | (7 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
              case
                  sWqu: { //move m = {np_i, np_t, sBki, sBki, sWqu};
                  gl_move = (np_i | (np_t << 6) | (10 << 12) | (10 << 16) | (11 << 20));
                  CHILD(ply);

                  if (isAttByWhi(BkiPos) == false) {
                    saveBlaPosition(np_offs);
                    np_offs++;
                  };

                  PARENT(ply);
                };

                break;
            };
          };
        };

        break;
      case
          sBqu: {
          for (np_v = 0; np_v < 8; np_v++) {
            for (np_c = 0; np_c < 8; np_c++) {
              np_t = Vec[np_v][np_i][np_c];

              switch (B[np_t]) {
                case
                  sEmp: {
                    ;//move m = {np_i, np_t, sBqu, sBqu, '0'};
                    /*
                    //#ifdef QS_CHECKS
                    if (checksearch==true) {
                                     gl_move = (np_i | (np_t<<6) | (12<<12) | (12<<16));
                      CHILD(ply);
                                     if (isBlaCheckGood(WkiPos)==true) {
                                    if (isAttByWhi(BkiPos)==false) {
                         saveBlaPosition(np_offs); np_offs++;
                      };
                      };
                                     PARENT(ply);
                    };
                                    //#endif
                                    */

                    #ifdef QS_MATES
	                  //move m = {np_i, np_t, sBqu, sBqu};
	                  gl_move = (np_i | (np_t << 6) | (12 << 12) | (12 << 16));
			              CHILD(ply);
			              if (isAttByBla(WkiPos)==true) {
	                    if (isWkiMated()==true) {
	        	            if (isAttByWhi(BkiPos)==false) {
								          saveBlaPosition(np_offs); np_offs++;
								          PARENT(ply); goto END;
	                      };
	                    };
		                };
			              PARENT(ply);
									  #endif

									};

                  break;
                case
                    sWpa: { //move m = {np_i, np_t, sBqu, sBqu, sWpa};
                    gl_move = (np_i | (np_t << 6) | (12 << 12) | (12 << 16) | (1 << 20));
                    CHILD(ply);

                    //if (checksearch==false) {
                    if (isAttByWhi(BkiPos) == false) {
										  if (isAttByWhi(np_t) == false) {
												saveBlaPosition(np_offs); np_offs++;
                      }
                      else {
                      	#ifdef QS_MATES
				                if (isAttByBla(WkiPos)==true) {
		                      if (isWkiMated()==true) {
									          saveBlaPosition(np_offs); np_offs++;
									          PARENT(ply); goto END;
									        };
                        };
										    #endif
											};
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sWro: { //move m = {np_i, np_t, sBqu, sBqu, sWro};
                    gl_move = (np_i | (np_t << 6) | (12 << 12) | (12 << 16) | (3 << 20));
                    CHILD(ply);

                    //if (checksearch==false) {
                    if (isAttByWhi(BkiPos) == false) {
										  if (isAttByWhi(np_t) == false) {
												saveBlaPosition(np_offs); np_offs++;
                      }
                      else {
                      	#ifdef QS_MATES
				                if (isAttByBla(WkiPos)==true) {
		                      if (isWkiMated()==true) {
									          saveBlaPosition(np_offs); np_offs++;
									          PARENT(ply); goto END;
									        };
                        };
										    #endif
											};
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sWbi: { //move m = {np_i, np_t, sBqu, sBqu, sWbi};
                    gl_move = (np_i | (np_t << 6) | (12 << 12) | (12 << 16) | (5 << 20));
                    CHILD(ply);

                    //if (checksearch==false) {
                    if (isAttByWhi(BkiPos) == false) {
										  if (isAttByWhi(np_t) == false) {
												saveBlaPosition(np_offs); np_offs++;
                      }
                      else {
                      	#ifdef QS_MATES
				                if (isAttByBla(WkiPos)==true) {
		                      if (isWkiMated()==true) {
									          saveBlaPosition(np_offs); np_offs++;
									          PARENT(ply); goto END;
									        };
                        };
										    #endif
											};
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sWkn: { //move m = {np_i, np_t, sBqu, sBqu, sWkn};
                    gl_move = (np_i | (np_t << 6) | (12 << 12) | (12 << 16) | (7 << 20));
                    CHILD(ply);

                    //if (checksearch==false) {
                    if (isAttByWhi(BkiPos) == false) {
										  if (isAttByWhi(np_t) == false) {
												saveBlaPosition(np_offs); np_offs++;
                      }
                      else {
                      	#ifdef QS_MATES
				                if (isAttByBla(WkiPos)==true) {
		                      if (isWkiMated()==true) {
									          saveBlaPosition(np_offs); np_offs++;
									          PARENT(ply); goto END;
									        };
                        };
										    #endif
											};
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                case
                    sWqu: { //move m = {np_i, np_t, sBqu, sBqu, sWqu};
                    gl_move = (np_i | (np_t << 6) | (12 << 12) | (12 << 16) | (11 << 20));
                    CHILD(ply);

                    if (isAttByWhi(BkiPos) == false) {
                      saveBlaPosition(np_offs);
                      np_offs++;
                    };

                    PARENT(ply);

                    np_c = 8;
                  };

                  break;
                default
                    : {
                    np_c = 8;
                  };
              };
            };
          };
        };

        break;
      default
          : {
          ;
        };
    };
  };

  END:{;};

/*
//in qs bla ply
  #ifdef REUSE_EVAL
  do_reuse_eval = false;
  #endif
*/
//if mate is found: dont save other moves to the tree:
//just one mating move.
//this will reduce tree size in full search and in qs
//save sorted moves to the tree in the right order
  if ((grade[0] == MIN_SCORE)
	&& (np_offs > 0)
	&& (ply > 1)
	) {
    np_offs = 1;
    MOVES_TREE[(ply << 8) | 0] = mymove[0]; //assign matingmove to the TREE
    UnsPosTree[(ply << 8) | 0].lastMove = mymove[0];
    VALS_TREE[(ply << 8) | 0] = MIN_SCORE; //assign matescore to the TREE
    //cout<<"mating move: "<<printMove(mymove[0])<<endl; printB("BLACK MATES:");

		#ifdef DEBUG_VERSION
		qsply_positions_count += np_offs;
    qsply_branch_count++;
    mate_qsply_branch_count++;
		#endif

		return np_offs; //return offset==1 mating move
  };

//////////////////////////////////////////
  /*
  now capture moves are sorted only by winned material
  reorder them:
    if the same captured piece in move B and A
     endless loop: if (B from piece > A from piece) swap moves and continue swaps until noncap found.
     break if no swap found
  */
#ifdef ATTA_REORD
  if (np_offs > 1)
    //if at least two moves
  {
    goto AR_LOOP;
AR_LOOP: {
      np_i = 1; //take second move index

      while (np_i < np_offs)
        //until offset end
      {
        gl_cp = ((mymove[np_i] << 8) >> 28);    //take second move captured piece

        if (gl_cp != 0)
          //if noncap
        {
          if (gl_cp == ((mymove[np_i - 1] << 8) >> 28)
             )
            //if the same captured piece type
          {
            ///if order of attackers to improve
            if ((UnsignedMaterialValue[((mymove[np_i] << 16) >> 28) ])
                <
                (UnsignedMaterialValue[((mymove[np_i - 1] << 16) >> 28) ])) {
              //ar_swap = true; //set loop repetition condition
              //swap moves and grades
              ar_move = mymove[np_i - 1];
              ar_grade = grade[np_i - 1];
              mymove[np_i - 1] = mymove[np_i];
              grade[np_i - 1] = grade[np_i];
              mymove[np_i] = ar_move;
              grade[np_i] = ar_grade;
              //repeat from beginning
              goto AR_LOOP;
            };
          };
        };

        np_i++;
      };
    };
  };

#endif



//////////////////////////////////////////
//insert null-move into the ply if allowed -
//the move would not be insorted after mating move
//(mate is always first and only move in the ply)
//move will not be later saved if mate was found (restricted offset)
//or if not position under check (this would lead to illegal position)
//IF NODE IS NOT PV NODE
//if proper depth
#ifdef NULL_MOVE
  //if no null move set upper
  if @@
    //if proper max ply
    //if (ply<qDepth-nms_reduction) {
    if (ply < qDepth) {
      //if (MOVES_TREE[((ply-1)<<8)|cur_offs[ply-1]]>2) {
      //if self king not in check
      if (CheckStatus[ply - 1] == false) {
        //if no check in the path
        //if (first_check_depth==0) {
        //if enough self material /little chance for zugzwang
        if ((BquNum > 0) || (BroNum > 0)) {
          //if proper min ply
          if (ply >= nms_min_ply) {
            //suitable move for black
            gl_move = 2;
            CHILD(ply);
            //if (isAttByWhi(BkiPos)==false) {saveBlaPosition(np_offs); np_offs++;};
            saveBlaPosition(np_offs);
            np_offs++;
            PARENT(ply);
          };
        };
      };
    };
  };
#endif

#ifdef CHECK_REORD
//////////////////////////////////////////
//do another sorting: search moves from the best to the weakest
//if check in the ply is found:
//if the first move is null - continue
//if the move is check - continue
//reorder moves
  /*
  np_i = 0;
  cout<<"moves BEFORE check_reord: "<<flush;
  while (np_i<np_offs) {
   cout<<"["<<np_i<<"]:"<<printMove(mymove[np_i])<<" "<<flush;
    np_i++;
  };
  cout<<endl;
  */
//take second move if any
  np_i = 1;

  while (np_i < np_offs) {
    //if the move causes the white king is checked
    if (mymove[np_i] == (mymove[np_i] | (1 << 31))) {
      //save this move
      ar_move = mymove[np_i];
      ar_grade = grade[np_i];
      //move all moves before it
      //which are not null move nor check ahead one step
      np_j = np_i;

      //if we have no null move first in the ply
      if (mymove[0] != 2) {
        //if safe bound
        while (np_j > 0) {
          //if previous move is not check
          if (mymove[np_j - 1] != (mymove[np_j - 1] | (1 << 31))) {
            //just move it ahead and consider previous move
            mymove[np_j] = mymove[np_j - 1];
            grade[np_j] = grade[np_j - 1];
            np_j--;
          }
          //if previous move is check - break at curent index
          else {
            break;
          };
        };

        //move save ar_move and ar grade into curent index
        mymove[np_j] = ar_move;

        grade[np_j] = ar_grade;
      }
      //if we have null move first
      else {
        //if safe bound
        while (np_j > 1) {
          //if previous move is not check
          if (mymove[np_j - 1] != (mymove[np_j - 1] | (1 << 31))) {
            //just move it ahead and consider previous move
            mymove[np_j] = mymove[np_j - 1];
            grade[np_j] = grade[np_j - 1];
            np_j--;
          }
          //if previous move is check - break at curent index
          else {
            break;
          };
        };

        //move save ar_move and ar grade into curent index
        mymove[np_j] = ar_move;

        grade[np_j] = ar_grade;
      };
    };

    np_i++;
  };

//////////////////
  /*
  np_i = 0;
    cout<<"moves AFTER check_reord: "<<flush;
  while (np_i<np_offs) {
   cout<<"["<<np_i<<"]:"<<printMove(mymove[np_i])<<" "<<flush;
    np_i++;
  };
    cout<<endl;
    */
///////////////
#endif
//////////////////////////////
//save sorted and marked data into the tree
  finishSavePositionInNewPly();


#ifdef CUTTOFF_MOVE_HASH_REORDER

////////////////////////////////////////////////////////////////////
//reorder the cuttoff move if found in the beginning of the ply
//if Zkey matches and there is available the best move which produced a cuttoff
//HT==
//[Zkey(64bits)]
//[score(20bits)-val(20bits)-ply(6bits)-qDepth(6bits)-BestMovetofrom(12bits)]
  if (ply > 1) {
    Hkey = (Zkey >> (Zkeylen - Hkeylen));

    if (HT[Hkey][0] == Zkey) {
      if (((HT[Hkey][1] << 52) >> 52)
          != 0)
        //if best move available
      {
        //find the best move index
        np_i = 0;

        while (np_i < np_offs) {
          //if the move coords matches insort it into the beginning of the ply
          if (((MOVES_TREE[np_c | np_i] << 20) >> 20)
              == ((HT[Hkey][1] << 52) >> 52)) {
            //cout<<"best move:"<<printMove(MOVES_TREE[np_c|np_i])<<
            //"at idx:"<<np_i<<endl;
            //copy the value of found move
            se_v = VALS_TREE[np_c | np_i];

            //copy all moves and values one move forward to the found move pos
            for (se_j = np_i; se_j > 0; se_j--) {
              MOVES_TREE[np_c | se_j] = MOVES_TREE[np_c | (se_j - 1) ];
              VALS_TREE[np_c | se_j] = VALS_TREE[np_c | (se_j - 1) ];
            };

            //paste found move and its value in the first move pos
            MOVES_TREE[np_c | 0] = MOVES_TREE[np_c | np_i];

            VALS_TREE[np_c | 0] = se_v;

            break;
          };

          np_i++;
        };
      };
    };
  };

//////////////////////////////////////////////
#endif

#ifdef DEBUG_VERSION
	qsply_positions_count += np_offs;
  qsply_branch_count++;
  if (np_offs==0) {empty_qsply_branch_count++;};
#endif

	return np_offs;
};

#ifdef DEBUG_VERSION
void printTreeLevels(unsigned char startply, unsigned char stopply)
{
  unsigned char i = 0;

  if (Log) {
    ofstream fout("Log.txt", ios::app);

    while (startply <= stopply) {
      fout << "Sorted moves (stored evals) of ply[" << startply << "], max_offs[" << startply
           << "]==" << max_offs[startply]
           << ", cur_offs[" << startply << "]==" << cur_offs[startply] <<
           " are:" << endl;

      while (i < max_offs[startply]) {
        fout << "[" << i << "]" << printMove(MOVES_TREE[(startply << 8) | i]) << "(" <<
             (VALS_TREE[(startply << 8) | i] / 100) << "), " << flush;
        i++;
        //show few moves in a row
        //if ((i==10)||(i==20)||(i==30)||(i==40)||(i==50)||(i==60))
        fout << endl;
      };

      fout << endl << endl;

      startply++;
    };
  };
};
#endif

#ifdef DEBUG_VERSION
void getTreeLevels(unsigned char startply, unsigned char stopply)
{
  int i = 0;

  while (startply <= stopply) {
    cout << "Sorted moves (stored evals) of ply[" << startply << "], max_offs[" << startply
         << "]==" << max_offs[startply]
         << ", cur_offs[" << startply << "]==" << cur_offs[startply] <<
         " are:" << endl;

    while (i < max_offs[startply]) {
      cout << "[" << i << "]" << printMove(MOVES_TREE[(startply << 8) | i]) << "(" <<
           (VALS_TREE[(startply << 8) | i] / 100) << "), " << flush;
      i++;
      //show few moves in a row
      //if ((i==10)||(i==20)||(i==30)||(i==40)||(i==50)||(i==60))
      //fout<<endl;
    };

    cout << endl;

    startply++;
  };
};
#endif

#ifdef DEBUG_VERSION
void printAll(string note, unsigned char ply)
{
  ;
  /*WARNING: this function makes a geat slowdown*/

  if (Log == false) {
    return;
  };

  ofstream fout("Log.txt", ios::app);

  int j;

  fout << "---------------------------//...printAll() START----------------------------" << endl;

//printGameBoard(GMI);
  printB("");

  fout << note << endl << endl;

  fout << "ply:" << ply << " qDepth:" << qDepth << endl;

  printPATH(0, ply);

  fout << "PV:" << flush;

  for (j = 0; j < PVlen[0]; j++)
    //PV
  {
    fout << printMove(PV[0][j]) << " " << flush;
  };

  fout << endl;

  fout << "GamePV:" << flush;

  for (j = 0; j < GamePVlen[GMI]; j++)
    //PV
  {
    fout << printMove(GamePV[GMI][j]) << " " << flush;
  };

  fout << endl;

//printEVAL(GameWtm[GMI+ply]);
//printEvals(ply);
  printVals();

  printSearchStats();

//printPVstats();
//printTreeLevels();
//printCutInfo();
//printWtm();
//printMiniMax();
//fout<<endl<<"Search time in centisecs:"
//<<" positions_count:"<<positions_count<<endl;
  fout << "---------------------------END----------------------------" << endl << endl;
};
#endif

//Function loading Game pieces data with data from string sBoard pointer in FEN standard and
//updates material counts. Other params must be updated.
//Return true if data is valid. false if invalid.
bool setGameMaterial(string F)
{
// reset all material counts
  WpaNum = 0;
  BpaNum = 0;
  WroNum = 0;
  BroNum = 0;
  WbiNum = 0;
  BbiNum = 0;
  WknNum = 0;
  BknNum = 0;
  WquNum = 0;
  BquNum = 0;
  MaterialScore = 0;
//clear and set Board
  int i = 0;

  while (i < 64) {
    GameBoard[0][i] = sEmp;
    i++;
  };

  i = 0;

  int d = 0;

  int len = ((int)(F.length()));

  while (i < len) {
    switch (F.at(i)) {
      case '/'
          : {
          ;
        };

        break;
      case '1'
          : {
          d++;
        };

        break;
      case '2'
          : {
          d += 2;
        };

        break;
      case '3'
          : {
          d += 3;
        };

        break;
      case '4'
          : {
          d += 4;
        };

        break;
      case '5'
          : {
          d += 5;
        };

        break;
      case '6'
          : {
          d += 6;
        };

        break;
      case '7'
          : {
          d += 7;
        };

        break;
      case '8'
          : {
          d += 8;
        };

        break;
      case 'P'
          : {
          GameBoard[0][d] = sWpa;
          WpaNum++;
          MaterialScore += evPawnMaterialValue;
          d++;
        };

        break;
      case 'p'
          : {
          GameBoard[0][d] = sBpa;
          BpaNum++;
          MaterialScore -= evPawnMaterialValue;
					d++;
        };

        break;
      case 'R'
          : {
          GameBoard[0][d] = sWro;
          WroNum++;
          MaterialScore += evRookMaterialValue;
          d++;
        };

        break;
      case 'r'
          : {
          GameBoard[0][d] = sBro;
          BroNum++;
          MaterialScore -= evRookMaterialValue;
          d++;
        };

        break;
      case 'B'
          : {
          GameBoard[0][d] = sWbi;
          WbiNum++;
          MaterialScore += evBishopMaterialValue;
          d++;
        };

        break;
      case 'b'
          : {
          GameBoard[0][d] = sBbi;
          BbiNum++;
          MaterialScore -= evBishopMaterialValue;
          d++;
        };

        break;
      case 'N'
          : {
          GameBoard[0][d] = sWkn;
          WknNum++;
          MaterialScore += evKnightMaterialValue;
          d++;
        };

        break;
      case 'n'
          : {
          GameBoard[0][d] = sBkn;
          BknNum++;
          MaterialScore -= evKnightMaterialValue;
          d++;
        };

        break;
      case 'K'
          : {
          GameBoard[0][d] = sWki;
          WkiPos = d;
          d++;
        };

        break;
      case 'k'
          : {
          GameBoard[0][d] = sBki;
          BkiPos = d;
          d++;
        };

        break;
      case 'Q'
          : {
          GameBoard[0][d] = sWqu;
          WquNum++;
          MaterialScore += evQueenMaterialValue;
          d++;
        };

        break;
      case 'q'
          : {
          GameBoard[0][d] = sBqu;
          BquNum++;
          MaterialScore -= evQueenMaterialValue;
          d++;
        };

        break;
      default
          : {
          return false;
        };
    };

    i++;
  };

//////////////////////////////////////
//set global king area boards
  for (ev_v = 0; ev_v < 64; ev_v++) {
    WkiArea[ev_v] = 0;
    BkiArea[ev_v] = 0;
  };

  WkiArea[WkiPos] = 1;

  BkiArea[BkiPos] = 1;

  for (ev_v = 0; ev_v < 8; ev_v++) {
    WkiArea[Vec[ev_v][WkiPos][0]] = 1;
    BkiArea[Vec[ev_v][BkiPos][0]] = 1;
  };

//////////////////////////////////////
  return true;
};

/*
Function sets side to move. it may be used in initiating position from FEN in setboard command
Return true if data is valid. false if invalid.
*/
bool setGameSideToMove(string F)
{
  if (F == "w") {
    int i = 0;

    while (i < 500) {
      GameWtm[i] = true;
      GameWtm[i + 1] = false;
      i += 2;
    };

    return true;
  } else
    if (F == "b") {
      int i = 0;

      while (i < 500) {
        GameWtm[i] = false;
        GameWtm[i + 1] = true;
        i += 2;
      };

      return true;
    } else {
      return false;
    };
};

/*
Function sets castle status. it i.e. may be used in initiating position from FEN or in new()
Return true if data is valid. false if invalid.
*/
bool setGameCastleStatus(string F)
{
// set castle rights
  char c;
  int Flen = ((int)(F.length()));
  int i = 0;
  Game_castle_data[GMI] = 0;

  while (i < Flen) {
    c = F.at(i);

    switch (c) {
      case 'K'
          : {
          Game_castle_data[GMI] |= castle_lost_WKK_mask; //always set bit
          Game_castle_data[GMI] ^= castle_lost_WKK_mask; //always clear bit
        };

        break;
      case 'Q'
          : {
          Game_castle_data[GMI] |= castle_lost_WKQ_mask;
          Game_castle_data[GMI] ^= castle_lost_WKQ_mask;
        };

        break;
      case 'k'
          : {
          Game_castle_data[GMI] |= castle_lost_BKK_mask;
          Game_castle_data[GMI] ^= castle_lost_BKK_mask;
        };

        break;
      case 'q'
          : {
          Game_castle_data[GMI] |= castle_lost_BKQ_mask;
          Game_castle_data[GMI] ^= castle_lost_BKQ_mask;
        };

        break;
      case '-'
          : {
          Game_castle_data[GMI] |= castle_lost_WKK_mask; //always set bit
          Game_castle_data[GMI] |= castle_lost_WKQ_mask;
          Game_castle_data[GMI] |= castle_lost_BKK_mask;
          Game_castle_data[GMI] |= castle_lost_BKQ_mask;
        };

        break;
      default
          : {
          return false;
        };
    };

    i++;
  };

//if king can castle potentially - set search castle status
  /*
  if ((GameWKK[GMI]==true) || (GameWKQ[GMI]==true))
  {gl_WKK = false;} else {SEARCH_WKI_CASTLED = true;};

  if ((GameBKK[GMI]==true) || (GameBKQ[GMI]==true))
  {SEARCH_BKI_CASTLED = false;} else {SEARCH_BKI_CASTLED = true;};
  */
  return true;
};
/*
Function sets enpassant status. it i.e. may be used in initiating position from FEN or in new()
Return true if data is valid. false if invalid.
*/
bool setGameEnpassantStatus(string F)
{
  char c;
  char d;
  int Flen = ((int)(F.length()));

  if (Flen == 1) {
    c = F.at(0);

    if (c == '-') {
      GameEnpassant[GMI] = 64;
      return true;
    } else {
      return false;
    };
  } else
    if (Flen == 2) {
      c = F.at(0);
      d = F.at(1);

      switch (c) {
        case 'a'
            : {
            if (d == '3') {
              GameEnpassant[GMI] = 40;
            } else
              if (d == '6') {
                GameEnpassant[GMI] = 16;
              } else {
                return false;
              };
          };

          break;
        case 'b'
            : {
            if (d == '3') {
              GameEnpassant[GMI] = 41;
            } else
              if (d == '6') {
                GameEnpassant[GMI] = 17;
              } else {
                return false;
              };
          };

          break;
        case 'c'
            : {
            if (d == '3') {
              GameEnpassant[GMI] = 42;
            } else
              if (d == '6') {
                GameEnpassant[GMI] = 18;
              } else {
                return false;
              };
          };

          break;
        case 'd'
            : {
            if (d == '3') {
              GameEnpassant[GMI] = 43;
            } else
              if (d == '6') {
                GameEnpassant[GMI] = 19;
              } else {
                return false;
              };
          };

          break;
        case 'e'
            : {
            if (d == '3') {
              GameEnpassant[GMI] = 44;
            } else
              if (d == '6') {
                GameEnpassant[GMI] = 20;
              } else {
                return false;
              };
          };

          break;
        case 'f'
            : {
            if (d == '3') {
              GameEnpassant[GMI] = 45;
            } else
              if (d == '6') {
                GameEnpassant[GMI] = 21;
              } else {
                return false;
              };
          };

          break;
        case 'g'
            : {
            if (d == '3') {
              GameEnpassant[GMI] = 46;
            } else
              if (d == '6') {
                GameEnpassant[GMI] = 22;
              } else {
                return false;
              };
          };

          break;
        case 'h'
            : {
            if (d == '3') {
              GameEnpassant[GMI] = 47;
            } else
              if (d == '6') {
                GameEnpassant[GMI] = 23;
              } else {
                return false;
              };
          };

          break;
        default
            : {
            return false;
          };
      };
    } else {
      return false; // if different length
    };

  return true; //if its alright
};

/*
//sort tab[] containing n elements in grow order
void InsertionSort(int tab[], int n, bool grow) {
  int i, j, item;
 if (grow==false) {
   for (i=1;i<n;i++) {
     item = tab[i];
     for (j=i; ((j>0)&&(tab[j-1]<item)); j--) {tab[j]=tab[j-1];};
     tab[j] = item;
   };
 }
 else {
   for (i=1;i<n;i++) {
     item = tab[i];
     for (j=i; ((j>0)&&(tab[j-1]>item)); j--) {tab[j]=tab[j-1];};
     tab[j] = item;
   };
  };
};
*/

/*
void LinearSort(int mymove[], int n) {
 int min = MAX_SCORE;
 int max = 0;
  for (int i=0;i<n;i++) {
  temp = mymove[i];
    CoordLine[temp] = 1;
    if (temp>max) max = temp;
    if (temp<min) min = temp;
 };
 int i=0;
 if (WTM==false) {
    while (min<=max) {
     if (CoordLine[min]) {
     CoordLine[min]--;
    mymove[i++]=min;
     };
     min++;
   };
 }
 else {
    while (min<=max) {
      if (CoordLine[max]) {
     CoordLine[max]--;
    mymove[i++]=max;
     };
     max--;
   };
 };
};


int Partition(int mymove[], int left, int right) {
  int val = mymove[left];
 int lm = left-1;
 int rm = right+1;
 if (WTM==true) {
   while (true) {
    do rm--; while (mymove[rm] < val);
    do lm++; while (mymove[lm] > val);
    if(lm < rm) {int tempr = mymove[rm]; mymove[rm] = mymove[lm]; mymove[lm] = tempr;}
    else {return rm;};
    };
  }
  else {
    while (true) {
    do rm--; while (mymove[rm] > val);
    do lm++; while (mymove[lm] < val);
    if(lm < rm) {int tempr = mymove[rm]; mymove[rm] = mymove[lm]; mymove[lm] = tempr;}
    else {return rm;};
    };
  };
};


void Quicksort(int mymove[], int left, int right) {
  if(left < right) {
  int split_pt = Partition(grade, left, right);
  Quicksort(grade, left, split_pt);
  Quicksort(grade, split_pt+1, right);
  };
};
*/




/*
SEARCH() is powerful iterative fixed-depth-first search routine. it is also used for illegal
move pruning, 50 move draw pruning, alfa-beta pruning, quiesence pruning, stalemate pruning,
futility pruning.
This function is used in IterativeDeeping() function which increments depth search and reuses information
from previous search.
SEARCH() is a alfa-beta algorithm which is called iteratively form
IterativeSearch().
It works as  follows:
  -start always from the root,
  -go from the tree root to the tree leaf:
     if PV is not empty at current ply: use this path to build first branch
      else: build the first branch using best static eval positions
  -if on the bottom - eval siblings and go up (use alfa-beta cuttoffs),
  update PV while moving through the tree. Go down if possible to the leaves,
   but in this case dont use PV to build the tree,
  - if SEARCH() ends normally - increment ply and do the same procedure again(iterative Search)
*/

/*
pruning idea.
dont extend moves which result doesnt change much in position.
i.e. if it is a pawn move - extend the search it if one of the following occurs:
  - the pawn is attacking opponent by the move (simple to implement)
 - the pawn is attacking square attacked by the opponent (simple o implement)
 - the pawn is freeing self piece (find attacks_to of self piece on from_square)
 - there is a danger of zugzwang
Else: return curent static score or q-search score of curent position.
Searching of such position is a waste of time because it is like a a null move:
no new opportunities such a move creates, and we are letting the opponent to imrove his position
*/
/*
bool isMoveWeak(unsigned int move, int ply) {

 return false;

  int fs = ((move<<26)>>26);
  int ts = ((move<<20)>>26);
  int fp = ((move<<16)>>28);
  int tp = ((move<<12)>>28);
  int cp = ((move<<8)>>28);
  int temp;
  switch (fp) {

  case (1): { //wpa
      //return false if pawn enters the enemy territory (promotion threat)
   if (fs<32) {return false;};
   //return false if capture
   if (cp!=0) {return false;};
   //return false if endgame
   int WhiMat = (WpaNum * evPawnMaterialValue) + (WroNum * evRookMaterialValue) + (WbiNum * evBishopMaterialValue) + (WknNum * evKnightMaterialValue)
           + (WquNum * evQueenMaterialValue);
   if (WhiMat < 1500) {return false;};

   //return false if pawn is escaping from attacked square
   if (isAttByBla(fs)==true) {return false;};
   //return false if pawn is entering on attacked square
   if (isAttByBla(ts)==true) {return false;};
   //return false if pawn is freeing self piece
   if (isAttByWhi(fs)==true) {return false;};
   //return false if pawn is supported by self piece
   if (isAttByWhi(ts)==true) {return false;};

   //return false if pawn is attacking square attacked or occupied by any piece
     temp = LWPCaps[ts];
   if (temp!=64) {
    if (isOccByBla(temp)==true) {return false;};
    if (isOccByWhi(temp)==true) {return false;};
     if (isAttByWhi(temp)==true) {return false;};
    if (isAttByBla(temp)==true) {return false;};
   };
   temp = RWPCaps[ts];
   if (temp!=64) {
     if (isOccByBla(temp)==true) {return false;};
    if (isOccByWhi(temp)==true) {return false;};
     if (isAttByWhi(temp)==true) {return false;};
    if (isAttByBla(temp)==true) {return false;};
   };

   cout<<"!!! Prunned move: "<<printMove(move)<<" at path "
   <<getPATH(0,ply)<<" at ply "<<ply<<" !!!"<<endl;
   PrunnedCount++;
   return true;

  }; break;
  case (2): { //bpa
      //return false if pawn enters the enemy territory (promotion threat)
   if (fs>31) {return false;};
   //return false if capture
   if (cp!=0) {return false;};
   //return false if endgame
   int BlaMat = (BpaNum * evPawnMaterialValue) + (BroNum * evRookMaterialValue) + (BbiNum * evBishopMaterialValue) + (BknNum * evKnightMaterialValue)
      + (BquNum * evQueenMaterialValue);
   if (BlaMat < 1500) {return false;};

   if (isAttByBla(fs)==true) {return false;};
   if (isAttByBla(ts)==true) {return false;};
   if (isAttByWhi(fs)==true) {return false;};
   if (isAttByWhi(ts)==true) {return false;};

   //return false if pawn is attacking square attacked or occupied by any piece
     temp = LBPCaps[ts];
   if (temp!=64) {
    if (isOccByBla(temp)==true) {return false;};
    if (isOccByWhi(temp)==true) {return false;};
     if (isAttByWhi(temp)==true) {return false;};
    if (isAttByBla(temp)==true) {return false;};
   };
   temp = RBPCaps[ts];
   if (temp!=64) {
     if (isOccByBla(temp)==true) {return false;};
    if (isOccByWhi(temp)==true) {return false;};
     if (isAttByWhi(temp)==true) {return false;};
    if (isAttByBla(temp)==true) {return false;};
   };

   cout<<"!!! Prunned move: "<<printMove(move)<<" at path "
   <<getPATH(0,ply)<<" at ply "<<ply<<" !!!"<<endl;
   PrunnedCount++;
   return true;
  }; break;

  default: {return false;};
 };

};
*/



void outputSomeThinking()
{
  /*
  Handle Winboard format thinking output
  If the user asks your engine to "show thinking", xboard sends your engine the "post" command.
  It sends "nopost" to turn thinking off. In post mode, your engine sends output lines to show
  the progress of its thinking. The engine can send as many or few of these lines as it wants to,
  whenever it wants to. Typically they would be sent when the PV (principal variation) changes
  or the depth changes. The thinking output should be in the following format:
  ply score time nodes pv
  Where:
  ply - Integer giving current search depth.
  score - Integer giving current evaluation in centipawns.
  time - Current search time in centiseconds (ex: 1028 = 10.28 seconds).
  nodes - Nodes searched.
  pv - Freeform text giving current "best" line.
  You can continue the pv onto another line if you start
  each continuation line with at least four space characters.
  Example:
  9 156 1084 48000 Nf3 Nc6 Nc3 Nf6
  Meaning:
  9 ply, score=1.56, time = 10.84 seconds, nodes=48000, PV = "Nf3 Nc6 Nc3 Nf6"
  */
//show thinking line if score or pv or depth changes
//**also if time is up per move
  if (SHOW_WB_THINKING_OUTPUT == true) {
    if ((show_score_change == true)
        || (show_increment_change == true)
        || (show_last_result == true)) {
      show_score_change = false;
      show_increment_change = false;
      show_last_result = false;

      //handle absolute values. + is always good for white.
      if (GameWtm[GMI] == true) {
        if (GameVal[GMI] == MAX_SCORE) {
          out_score = (32768 - (2 * (GamePVlen[GMI] - 1)));
        } else
          if (GameVal[GMI] == MIN_SCORE) {
            out_score = (-32767 + (2 * (GamePVlen[GMI] - 1)));
          } else {
            out_score = (GameVal[GMI] / 100);
          };
      } else {
        if (GameVal[GMI] == MAX_SCORE) {
          out_score = (32768 - (2 * (GamePVlen[GMI] - 1)));
        } else
          if (GameVal[GMI] == MIN_SCORE) {
            out_score = (-32767 + (2 * (GamePVlen[GMI] - 1)));
          } else {
            out_score = (GameVal[GMI] / 100);
          };
      };

      //cout<<MAX_DEPTH_REACHED<<endl;
      cout << (unsigned short)qDepth << " " //current search depth
           << out_score << " " //score in centipawns
           << (__int64)(myTimer.getElapsedTimeInCentiseconds() - MoveStartTime) << " "      //time in centisecs

					 #ifdef DEBUG_VERSION
					 << (nonqs_child_count + qs_child_count)
					 #endif
					 //!!!!! if not defined
           #ifndef DEBUG_VERSION
           << (total_child_count)
           #endif

					 << flush; //nodes

      for (unsigned int j = 0; j < GamePVlen[GMI]; j++)
        //PV
      {
        cout << " " << printMove(GamePV[GMI][j]) << flush;
      };

      //progress in examining moves of first ply
      cout << " [" << (unsigned short)cur_offs[1] << "/" << (unsigned short)max_offs[1] << "]" <<flush;

      cout << endl;

      //debug
      //cout<<"GameVal[GMI]:"<<GameVal[GMI]<<"GamePVlen[GMI]"<<GamePVlen[GMI]<<endl;
    };
  };
};

//function defined in CommunicationSession implementation file,
//used also in Search() function
unsigned int GetMove(std::string);
unsigned int SEARCH()
{
  //se_return_static_eval = true;
  se_ply = 0;
  se_nextPly = 0;
  se_doPly = true;
  gl_move = 0;
  se_v = 0;
  se_j = 0;
  se_i = 0;
  se_r = 0;
  unsigned char se_z = 0;
  unsigned char se_h = 0;

#ifdef LATE_MOVE
	//turn on lmr
	lmr_already_used = false;
#endif

#ifdef OFFSET_PRUNNING
  reduced_tree_top = 0;
#endif
#ifdef MAT_POS_PRUNNING
  reduced_tree_top = 0;
#endif
//PVnode = false;
  goto FIRST_DOWN_PROC;
//////////////////////////////////////////////////////////////////////////////////////////////
//this procedure uses PV from search(depth-1) and from previous game move
//to step down using the best path so far.
//it is used once per first possible move in every SEARCH().
//then we use other search procedures.
//in first down proc - dont use null move because node belongs to pv path
FIRST_DOWN_PROC: {
    while (se_ply < qDepth)
      //normal search depth
    {
      if (GameWtm[GMI + se_ply])
        //wtm
      {
        //set check evasion status
        if (isAttByBla(WkiPos)) {
          CheckStatus[se_ply] = true;
        } else {
          CheckStatus[se_ply] = false;
        };

        //generate sorted se_ply
#ifdef NULL_MOVE
        //dont create null move in pv node
        //nms_set[ply] = false;

#endif

#ifdef SEARCH_REORD
        //dont create sr move in pv node
        sr_set = true;

#endif
        se_ply++;

        //always create full ply in pv
        max_offs[se_ply] = FULL_WHI_PLY(se_ply);
        se_ply_finished[se_ply] = true;

        //if no moves in the se_ply - get score and go to UP_PROC
        if (max_offs[se_ply] == 0) {
//#ifdef NULL_MOVE
          //@@@
          //nms_set = false;
//#endif

#ifdef SEARCH_REORD
          sr_set = false;
#endif
          se_ply--;

          if (CheckStatus[se_ply] == true) {
            val[se_ply] = MIN_SCORE;
          } else {
            val[se_ply] = DRAW_SCORE;
            //buggy?@
          };

          PVlen[se_ply] = se_ply;

          //gl_move = MOVES_TREE[((se_ply << 8) | cur_offs[se_ply])];

          //...printAll("end pos in FIRST_DOWN_PROC",se_ply);
          goto UP_PROC;
        };

#ifdef SELECTIVE_SEARCH
				//set flag
				//update_results_tab_score = true;
        //create table of first ply moves to better navigate search depth
        if ((INCREMENTS == 0) && (se_ply == 1)) {
          for (se_r = 0; se_r < max_offs[1]; se_r++) {
            results_tab[se_r][0] = MOVES_TREE[(se_ply << 8) | se_r];
          };
        };

#endif

        //reorder first-se_ply moves by search results from vals_tab[]
        if ((se_ply == 1) && (INCREMENTS > 0)) {
          //sort values and moves
          for (se_r = 0; se_r < max_offs[se_ply]; se_r++) {
            se_v = vals_tab[se_r];
            gl_move = moves_tab[se_r];

            for (se_j = se_r; ((se_j > 0) && (vals_tab[(se_j - 1) ] < se_v)); se_j--) {
              vals_tab[se_j] = vals_tab[se_j - 1];
              moves_tab[se_j] = moves_tab[se_j - 1];
            };

            vals_tab[se_j] = se_v;

            moves_tab[se_j] = gl_move;
          };

          //paste sorted moves and values
          for (se_r = 0; se_r < max_offs[se_ply]; se_r++) {
            MOVES_TREE[(1 << 8) | se_r] = moves_tab[se_r];
            VALS_TREE[(1 << 8) | se_r] = vals_tab[se_r];
          };
        };

        //insort PV move in the beginning of moves in children if
        //a move from PV is found
        for (se_r = 0; se_r < max_offs[se_ply]; se_r++) {
          if (GamePV[GMI][se_ply - 1] == MOVES_TREE[(se_ply << 8) | se_r]) {
            //copy the value of found move
            se_v = VALS_TREE[(se_ply << 8) | se_r];

            //copy all moves and values one move forward to the found move pos
            for (se_j = se_r; se_j > 0; se_j--) {
              MOVES_TREE[(se_ply << 8) | se_j] = MOVES_TREE[(se_ply << 8) | (se_j - 1) ];
              VALS_TREE[(se_ply << 8) | se_j] = VALS_TREE[(se_ply << 8) | (se_j - 1) ];
            };

            //paste found move and its value in the first move pos
            MOVES_TREE[(se_ply << 8) | 0] = GamePV[GMI][se_ply - 1];

            VALS_TREE[(se_ply << 8) | 0] = se_v;

            //cout<<"telluser Move from PV of last search found:"<<printMove(GamePV[GMI][se_ply-1])<<endl;
            break;
          };
        };

        //save PV flag into the move
        //MOVES_TREE[(se_ply<<8)|0] |= PVmove_mask;

				//be careful because full ply changes gl_move (i.e. gl_move may be invalid)
				//go to first child move
        gl_move = MOVES_TREE[(se_ply << 8) | 0];

        CHILD(se_ply);

        //#ifdef EXTEND_CHECK
        //if the move causes the black king is checked
        //if (gl_move==(gl_move|(1<<30))) {
        //qDepth++;
        //}
#ifdef EXTEND_ONLY_MOVE

        //else
        if (max_offs[se_ply] == 1) {
          qDepth++;
          //cout<<"only whi move ext: "<<printMove(gl_move)<<endl;
          //printB("");
        };

#endif

        /////////////////////////////////
        //handle 3-fold draw
        if (retract < 99) {
          se_j = se_ply - 1;
          se_r = 0;

          while (se_j > 0) {
            if (retract_tab[se_j] == 0) {
              se_v = 0;
              break;
            }; //opponent move

            se_j--;

            if (se_j == 0) {
              se_v = 1;
              break;
            }; //self move

            if (retract_tab[se_j] == 0) {
              se_v = 0;
              break;
            };

            if (Zkey == Zkey_tab[se_j]) {
              se_r++;

              if (se_r > 1) {
                val[se_ply] = DRAW_SCORE;
                PVlen[se_ply] = se_ply;
//#ifdef NULL_MOVE
                //nms_set = false;
//#endif

#ifdef SEARCH_REORD
                sr_set = false;
#endif
                goto UP_PROC;
              };
            };

            se_j--;

            se_v = 1;
          };

          if (se_v == 1) {
            se_j = GMI;

            if (GameWtm[GMI + se_ply] == GameWtm[GMI]) {
              while (se_j > 0) {
                if (GameRetract[se_j] == 0) {
                  break;
                }; //self move

                if (Zkey == Game_Zkey_tab[se_j]) {
                  se_r++;

                  if (se_r > 1) {
                    val[se_ply] = DRAW_SCORE;
                    PVlen[se_ply] = se_ply;
//#ifdef NULL_MOVE
                    //nms_set = false;
//#endif

#ifdef SEARCH_REORD
                    sr_set = false;
#endif
                    goto UP_PROC;
                  };
                };

                se_j--;

                if (se_j == 0) {
                  break;
                }; //opponent move

                if (GameRetract[se_j] == 0) {
                  break;
                };

                se_j--;
              };
            } else {
              while (se_j > 0) {
                if (GameRetract[se_j] == 0) {
                  break;
                }; //opponent move

                se_j--;

                if (se_j == 0) {
                  break;
                }; //self move

                if (GameRetract[se_j] == 0) {
                  break;
                };

                if (Zkey == Game_Zkey_tab[se_j]) {
                  se_r++;

                  if (se_r > 1) {
                    val[se_ply] = DRAW_SCORE;
                    PVlen[se_ply] = se_ply;
//#ifdef NULL_MOVE
                    //nms_set = false;
//#endif

#ifdef SEARCH_REORD
                    sr_set = false;
#endif
                    goto UP_PROC;
                  };
                };

                se_j--;
              };
            };
          };
        }
        //handle 50-moves rule
        else {
          val[se_ply] = DRAW_SCORE;
          PVlen[se_ply] = se_ply;
//#ifdef NULL_MOVE
          //nms_set = false;
//#endif

#ifdef SEARCH_REORD
          sr_set = false;
#endif
          goto UP_PROC;
        };

        //erase value
        val[se_ply] = EMPTY_VAL;

        //...printAll("after going down in FIRST_DOWN_PROC",se_ply);
      } //btm
      else {
        //set check evasion status
        if (isAttByWhi(BkiPos)) {
          CheckStatus[se_ply] = true;
        } else {
          CheckStatus[se_ply] = false;
        };

        //generate se_ply
//#ifdef NULL_MOVE
        //nms_set = true;
//#endif

#ifdef SEARCH_REORD
        sr_set = true;

#endif
        se_ply++;

        max_offs[se_ply] = FULL_BLA_PLY(se_ply);
        se_ply_finished[se_ply] = true;

        //if no legal moves in the se_ply get score and go to UP_PROC
        if (max_offs[se_ply] == 0) {
          se_ply--;

          if (CheckStatus[se_ply] == true) {
            val[se_ply] = MAX_SCORE;
          } else {
            val[se_ply] = DRAW_SCORE;
          };

          PVlen[se_ply] = se_ply;

          //gl_move = MOVES_TREE[((se_ply << 8) | cur_offs[se_ply])];

          //...printAll("end pos in FIRST_DOWN_PROC",se_ply);
//#ifdef NULL_MOVE
          //nms_set = false;
//#endif

#ifdef SEARCH_REORD
          sr_set = false;

#endif
          goto UP_PROC;
        };

#ifdef SELECTIVE_SEARCH
				//set flag
				//update_results_tab_score = true;
        //create table of first ply moves to better navigate search depth
        if ((INCREMENTS == 0) && (se_ply == 1)) {
          for (se_r = 0; se_r < max_offs[1]; se_r++) {
            results_tab[se_r][0] = MOVES_TREE[(se_ply << 8) | se_r];
          };
        };

#endif

        //reorder first-se_ply moves by search results from vals_tab[]
        if ((se_ply == 1) && (INCREMENTS > 0)) {
          //sort values and moves
          for (se_r = 0; se_r < max_offs[se_ply]; se_r++) {
            se_v = vals_tab[se_r];
            gl_move = moves_tab[se_r];

            for (se_j = se_r; ((se_j > 0) && (vals_tab[(se_j - 1) ] > se_v)); se_j--) {
              vals_tab[se_j] = vals_tab[se_j - 1];
              moves_tab[se_j] = moves_tab[se_j - 1];
            };

            vals_tab[se_j] = se_v;

            moves_tab[se_j] = gl_move;
          };

          //paste sorted moves and values
          for (se_r = 0; se_r < max_offs[se_ply]; se_r++) {
            MOVES_TREE[(1 << 8) | se_r] = moves_tab[se_r];
            VALS_TREE[(1 << 8) | se_r] = vals_tab[se_r];
          };
        };

        //insort PV move in the beginning of moves in children if a move from PV is found
        for (se_r = 0; se_r < max_offs[se_ply]; se_r++) {
          if (GamePV[GMI][se_ply - 1] == MOVES_TREE[(se_ply << 8) | se_r]) {
            //copy the value of found move
            se_v = VALS_TREE[(se_ply << 8) | se_r];

            //copy all moves and values one move forward to the found move pos
            for (se_j = se_r; se_j > 0; se_j--) {
              MOVES_TREE[(se_ply << 8) | se_j] = MOVES_TREE[(se_ply << 8) | (se_j - 1) ];
              VALS_TREE[(se_ply << 8) | se_j] = VALS_TREE[(se_ply << 8) | (se_j - 1) ];
            };

            //paste found move value in the first move pos
            MOVES_TREE[(se_ply << 8) | 0] = GamePV[GMI][se_ply - 1];

            VALS_TREE[(se_ply << 8) | 0] = se_v;

            //cout<<"telluser Move from PV of last search found:"<<printMove(GamePV[GMI][se_ply-1])<<endl;
            break;
          };
        };

        //save PV mask on the move
        //MOVES_TREE[(se_ply<<8)|0] |= PVmove_mask;
        //go to first child move
        gl_move = MOVES_TREE[(se_ply << 8) | 0];

        CHILD(se_ply);

        //#ifdef EXTEND_CHECK
        //if the move causes the whi king is checked
        //if (gl_move==(gl_move|(1<<31))) {
        //qDepth++;
        //}
#ifdef EXTEND_ONLY_MOVE

        //else
        if (max_offs[se_ply] == 1) {
          qDepth++;
          //cout<<"only bla move ext: "<<printMove(gl_move)<<endl;
          //printB("");
        };

#endif

        /////////////////////////////////
        //handle 3-fold draw
        if (retract < 99) {
          se_j = se_ply - 1;
          se_r = 0;

          while (se_j > 0) {
            if (retract_tab[se_j] == 0) {
              se_v = 0;
              break;
            }; //opponent move

            se_j--;

            if (se_j == 0) {
              se_v = 1;
              break;
            }; //self move

            if (retract_tab[se_j] == 0) {
              se_v = 0;
              break;
            };

            if (Zkey == Zkey_tab[se_j]) {
              se_r++;

              if (se_r > 1) {
                val[se_ply] = DRAW_SCORE;
                PVlen[se_ply] = se_ply;
//#ifdef NULL_MOVE
                //nms_set = false;
//#endif

#ifdef SEARCH_REORD
                sr_set = false;
#endif
                goto UP_PROC;
              };
            };

            se_j--;

            se_v = 1;
          };

          if (se_v == 1) {
            se_j = GMI;

            if (GameWtm[GMI + se_ply] == GameWtm[GMI]) {
              while (se_j > 0) {
                if (GameRetract[se_j] == 0) {
                  break;
                }; //self move

                if (Zkey == Game_Zkey_tab[se_j]) {
                  se_r++;

                  if (se_r > 1) {
                    val[se_ply] = DRAW_SCORE;
                    PVlen[se_ply] = se_ply;
//#ifdef NULL_MOVE
                    //nms_set = false;
//#endif

#ifdef SEARCH_REORD
                    sr_set = false;
#endif
                    goto UP_PROC;
                  };
                };

                se_j--;

                if (se_j == 0) {
                  break;
                }; //opponent move

                if (GameRetract[se_j] == 0) {
                  break;
                };

                se_j--;
              };
            } else {
              while (se_j > 0) {
                if (GameRetract[se_j] == 0) {
                  break;
                }; //opponent move

                se_j--;

                if (se_j == 0) {
                  break;
                }; //self move

                if (GameRetract[se_j] == 0) {
                  break;
                };

                if (Zkey == Game_Zkey_tab[se_j]) {
                  se_r++;

                  if (se_r > 1) {
                    val[se_ply] = DRAW_SCORE;
                    PVlen[se_ply] = se_ply;
//#ifdef NULL_MOVE
                    //nms_set = false;
//#endif

#ifdef SEARCH_REORD
                    sr_set = false;
#endif
                    goto UP_PROC;
                  };
                };

                se_j--;
              };
            };
          };
        }
        //handle 50-moves rule
        else {
          val[se_ply] = DRAW_SCORE;
          PVlen[se_ply] = se_ply;
//#ifdef NULL_MOVE
          //nms_set = false;
//#endif

#ifdef SEARCH_REORD
          sr_set = false;
#endif
          goto UP_PROC;
        };

        ///////////////////////////////////////////
        //erase value
        val[se_ply] = EMPTY_VAL;

        //...printAll("after going down in FIRST_DOWN_PROC",se_ply);
      };
    };

    // Here always se_ply==qDepth. Do static eval pos at qDepth if position is quiesent.
    // Enter qiesence search if position is unquiesent (unstable).
    // entering QS
//#ifdef NULL_MOVE
    //nms_set = false;
//#endif

#ifdef SEARCH_REORD
    sr_set = false;

#endif
    goto Q_DOWN_PROC;
  };

///@@@ if lmr_already_used set to true --> it is not examined
/////////////////////////////////////////////////////////////////////////
DOWN_PROC: {
    while (se_ply < qDepth) {
      if (GameWtm[GMI + se_ply] == true) {
        //produce the se_ply only if unproduced yet
        if (se_doPly == false) {
          se_doPly = true;
          se_ply++;
        } else {
          //set check evasion status
          if (isAttByBla(WkiPos)) {
            CheckStatus[se_ply] = true;
          } else {
            CheckStatus[se_ply] = false;
          };


          //generate sorted ply
          se_ply++;

          cur_offs[se_ply] = 0;

					#ifndef PARTIAL_PLY
          max_offs[se_ply] = FULL_WHI_PLY(se_ply);
          se_ply_finished[se_ply] = true;
          #endif

          //create qs ply if not escaping from check and qs ply is not empty
          #ifdef PARTIAL_PLY
          if (CheckStatus[se_ply-1] == false) {
						max_offs[se_ply] = QS_WHI_PLY(se_ply);
            if (max_offs[se_ply] == 0) {
            	//may try some killer moves here
							max_offs[se_ply] = REST_WHI_PLY(se_ply);
							se_ply_finished[se_ply] = true;
					  }
					  else {
						  se_ply_finished[se_ply] = false;
						};
          }
          else {
					  max_offs[se_ply] = FULL_WHI_PLY(se_ply);
					  se_ply_finished[se_ply] = true;
					};

					#endif

#ifdef KILLERS

          //reorder killer move if matched
          //insort killer moves
          for (se_r = 0; se_r < max_offs[se_ply]; se_r++) {
            if (FirstKiller[se_ply] == MOVES_TREE[(se_ply << 8) | se_r]) {
              //save killer move value
              se_v = VALS_TREE[(se_ply << 8) | se_r];

              //copy moves one step forward until capture or promotion found
              for (se_j = se_r; se_j > 0; se_j--) {
                gl_move = MOVES_TREE[(se_ply << 8) | (se_j - 1) ];

                if (((gl_move << 8) >> 28)
                    != 0) {
                  se_j++;
                  break;
                }; //break if capture

                if (((gl_move << 16) >>
                     28) != ((gl_move << 12) >> 28)) {
                  se_j++;
                  break;
                }; //break if promo

                MOVES_TREE[(se_ply << 8) | se_j] = gl_move;

                VALS_TREE[(se_ply << 8) | se_j] = VALS_TREE[(se_ply << 8) | (se_j - 1) ];
              };

              //paste move in se_j position
              MOVES_TREE[(se_ply << 8) | se_j] = FirstKiller[se_ply];

              VALS_TREE[(se_ply << 8) | se_j] = se_v;

              //cout<<"First Killer: "<<printMove(FirstKiller[se_ply])<<endl;
              break;
            };

            if (SecondKiller[se_ply] == MOVES_TREE[(se_ply << 8) | se_r]) {
              //save killer move value
              se_v = VALS_TREE[(se_ply << 8) | se_r];

              //copy moves one step forward until capture or promotion found
              for (se_j = se_r; se_j > 0; se_j--) {
                gl_move = MOVES_TREE[(se_ply << 8) | (se_j - 1) ];

                if (((gl_move << 8) >> 28)
                    != 0) {
                  se_j++;
                  break;
                };

                if (((gl_move << 16) >>
                     28) != ((gl_move << 12) >> 28)) {
                  se_j++;
                  break;
                };

                MOVES_TREE[(se_ply << 8) | se_j] = gl_move;

                VALS_TREE[(se_ply << 8) | se_j] = VALS_TREE[(se_ply << 8) | (se_j - 1) ];
              };

              //paste move in se_j position
              MOVES_TREE[(se_ply << 8) | se_j] = SecondKiller[se_ply];

              VALS_TREE[(se_ply << 8) | se_j] = se_v;

              //cout<<"Second Killer: "<<printMove(SecondKiller[se_ply])<<endl;
              break;
            };
          };

#endif

          //if no legal moves in the se_ply get score and go to UP_PROC
          if (max_offs[se_ply] == 0) {
            se_ply--;

            if (CheckStatus[se_ply] == true) {
              val[se_ply] = MIN_SCORE;
            } else {
              val[se_ply] = DRAW_SCORE;
            };

            PVlen[se_ply] = se_ply;

            //gl_move = MOVES_TREE[((se_ply << 8) | cur_offs[se_ply])];

            //...printAll("end pos in QS",se_ply);
            goto UP_PROC;
          };
        };

        //go to curent child move
        se_j = ((se_ply << 8) | cur_offs[se_ply]);

        gl_move = MOVES_TREE[se_j];

        CHILD(se_ply);

        //#ifdef EXTEND_CHECK
        //if the move causes the black king is checked
        //if (gl_move==(gl_move|(1<<30))) {
        //qDepth++;
        //}
#ifdef EXTEND_ONLY_MOVE
        //else if (max_offs[se_ply]==1)
        {
          qDepth++;
          //cout<<"only whi move ext: "<<printMove(gl_move)<<endl;
          //printB("");
        };

#endif

#ifdef DEBUG_VERSION
        //count late moves which occur during search in down proc - potential to reduce
        #ifdef LATE_MOVE
        if (gl_move == (gl_move | (1 << 29))) {
					lmr_whi_cnt++;
          /*
            cout<<"----------------"<<endl;
          cout<<"late move potential to produce reduction in whi down proc: "<<printMove(gl_move)
          <<" ("<<((VALS_TREE[((se_ply-1)<<8)|cur_offs[se_ply-1]]/100)-(MIDDLE_SCORE/100))<<")"<<endl;
          printB(", board after making lmr move:");
          printPATH(1,se_ply);
            cout<<"Whi late moves report (se_ply:"<<se_ply<<", qDepth:"<<qDepth<<"):"<<endl;
            se_i = 0;
            while (se_i<max_offs[se_ply]) {
              ar_move = MOVES_TREE[(se_ply<<8)|se_i];
              if (ar_move==(ar_move | (1<<29))) {
                cout<<"["<<se_i<<"]"<<printMove(ar_move)<<"-late("
              <<((VALS_TREE[(se_ply<<8)|se_i]/100)-(MIDDLE_SCORE/100))
              <<") "<<flush;
               }
              else {
               cout<<"["<<se_i<<"]"<<printMove(ar_move)<<"-norm("
              <<((VALS_TREE[(se_ply<<8)|se_i]/100)-(MIDDLE_SCORE/100))
              <<") "<<flush;
              };
              se_i++;
            };
            cout<<endl;
            cout<<"----------------"<<endl;
            */
        };

#endif
#endif //debug_version

        //set sr byte in the move
#ifdef SEARCH_REORD

        //IF NODE IS NOT PV NODE
        //if no sr flag set (upper)
        if (sr_set == false) {
          //if proper max depth
          if (se_ply < qDepth - 1) {
            //if no null move search or lmr search
            MOVES_TREE[se_j] |= (1 << 27);
            ///////
            //printB("board after making white SR move:");
            //printPATH(1,se_ply);
            ///////
          };
        };

#endif


#ifdef ATTACKS_MAP
//if no attack threat in curent move
//and if no attack threat in previous move
//if not lazy eval position
//if qDepth > 4
//return static score and go up

//u  u  u  u  u  u  u  u  c  c  c  c  x  x  x  x  p  p  p  p  t  t  t  t  t  t  f  f  f  f  f  f
//1  2  3  4  5  6  7  8  9  10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32
//32 31 30 29 28 27 26 25 24 23 22 21 20 19 18 17 16 15 14 13 12 11 10 9  8  7  6  5  4  3  2  1

//bit nr 32 - check flag (1 << 31)
//bit nr 31 - check flag (1 << 30)
//bit nr 30 - lmr flag (1 << 29)
//bit nr 29 - forced pos mask (1 << 28)
//bit nr 28 - sr root move flag (1 << 27)
//bit nr 27 - lazy eval mask (1 << 26)
//bit nr 26 - white threat flag (1 << 25)
//bit nr 25 - black threat flag (1 << 24)



	if (((gl_move<<6)>>31) == 0) {
		if (((gl_move<<7)>>31) == 0) {
	    if (((MOVES_TREE[(((se_ply-1) << 8) | (cur_offs[se_ply-1]))]<<6)>>31) == 0) {
	    	if (((MOVES_TREE[(((se_ply-1) << 8) | (cur_offs[se_ply-1]))]<<7)>>31) == 0) {
	    		if (cur_offs[se_ply]>2) {
	    			if (qDepth > 3) {
  		        val[se_ply] = VALS_TREE[((se_ply << 8) | cur_offs[se_ply])];
              PVlen[se_ply] = se_ply;
              //cout<<"attack map filter whi move cuttoff:"<<getPATH(1,se_ply)<<endl;
              goto UP_PROC;
            };
          };
        };
      };
    };
  };
#endif



        //if enough depth and move offset is poor - goto qsearch
        //take all caps and 3 best noncaps
#ifdef PRUNE_STATIC_TREE
        if (
          (cur_offs[se_ply] > 3)
          && (((MOVES_TREE[((se_ply << 8) | (cur_offs[se_ply] - 3)) ] << 8) >> 28) == 0)
          //(cur_offs[se_ply] > (max_offs[se_ply] * 0.3))
          && (gl_cp == 0)
          && (gl_tp == gl_fp)
          && (CheckStatus[se_ply - 1] == false)
          && (se_ply > 3)
          //&&(max_offs[se_ply]>8)
        ) {
          val[se_ply] = EMPTY_VAL;
          goto Q_DOWN_PROC;
        };

#endif
#ifdef LOST_POS_CUTTOFFS_TYPE1

        //do unreal_path prunning.
        //It works as follows: (if WHITE move and enough depth)
        //if it is noncapture and MOVE VAL is worse than MOVE-1 VAL
        //and if MOVE-1 is a capture
        //and if MOVE-2 is noncapture,,, and MOVE-2 VAL is worse than MOVE-3 VAL
        //and if MOVE-3 is a capture
        //dont search this position deeper because it should be lost anyway.
        //just return static eval and go up
        if (se_ply > 3) {
          if (gl_cp == 0)
            //if cur move is noncap
          {
            se_r = (((se_ply - 1) << 8) | cur_offs[se_ply - 1]);

            if ((((MOVES_TREE[se_r]) << 8) >> 28)
                != 0)
              //if move-1 was capture
            {
              //if (VALS_TREE[se_j] < VALS_TREE[se_r]) { //if pos is worse than pos-1
              se_j = (((se_ply - 2) << 8) | cur_offs[se_ply - 2]);

              if ((((MOVES_TREE[se_j]) << 8) >> 28)
                  == 0)
                //if move-2 was noncapture
              {
                se_r = (((se_ply - 3) << 8) | cur_offs[se_ply - 3]);

                if ((((MOVES_TREE[se_r]) << 8) >> 28)
                    != 0)
                  //if move-3 was capture
                {
                  //if (VALS_TREE[se_j] < VALS_TREE[se_r]) { //if pos-2 is worse than pos-3
                  val[se_ply] = VALS_TREE[((se_ply << 8) | cur_offs[se_ply]) ];
                  PVlen[se_ply] = se_ply;
                  lost_pos_cuttoffs_type1++;
                  //cout<<"alfa filter1 cuttoff:"<<getPATH(1,se_ply)<<endl;
                  goto UP_PROC;
                  //};
                };
              };

              //};
            };
          };
        };

#endif
#ifdef MAT_POS_PRUNNING
        //goto qsearch if path has low chance to affect PV
        //It works as follows:
        //if white has just moved and enough depth
        //1)
        //if black have enough positional and material advantage
        //if position is quiescent
        //if move is not check, checkevasion, threat
        //set qs flag for all children of this position
        //- goto qsearch
        /*
        cout<<"telluser static score: "<<(signed int)((EVAL()/100)-(MIDDLE_SCORE/100))
        <<" material score: "<<(signed int)((ev_mat_score/100)-(MIDDLE_SCORE/100))
        <<" root position score: "<<(signed int)((EVAL()/100)-(MIDDLE_SCORE/100))-
        (signed int)((ev_mat_score/100)-(MIDDLE_SCORE/100))<<endl;
        */
        //curent material score
        ev_mat_score = MaterialScore;
/*
                       + (WpaNum * evPawnMaterialValue)
                       - (BpaNum * evPawnMaterialValue)
                       + (WroNum * evRookMaterialValue)
                       - (BroNum * evRookMaterialValue)
                       + (WbiNum * evBishopMaterialValue)
                       - (BbiNum * evBishopMaterialValue)
                       + (WknNum * evKnightMaterialValue)
                       - (BknNum * evKnightMaterialValue)
                       + (WquNum * evQueenMaterialValue)
                       - (BquNum * evQueenMaterialValue);
*/
        //curent positional score
        ev_pos_score =  - ev_mat_score
                        + (VALS_TREE[(se_ply << 8) | cur_offs[se_ply]]);

        //if noncap, nonpromo, noncheckevasion, noncheck
        if ((gl_cp == 0)
            && (gl_tp == gl_fp) && (CheckStatus[se_ply - 1] == false)) {
          //if white decisive positional advantage comparing to parent
          if (ev_pos_score > (VALS_TREE[((se_ply - 1) << 8) | cur_offs[se_ply - 1]] - ev_mat_score + (evPawnMaterialValue * 0.4))) {
            //if not in reduced depth mode already
            if (reduced_tree_top == 0) {
              //save params to later return to original qDepth and
              //go to quiescence search with reduced qDepth mode
              reduced_tree_top = se_ply;
              val[se_ply] = EMPTY_VAL;
              //cout<<"reduced to QS after:"<<getPATH(0,se_ply)<<"equal material, position score:"<<((ev_pos_score/100)-(MIDDLE_SCORE/100))<<endl;
              goto Q_DOWN_PROC;
            };
          };
        };

#endif
#ifdef WEAK_PATH_PRUNNING

        //go to qsearch if path has low chance to affect principle variation
        //It works as follows: (if WHITE move and enough depth)
        //if it is noncapture and offset>15 and move_offs>offset*66%
        //and if offset>15 and (MOVE-1)_offset<offset*33%
        //and if MOVE-2 is noncapture and offset>15 and MOVE-2_offs>offset*66%
        //and if offset>15 and (MOVE-3)_offset<offset*33%
        //than goto qDownProc.
        if ((qDepth > 3)
            && (se_ply > 2)) {
          //if offset>15 and move_offs>offset*66%
          if ((max_offs[se_ply] > 15) && (cur_offs[se_ply] > (max_offs[se_ply] * 0.1))) {
            //cout<<"success1"<<endl;
            //and if prev offset>15 and (MOVE-1)_offset<offset*33%
            //if ((max_offs[se_ply-1]>15)&&(cur_offs[se_ply-1]<(max_offs[se_ply-1] * 0.3))) {
            //cout<<"success2"<<endl;
            //and if MOVE-2_offset>15 and MOVE-2_offs>offset*66%
            if ((max_offs[se_ply - 2] > 15) && (cur_offs[se_ply - 2] > (max_offs[se_ply - 2] * 0.1))) {
              weak_path_cnt++;
              //cout<<"success3"<<endl;
              //cout<<getPATH(1,se_ply)<<endl;
              val[se_ply] = EMPTY_VAL;
              goto Q_DOWN_PROC;
              //val[se_ply] = VALS_TREE[((se_ply<<8)|cur_offs[se_ply])];
              //PVlen[se_ply]=se_ply;
              //goto UP_PROC;
            };

            //};
          };
        };

#endif
#ifdef SELECTIVE_SEARCH

//if the move is not:
// -"early" in the tree order
// -null move,
// -check,
// -capture
// -promotion
// -forced move (detected by null move)
// -promising move (makes the score upgrade in shallow search - it should be researched
// to the full depth)
// decrease search depth of this ROOT move by one.
// reuse the search result from previous iteration.
// todo: try to reduce the depth of ply2 moves

        //if we are at ply1
        if (se_ply == 1) {
        	//set qDepth from IS()
        	qDepth = tmp_qDepth;
          //cout<<"global move in selective search: "<<printMove(gl_move)<<endl;
          //find move index in results_tab
          for (se_r = 0; se_r < max_offs[se_ply]; se_r++) {
            //cout<<"se_r:"<<se_r<<" move from results tab: "<<printMove(results_tab[se_r][0])
            //<<" max_offs[1]:"<<max_offs[1]<<endl;
            if (results_tab[se_r][0] == gl_move) {
            	//cout<<"move found!!!"<<endl;
              //if noncapture, nonenpassant, noncheckevasion,
							//nonpromotion, noncheck, many moves and bad static offset
              if ((gl_cp == 0) &&
                  (gl_fp == gl_tp) &&
                  (CheckStatus[se_ply - 1] == false) &&
                  (isAttByWhi(BkiPos) == false) &&
                  (cur_offs[se_ply] >= ss_min_reduce_offset) &&
									//(cur_offs[se_ply] > (max_offs[se_ply] * 0.33)) &&
                  (max_offs[se_ply] >= ss_min_reduce_ply_size)) {
                //if enough qDepth stored
                se_j = results_tab[se_r][1];
                if (se_j >= ss_min_depth) {

									//if result is worse enough than best move
                  if ((results_tab[se_r][2 + se_j] + (ss_min_score_difference)) < GameVal[GMI]) {

										//if enough "fresh" search result is stored
									  if (se_j==(qDepth-1)) {

											//use stored search result as the move appears quite weak
											val[1] = results_tab[se_r][2 + se_j];
	                    PVlen[1] = se_ply;

                      //cout<<"white gl_move UP at root (shallower search result used): "<<printMove(gl_move)<<endl;
										  goto UP_PROC;
									  };
                  };
                };
              };
              break;
						};
          };
          //cout<<"white gl_move normal down at root: "<<printMove(gl_move)<<endl;
        };

#endif
#ifdef OFFSET_PRUNNING

        //slims some parts of the tree if
        //enough depth
        //(depending on previus move type)
        //(depending on material/position balance)
        if (
          (qDepth > 2)
          &&
          (se_ply > 2) &&
          (CheckStatus[se_ply - 1] == false) &&
          (max_offs[se_ply] > 10) &&
          (cur_offs[se_ply] > (max_offs[se_ply] * 0.5)) &&
          (reduced_tree_top == 0)
        ) {
          //save params to later return to original qDepth and
          //go to quiescence search with reduced qDepth mode
          reduced_tree_top = se_ply;
          offset_prunning_cnt++;
          val[se_ply] = EMPTY_VAL;
          goto Q_DOWN_PROC;
        };

#endif

        //#ifdef STATIC_POS_PRUNNING

        //we use shallower search result (previus search in IS) of the first ply move if:
        //the standard deviation of the average score of this move is not signifficant
        //the score is poor and move offset is poor
        /*
          if (se_ply==1) {
           if (qDepth>3) {
             if ((float)(cur_offs[1]) < (((float)(max_offs[1])) * 0.30)) {
                 cout<<"good move:"<<printMove(MOVES_TREE[((1<<8)|cur_offs[1])])<<endl;
             }
             else {
                cout<<"worse move:"<<printMove(MOVES_TREE[((1<<8)|cur_offs[1])])<<endl;
             };
           };
           };
           */
        //#endif

        //#ifdef FUTIL1

        //if position doesnt contain threat
        //if position eval is worse than val[] + 1 pawn - use this pos value and go up

        //#endif

        /////////////////////////////////
        //handle 3-fold draw
        if (retract < 99) {
          se_j = se_ply - 1;
          se_r = 0;

          while (se_j > 0) {
            if (retract_tab[se_j] == 0) {
              se_v = 0;
              break;
            }; //opponent move

            se_j--;

            if (se_j == 0) {
              se_v = 1;
              break;
            }; //self move

            if (retract_tab[se_j] == 0) {
              se_v = 0;
              break;
            };

            if (Zkey == Zkey_tab[se_j]) {
              se_r++;

              if (se_r > 1) {
                val[se_ply] = DRAW_SCORE;
                PVlen[se_ply] = se_ply;
                goto UP_PROC;
              };
            };

            se_j--;

            se_v = 1;
          };

          if (se_v == 1) {
            se_j = GMI;

            if (GameWtm[GMI + se_ply] == GameWtm[GMI]) {
              while (se_j > 0) {
                if (GameRetract[se_j] == 0) {
                  break;
                }; //self move

                if (Zkey == Game_Zkey_tab[se_j]) {
                  se_r++;

                  if (se_r > 1) {
                    val[se_ply] = DRAW_SCORE;
                    PVlen[se_ply] = se_ply;
                    goto UP_PROC;
                  };
                };

                se_j--;

                if (se_j == 0) {
                  break;
                }; //opponent move

                if (GameRetract[se_j] == 0) {
                  break;
                };

                se_j--;
              };
            } else {
              while (se_j > 0) {
                if (GameRetract[se_j] == 0) {
                  break;
                }; //opponent move

                se_j--;

                if (se_j == 0) {
                  break;
                }; //self move

                if (GameRetract[se_j] == 0) {
                  break;
                };

                if (Zkey == Game_Zkey_tab[se_j]) {
                  se_r++;

                  if (se_r > 1) {
                    val[se_ply] = DRAW_SCORE;
                    PVlen[se_ply] = se_ply;
                    goto UP_PROC;
                  };
                };

                se_j--;
              };
            };
          };
        }
        //handle 50-moves rule
        else {
          val[se_ply] = DRAW_SCORE;
          PVlen[se_ply] = se_ply;
          goto UP_PROC;
        };

        ////////////////////////////////////////////
#ifdef HASH_TRANSP_CUTTOFF
        ///////////////////////////////////////////////////
        //if HT entry with value found - do transposition cuttoff:
        //get val from HT if key matches
        //and if HT qDepth == qDepth
        //and if HT se_ply == se_ply
        //and if score in HT is value type (not erased)
        //HT==
        //[Zkey(64bits)]
        //[score(20bits)-val(20bits)-ply(6bits)-qDepth(6bits)-BestMovefromto(12bits)]
        Hkey = (Zkey >> (Zkeylen - Hkeylen));

        if ((HT[Hkey][0] == Zkey)
            && //key compare
            (qDepth == (((HT[Hkey][1]) << 46) >> 58))
            &&         //qDepth compare
            (se_ply == (((HT[Hkey][1]) << 40) >> 58)) &&        //ply compare
            ((((HT[Hkey][1]) << 20) >> 44) != EMPTY_VAL)        //value not erased
           ) {
          H_transp_cuttoffs++;
          val[se_ply] = (((HT[Hkey][1]) << 20) >> 44);
          //cout<<"HT transp cut score"<<val[se_ply]<<endl;
          PVlen[se_ply] = se_ply; //limit pv
          goto UP_PROC;
        } else {
          //erase value and proceed
          val[se_ply] = EMPTY_VAL;
          //...printAll("after going down in wDOWN_PROC",se_ply);
        };

        /////////////////////////////////////////////////
#endif
        //else
#ifndef HASH_TRANSP_CUTTOFF
        val[se_ply] = EMPTY_VAL;

#endif
        ///////////////////////////////////////////////////////////
      } //btm
      else {
        if (se_doPly == false) {
          se_doPly = true;
          se_ply++;
        } else {
          //set check evasion status
          if (isAttByWhi(BkiPos)) {
            CheckStatus[se_ply] = true;
          } else {
            CheckStatus[se_ply] = false;
          };

          //generate sorted se_ply
          se_ply++;

          cur_offs[se_ply] = 0;

					#ifndef PARTIAL_PLY
          max_offs[se_ply] = FULL_BLA_PLY(se_ply);
          se_ply_finished[se_ply] = true;
					#endif

          //create qs ply if not escaping from check and qs ply is not empty
          #ifdef PARTIAL_PLY
          if (CheckStatus[se_ply-1] == false) {

						max_offs[se_ply] = QS_BLA_PLY(se_ply);

            if (max_offs[se_ply] == 0) {
              max_offs[se_ply] = REST_BLA_PLY(se_ply);
							se_ply_finished[se_ply] = true;
					  }
					  else {
						  se_ply_finished[se_ply] = false;
						};
          }
          else {
					  max_offs[se_ply] = FULL_BLA_PLY(se_ply);
					  se_ply_finished[se_ply] = true;
					};

					#endif

#ifdef KILLERS

          //insort killer moves
          for (se_r = 0; se_r < max_offs[se_ply]; se_r++) {
            if (FirstKiller[se_ply] == MOVES_TREE[(se_ply << 8) | se_r]) {
              //save killer move value
              se_v = VALS_TREE[(se_ply << 8) | se_r];

              //copy moves one step forward until capture or promotion found
              for (se_j = se_r; se_j > 0; se_j--) {
                gl_move = MOVES_TREE[(se_ply << 8) | (se_j - 1) ];

                if (((gl_move << 8) >> 28)
                    != 0) {
                  se_j++;
                  break;
                };

                if (((gl_move << 16) >>
                     28) != ((gl_move << 12) >> 28)) {
                  se_j++;
                  break;
                };

                MOVES_TREE[(se_ply << 8) | se_j] = gl_move;

                VALS_TREE[(se_ply << 8) | se_j] = VALS_TREE[(se_ply << 8) | (se_j - 1) ];
              };

              //paste move in se_j position
              MOVES_TREE[(se_ply << 8) | se_j] = FirstKiller[se_ply];

              VALS_TREE[(se_ply << 8) | se_j] = se_v;

              //cout<<"First Killer: "<<printMove(FirstKiller[se_ply])<<endl;
              break;
            };

            if (SecondKiller[se_ply] == MOVES_TREE[(se_ply << 8) | se_r]) {
              //save killer move value
              se_v = VALS_TREE[(se_ply << 8) | se_r];

              //copy moves one step forward until capture or promotion found
              for (se_j = se_r; se_j > 0; se_j--) {
                gl_move = MOVES_TREE[(se_ply << 8) | (se_j - 1) ];

                if (((gl_move << 8) >> 28)
                    != 0) {
                  se_j++;
                  break;
                };

                if (((gl_move << 16) >>
                     28) != ((gl_move << 12) >> 28)) {
                  se_j++;
                  break;
                };

                MOVES_TREE[(se_ply << 8) | se_j] = gl_move;

                VALS_TREE[(se_ply << 8) | se_j] = VALS_TREE[(se_ply << 8) | (se_j - 1) ];
              };

              //paste move in se_j position
              MOVES_TREE[(se_ply << 8) | se_j] = SecondKiller[se_ply];

              VALS_TREE[(se_ply << 8) | se_j] = se_v;

              //cout<<"Second Killer: "<<printMove(SecondKiller[se_ply])<<endl;
              break;
            };
          };

#endif

          //if no legal moves in the se_ply get score and go to UP_PROC
          if (max_offs[se_ply] == 0) {
            se_ply--;

            if (CheckStatus[se_ply] == true) {
              val[se_ply] = MAX_SCORE;
            } else {
              val[se_ply] = DRAW_SCORE;
            };

            PVlen[se_ply] = se_ply;

            //gl_move = MOVES_TREE[((se_ply << 8) | cur_offs[se_ply])];

            //...printAll("end pos in QS",se_ply);
            goto UP_PROC;
          };
        };

        //go to first child
        se_j = ((se_ply << 8) | cur_offs[se_ply]);

        gl_move = MOVES_TREE[se_j];

        CHILD(se_ply);

        //#ifdef EXTEND_CHECK
        //if the move causes the white king is checked
        //if (gl_move==(gl_move|(1<<31))) {
        //qDepth++;
        //}
#ifdef EXTEND_ONLY_MOVE
        //else if (max_offs[se_ply]==1)
        {
          qDepth++;
          //cout<<"only bla move ext: "<<printMove(gl_move)<<endl;
          //printB("");
        };

#endif
#ifdef DEBUG_VERSION
        //count late moves which occur during search - potential to reduce
#ifdef LATE_MOVE
        if (gl_move == (gl_move | (1 << 29))) {
          lmr_bla_cnt++;
          /*
            cout<<"----------------"<<endl;
          cout<<"late move potential to produce reduction in bla down proc: "<<printMove(gl_move)
            <<" ("<<((VALS_TREE[((se_ply-1)<<8)|cur_offs[se_ply-1]]/100)-(MIDDLE_SCORE/100))<<")"<<endl;
          printB(", board after making lmr move:");
          printPATH(1,se_ply);
          cout<<"Bla late moves report (se_ply:"<<se_ply<<", qDepth:"<<qDepth<<"):"<<endl;
            se_i = 0;
            while (se_i<max_offs[se_ply]) {
              ar_move = MOVES_TREE[(se_ply<<8)|se_i];
              if (ar_move==(ar_move | (1<<29))) {
                cout<<"["<<se_i<<"]"<<printMove(ar_move)<<"-late("
              <<((VALS_TREE[(se_ply<<8)|se_i]/100)-(MIDDLE_SCORE/100))
              <<") "<<flush;
               }
              else {
               cout<<"["<<se_i<<"]"<<printMove(ar_move)<<"-norm("
              <<((VALS_TREE[(se_ply<<8)|se_i]/100)-(MIDDLE_SCORE/100))
              <<") "<<flush;
              };
              se_i++;
            };
            cout<<endl;
            cout<<"----------------"<<endl;
            */
        };

#endif
#endif //debug_version
        //set sr byte in the move
#ifdef SEARCH_REORD

        //IF NODE IS NOT PV NODE
        //if no sr flag set (upper)
        if (sr_set == false) {
          //if proper max depth
          if (se_ply < qDepth - 1) {
            //if no null move search or lmr search
            MOVES_TREE[se_j] |= (1 << 27);
            ///////
            //printB("board after making black SR move:");
            //printPATH(1,se_ply);
            ///////
          };
        };

#endif

#ifdef ATTACKS_MAP
//if no attack threat in curent move
//and if no attack threat in previous move
//if not lazy eval position
//if qDepth > 4
//return static score and go up

//u  u  u  u  u  u  u  u  c  c  c  c  x  x  x  x  p  p  p  p  t  t  t  t  t  t  f  f  f  f  f  f
//1  2  3  4  5  6  7  8  9  10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32
//32 31 30 29 28 27 26 25 24 23 22 21 20 19 18 17 16 15 14 13 12 11 10 9  8  7  6  5  4  3  2  1

//bit nr 32 - check flag (1 << 31)
//bit nr 31 - check flag (1 << 30)
//bit nr 30 - lmr flag (1 << 29)
//bit nr 29 - forced pos mask (1 << 28)
//bit nr 28 - sr root move flag (1 << 27)
//bit nr 27 - lazy eval mask (1 << 26)
//bit nr 26 - white threat flag (1 << 25)
//bit nr 25 - black threat flag (1 << 24)



	if (((gl_move<<6)>>31) == 0) {
		if (((gl_move<<7)>>31) == 0) {
	    if (((MOVES_TREE[(((se_ply-1) << 8) | (cur_offs[se_ply-1]))]<<6)>>31) == 0) {
	    	if (((MOVES_TREE[(((se_ply-1) << 8) | (cur_offs[se_ply-1]))]<<7)>>31) == 0) {
	    		if (cur_offs[se_ply]>2) {
	    			if (qDepth > 3) {
  		        val[se_ply] = VALS_TREE[((se_ply << 8) | cur_offs[se_ply])];
              PVlen[se_ply] = se_ply;
              //cout<<"attack map filter bla move cuttoff:"<<getPATH(1,se_ply)<<endl;
              goto UP_PROC;
            };
          };
        };
      };
    };
  };
#endif


        //if enough depth and move offset is poor - goto qsearch
        //take all caps and 3 best noncaps
#ifdef PRUNE_STATIC_TREE
        if (
          (cur_offs[se_ply] > 3)
          && (((MOVES_TREE[((se_ply << 8) | (cur_offs[se_ply] - 3)) ] << 8) >> 28) == 0)
          //(cur_offs[se_ply] > (max_offs[se_ply] * 0.3))
          && (gl_cp == 0)
          && (gl_tp == gl_fp)
          && (CheckStatus[se_ply - 1] == false)
          && (se_ply > 3)
          //&&(max_offs[se_ply]>8)
        ) {
          val[se_ply] = EMPTY_VAL;
          goto Q_DOWN_PROC;
        };

#endif
#ifdef LOST_POS_CUTTOFFS_TYPE1

        //do unreal_path prunning.
        //It works as follows: (if BLACK move and enough depth)
        //if it is noncapture and MOVE VAL is bigger than MOVE-1 VAL
        //and if MOVE-1 is a capture
        //and if MOVE-2 is noncapture,,, and MOVE-2 VAL is worse than MOVE-3 VAL
        //and if MOVE-3 is a capture
        //dont search this position deeper because it should be lost anyway.
        //just return static eval and go up
        if (se_ply > 3) {
          if (gl_cp == 0)
            //if cur move is noncap
          {
            se_r = (((se_ply - 1) << 8) | cur_offs[se_ply - 1]);

            if ((((MOVES_TREE[se_r]) << 8) >> 28)
                != 0)
              //if move-1 was capture
            {
              //if (VALS_TREE[se_j] > VALS_TREE[se_r]) { //if pos is worse than pos-1
              se_j = (((se_ply - 2) << 8) | cur_offs[se_ply - 2]);

              if ((((MOVES_TREE[se_j]) << 8) >> 28)
                  == 0)
                //if move-2 was noncapture
              {
                se_r = (((se_ply - 3) << 8) | cur_offs[se_ply - 3]);

                if ((((MOVES_TREE[se_r]) << 8) >> 28)
                    != 0)
                  //if move-3 was capture
                {
                  //if (VALS_TREE[se_j] > VALS_TREE[se_r]) { //if pos-2 is worse than pos-3
                  val[se_ply] = VALS_TREE[((se_ply << 8) | cur_offs[se_ply]) ];
                  PVlen[se_ply] = se_ply;
                  //cout<<"beta filter1 cuttoff:"<<getPATH(1,se_ply)<<endl;
                  lost_pos_cuttoffs_type1++;
                  goto UP_PROC;
                  //};
                };
              };

              //};
            };
          };
        };

#endif
#ifdef MAT_POS_PRUNNING
        //goto qsearch if path has low chance to affect principle variation
        //It works as follows: (if WHITE move and enough depth)
        //if purly positional and purly material static score advantage - goto qsearch
        //if purly positional and material loss - goto qsearch
        //Positions with positional imbalance have potential to change (regardless of material)
        //Positions equal positionally and material imbalance have potential to win/lose
        /*
        cout<<"telluser static score: "<<(signed int)((EVAL()/100)-(MIDDLE_SCORE/100))
        <<" material score: "<<(signed int)((ev_mat_score/100)-(MIDDLE_SCORE/100))
        <<" root position score: "<<(signed int)((EVAL()/100)-(MIDDLE_SCORE/100))-
        (signed int)((ev_mat_score/100)-(MIDDLE_SCORE/100))<<endl;
        */
        //curent material score
        ev_mat_score = MaterialScore;
        /*
                       + (WpaNum * evPawnMaterialValue)
                       - (BpaNum * evPawnMaterialValue)
                       + (WroNum * evRookMaterialValue)
                       - (BroNum * evRookMaterialValue)
                       + (WbiNum * evBishopMaterialValue)
                       - (BbiNum * evBishopMaterialValue)
                       + (WknNum * evKnightMaterialValue)
                       - (BknNum * evKnightMaterialValue)
                       + (WquNum * evQueenMaterialValue)
                       - (BquNum * evQueenMaterialValue);
				*/
        //curent positional score
        ev_pos_score = - ev_mat_score
                       + (VALS_TREE[(se_ply << 8) | cur_offs[se_ply]]);

        //if noncap, nonpromo, noncheckevasion, (noncheck)
        if ((gl_cp == 0)
            && (gl_tp == gl_fp) && (CheckStatus[se_ply - 1] == false)) {
          //if white decisive positional advantage comparing to parent
          if (ev_pos_score < (VALS_TREE[((se_ply - 1) << 8) | cur_offs[se_ply - 1]] - ev_mat_score - (evPawnMaterialValue * 0.4))) {
            //if not in reduced depth mode already
            if (reduced_tree_top == 0) {
              //save params to later return to original qDepth and
              //go to quiescence search with reduced qDepth mode
              reduced_tree_top = se_ply;
              val[se_ply] = EMPTY_VAL;
              //cout<<"reduced to QS after:"<<getPATH(0,se_ply)<<"equal material, position score:"<<((ev_pos_score/100)-(MIDDLE_SCORE/100))<<endl;
              goto Q_DOWN_PROC;
            };
          };
        };

#endif
#ifdef WEAK_PATH_PRUNNING

        //go to qsearch if path has low chance to affect principle variation
        //It works as follows: (if WHITE move and enough depth)
        //if it is noncapture and offset>15 and move_offs>offset*66%
        //and if offset>15 and (MOVE-1)_offset<offset*33%
        //and if MOVE-2 is noncapture and offset>15 and MOVE-2_offs>offset*66%
        //and if offset>15 and (MOVE-3)_offset<offset*33%
        //than goto qDownProc.
        if ((qDepth > 3)
            && (se_ply > 2)) {
          //if offset>15 and move_offs>offset*66%
          if ((max_offs[se_ply] > 15) && (cur_offs[se_ply] > (max_offs[se_ply] * 0.1))) {
            //cout<<"success1"<<endl;
            //and if prev offset>15 and (MOVE-1)_offset<offset*33%
            //if ((max_offs[se_ply-1]>15)&&(cur_offs[se_ply-1]<(max_offs[se_ply-1] * 0.3))) {
            //cout<<"success2"<<endl;
            //and if MOVE-2_offset>15 and MOVE-2_offs>offset*66%
            if ((max_offs[se_ply - 2] > 15) && (cur_offs[se_ply - 2] > (max_offs[se_ply - 2] * 0.1))) {
              weak_path_cnt++;
              //cout<<"success3"<<endl;
              //cout<<getPATH(1,se_ply)<<endl;
              val[se_ply] = EMPTY_VAL;
              goto Q_DOWN_PROC;
              //val[se_ply] = VALS_TREE[((se_ply<<8)|cur_offs[se_ply])];
              //PVlen[se_ply]=se_ply;
              //goto UP_PROC;
            };

            //};
          };
        };

#endif
#ifdef SELECTIVE_SEARCH

        //if we are at ply1
        //if the move is noncapture and leads to material loss - just return its search result
        if (se_ply == 1) {
          //set qDepth from IS()
        	qDepth = tmp_qDepth;
					//cout<<"global move in selective search: "<<printMove(gl_move)<<endl;
          //find move index in results_tab
          for (se_r = 0; se_r < max_offs[se_ply]; se_r++) {
            //cout<<"se_r:"<<se_r<<" move from results_tab: "<<printMove(results_tab[se_r][0])
            //<<" max_offs[1]:"<<max_offs[1]<<endl;
            if (results_tab[se_r][0] == gl_move) {
              //if noncapture, nonenpassant, noncheckevasion, nonpromotion, noncheck, many moves and bad static offset
              if ((gl_cp == 0) &&
                  (gl_fp == gl_tp) &&
                  (CheckStatus[se_ply - 1] == false) &&
                  (isAttByBla(WkiPos) == false) &&
                  (cur_offs[se_ply] >= ss_min_reduce_offset) &&
                  //(cur_offs[se_ply] > (max_offs[se_ply] * 0.33)) &&
                  (max_offs[se_ply] >= ss_min_reduce_ply_size)) {

								//if enough qDepth stored
                se_j = results_tab[se_r][1];
                if (se_j >= ss_min_depth) {

									//if result is worse enough than best move
                  if ((results_tab[se_r][2 + se_j] - (ss_min_score_difference)) > GameVal[GMI]) {

										//if enough "fresh" search result is stored
									  if (se_j==(qDepth-1)) {

										  //use stored search result as the move appears quite weak
											val[1] = results_tab[se_r][2 + se_j];
	                    PVlen[1] = se_ply;

                      //cout<<"black gl_move UP at root (shallower search result used): "<<printMove(gl_move)<<endl;
										  goto UP_PROC;
									  };
                  };
                };
              };
              break;
            };
          };
          //cout<<"black gl_move normal down at root: "<<printMove(gl_move)<<endl;
        };

#endif
#ifdef OFFSET_PRUNNING

        //slims some parts of the tree if
        //enough depth
        //(depending on previus move type)
        //(depending on material/position balance)
        if (
          (qDepth > 2)
          &&
          (se_ply > 2) &&
          (CheckStatus[se_ply - 1] == false) &&
          (max_offs[se_ply] > 10) &&
          (cur_offs[se_ply] > (max_offs[se_ply] * 0.5)) &&
          (reduced_tree_top == 0)
        ) {
          //save params to later return to original qDepth and
          //go to quiescence search with reduced qDepth mode
          reduced_tree_top = se_ply;
          offset_prunning_cnt++;
          val[se_ply] = EMPTY_VAL;
          goto Q_DOWN_PROC;
        };

#endif

        /////////////////////////////////
        //handle 3-fold draw
        if (retract < 99) {
          se_j = se_ply - 1;
          se_r = 0;

          while (se_j > 0) {
            if (retract_tab[se_j] == 0) {
              se_v = 0;
              break;
            }; //opponent move

            se_j--;

            if (se_j == 0) {
              se_v = 1;
              break;
            }; //self move

            if (retract_tab[se_j] == 0) {
              se_v = 0;
              break;
            };

            if (Zkey == Zkey_tab[se_j]) {
              se_r++;

              if (se_r > 1) {
                val[se_ply] = DRAW_SCORE;
                PVlen[se_ply] = se_ply;
                goto UP_PROC;
              };
            };

            se_j--;

            se_v = 1;
          };

          if (se_v == 1) {
            se_j = GMI;

            if (GameWtm[GMI + se_ply] == GameWtm[GMI]) {
              while (se_j > 0) {
                if (GameRetract[se_j] == 0) {
                  break;
                }; //self move

                if (Zkey == Game_Zkey_tab[se_j]) {
                  se_r++;

                  if (se_r > 1) {
                    val[se_ply] = DRAW_SCORE;
                    PVlen[se_ply] = se_ply;
                    goto UP_PROC;
                  };
                };

                se_j--;

                if (se_j == 0) {
                  break;
                }; //opponent move

                if (GameRetract[se_j] == 0) {
                  break;
                };

                se_j--;
              };
            } else {
              while (se_j > 0) {
                if (GameRetract[se_j] == 0) {
                  break;
                }; //opponent move

                se_j--;

                if (se_j == 0) {
                  break;
                }; //self move

                if (GameRetract[se_j] == 0) {
                  break;
                };

                if (Zkey == Game_Zkey_tab[se_j]) {
                  se_r++;

                  if (se_r > 1) {
                    val[se_ply] = DRAW_SCORE;
                    PVlen[se_ply] = se_ply;
                    goto UP_PROC;
                  };
                };

                se_j--;
              };
            };
          };
        }
        //handle 50-moves rule
        else {
          val[se_ply] = DRAW_SCORE;
          PVlen[se_ply] = se_ply;
          goto UP_PROC;
        };

        ////////////////////////////////////////////
#ifdef HASH_TRANSP_CUTTOFF
        ///////////////////////////////////////////////////
        //if HT entry with value found - do transposition cuttoff:
        //get val from HT if key matches
        //and if HT qDepth == qDepth
        //and if HT se_ply == se_ply
        //and if score in HT is value type (not erased)
        //HT==
        //[Zkey(64bits)]
        //[score(20bits)-val(20bits)-ply(6bits)-qDepth(6bits)-BestMovefromto(12bits)]
        //if (se_ply<qDepth) {
        //if ((se_ply<(qDepth))&&(se_ply>2)) {
        Hkey = (Zkey >> (Zkeylen - Hkeylen));

        if ((HT[Hkey][0] == Zkey)
            && //key compare
            (qDepth == (((HT[Hkey][1]) << 46) >> 58))
            &&         //qDepth compare
            (se_ply == (((HT[Hkey][1]) << 40) >> 58)) &&        //ply compare
            ((((HT[Hkey][1]) << 20) >> 44) != EMPTY_VAL)        //value not erased
           ) {
          H_transp_cuttoffs++;
          val[se_ply] = (((HT[Hkey][1]) << 20) >> 44);
          //cout<<"HT transp cut score"<<val[se_ply]<<endl;
          PVlen[se_ply] = se_ply; //limit pv
          goto UP_PROC;
        } else {
          //erase value and proceed
          val[se_ply] = EMPTY_VAL;
          //...printAll("after going down in wDOWN_PROC",se_ply);
        };

        /////////////////////////////////////////////////
#endif
        //else
#ifndef HASH_TRANSP_CUTTOFF
        val[se_ply] = EMPTY_VAL;

#endif
      };
    };

    //always here se_ply==qDepth.
    goto Q_DOWN_PROC;
  };
Q_DOWN_PROC: {
    //here se_ply==qDepth
    while (true)
      // endless until no piece to capture
    {
    	#ifdef DEBUG_VERSION
      //if search depth safety bound reached call error
      if (se_ply > 62) {
        //string my_path = getPATH(0, 62);
        cout << "telluser Ply 62 reached!. Search may be broken. Curent path: "
             //<< my_path
						 << endl;
        //if below any search margin - prune result
        //val[se_ply] = VALS_TREE[(se_ply << 8) | cur_offs[se_ply]];
        //PVlen[se_ply] = se_ply;
        //...printAll("last move evaluated in maxdepth",se_ply);
        //goto UP_PROC;
      };
      #endif

      //whites move
      if (GameWtm[GMI + se_ply]) {
        if (se_doPly == false) {
          se_doPly = true;
          se_ply++;
        } else {
          //set check evasion status
          if (isAttByBla(WkiPos)) {
            CheckStatus[se_ply] = true;
          } else {
            CheckStatus[se_ply] = false;
          };

          //incr ply
          se_ply++;

#ifdef QS_CHECK_EVASION_EXT

          //if white king check evasion: use full ply to defend
          //if (CheckStatus[se_ply-1]==true) {se_ply_finished[se_ply] = true;};
          //se_j = MOVES_TREE[((se_ply-1)<<8)|cur_offs[se_ply-1]];
          //if ((se_j==(se_j|(1<<31)))
          if ((CheckStatus[se_ply - 1] == true)
              && (se_ply <= (qDepth + QS_EVASIONS_DEPTH))) {
            se_ply_finished[se_ply] = true;
            cur_offs[se_ply] = 0;
            max_offs[se_ply] = FULL_WHI_PLY(se_ply);

            //if full ply developed and no legal moves - set final score
            if (max_offs[se_ply] == 0) {
              se_ply--;

              if (CheckStatus[se_ply] == true) {
                val[se_ply] = MIN_SCORE;
              } else {
                val[se_ply] = DRAW_SCORE;
              };

              PVlen[se_ply] = se_ply;
              //gl_move = MOVES_TREE[((se_ply << 8) | cur_offs[se_ply])];
              goto UP_PROC;
            };
            goto FULL_WHI_PLY_CREATED;
          };

#endif
          //if (se_ply_finished[se_ply] == false) {
//#ifdef TOTAL_QS_LIMIT

          //if (se_ply > (qDepth + QS_MARGIN)) {
            //se_ply--;
            //val[se_ply] = VALS_TREE[((se_ply) << 8) | cur_offs[se_ply]];
            //PVlen[se_ply] = se_ply;
            //...printAll("last move evaluated in max QS margin",se_ply);
            //gl_move = MOVES_TREE[((se_ply << 8) | cur_offs[se_ply])];
            //goto UP_PROC;
          //};

//#endif


          se_ply_finished[se_ply] = false;
          cur_offs[se_ply] = 0;
          max_offs[se_ply] = QS_WHI_PLY(se_ply);

          //if partial ply produced and no moves - set static score
          if (max_offs[se_ply] == 0) {
            se_ply--;
            val[se_ply] = VALS_TREE[(se_ply << 8) | cur_offs[se_ply]];
            PVlen[se_ply] = se_ply;
            //gl_move = MOVES_TREE[((se_ply << 8) | cur_offs[se_ply])];
						goto UP_PROC;
          };
        };

        FULL_WHI_PLY_CREATED: {;};

        //go to curent child move
        se_j = ((se_ply << 8) | cur_offs[se_ply]);

        gl_move = MOVES_TREE[se_j];

        CHILD(se_ply);

#ifdef EXTEND_ONLY_MOVE
        //if (se_ply_finished[se_ply] == true) {
          //#ifdef EXTEND_CHECK
          //if the move causes the black king is checked
          //if (gl_move==(gl_move|(1<<30))) {
          //qDepth++;
          //cout<<"whi check move ext in qs: "<<printMove(gl_move)<<endl;
          //printB("");
          //}

          //else
          //if (max_offs[se_ply] == 1) {
            //qDepth++;
            //cout<<"only whi move ext: "<<printMove(gl_move)<<endl;
            //printB("");
          //};
        //};

#endif
        /*
        //in qs:
                //if the parent move is check - respond with full ply.
                //allow checks without capture till qDepth+6
                //and only if all previus moves at same side in qs are checks
        */
#ifdef HASH_TRANSP_CUTTOFF
        ///////////////////////////////////////////////////
        //if HT entry with value found - do transposition cuttoff:
        //get val from HT if key matches
        //and if HT qDepth == qDepth
        //and if HT se_ply == se_ply
        //and if score in HT is value type (not erased)
        //HT==
        //[Zkey(64bits)]
        //[score(20bits)-val(20bits)-ply(6bits)-qDepth(6bits)-BestMovefromto(12bits)]
        Hkey = (Zkey >> (Zkeylen - Hkeylen));

        if ((HT[Hkey][0] == Zkey) &&    //key compare
            (qDepth == (((HT[Hkey][1]) << 46) >> 58))
            && //qDepth compare
            (se_ply == (((HT[Hkey][1]) << 40) >> 58)) &&        //ply compare
            ((((HT[Hkey][1]) << 20) >> 44) != EMPTY_VAL)        //value not erased
           ) {
          H_transp_cuttoffs++;
          val[se_ply] = (((HT[Hkey][1]) << 20) >> 44);
          PVlen[se_ply] = se_ply;
          goto UP_PROC;
        } else {
          //erase value and proceed
          val[se_ply] = EMPTY_VAL;
          //...printAll("after going down in wDOWN_PROC",se_ply);
        };

        /////////////////////////////////////////////////
#endif
        //else
#ifndef HASH_TRANSP_CUTTOFF
        val[se_ply] = EMPTY_VAL;

#endif
      }//btm
      else {
        if (se_doPly == false) {
          se_doPly = true;
          se_ply++;
        }
				else {
          //set check evasion status
          if (isAttByWhi(BkiPos)) {
            CheckStatus[se_ply] = true;
          } else {
            CheckStatus[se_ply] = false;
          };

          //increment se_ply
          se_ply++;


#ifdef QS_CHECK_EVASION_EXT

          if ((CheckStatus[se_ply - 1] == true)
              && (se_ply <= (qDepth + QS_EVASIONS_DEPTH))) {
            se_ply_finished[se_ply] = true;
            cur_offs[se_ply] = 0;
            max_offs[se_ply] = FULL_BLA_PLY(se_ply);

            //if full ply developed and no legal moves - set final score
            if (max_offs[se_ply] == 0) {
              se_ply--;

              if (CheckStatus[se_ply] == true) {
                val[se_ply] = MAX_SCORE;
              } else {
                val[se_ply] = DRAW_SCORE;
              };

              PVlen[se_ply] = se_ply;
              //gl_move = MOVES_TREE[((se_ply << 8) | cur_offs[se_ply])];
              goto UP_PROC;
            };
            goto FULL_BLA_PLY_CREATED;
          };
#endif

          se_ply_finished[se_ply] = false;
          cur_offs[se_ply] = 0;
          max_offs[se_ply] = QS_BLA_PLY(se_ply);

          //if partial ply produced and no moves - set static score
          if (max_offs[se_ply] == 0) {
            se_ply--;
            val[se_ply] = VALS_TREE[(se_ply << 8) | cur_offs[se_ply]];
            PVlen[se_ply] = se_ply;
            //gl_move = MOVES_TREE[((se_ply << 8) | cur_offs[se_ply])];
						goto UP_PROC;
          };
        };

        FULL_BLA_PLY_CREATED: {;};

        //go to curent child move
        se_j = ((se_ply << 8) | cur_offs[se_ply]);

        gl_move = MOVES_TREE[se_j];

        CHILD(se_ply);

#ifdef EXTEND_ONLY_MOVE
        //if (se_ply_finished[se_ply] == true) {
          //#ifdef EXTEND_CHECK
          //if the move causes the white king is checked
          //if (gl_move==(gl_move|(1<<31))) {
          //qDepth++;
          //cout<<"bla check move ext in qs: "<<printMove(gl_move)<<endl;
          //printB("");
          //}
          //
          //else
          //if (max_offs[se_ply] == 1) {
            //qDepth++;
            //cout<<"only bla move ext: "<<printMove(gl_move)<<endl;
            //printB("");
          //};
        //};

#endif
#ifdef HASH_TRANSP_CUTTOFF
        ///////////////////////////////////////////////////
        //if HT entry with value found - do transposition cuttoff:
        //get val from HT if key matches
        //and if HT qDepth == qDepth
        //and if HT se_ply == se_ply
        //and if score in HT is value type (not erased)
        //HT==
        //[Zkey(64bits)]
        //[score(20bits)-val(20bits)-ply(6bits)-qDepth(6bits)-BestMovefromto(12bits)]
        Hkey = (Zkey >> (Zkeylen - Hkeylen));

        if ((HT[Hkey][0] == Zkey) &&    //key compare
            (qDepth == (((HT[Hkey][1]) << 46) >> 58))
            && //qDepth compare
            (se_ply == (((HT[Hkey][1]) << 40) >> 58)) &&        //ply compare
            ((((HT[Hkey][1]) << 20) >> 44) != EMPTY_VAL)        //value not erased
           ) {
          H_transp_cuttoffs++;
          val[se_ply] = (((HT[Hkey][1]) << 20) >> 44);
          PVlen[se_ply] = se_ply;
          goto UP_PROC;
        } else {
          //erase value and proceed
          val[se_ply] = EMPTY_VAL;
          //...printAll("after going down in wDOWN_PROC",se_ply);
        };

        /////////////////////////////////////////////////
#endif
        //else
#ifndef HASH_TRANSP_CUTTOFF
        val[se_ply] = EMPTY_VAL;
#endif
      };
    };
  };
//////////////////////////////////////////////////////////////////////////////////////////////////////
UP_PROC: {
    if (THINKING == true) {
      //go up (if search ends B[] must be in starting move position)
      if (se_ply > 0) {
        //if (se_ply > MAX_DEPTH_REACHED) {MAX_DEPTH_REACHED = se_ply;};


				gl_move = MOVES_TREE[(se_ply << 8) | cur_offs[se_ply]];


#ifdef EXTEND_ONLY_MOVE

        //if (gl_move==(gl_move|(1<<30))) {
        //qDepth--;
        //cout<<"whi check move ext in qs: "<<printMove(gl_move)<<endl;
        //printB("");
        //};
        //else if (gl_move==(gl_move|(1<<31))) {
        //qDepth--;
        //cout<<"bla check move ext in qs: "<<printMove(gl_move)<<endl;
        //printB("");
        //}
        //else
        /*
				if (max_offs[se_ply] == 1) {
          if (se_ply_finished[se_ply] == true) {
            qDepth--;
            //cout<<"extension only move retracted:"<<printMove(gl_move)<<endl;
            //printB("");
          };
        };
        */
#endif
        PARENT(se_ply);    //move up position and get parent Zkey

        se_nextPly = se_ply;//save se_nextPly as lower ply

        se_ply--;  //move up se_ply

#ifdef CUTTOFF_MOVE_HASH_REORDER
        cut_move_coords = 0; //erase cut move coords

#endif
#ifdef LATE_MOVE
				//set this flag initially
        lmr_research = false;
#endif

        //if full ply has been developed (restply or fullply)
        if (se_ply_finished[se_nextPly] == true) {

#ifdef MAT_POS_PRUNNING

          if (reduced_tree_top == se_nextPly) {
            reduced_tree_top = 0;
          };

#endif
#ifdef OFFSET_PRUNNING
          if (reduced_tree_top == se_nextPly) {
            reduced_tree_top = 0;
          };

#endif
          if (GameWtm[GMI + se_ply] == true) {
            //improve order of first ply moves
            if (se_ply == 0) {
              vals_tab[cur_offs[1]] = val[1]; //save first move score to vals_tab
              moves_tab[cur_offs[1]] = gl_move;
            };

#ifdef SELECTIVE_SEARCH

            //save search results of first-ply-moves
            if (se_ply == 0) {
              //find move index in results_tab
              for (se_r = 0; se_r < max_offs[1]; se_r++) {
                if (results_tab[se_r][0] == gl_move) {
                  results_tab[se_r][1] = qDepth;
                  results_tab[se_r][2 + qDepth] = val[1];
									break;
                };
              };
            };

#endif

            /*
            //if move is late and almost improved score - it should be researched.
            //Convert it to non-lmr move, set research flag
                       #ifdef LATE_MOVE
            if (gl_move==(gl_move|(1<<29))) {
              if ((val[se_ply] < val[se_nextPly]+3333)) {
              //restore and sweep
              MOVES_TREE[(se_nextPly<<8)|cur_offs[se_nextPly]] ^= (1<<29);
              lmr_research = true;
              lmr_whi_research++;
              };
            };
            #endif
            */

            //change parent score if it is worse than child or undefined
            if ((val[se_ply] < val[se_nextPly]) || (val[se_ply] == EMPTY_VAL)) {

#ifdef LATE_MOVE
              //if late move improves score
              //convert it to non-lmr move, set research flag
              if (gl_move == (gl_move | (1 << 29))) {
                //restore and sweep
                MOVES_TREE[(se_nextPly << 8) | cur_offs[se_nextPly]] ^= (1 << 29);
                lmr_research = true;
                #ifdef DEBUG_VERSION
								lmr_whi_research++;
								#endif
                //val[se_ply] = tmp_val;
                //val[se_nextPly] = EMPTY_VAL;

								/*
                cout<<"cuttoff, whi lmr_research, val[se_ply]:" << val[se_ply]
                <<" late move:" << printMove(gl_move)
                <<" qDepth:" << qDepth
								<<endl;
                */

                /*
                while (se_r <= 64) {
                  PVlen[se_r]=0;
                  cur_offs[se_r]=0;
                  max_offs[se_r+1]=0;
                  enp_sq[se_r+1]=64;
                  castle_data[se_r+1]=0;
                  Zkey_tab[se_r+1]=0;
                  retract_tab[se_r+1]=0;
                se_ply_finished[se_r+1] = false;
                //clear MOVES_TREE before each search() while (j<256) {MOVES_TREE[(se_r<<8)|j]=0; j++;};
                  //clear PV[]
                 //j=0; while (j<64){PV[se_r][j] = 0; j++;};
                 se_r++;
                         };
                */
                /*
                printB("Whi lmr research:");
                cout<<"Whi late move "<<printMove(gl_move)
                <<" research!"<<endl;
                ///////////////////
                cout<<"Whi late moves report (se_nextPly:"<<se_nextPly<<", qDepth:"<<qDepth<<"):"<<endl;
                se_i = 0;
                while (se_i<max_offs[se_nextPly]) {
                  ar_move = MOVES_TREE[(se_nextPly<<8)|se_i];
                  if (ar_move==(ar_move | (1<<29))) {
                    cout<<"["<<se_i<<"]"<<printMove(ar_move)<<"-late "<<flush;
                  }
                  else {
                   cout<<"["<<se_i<<"]"<<printMove(ar_move)<<"-norm "<<flush;
                  };
                  se_i++;
                };
                cout<<endl;
                //////////////////
                */
              }
              else {
#endif
								//tmp_val = val[se_ply];
	              val[se_ply] = val[se_nextPly]; //maximizing val
	              PV[se_ply][se_ply] = gl_move; //insert move to PV

	              if (se_ply == 0) {
	                show_score_change = true;
	              };//output PV score change

#ifdef LATE_MOVE
							};
#endif
              //if null move (almost?) produced a cuttoff - make the cuttoff
#ifdef NULL_MOVE

              if (gl_move < 3) {
                if (
								  //(se_ply > 0) &&
								  (val[se_ply - 1] <= (val[se_ply]
									//+ evNullMoveMargin
									)) &&
									(val[se_ply - 1] != EMPTY_VAL)
									) {
                  //adjust val to cause a cuttoff
                  val[se_ply] = val[se_ply - 1];
                  //val[se_ply] = tmp_val;
                  //val[se_nextPly] = 0;
                  nms_whi_cut++;
                  goto ALFA_NMS_CUT;
                } else {
                  nms_whi_fail++;
                  /////////////////new code
              	  /*
									if (
									//(se_ply > 0) &&
									(val[se_ply - 1] > (val[se_ply] + evForcedMoveMargin)) &&
									(val[se_ply - 1] != EMPTY_VAL)
									) {
                    //cout<<"1.Forcing move detected by null move search:"<<getPATH(0,se_ply)<<endl;
										//here null move returns really poor score.
										//it means that the parent move is a forcing move and it shouldnt be reduced
										//only positions which have no forcing move and weak position score can be searched shallower,
										//because they dont contain direct threat
                    //printB("2.Position before forced move:");
                    (MOVES_TREE[((se_ply) << 8) | cur_offs[se_ply]]) |= forced_pos_mask;
                    //cout<<"3.Parent of forced move:"<<printMove(MOVES_TREE[((se_ply) << 8) | cur_offs[se_ply]])<<endl;

									};
									*/
              	  /////////////////new code end@
                };
              };

#endif
              //handle score upgrade
#ifdef SEARCH_REORD

              //if parent move is sr root move
              if (sr_set == true) {
                if (sr_ply == se_ply) {
                  //save search result when score upgraded, dont cuttoff
                  sr_vals_tab[cur_offs[se_nextPly]] = val[se_ply];
                  sr_moves_tab[cur_offs[se_nextPly]] = gl_move;
                  goto DONT_ALFACUT;
                };
              };

#endif
              ab_cut_flag = false;
              //make alfa cuttoff eventually (dont upgrade insignificant pv)
              if ((se_ply > 0)
                  && (val[se_ply - 1] <= val[se_ply])
                  && (val[se_ply - 1] != EMPTY_VAL)) {
#ifdef NULL_MOVE
ALFA_NMS_CUT: {
                  ;
                };
#endif

                #ifdef DEBUG_VERSION
								visited_nonqs_positions_count += (cur_offs[se_nextPly]+1);
                #endif

                /*
								//find out which moves cause most cuttoffs (captures?, checks?, promotions?, which piece type?, where on the board?)


								if ((gl_move==1) || (gl_move==2)) {
								  cout<<"cuttoff move: "<<printMove(gl_move)<<endl;
								  //gl_nm_cut++;
								}
								else {
									cout<<"cuttoff move: "<<printMove(gl_move)
									//<<" gl_fs: "<<SQUARE[((gl_move << 26) >> 26)]
									//<<" gl_ts: "<<SQUARE[((gl_move << 20) >> 26)]
									<<" gl_fp: "<<printPiece((gl_move << 16) >> 28)
	  							<<", gl_tp: "<<printPiece((gl_move << 12) >> 28)
	  							<< flush;
	  							if (((gl_move << 8) >> 28) == 0) {
									  cout<<", noncapture"<<flush;
								  }
								  else {
									  cout<<", gl_cp: "<<printPiece((gl_move << 8) >> 28)<<flush;
	  						  };
	  							//gl_fs_cut[((gl_move << 26) >> 26)]++;
	  							//gl_ts_cut[((gl_move << 20) >> 26)]++;
	  							//gl_fp_cut[((gl_move << 16) >> 28)]++;
	  							//gl_tp_cut[((gl_move << 12) >> 28)]++;
	  							//gl_cp_cut[((gl_move << 8) >> 28)]++;

									if ((gl_move == (gl_move | (1 << 30))) || (gl_move == (gl_move | (1 << 31)))) {
								    //gl_check_cut++;
								    cout<<", check "<<flush;
									};

									//gl_offs_cut[cur_offs[se_nextPly]]++;
									cout<<", offs: "<<cur_offs[se_nextPly]<<" of "<<max_offs[se_nextPly]<<flush;
									cout<<", qDepth: "<<qDepth<<", se_nextPly:"<<se_nextPly<<endl;
  						  };
                ///////////////////////
                */

								cur_offs[se_nextPly] = max_offs[se_nextPly];

								#ifdef DEBUG_VERSION
								alfa_cut_count++;
								#endif

                ab_cut_flag = true;

#ifdef CUTTOFF_MOVE_HASH_REORDER
                cut_move_coords = ((gl_move << 20) >> 20);
#endif
#ifdef KILLERS

                //update killer moves only if noncapture or nonpromotion found
                if (((gl_move << 8) >>
                     28) == 0) {
                  if (((gl_move << 16) >> 28)
                      == ((gl_move << 12) >> 28)) {
                    SecondKiller[se_nextPly] = FirstKiller[se_nextPly];
                    FirstKiller[se_nextPly] = gl_move;
                  };
                };

#endif
              };

              //else {
              //if score upgraded (cuttoff or not) move up the rest of lowerply PV to se_ply PV
#ifdef SEARCH_REORD
DONT_ALFACUT: {
                ;
              };

#endif

              //trim pv len to qDepth
							#ifdef TRIM_PV
              if (PVlen[se_nextPly] > qDepth) {PVlen[se_nextPly] = qDepth;};
              #endif

							//do pv propagation
              se_i = se_nextPly;
              se_j = PVlen[se_i];
              while (se_i < se_j) {
                PV[se_ply][se_i] = PV[se_nextPly][se_i];
                se_i++;
              };
              PVlen[se_ply] = PVlen[se_nextPly];
              //...printAll("val and PV update in wUP_PROC",se_ply);

            }
						//if score of parent is better or equal and no val upgrade
						else {

              //save worse score to reord tables
#ifdef SEARCH_REORD
              //if parent move is sr root move
              if ((sr_set == true) && (sr_ply == se_ply)) {
                //save search result
                sr_vals_tab[cur_offs[se_nextPly]] = val[se_nextPly];
                sr_moves_tab[cur_offs[se_nextPly]] = gl_move;
              };

#endif
            };
          } else
            //btm
          {
            if (se_ply == 0) {
              vals_tab[cur_offs[1]] = val[1]; //save first move score to vals_tab
              moves_tab[cur_offs[1]] = gl_move;
            };

#ifdef SELECTIVE_SEARCH

            //save search results of first ply moves
            if (se_ply == 0) {
              //find move index in results_tab
              for (se_r = 0; se_r < max_offs[1]; se_r++) {
                if (results_tab[se_r][0] == gl_move) {
                  results_tab[se_r][1] = qDepth;
                  results_tab[se_r][2 + qDepth] = val[1];
									break;
                };
              };
            };

#endif

            /*
            //if move is late and almost improved score - it should be researched.
               //Convert it to non-lmr move, set research flag
              #ifdef LATE_MOVE
               if (gl_move==(gl_move|(1<<29))) {
                 if ((val[se_ply] > val[se_nextPly]-3333)) {
                    //restore and sweep
                 MOVES_TREE[(se_nextPly<<8)|cur_offs[se_nextPly]] ^= (1<<29);
                 lmr_research = true;
                 lmr_whi_research++;
                 };
               };
               #endif
            */

            //change parent score if it is worse than child or undefined
            if ((val[se_ply] > val[se_nextPly]) || (val[se_ply] == EMPTY_VAL)) {

#ifdef LATE_MOVE
              //if late move improved score
              //convert it to non-lmr move, set research flag
							if (gl_move == (gl_move | (1 << 29))) {
                //restore and sweep
                MOVES_TREE[(se_nextPly << 8) | cur_offs[se_nextPly]] ^= (1 << 29);
                lmr_research = true;
                #ifdef DEBUG_VERSION
                lmr_bla_research++;
                #endif
                //val[se_ply] = tmp_val;
                //val[se_nextPly] = EMPTY_VAL;

                /*
								cout<<"cuttoff, bla lmr_research, val[se_ply]:" << val[se_ply]
                 <<" late move:" << printMove(gl_move)
                 <<" qDepth:" << qDepth
                 << endl;
								*/
								/*
                while (se_r <= lmr_qDepth) {
                  PVlen[se_r]=0;
                  cur_offs[se_r+1]=0;
                  max_offs[se_r+1]=0;
                  enp_sq[se_r+1]=64;
                  castle_data[se_r+1]=0;
                  Zkey_tab[se_r+1]=0;
                  retract_tab[se_r+1]=0;
                se_ply_finished[se_r+1] = false;
                //clear MOVES_TREE before each search() while (j<256) {MOVES_TREE[(se_r<<8)|j]=0; j++;};
                  //clear PV[]
                 //j=0; while (j<64){PV[se_r][j] = 0; j++;};
                 se_r++;
                         };
                */
                /*
                printB("Bla lmr research");
                cout<<"Bla late move "<<printMove(gl_move)
                <<" research!"<<endl;
                ///////////////////
                cout<<"Bla late moves report (se_nextPly:"<<se_nextPly<<", qDepth:"<<qDepth<<"):"<<endl;
                se_i = 0;
                while (se_i<max_offs[se_nextPly]) {
                  ar_move = MOVES_TREE[(se_nextPly<<8)|se_i];
                  if (ar_move==(ar_move | (1<<29))) {
                    cout<<"["<<se_i<<"]"<<printMove(ar_move)<<"-late "<<flush;
                  }
                  else {
                   cout<<"["<<se_i<<"]"<<printMove(ar_move)<<"-norm "<<flush;
                  };
                  se_i++;
                };
                cout<<endl;
                //////////////////
                */
              }
							else {
#endif
								//tmp_val = val[se_ply];
	              val[se_ply] = val[se_nextPly]; //minimizing val
	              PV[se_ply][se_ply] = gl_move; //insert move to PV

	              //output PV score change
	              if (se_ply == 0) {
	                show_score_change = true;
	              };

#ifdef LATE_MOVE
						  };
#endif

              //if null move almost produced a cuttoff -
              //make the cuttoff
#ifdef NULL_MOVE
              if (gl_move < 3) {
                if (
								//(se_ply > 0) &&
								  (val[se_ply - 1] >= (val[se_ply]
									//- evNullMoveMargin
									)) &&
									(val[se_ply - 1] != EMPTY_VAL)
									) {
                  //adjust val to cause a cuttoff
                  val[se_ply] = val[se_ply - 1];
                  //val[se_ply] = tmp_val;
                  //val[se_nextPly] = 0;
                  nms_bla_cut++;
                  goto BETA_NMS_CUT;
                } else {
                  nms_bla_fail++;
                  /////////////////new code
              	  /*
									if (
									  //(se_ply > 0) &&
										(val[se_ply - 1] < (val[se_ply] + evForcedMoveMargin)) &&
                    (val[se_ply - 1] != EMPTY_VAL)
										) {
                    //cout<<"1.Forcing move detected by null move search:"<<getPATH(0,se_ply)<<endl;
										//here null move returns really poor score.
										//it means that the parent move is a forcing move and it shouldnt be reduced
										//only positions which have no forcing move and weak position score can be searched shallower,
										//because they dont contain direct threat
                    //printB("2.Position before forced move:");

                    (MOVES_TREE[((se_ply) << 8) | cur_offs[se_ply]]) |= forced_pos_mask;
                    //cout<<"3.Parent of forced move:"<<printMove(MOVES_TREE[((se_ply) << 8) | cur_offs[se_ply]])<<endl;

									};
									*/
              	  /////////////////new code end@
                };
              };

#endif
              //handle score upgrade
#ifdef SEARCH_REORD

              //if parent move is sr root move
              if ((sr_set == true) && (sr_ply == se_ply)) {
                //save search result when score upgraded, dont cuttoff
                sr_vals_tab[cur_offs[se_nextPly]] = val[se_ply];
                sr_moves_tab[cur_offs[se_nextPly]] = gl_move;
                goto DONT_BETACUT;
              };

#endif
							ab_cut_flag = false;
              //make beta cuttoff eventually
              if ((se_ply > 0)
                  && (val[se_ply - 1] >= val[se_ply])
                  && (val[se_ply - 1] != EMPTY_VAL)) {
#ifdef NULL_MOVE
BETA_NMS_CUT: {
                  ;
                };
#endif
								#ifdef DEBUG_VERSION
                visited_nonqs_positions_count += (cur_offs[se_nextPly]+1);
								#endif
								/*
								//find out which moves cause most cuttoffs (captures?, checks?, promotions?, which piece type?, where on the board?)


								if ((gl_move==1) || (gl_move==2)) {
								  cout<<"cuttoff move: "<<printMove(gl_move)<<endl;
								  //gl_nm_cut++;
								}
								else {
									cout<<"cuttoff move: "<<printMove(gl_move)
									//<<" gl_fs: "<<SQUARE[((gl_move << 26) >> 26)]
									//<<" gl_ts: "<<SQUARE[((gl_move << 20) >> 26)]
									<<" gl_fp: "<<printPiece((gl_move << 16) >> 28)
	  							<<", gl_tp: "<<printPiece((gl_move << 12) >> 28)
	  							<< flush;
	  							if (((gl_move << 8) >> 28) == 0) {
									  cout<<", noncapture"<<flush;
								  }
								  else {
									  cout<<", gl_cp: "<<printPiece((gl_move << 8) >> 28)<<flush;
	  						  };
	  							//gl_fs_cut[((gl_move << 26) >> 26)]++;
	  							//gl_ts_cut[((gl_move << 20) >> 26)]++;
	  							//gl_fp_cut[((gl_move << 16) >> 28)]++;
	  							//gl_tp_cut[((gl_move << 12) >> 28)]++;
	  							//gl_cp_cut[((gl_move << 8) >> 28)]++;

									if ((gl_move == (gl_move | (1 << 30))) || (gl_move == (gl_move | (1 << 31)))) {
								    //gl_check_cut++;
								    cout<<", check "<<flush;
									};

									//gl_offs_cut[cur_offs[se_nextPly]]++;
									cout<<", offs: "<<cur_offs[se_nextPly]<<" of "<<max_offs[se_nextPly]<<flush;
									cout<<", qDepth: "<<qDepth<<", se_nextPly:"<<se_nextPly<<endl;
  						  };
                ///////////////////////
                */


								cur_offs[se_nextPly] = max_offs[se_nextPly];

								#ifdef DEBUG_VERSION
								beta_cut_count++;
								#endif

                ab_cut_flag = true;


#ifdef CUTTOFF_MOVE_HASH_REORDER
                cut_move_coords = ((gl_move << 20) >> 20);
#endif
#ifdef KILLERS

                //update killer moves only if noncapture or nonpromotion found
                if (((gl_move << 8) >>
                     28) == 0) {
                  if (((gl_move << 16) >> 28)
                      == ((gl_move << 12) >> 28)) {
                    SecondKiller[se_nextPly] = FirstKiller[se_nextPly];
                    FirstKiller[se_nextPly] = gl_move;
                  };
                };

#endif
              };

              //else {
              //move up the rest of lowerply PV to se_ply PV
#ifdef SEARCH_REORD
DONT_BETACUT: {
                ;
              };

#endif

              //trim pv len to qDepth
							#ifdef TRIM_PV
              if (PVlen[se_nextPly] > qDepth) {PVlen[se_nextPly] = qDepth;};
              #endif

              se_i = se_nextPly;
              se_j = PVlen[se_i];
              while (se_i < se_j) {
                PV[se_ply][se_i] = PV[se_nextPly][se_i];
                se_i++;
              };
              PVlen[se_ply] = PVlen[se_nextPly];
              //...printAll("val and PV update in bUP_PROC",se_ply);

            } else {
              //if score of parent is better or equal and no val upgrade
              //save worse score into reord tables
#ifdef SEARCH_REORD
              //if parent move is sr root move
              if ((sr_set == true) && (sr_ply == se_ply)) {
                //save search result
                sr_vals_tab[cur_offs[se_nextPly]] = val[se_nextPly];
                sr_moves_tab[cur_offs[se_nextPly]] = gl_move;
              };

#endif
            };
          };
        }

				//assume se_ply_finished[se_nextPly] == false
				//it means that either we wave qsply moves created
				//and we should build the restply
				//or we are done with qsply because we are below qDepth
				else {


          se_update = false;

          if (GameWtm[GMI + se_ply]) {
            //at first promote move if it is better than father or undefined
            if ((val[se_ply] < val[se_nextPly]) || (val[se_ply] == EMPTY_VAL)) {
              //if (val[se_nextPly]==0) {EXTRA//...printAll("wtm return - zero value in leaf!",se_nextPly);};
              val[se_ply] = val[se_nextPly];
              PV[se_ply][se_ply] = gl_move; //insert move to PV
              se_update = true;
            };

            //if now parent EVAL is better - use it instead of val
						//(it simulates not capturing
						//if it leads to poor capture trade in qs - state of game before making the move)
            //this shouldnt be done if we plan to build restply or we
						//already have fullply because
						//the search result will be more precise and complete in this case
						if (se_ply >= qDepth) {
				      if (VALS_TREE[(se_ply << 8) | cur_offs[se_ply]] > val[se_ply]) {
                val[se_ply] = VALS_TREE[((se_ply) << 8) | cur_offs[se_ply]]; //maximizing val
                PV[se_ply][se_ply] = gl_move;
                //cout<<"W val[] promote code used"<<endl;
                se_update = true;
              };
            };

						ab_cut_flag = false;

            //make alfa cuttoff eventually
            if ((se_ply > 0) && (val[se_ply - 1] <= val[se_ply]) &&
						(val[se_ply - 1] != EMPTY_VAL)) {

            	#ifdef DEBUG_VERSION
							visited_qs_positions_count += (cur_offs[se_nextPly]+1);
              #endif

              /*
							//find out which moves cause most cuttoffs (captures?, checks?, promotions?, which piece type?, where on the board?)


							if ((gl_move==1) || (gl_move==2)) {
							  cout<<"qs cuttoff move: "<<printMove(gl_move)<<endl;
							  //gl_nm_cut++;
							}
							else {
								cout<<"qs cuttoff move: "<<printMove(gl_move)
								//<<" gl_fs: "<<SQUARE[((gl_move << 26) >> 26)]
								//<<" gl_ts: "<<SQUARE[((gl_move << 20) >> 26)]
								<<" gl_fp: "<<printPiece((gl_move << 16) >> 28)
  							<<", gl_tp: "<<printPiece((gl_move << 12) >> 28)
  							<< flush;
  							if (((gl_move << 8) >> 28) == 0) {
								  cout<<", noncapture"<<flush;
							  }
							  else {
								  cout<<", gl_cp: "<<printPiece((gl_move << 8) >> 28)<<flush;
  						  };
  							//gl_fs_cut[((gl_move << 26) >> 26)]++;
  							//gl_ts_cut[((gl_move << 20) >> 26)]++;
  							//gl_fp_cut[((gl_move << 16) >> 28)]++;
  							//gl_tp_cut[((gl_move << 12) >> 28)]++;
  							//gl_cp_cut[((gl_move << 8) >> 28)]++;

								if ((gl_move == (gl_move | (1 << 30))) || (gl_move == (gl_move | (1 << 31)))) {
							    //gl_check_cut++;
							    cout<<", check "<<flush;
								};

								//gl_offs_cut[cur_offs[se_nextPly]]++;
								cout<<", offs: "<<cur_offs[se_nextPly]<<" of "<<max_offs[se_nextPly]<<flush;
								cout<<", qDepth: "<<qDepth<<", se_nextPly:"<<se_nextPly<<endl;
						  };
              ///////////////////////
              */


							cur_offs[se_nextPly] = max_offs[se_nextPly];

							#ifdef DEBUG_VERSION
							alfa_cut_count++;
							#endif

              ab_cut_flag = true;
#ifdef CUTTOFF_MOVE_HASH_REORDER
              cut_move_coords = ((gl_move << 20) >> 20);
#endif
            };


            //trim pv len to qDepth
						#ifdef TRIM_PV
            if (PVlen[se_nextPly] > qDepth) {PVlen[se_nextPly] = qDepth;};
            #endif

						if (se_update == true) {
              //move up the rest of lowerply PV to se_ply PV and delete junks
              se_i = se_nextPly;
              se_j = PVlen[se_i];
              while (se_i < se_j) {
                PV[se_ply][se_i] = PV[se_nextPly][se_i];
                se_i++;
              };
              PVlen[se_ply] = PVlen[se_nextPly];
              //...printAll("val and PV update in wUP_PROC",se_ply);
            };

          } else
            //btm
          {
            //at first promote move if it is better than father or undefined
            if ((val[se_ply] > val[se_nextPly]) || (val[se_ply] == EMPTY_VAL)) {
              val[se_ply] = val[se_nextPly];
              PV[se_ply][se_ply] = gl_move; //insert move to PV
              se_update = true;
            };

            //promote EVAL if it is better than val
            //(it simulates making silent move instead of capture
						//if it leads to poor capture trade in qs)
            //this shouldnt be done if we plan to build restply because
						//the search result will be more precise and complete in this case
						if (se_ply >= qDepth) {
              if (VALS_TREE[(se_ply << 8) | cur_offs[se_ply]] < val[se_ply]) {
                val[se_ply] = VALS_TREE[(se_ply << 8) | cur_offs[se_ply]];
                PV[se_ply][se_ply] = gl_move;
                se_update = true;
                //cout<<"B val[] promote code used"<<endl;
              };
						};

						ab_cut_flag = false;
            //make beta cuttoff eventually
            if ((se_ply > 0) && (val[se_ply - 1] >= val[se_ply]) &&
						(val[se_ply - 1] != EMPTY_VAL)) {

							#ifdef DEBUG_VERSION
							visited_qs_positions_count += (cur_offs[se_nextPly]+1);
							#endif

							/*
							//find out which moves cause most cuttoffs (captures?, checks?, promotions?, which piece type?, where on the board?)


							if ((gl_move==1) || (gl_move==2)) {
							  cout<<"qs cuttoff move: "<<printMove(gl_move)<<endl;
							  //gl_nm_cut++;
							}
							else {
								cout<<"qs cuttoff move: "<<printMove(gl_move)
								//<<" gl_fs: "<<SQUARE[((gl_move << 26) >> 26)]
								//<<" gl_ts: "<<SQUARE[((gl_move << 20) >> 26)]
								<<" gl_fp: "<<printPiece((gl_move << 16) >> 28)
  							<<", gl_tp: "<<printPiece((gl_move << 12) >> 28)
  							<< flush;
  							if (((gl_move << 8) >> 28) == 0) {
								  cout<<", noncapture"<<flush;
							  }
							  else {
								  cout<<", gl_cp: "<<printPiece((gl_move << 8) >> 28)<<flush;
  						  };
  							//gl_fs_cut[((gl_move << 26) >> 26)]++;
  							//gl_ts_cut[((gl_move << 20) >> 26)]++;
  							//gl_fp_cut[((gl_move << 16) >> 28)]++;
  							//gl_tp_cut[((gl_move << 12) >> 28)]++;
  							//gl_cp_cut[((gl_move << 8) >> 28)]++;

								if ((gl_move == (gl_move | (1 << 30))) || (gl_move == (gl_move | (1 << 31)))) {
							    //gl_check_cut++;
							    cout<<", check "<<flush;
								};

								//gl_offs_cut[cur_offs[se_nextPly]]++;
								cout<<", offs: "<<cur_offs[se_nextPly]<<" of "<<max_offs[se_nextPly]<<flush;
								cout<<", qDepth: "<<qDepth<<", se_nextPly:"<<se_nextPly<<endl;
						  };
              ///////////////////////
							*/

							cur_offs[se_nextPly] = max_offs[se_nextPly];

							#ifdef DEBUG_VERSION
							beta_cut_count++;
							#endif

              ab_cut_flag = true;

#ifdef CUTTOFF_MOVE_HASH_REORDER
              cut_move_coords = ((gl_move << 20) >> 20);
#endif
            };

            //trim pv len to qDepth
						#ifdef TRIM_PV
            if (PVlen[se_nextPly] > qDepth) {PVlen[se_nextPly] = qDepth;};
            #endif

						if (se_update == true) {
              //move up the rest of lowerply PV to se_ply PV and delete junks
              se_i = se_nextPly;
              se_j = PVlen[se_i];
              while (se_i < se_j) {
                PV[se_ply][se_i] = PV[se_nextPly][se_i];
                se_i++;
              };
              PVlen[se_ply] = PVlen[se_nextPly];
              //...printAll("val and PV update in wUP_PROC",se_ply);
            };

          };
        };
      };

#ifdef HASH_TRANSP_CUTTOFF
      //////////////////////////////////////////////////////////////
      //overwrite HT entry (if cuttoff or not) for detecting transpositions.
      //HT==
      //[Zkey(64bits)]
      //[score(20bits)-val(20bits)-ply(6bits)-qDepth(6bits)-BestMovefromto(12bits)]
      Hkey = (Zkey >> (Zkeylen - Hkeylen));

      //dont overwrite HT score if Zkey matches
      if (HT[Hkey][0] == Zkey) {
        H_transp_overwrites++;
        HT[Hkey][1] = (
                        (((HT[Hkey][1]) >> 44) << 44) |       //HT score
                        (((unsigned __int64)(val[se_ply])) << 24) |          //curent val
                        (((unsigned __int64)(se_ply)) << 18) |          //curent ply
                        (((unsigned __int64)(qDepth)) << 12)          //curent qDepth
#ifdef CUTTOFF_MOVE_HASH_REORDER
                        | cut_move_coords //eventual curent cuttoff move coords
#endif
                      );
      }
      //if Zkey doesnt match - overwrite all
      else {
        H_transp_overwrites++;
        HT[Hkey][0] = Zkey;
        HT[Hkey][1] = (
                        (((unsigned __int64)(val[se_ply])) << 24) |          //val
                        (((unsigned __int64)(se_ply)) << 18) |          //ply
                        (((unsigned __int64)(qDepth)) << 12)          //qDepth
#ifdef CUTTOFF_MOVE_HASH_REORDER
                        | cut_move_coords //eventual curent cuttoff move coords
#endif
                      );
      };

      //////////////////////////////////////////////////////////////
#endif

      //if treeroot visited in up proc
      if (se_ply == 0) {
        //save info into game pv data
        //(necessary to use best move in FIRST_DOWN_PROC)
        se_r = PVlen[0];
        GamePVlen[GMI] = se_r;

        for (se_j = 0; se_j < se_r; se_j++) {
          GamePV[GMI][se_j] = PV[0][se_j];
        };

				//debug
        //if (PV[0][0]==0) {
				  //cout<<"bug - zero move at PV[0][0] returned by SEARCH()"<<endl;
				//};

        //return loss result if no thinking result yet (i.e no time left)

        GameVal[GMI] = val[0];

        //} else {
        //GameVal[GMI] = VALS_TREE[0];
        //se_return_static_eval = false;
        //};
        //////////////////////////////////////
        outputSomeThinking();

        /////////////////////////////////////////////////////
        //cout<<"ZKey:"<<Zkey<<" at se_ply:0, qDepth:"<<qDepth<<endl;
      };

      //#ifdef NULL_MOVE
      //output null move search results
      //if (gl_move<3) {
      /*
      cout<<"null move data in UP_PROC: nms_set:"<<nms_set
        <<" se_ply:"<<se_ply
       <<" val[se_ply-1]:"<<((val[se_ply-1]/100)-(MIDDLE_SCORE/100))
       <<" val[se_ply]:"<<((val[se_ply]/100)-(MIDDLE_SCORE/100))
       <<" val[se_nextPly]:"<<((val[se_nextPly]/100)-(MIDDLE_SCORE/100))
       <<" cur_offs[se_ply-1]:"<<cur_offs[se_ply-1]
       <<" cur_offs[se_ply]:"<<cur_offs[se_ply]
       <<" cur_offs[se_nextPly]:"<<cur_offs[se_nextPly]
       <<endl;
      printB("board at gl_move<3:");
      */
      /*
      switch (gl_move) {
        case 1: {
         if (cuttoff==true) {
           //cout<<" ,whi null move cuttoff HAPPENED:"<<getPATH(0,se_ply)<<endl;
           nms_whi_cut++;
         }
         //if no cuttoff - nms search failed.
         //other moves will be searched with full depth
         else {
           //cout<<" ,whi null move cuttoff FAILED: "<<getPATH(0,se_ply)<<endl;
            nms_whi_fail++;
        };
        }; break;
        case 2: {
         if (cuttoff==true) {
           //cout<<" ,bla null move cuttoff HAPPENED:"<<getPATH(0,se_ply)<<endl;
           nms_bla_cut++;
         }
         else {
           //cout<<" ,bla null move cuttoff FAILED: "<<getPATH(0,se_ply)<<endl;
            nms_bla_fail++;
        };
        }; break;
        */
      /*
      case 3: {
        if (cuttoff==true) {
          //cout<<" ,whi q null move cuttoff HAPPENED:"<<getPATH(0,se_ply)<<endl;
          nmq_whi_cut++;
        }
        //if no cuttoff - nms search failed.
        //other moves will be searched with full depth
        else {
          //cout<<" ,whi q null move cuttoff FAILED: "<<getPATH(0,se_ply)<<endl;
          nmq_whi_fail++;
       };
      }; break;
      case 4: {
        if (cuttoff==true) {
          //cout<<" ,bla q null move cuttoff HAPPENED:"<<getPATH(0,se_ply)<<endl;
          nmq_bla_cut++;
        }
        else {
          //cout<<" ,bla q null move cuttoff FAILED: "<<getPATH(0,se_ply)<<endl;
          nmq_bla_fail++;
       };
      }; break;
      */
      //default: {;};
      //};
      //};
      //#endif
#ifdef LATE_MOVE

      //if research has to be done- do it (be careful of zero index)
      //other lmr settings are cleared by PARENT()
      if (lmr_research == true) {
        lmr_research = false;
        goto RESEARCH; //dont increment cur_offs
      };

#endif

      //for all plies: go to next sibling if any, else - continue going up
      if ((cur_offs[se_nextPly] + 1) < max_offs[se_nextPly]) {
        cur_offs[se_nextPly]++;

#ifdef LATE_MOVE
RESEARCH: {
          ;
        };
#endif
				//IMPORTANT
        se_doPly = false;

        //EXTRA//...printAll("in UP_PROC - going down to next child (sibling)",se_ply);
        if ((se_ply >= qDepth)
#ifdef MAT_POS_PRUNNING
            || ((reduced_tree_top != 0) && (reduced_tree_top <= se_ply))
#endif
#ifdef OFFSET_PRUNNING
            || ((reduced_tree_top != 0) && (reduced_tree_top <= se_ply))
#endif
           ) {
          goto Q_DOWN_PROC;
        } else {
          goto DOWN_PROC;
        };
      };

      #ifdef PARTIAL_PLY
      //if lower ply was qs instead of full (check evasion status important) and we are not beyond qDepth
			//and if no cuttoff occured - rebuild the full ply
			//try to go down
			if (se_ply < qDepth) {
			  if (se_ply_finished[se_nextPly]==false) {
	  	  	if (ab_cut_flag==false) {
	  	      if (GameWtm[GMI + se_ply]) {

	  	      	//debug
	  	      	//if (CheckStatus[se_ply] == true) {cout<<"ERROR12345654321"<<endl;};
	  	      	//debug end

				      //be careful because new ply changes gl_move
				      se_doPly = false;
							cur_offs[se_nextPly] = 0;
							se_ply_finished[se_nextPly] = true;
							#ifdef DEBUG_VERSION
							qsply_to_restply_conversion_count++;
							#endif
							max_offs[se_nextPly] = REST_WHI_PLY(se_nextPly);
							goto DOWN_PROC;

				      /*
				      //debug
							for (se_r = 0; se_r < max_offs[se_nextPly]; se_r++) {
		            if (gl_move==(MOVES_TREE[(se_nextPly << 8) | se_r])) {
								  //cout<<"OK"<<endl;
								  break;
				        };
						  };
						  if (se_r==max_offs[se_nextPly]) {
							  cout<<"not ok - gl_move:"<<printMove(gl_move)<<endl;
							  getTreeLevels(se_nextPly,se_nextPly);
							  printB("debug not ok:");
							  printVals();
							  if (CheckStatus[se_ply] == false) {cout<<"CheckStatus[se_ply]:false"<<endl;}
							  else {cout<<"CheckStatus[se_ply]:true"<<endl;};
							  if (CheckStatus[se_nextPly] == false) {cout<<"CheckStatus[se_nextPly]:false"<<endl;}
							  else {cout<<"CheckStatus[se_nextPly]:true"<<endl;};
							  cout<<"WkiPos: "<<WkiPos<<" ,BkiPos: "<<BkiPos<<endl;
							  cout<<"PATH: "<<getPATH(0,se_nextPly)<<endl;
						  };
						  */
				    }
				    else {

				    	//debug
	  	      	//if (CheckStatus[se_ply] == true) {cout<<"ERROR12345654321B"<<endl;};
	  	      	//debug end

				    	//be careful because new ply changes gl_move
						  se_doPly = false;
							cur_offs[se_nextPly] = 0;
							se_ply_finished[se_nextPly] = true;
							#ifdef DEBUG_VERSION
							qsply_to_restply_conversion_count++;
							#endif
							max_offs[se_nextPly] = REST_BLA_PLY(se_nextPly);
				      goto DOWN_PROC;

							/*
							//debug
							for (se_r = 0; se_r < max_offs[se_nextPly]; se_r++) {
	              if (gl_move==(MOVES_TREE[(se_nextPly << 8) | se_r])) {
						      //cout<<"OK"<<endl;
						      break;
						    };
						  };
						  if (se_r==max_offs[se_nextPly]) {
							  cout<<"not ok - gl_move:"<<printMove(gl_move)<<endl;
							  getTreeLevels(se_nextPly,se_nextPly);
							  printB("debug not ok");
							  printVals();
							  if (CheckStatus[se_ply] == false) {cout<<"CheckStatus[se_ply]:false"<<endl;}
							  else {cout<<"CheckStatus[se_ply]:true"<<endl;};
							  if (CheckStatus[se_nextPly] == false) {cout<<"CheckStatus[se_nextPly]:false"<<endl;}
							  else {cout<<"CheckStatus[se_nextPly]:true"<<endl;};
							  cout<<"WkiPos: "<<WkiPos<<" ,BkiPos: "<<BkiPos<<endl;
							  cout<<"PATH: "<<getPATH(0,se_nextPly)<<endl;
							};
							*/

						};
				  };
			  };
		  };

		  //cur_offs[se_nextPly] = 0;

		  //if ((cur_offs[se_nextPly] + 1) < max_offs[se_nextPly]) {
        //cur_offs[se_nextPly]++;
		    //se_doPly = false;
				//goto DOWN_PROC;
      //};
			#endif

      /* Handle time control and analyze mode */

      //if NORMAL search mode
      if (ANALYZE_MODE == false) {

        //control search time - stop thinking if out of time or mate found
				if (GameWtm[GMI]) {
          if ((myTimer.getElapsedTimeInCentiseconds() - MoveStartTime) >= WhiTimePerMove) {
            THINKING = false;
          } else
            if (GameVal[GMI] == MAX_SCORE) {
              THINKING = false;
            };
        } else {
          if ((myTimer.getElapsedTimeInCentiseconds() - MoveStartTime) >= BlaTimePerMove) {
            THINKING = false;
          } else
            if (GameVal[GMI] == MIN_SCORE) {
              THINKING = false;
            };
        };

        //here thinking may be true or false

        //@why use bioskey instead of just reading input

				//poll for input
        cin.rdbuf()->in_avail();
        int bsk = Bioskey();

        //cout<<"Bioskey():"<<bsk<<endl;
        if (bsk) {
          // We are line oriented, don't read single chars
          string command = "";
          cin.rdbuf()->in_avail();

          if (!getline(cin, command)) {
            command = "quit";
          };

          if (command == "quit") {
          	#ifdef DEBUG_VERSION
            cout << "terminating by quit command received while searching" << endl;
            #endif
            exit(0);
          }
					else if (command == "?") {
						#ifdef DEBUG_VERSION
            cout << "question mark received while searching, THINKING turns off" << endl;
            #endif
            THINKING = false;
          }
					else if (command == "ping") {
						#ifdef DEBUG_VERSION
						cout<<"unhandled ping command received while searching, doing nothing"<<endl;
					  #endif
					}
					else if (command == "hint") {
            #ifdef DEBUG_VERSION
            cout<<"hint command received while searching, returning best move..."<<endl;
            #endif
						cout << "Hint: " << printMove(GamePV[GMI][0]) << endl;
					}
          else {
          	#ifdef DEBUG_VERSION
            cout<<"unhandled command received while searching: "<< command << endl;
            #endif
					};

          //else if (command == "ponderhit")
          //ponderhit();
        };

      }
      /////////////////////////////////////////////////////////////
      //else if analysis mode
      else {
        cin.rdbuf()->in_avail();
        cin >> lin;

        if (lin == "exit") {
          if (EDIT_MODE == true) {
            #ifdef DEBUG_VERSION
            cout<<"exit command received in analysis mode, quitting edit mode"<<endl;
            #endif
						EDIT_MODE = false;
            ANALYZE_MODE = true;
          } else
            if (ANALYZE_MODE == true) {
            	#ifdef DEBUG_VERSION
              cout<<"exit command received in analysis mode, quitting analyse mode"<<endl;
              #endif
              ANALYZE_MODE = false;
            };
        } else
          if (lin == ".") {
            //stat01: time nodes ply mvleft mvtot mvname
            cout << "stat01: "
                 << (__int64)(myTimer.getElapsedTimeInCentiseconds() - MoveStartTime)

                 #ifdef DEBUG_VERSION
								 << " " << (qs_child_count + nonqs_child_count)
								 #endif

								 //!!!!!if not defined
								 #ifndef DEBUG_VERSION
								 << " " << (total_child_count)
								 #endif

								 << " " << qDepth << " " << (max_offs[1] - cur_offs[1])
								 << " " << max_offs[1]
                 << " " << printMove(MOVES_TREE[(1 << 8) | cur_offs[1]]) << endl;
          } else
            if (lin == "usermove") {
              cin.rdbuf()->in_avail();
              cin >> lin;

              if (lin == "accepted") {
                ;
              } else {
                gl_move = GetMove(lin);

								#ifdef DEBUG_VERSION
                cout<<"usermove command received in analysis mode !?"<<endl;
                #endif

								//cout<<"Getmove() found: "<<printMove(gl_move)<<" and move is: "<<lin<<endl;
                //printExtras("in usermove before whites move:");
                se_h = 0;

                while (se_h < 64) {
                  B[se_h] = GameBoard[GMI][se_h];
                  se_h++;
                };

                WpaNum = 0;

                BpaNum = 0;

                WroNum = 0;

                BroNum = 0;

                WbiNum = 0;

                BbiNum = 0;

                WknNum = 0;

                BknNum = 0;

                WquNum = 0;

                BquNum = 0;

                MaterialScore = 0;

                for (se_h = 0; se_h < 64; se_h++) {
                  switch (B[se_h]) {
                    case
                        sWpa: {
                        WpaNum++;
                        MaterialScore += evPawnMaterialValue;
                      };

                      break;
                    case
                        sBpa: {
                        BpaNum++;
                        MaterialScore -= evPawnMaterialValue;
                      };

                      break;
                    case
                        sWro: {
                        WroNum++;
                        MaterialScore += evRookMaterialValue;
                      };

                      break;
                    case
                        sBro: {
                        BroNum++;
                        MaterialScore -= evRookMaterialValue;
                      };

                      break;
                    case
                        sWbi: {
                        WbiNum++;
                        MaterialScore += evBishopMaterialValue;
                      };

                      break;
                    case
                        sBbi: {
                        BbiNum++;
                        MaterialScore -= evBishopMaterialValue;
                      };

                      break;
                    case
                        sWkn: {
                        WknNum++;
                        MaterialScore += evKnightMaterialValue;
                      };

                      break;
                    case
                        sBkn: {
                        BknNum++;
                        MaterialScore -= evKnightMaterialValue;
                      };

                      break;
                    case
                        sWki: {
                        WkiPos = se_h;
                      };

                      break;
                    case
                        sBki: {
                        BkiPos = se_h;
                      };

                      break;
                    case
                        sWqu: {
                        WquNum++;
                        MaterialScore += evQueenMaterialValue;
                      };

                      break;
                    case
                        sBqu: {
                        BquNum++;
                        MaterialScore -= evQueenMaterialValue;
                      };

                      break;
                  };
                };

                //////////////////////////////////////
                //set global king area boards
                for (ev_v = 0; ev_v < 64; ev_v++) {
                  WkiArea[ev_v] = 0;
                  BkiArea[ev_v] = 0;
                };

                WkiArea[WkiPos] = 1;

                BkiArea[BkiPos] = 1;

                for (ev_v = 0; ev_v < 8; ev_v++) {
                  WkiArea[Vec[ev_v][WkiPos][0]] = 1;
                  BkiArea[Vec[ev_v][BkiPos][0]] = 1;
                };

                //////////////////////////////////////
                enpassant = GameEnpassant[GMI];

                castle_dat = Game_castle_data[GMI];

                Zkey = Game_Zkey_tab[GMI];

                retract = GameRetract[GMI];

                CHILD(1);    //uses gl_move

                GMI++;

                GameLen++;

                GameEnpassant[GMI] = enpassant;

                Game_castle_data[GMI] = castle_dat;

                Game_Zkey_tab[GMI] = Zkey;

                GameRetract[GMI] = retract;

                //handle 3-fold draw
                if (retract < 99) {
                  se_h = 0;
                  se_z = GMI - 1;

                  while (se_z > 0) {
                    if (GameRetract[se_z] == 0) {
                      break;
                    };

                    if (Zkey == Game_Zkey_tab[se_z]) {
                      se_h++;

                      if (se_h > 1) {
                        GameVal[GMI] = DRAW_SCORE;
                        cout << "telluser 3-fold repetition draw!" << endl;
                        break;
                      };
                    };

                    se_z--;
                  };
                }
                //handle 50-moves rule
                else {
                  GameVal[GMI] = DRAW_SCORE;
                  cout << "telluser 50-moves rule draw!" << endl;
                };

                GameMoves[GMI] = gl_move; //set game move

                se_h = 0;

                while (se_h < 64) {
                  GameBoard[GMI][se_h] = B[se_h];
                  se_h++;
                }; //set game board

                //printExtras("in usermove after whites move:");
              };
            } else
              if (lin == "hint") {
              	#ifdef DEBUG_VERSION
                cout<<"hint command received in analysis mode, returning best move..."<<endl;
                #endif
                cout << "Hint: " << printMove(GamePV[GMI][0]) << endl;
              } else
                if (lin == "setboard") {
                  cin.rdbuf()->in_avail();
                  cin >> lin;

                  if (lin == "accepted") {
                    ;
                  } else {
                  	#ifdef DEBUG_VERSION
                    cout<<"setboard command received in analysis mode, setting chessboard..."<<endl;
                    #endif
                  	//process FEN string
                    THINKING = false;
                    FORCE_MODE = true;
                    GMI = 0;
                    GameLen = 0;
                    GamePVlen[GMI] = 0;
                    GameVal[GMI] = EMPTY_VAL;

                    for (se_z = 0; se_z < 64; se_z++) {
                      GamePV[GMI][se_z] = 0; //[GMI][board]
                    };

                    //what happens with next GameVal[GMI]??

                    if (setGameMaterial(lin) == false) {
                      cout << "telluser Illegal position (material)." << endl;
                    };

                    cin.rdbuf()->in_avail();

                    cin >> lin;

                    if (setGameSideToMove(lin) == false) {
                      cout << "telluser Illegal position (side to move)." << endl;
                    };

                    cin.rdbuf()->in_avail();

                    cin >> lin;

                    if (setGameCastleStatus(lin) == false) {
                      cout << "telluser Illegal position (castle status)." << endl;
                    };

                    cin.rdbuf()->in_avail();

                    cin >> lin;

                    if (setGameEnpassantStatus(lin) == false) {
                      cout << "telluser Illegal position (enpassant status)." << endl;
                    };

                    clearHash();

                    setGameZkey(64);

                    GameRetract[GMI] = 0;

                    se_z = 0;

                    while (se_z < 64) {
                      B[se_z] = GameBoard[0][se_z];
                      se_z++;
                    };

                    enpassant = GameEnpassant[GMI];

                    castle_dat = Game_castle_data[GMI];

                    Zkey = Game_Zkey_tab[GMI];

                    retract = GameRetract[GMI];

                    if (GameWtm[0] == false) {ENGINE_PLAYS_WHITE = false;}
                    else {ENGINE_PLAYS_WHITE = true;};

                    SD_LIMIT = 255;

 										getTimeSettings();

                  };
                } else
                  if (lin == "undo") {
                      #ifdef DEBUG_VERSION
                      cout<<"unhandled undo command received in analysis mode because always force mode precedes undo command"<<endl;
                      #endif
                  } else
                    if (lin == "new") {

											#ifdef DEBUG_VERSION
                      cout<<"new command received in analysis mode"<<endl;
                      #endif

											GamePVlen[GMI] = 0;
                      GameVal[GMI] = EMPTY_VAL;

                      for (se_z = 0; se_z < 64; se_z++) {
                        GamePV[GMI][se_z] = 0; //[GMI][board]
                      };

                      GMI = 0;

                      GameLen = 0;

                      if ((setGameMaterial("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR"))
                          && (setGameSideToMove("w"))
                          && (setGameCastleStatus("KQkq"))
                          && (setGameEnpassantStatus("-"))) {

												clearHash();
                        setGameZkey(64);
                        GameRetract[GMI] = 0;
                        se_z = 0;

                        while (se_z < 64) {
                          B[se_z] = GameBoard[0][se_z];
                          se_z++;
                        };

                        enpassant = GameEnpassant[GMI];

                        castle_dat = Game_castle_data[GMI];

                        Zkey = Game_Zkey_tab[GMI];

                        retract = GameRetract[GMI];

                        FORCE_MODE = false;

                        ENGINE_PLAYS_WHITE = false;

                        WhiTimeLeft = 0;

                        BlaTimeLeft = 0;

                        THINKING = false;

                        SD_LIMIT = 255;
                      } else {
                      	#ifdef DEBUG_VERSION
                        cout << "error cjytujtfjyt" << endl;
                        #endif
                      };
                    }
                    else {
          	          #ifdef DEBUG_VERSION
                      cout<<"unhandled command received while analysis mode: "<< lin << endl;
                      #endif
					          };
      };
      //end of processing commands received in analysis mode
      ///////////////////////////////////

      //if search not redirected (all nodes have been searched) - return search result
      if (se_ply == 0) {
        //EXTRAprintAll("search ends",se_ply);
        return GamePV[GMI][0];
      };

      ////...printAll("in UP_PROC - going up",se_ply);
      goto UP_PROC;

    }
    //if THINKING is over
    else {
      //go up (if search ends B[] must be in starting move position)
      //dont update PV and values
      if (se_ply > 0) {
        gl_move = MOVES_TREE[(se_ply << 8) | cur_offs[se_ply]];
#ifdef EXTEND_ONLY_MOVE

        //if (gl_move==(gl_move|(1<<30))) {
        //qDepth--;
        //cout<<"whi check move ext in qs: "<<printMove(gl_move)<<endl;
        //printB("");
        //};
        //else if (gl_move==(gl_move|(1<<31))) {
        //qDepth--;
        //cout<<"bla check move ext in qs: "<<printMove(gl_move)<<endl;
        //printB("");
        //}
        //else
        /*
        if (max_offs[se_ply] == 1) {
          if (se_ply_finished[se_ply] == true) {
            qDepth--;
            //cout<<"extension only move retracted:"<<printMove(gl_move)<<endl;
            //printB("");
          };
        };
        */

#endif
        PARENT(se_ply);    //move up position

        se_nextPly = se_ply;//save se_nextPly as lower se_ply

        se_ply--;  //move up se_ply
      };

      //if treeroot visited in up proc
      if (se_ply == 0) {
      	if (GamePV[GMI][0]==0) {
				  cout<<"crashes but should return best static-score move, no search result yet (thinking turned off)"<<endl;
					//GamePV[GMI][0] = MOVES_TREE[((se_ply << 8) | 0)];
        };
        show_last_result = true;
        outputSomeThinking();
        //EXTRAprintAll("search ends",se_ply);
        return GamePV[GMI][0];
      };

			#ifdef DEBUG_VERSION
			/*
			if (ab_cut_flag == false) { //if no cuttoff occured
			  //if (se_ply_finished[se_nextPly] == true) { //if full ply
				if (se_ply < qDepth) {
					visited_nonqs_positions_count += (cur_offs[se_nextPly]+1);
				}
				else {
				  visited_qs_positions_count += (cur_offs[se_nextPly]+1);
				};
			};
			*/
			#endif

      goto UP_PROC;
    };
  };
};

////////////////////////////////////////////////////////////////////////////
unsigned int IncrementalSearch()
{
  cin.rdbuf()->in_avail();
//clean LOG.txt
//ofstream fout("Log.txt"); fout<<"LOG.txt cleared by IncrementalSearch()"<<endl;
  show_increment_change = true;
//clean params of search() from previous Game position or the same position
  int i;
//int h=0;
#ifdef DEBUG_VERSION

#ifdef WEAK_PATH_PRUNNING
  weak_path_cnt = 0;
#endif
#ifdef OFFSET_PRUNNING
  offset_prunning_cnt = 0;
#endif
#endif //debug_version
  unsigned int move = 0;
  gl_move = 0;
  GamePVlen[GMI] = 0;
  GamePV[GMI][0] = 0;
  GameVal[GMI] = EMPTY_VAL;

#ifdef DEBUG_VERSION

  #ifdef LAZY_EVAL
  unlazy_evals_count = 0;
  lazy_evals_count = 0;
  #endif

  #ifdef ATTACKS_MAP
	WhiAttackedMapCount = 0;
  WhiUnattackedMapCount = 0;
  BlaAttackedMapCount = 0;
  BlaUnattackedMapCount = 0;
  #endif

  fullply_positions_count = 0;
  qsply_positions_count = 0;
  restply_positions_count = 0;
	qs_child_count = 0;
  nonqs_child_count = 0;
	visited_nonqs_positions_count = 0;
  visited_qs_positions_count = 0;

  alfa_cut_count = 0;
  beta_cut_count = 0;
  H_eval_overwrites = 0;
  H_transp_overwrites = 0;
  H_eval_cuttoffs = 0;
  H_transp_cuttoffs = 0;
  fullply_branch_count = 0;
  empty_fullply_branch_count = 0;
  mate_fullply_branch_count = 0;
  terminal_fullply_branch_count = 0;
  restply_branch_count = 0;
  empty_restply_branch_count = 0;
  terminal_restply_branch_count = 0;
	qsply_branch_count = 0;
	empty_qsply_branch_count = 0;
	mate_qsply_branch_count = 0;
	qsply_to_restply_conversion_count = 0;
	precalc_score_used_count = 0;
	ev_square_func_count = 0;
#endif  //debug_version

//!!!!! if not defined
#ifndef DEBUG_VERSION
  total_child_count = 0;
#endif

//NC_search = 0;
  INCREMENTS = 0;
//MAX_DEPTH_REACHED = 0;
//PrunnedCount = 0;



#ifdef LOST_POS_CUTTOFFS_TYPE1
  lost_pos_cuttoffs_type1 = 0;
#endif

//set qDepth before incremental search
  if (SD_LIMIT <= 1) {
    qDepth = SD_LIMIT;
  } else {
    qDepth = 1;
  };

//root static eval
  if (GameWtm[GMI]) {
    side = true;
  } else {
    side = false;
  };

#ifdef DEBUG_EVAL
  display_eval_details = true; //works nice-doesnt cause data overflow
#endif

  VALS_TREE[0] = EVAL();

#ifdef DEBUG_EVAL
  display_eval_details = false;
#endif

#ifdef MAT_POS_SCORE
//get material and positional value of root search position
//root material score
  ev_root_mat_score = MaterialScore;
/*
                      + (WpaNum * evPawnMaterialValue)
                      - (BpaNum * evPawnMaterialValue)
                      + (WroNum * evRookMaterialValue)
                      - (BroNum * evRookMaterialValue)
                      + (WbiNum * evBishopMaterialValue)
                      - (BbiNum * evBishopMaterialValue)
                      + (WknNum * evKnightMaterialValue)
                      - (BknNum * evKnightMaterialValue)
                      + (WquNum * evQueenMaterialValue)
                      - (BquNum * evQueenMaterialValue);
*/
//positional score
  ev_root_pos_score =  VALS_TREE[0]
                      - ev_root_mat_score);
#endif
  /*
  cout<<"telluser static score: "<<(signed int)((EVAL()/100)-(MIDDLE_SCORE/100))
  <<" material score: "<<(signed int)((ev_mat_score/100)-(MIDDLE_SCORE/100))
  <<" root position score: "<<(signed int)((EVAL()/100)-(MIDDLE_SCORE/100))-
  (signed int)((ev_mat_score/100)-(MIDDLE_SCORE/100))<<endl;
  */
#ifdef SELECTIVE_SEARCH

  //clear results_tab before IS()
  for (int x = 0; x < 70; x++) {
    for (int y = 0; y < 256; y++) {
      results_tab[y][x] = 0;
    };
  };

#endif

#ifdef DEBUG_VERSION
#ifdef NULL_MOVE
  nms_whi_cut = 0;
  nms_whi_fail = 0;
  nms_bla_cut = 0;
  nms_bla_fail = 0;

#endif
#ifdef LATE_MOVE
  lmr_whi_cnt = 0;
  lmr_bla_cnt = 0;
  lmr_whi_research = 0;
  lmr_bla_research = 0;
#endif
#endif //debug_version
//first_check_depth=0; //clear first_check_depth

//proccess incremental search/////////////////////////////////////////
  while (THINKING == true) {
    //clear some data before each search()/////////////////////////////
    i = 0;

    while (i < 64) {
    	//grade[i] = EMPTY_VAL; //@@@ grade is [256]
      val[i] = EMPTY_VAL;  //clear val[] before each search()
      PVlen[i] = 0; //clear PVlen[] before each search()
      cur_offs[i] = 0; //clear cur_offs[] before each search()
      max_offs[i] = 0; //clear max_offs[] before each search()
      enp_sq[i] = 64; //clear enp_sq[] before each search()
      castle_data[i] = 0; //clear castle_data[] before each search()
      Zkey_tab[i] = 0; //clear Zkey_tab[] before each search()
      retract_tab[i] = 0; //clear retract_tab[] before each search()
      B[i] = GameBoard[GMI][i]; //set B[i] before each search()
      se_ply_finished[i] = false; //set se_ply_finished[i] false before each search
      #ifdef NULL_MOVE
			nms_set[i] = false;
			#endif
      //clear MOVES_TREE before each search() while (j<256) {MOVES_TREE[(i<<8)|j]=0; j++;};
      //clear PV[] before each search() j=0; while (j<64){PV[i][j] = 0; j++;}; j=0;
      i++;
    };

    enp_sq[0] = GameEnpassant[GMI]; //import game data

    castle_data[0] = Game_castle_data[GMI]; //import game data

    Zkey_tab[0] = Game_Zkey_tab[GMI]; //import game data

    retract_tab[0] = GameRetract[GMI]; //import game data

    #ifdef SELECTIVE_SEARCH
    //store search depth
    tmp_qDepth = qDepth;
    #endif

    move = SEARCH(); // move = actual GamePV[GMI][0]

    //break search without returning move if force mode
    if (FORCE_MODE == true) {
    	cout << "force mode. SEARCH returned ZERO normally" << endl;
		  return 0;
		};

    //cout<<"telluser search ends: GamePV[GMI][0]=="<<printMove(move)<<endl;
    if (move == 0) {
      cout << "telluser possible error. SEARCH returned best static score move:" <<
			printMove(MOVES_TREE[(1 << 8) | cur_offs[1]])<< endl;
      return (MOVES_TREE[(1 << 8) | cur_offs[1]]);
      //return 0;
    };

    //log hash stats
    //printSearchStats();

    //break if time passed or depth exceeded (not in analyze mode)
    if (ANALYZE_MODE == false) {
      if ((THINKING == false) || (qDepth >= SD_LIMIT)) {
        break;
      };
    };

    #ifdef SELECTIVE_SEARCH
    //restore qDepth as it was before Search()
		qDepth = tmp_qDepth;
    #endif

    qDepth++;

    INCREMENTS++;

    show_increment_change = true;
  };

#ifdef DEBUG_VERSION

  #ifdef SELECTIVE_SEARCH
  printResultsTab();
  #endif
	//printGameBoard(GMI);

	#ifdef WEAK_PATH_PRUNNING
	  cout << "weak_path_cnt:" << weak_path_cnt << endl;
	#endif
	#ifdef OFFSET_PRUNNING
	  cout << "offset_prunning_cnt" << offset_prunning_cnt << endl;
	#endif

	#ifdef NULL_MOVE
	  cout << "nms_whi_cut:" << nms_whi_cut
	       << ", nms_whi_fail:" << nms_whi_fail
	       << ", nms_bla_cut:" << nms_bla_cut
	       << ", nms_bla_fail:" << nms_bla_fail << endl;
  /*
  cout<<"nmq_whi_cut:"<<nmq_whi_cut
  <<", nmq_whi_fail:"<<nmq_whi_fail
  <<", nmq_bla_cut:"<<nmq_bla_cut
  <<", nmq_bla_fail:"<<nmq_bla_fail<<endl;
  */
  #endif

  #ifdef LATE_MOVE
  cout << "lmr_whi_cnt:" << lmr_whi_cnt
       << ", lmr_bla_cnt:" << lmr_bla_cnt
       << ", lmr_whi_research:" << lmr_whi_research
       << ", lmr_bla_research:" << lmr_bla_research
       << endl;
  #endif

  #ifdef ATTACKS_MAP
	cout << "WhiAttackedMapCount:" << WhiAttackedMapCount
       << ", WhiUnattackedMapCount:" << WhiUnattackedMapCount
       << ", BlaAttackedMapCount:" << BlaAttackedMapCount
       << ", BlaUnattackedMapCount:" << BlaUnattackedMapCount
       << endl;
  #endif

  printSearchStats(); //print position and branch counters and HT data

  cout << "Search advance:" << endl;
  for (int d = 1; d <= qDepth; d++) {
    cout << "cur/max offs[ply:" << d << "]:" << cur_offs[d]
         << "/" << max_offs[d] << endl;
  };

	#ifdef S_E_E
	//side is swapped in debugging here
	cout << "SEE of d4:" << SEE(35, true) << endl;
	//cout<<"gl_move: "<<printMove(gl_move)
      //<<" attacked_sq_index: "<<SQUARE[35]
      //<<endl;
	#endif

#endif //debug_version

	return move;
};


////////////////////////////////////////////////////////////////////////

//must be declared before main() due to existence in different translation unit
void makeWinboardSession();
int main()
{

  if ((is_little_endian()) == false) {
    cout << "telluser Byte order on this machine is big-endian. Not implemented into chess program yet!" << endl;
    return 0;
  };

  //generate table of vectors to speedup chessboard lookup
	#ifdef REUSE_EVAL
	//generateGetVec();
	#endif

  //sortKnightMap(true);

// set up position from FEN input, whites are on the bottom
//"rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
//"rnbqkb1r/1ppppppp/5n2/P7/8/P7/2PPPPPP/RNBQKBNR b KQkq - 0 1";
//"r1bqkbnr/1ppp1ppp/p1n5/4p3/4P3/5Q2/PPPPBPPP/RNB1K1NR w KQkq - 0 1";
#ifdef DEBUG_VERSION
	//ofstream fout("Log.txt");
  //fout << "LOG.TXT CLEARED BY MAIN()" << endl;
  SHOW_TO_PLY = 9;
  Log = false;
#endif
//if (setGameMaterial("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR")) {
//printGameBoards(0);
//CreateManhattanProximityTable();
//CreateKingProximityTable();
//CreateIsKnightJumpTable();
//Wait();

/////////////////////////
  makeWinboardSession();
};

