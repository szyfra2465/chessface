#ifdef DEBUG_VERSION
//void getTreeLevels(int,int);

void log(string s)
{
  ofstream fout("Log.txt", ios::app);
  fout << s << endl;
};

// use Wait() to stop proccessing output
void Wait()
{
  char e;
  cout << "enter any char to continue...";
  cin >> e;
};
#endif //debug_version

// get info about byte order on this machine
bool is_little_endian()
{
  unsigned int ii = 0x01;

  if (* (unsigned char *) &ii == 0x01) {
    return (true);
  } else {
    return (false);
  }
};

// print info about this machine
void print_machine_info()
{
  cout << "Machine info: ";

  if (is_little_endian()) {
    cout << "little endian, ";
  } else {
    cout << "big endian, ";
  }

  cout << (sizeof(int) * 8) << "-bit architecture." << '\n';
};

#ifdef DEBUG_VERSION
//print binary
void printBinary(unsigned  __int64 num, bool log)
{
  const unsigned __int64 mask1 = 1;

  if (log == true) {
    ofstream fout("Log.txt", ios::app);

    for (int j = 0; j < 64; j++) {
      if (num == (num | (mask1 << j))) {
        fout << "1";
      } else {
        fout << "0";
      }
    };

    fout << endl;
  } else {
    for (int j = 0; j < 64; j++) {
      if (num == (num | (mask1 << j))) {
        cout << "1";
      } else {
        cout << "0";
      }
    };

    cout << endl;
  };
};
#endif //debug version

#ifdef DEBUG_VERSION
string printPiece(short piece_numeric_symbol)
{
  string piece;

  switch (piece_numeric_symbol) {
    case
        sEmp: {
        piece = "Empty square";
      };

      break;
    case
        sWpa: {
        piece = "White pawn";
      };

      break;
    case
        sBpa: {
        piece = "Black pawn";
      };

      break;
    case
        sWro: {
        piece = "White rook";
      };

      break;
    case
        sBro: {
        piece = "Black rook";
      };

      break;
    case
        sWbi: {
        piece = "White bishop";
      };

      break;
    case
        sBbi: {
        piece = "Black bishop";
      };

      break;
    case
        sWkn: {
        piece = "White knight";
      };

      break;
    case
        sBkn: {
        piece = "Black knight";
      };

      break;
    case
        sWki: {
        piece = "White king";
      };

      break;
    case
        sBki: {
        piece = "Black king";
      };

      break;
    case
        sWqu: {
        piece = "White queen";
      };

      break;
    case
        sBqu: {
        piece = "Black queen";
      };

      break;
    default
        : {
        piece = "INVALID PIECE";
      };
  };

  return piece;
};
#endif //debug version

#ifdef DEBUG_VERSION
// function printing the chessboard from board table B[]
void printB(string note)
{
  string D = "";

//encode shorts data into characters
  for (int j = 0; j < 64; j++) {
    switch (B[j]) {
      case
          1: {
          D += "P";
        };

        break;
      case
          2: {
          D += "p";
        };

        break;
      case
          3: {
          D += "R";
        };

        break;
      case
          4: {
          D += "r";
        };

        break;
      case
          5: {
          D += "B";
        };

        break;
      case
          6: {
          D += "b";
        };

        break;
      case
          7: {
          D += "N";
        };

        break;
      case
          8: {
          D += "n";
        };

        break;
      case
          9: {
          D += "K";
        };

        break;
      case
          10: {
          D += "k";
        };

        break;
      case
          11: {
          D += "Q";
        };

        break;
      case
          12: {
          D += "q";
        };

        break;
      case
          13: {
          D += " ";
        };

        break;
      default
          :
        D += "X";
    };
  };

  if (Log == false) {
    //print headline
    //cout << "------------POSITION DATA:----------------" << endl;
    //print the board chars
    cout << note << endl <<
         "* +---+---+---+---+---+---+---+---+" << endl <<
         "8 | " << D[0] << " | " << D[1] << " | " << D[2] << " | " <<
         D[3] << " | " << D[4] << " | " << D[5] << " | " << D[6] <<
         " | " << D[7] << " |" << endl;
    cout << "* +---+---+---+---+---+---+---+---+" << endl <<
         "7 | " << D[8] << " | " << D[9] << " | " << D[10] << " | " <<
         D[11] << " | " << D[12] << " | " << D[13] << " | " << D[14] <<
         " | " << D[15] << " |" << endl;
    cout << "* +---+---+---+---+---+---+---+---+" << endl <<
         "6 | " << D[16] << " | " << D[17] << " | " << D[18] << " | " <<
         D[19] << " | " << D[20] << " | " << D[21] << " | " << D[22] <<
         " | " << D[23] << " |" << endl;
    cout << "* +---+---+---+---+---+---+---+---+" << endl <<
         "5 | " << D[24] << " | " << D[25] << " | " << D[26] << " | " <<
         D[27] << " | " << D[28] << " | " << D[29] << " | " << D[30] <<
         " | " << D[31] << " |" << endl;
    cout << "* +---+---+---+---+---+---+---+---+" << endl <<
         "4 | " << D[32] << " | " << D[33] << " | " << D[34] << " | " <<
         D[35] << " | " << D[36] << " | " << D[37] << " | " << D[38] <<
         " | " << D[39] << " |" << endl;
    cout << "* +---+---+---+---+---+---+---+---+" << endl <<
         "3 | " << D[40] << " | " << D[41] << " | " << D[42] << " | " <<
         D[43] << " | " << D[44] << " | " << D[45] << " | " << D[46] <<
         " | " << D[47] << " |" << endl;
    cout << "* +---+---+---+---+---+---+---+---+" << endl <<
         "2 | " << D[48] << " | " << D[49] << " | " << D[50] << " | " <<
         D[51] << " | " << D[52] << " | " << D[53] << " | " << D[54] <<
         " | " << D[55] << " |" << endl;
    cout << "* +---+---+---+---+---+---+---+---+" << endl <<
         "1 | " << D[56] << " | " << D[57] << " | " << D[58] << " | " <<
         D[59] << " | " << D[60] << " | " << D[61] << " | " << D[62] <<
         " | " << D[63] << " |" << endl;
    cout << "* +---+---+---+---+---+---+---+---+" << endl <<
         "*   a   b   c   d   e   f   g   h"  << endl;
    //print footline
    //cout << "------------POSITION DATA END----------------" << endl;
    // analogically append stream of data to Log file if L==true
  } else {
    ofstream fout("Log.txt", ios::app);
    fout << note << endl;
    //print headline to file
    //fout << "------------POSITION DATA:----------------" << endl;
    fout << endl << "    +---+---+---+---+---+---+---+---+" << endl <<
         "8 | " << D[0] << " | " << D[1] << " | " << D[2] << " | " <<
         D[3] << " | " << D[4] << " | " << D[5] << " | " << D[6] <<
         " | " << D[7] << " |" << endl;
    fout << "    +---+---+---+---+---+---+---+---+" << endl <<
         "7 | " << D[8] << " | " << D[9] << " | " << D[10] << " | " <<
         D[11] << " | " << D[12] << " | " << D[13] << " | " << D[14] <<
         " | " << D[15] << " |" << endl;
    fout << "    +---+---+---+---+---+---+---+---+" << endl <<
         "6 | " << D[16] << " | " << D[17] << " | " << D[18] << " | " <<
         D[19] << " | " << D[20] << " | " << D[21] << " | " << D[22] <<
         " | " << D[23] << " |" << endl;
    fout << "    +---+---+---+---+---+---+---+---+" << endl <<
         "5 | " << D[24] << " | " << D[25] << " | " << D[26] << " | " <<
         D[27] << " | " << D[28] << " | " << D[29] << " | " << D[30] <<
         " | " << D[31] << " |" << endl;
    fout << "    +---+---+---+---+---+---+---+---+" << endl <<
         "4 | " << D[32] << " | " << D[33] << " | " << D[34] << " | " <<
         D[35] << " | " << D[36] << " | " << D[37] << " | " << D[38] <<
         " | " << D[39] << " |" << endl;
    fout << "    +---+---+---+---+---+---+---+---+" << endl <<
         "3 | " << D[40] << " | " << D[41] << " | " << D[42] << " | " <<
         D[43] << " | " << D[44] << " | " << D[45] << " | " << D[46] <<
         " | " << D[47] << " |" << endl;
    fout << "    +---+---+---+---+---+---+---+---+" << endl <<
         "2 | " << D[48] << " | " << D[49] << " | " << D[50] << " | " <<
         D[51] << " | " << D[52] << " | " << D[53] << " | " << D[54] <<
         " | " << D[55] << " |" << endl;
    fout << "    +---+---+---+---+---+---+---+---+" << endl <<
         "1 | " << D[56] << " | " << D[57] << " | " << D[58] << " | " <<
         D[59] << " | " << D[60] << " | " << D[61] << " | " << D[62] <<
         " | " << D[63] << " |" << endl;
    fout << "    +---+---+---+---+---+---+---+---+" << endl <<
         "    a   b   c   d   e   f   g   h"  << endl << endl;
    //print footline
    //fout << "------------POSITION DATA END----------------" << endl;
  };
};
#endif //debug version

#ifdef DEBUG_VERSION
// function printing the chessboard from board table B[]
void printGameBoard(unsigned short idx)
{
  string D = "";

//encode shorts data into characters
  for (int j = 0; j < 64; j++) {
    switch (GameBoard[idx][j]) {
      case
          1: {
          D += "P";
        };

        break;
      case
          2: {
          D += "p";
        };

        break;
      case
          3: {
          D += "R";
        };

        break;
      case
          4: {
          D += "r";
        };

        break;
      case
          5: {
          D += "B";
        };

        break;
      case
          6: {
          D += "b";
        };

        break;
      case
          7: {
          D += "N";
        };

        break;
      case
          8: {
          D += "n";
        };

        break;
      case
          9: {
          D += "K";
        };

        break;
      case
          10: {
          D += "k";
        };

        break;
      case
          11: {
          D += "Q";
        };

        break;
      case
          12: {
          D += "q";
        };

        break;
      case
          13: {
          D += " ";
        };

        break;
      default
          :
        D += "X";
    };
  };

  if (Log == false) {
    //print headline
    //cout << "------------POSITION DATA:----------------" << endl;
    //print the board chars
    cout << "GameBoard[" << idx << "]:" << endl <<
         "* +---+---+---+---+---+---+---+---+" << endl <<
         "8 | " << D[0] << " | " << D[1] << " | " << D[2] << " | " <<
         D[3] << " | " << D[4] << " | " << D[5] << " | " << D[6] <<
         " | " << D[7] << " |" << endl;
    cout << "* +---+---+---+---+---+---+---+---+" << endl <<
         "7 | " << D[8] << " | " << D[9] << " | " << D[10] << " | " <<
         D[11] << " | " << D[12] << " | " << D[13] << " | " << D[14] <<
         " | " << D[15] << " |" << endl;
    cout << "* +---+---+---+---+---+---+---+---+" << endl <<
         "6 | " << D[16] << " | " << D[17] << " | " << D[18] << " | " <<
         D[19] << " | " << D[20] << " | " << D[21] << " | " << D[22] <<
         " | " << D[23] << " |" << endl;
    cout << "* +---+---+---+---+---+---+---+---+" << endl <<
         "5 | " << D[24] << " | " << D[25] << " | " << D[26] << " | " <<
         D[27] << " | " << D[28] << " | " << D[29] << " | " << D[30] <<
         " | " << D[31] << " |" << endl;
    cout << "* +---+---+---+---+---+---+---+---+" << endl <<
         "4 | " << D[32] << " | " << D[33] << " | " << D[34] << " | " <<
         D[35] << " | " << D[36] << " | " << D[37] << " | " << D[38] <<
         " | " << D[39] << " |" << endl;
    cout << "* +---+---+---+---+---+---+---+---+" << endl <<
         "3 | " << D[40] << " | " << D[41] << " | " << D[42] << " | " <<
         D[43] << " | " << D[44] << " | " << D[45] << " | " << D[46] <<
         " | " << D[47] << " |" << endl;
    cout << "* +---+---+---+---+---+---+---+---+" << endl <<
         "2 | " << D[48] << " | " << D[49] << " | " << D[50] << " | " <<
         D[51] << " | " << D[52] << " | " << D[53] << " | " << D[54] <<
         " | " << D[55] << " |" << endl;
    cout << "* +---+---+---+---+---+---+---+---+" << endl <<
         "1 | " << D[56] << " | " << D[57] << " | " << D[58] << " | " <<
         D[59] << " | " << D[60] << " | " << D[61] << " | " << D[62] <<
         " | " << D[63] << " |" << endl;
    cout << "* +---+---+---+---+---+---+---+---+" << endl <<
         "*   a   b   c   d   e   f   g   h"  << endl;
    //print footline
    //cout << "------------POSITION DATA END----------------" << endl;
    // analogically append stream of data to Log file if L==true
  } else {
    ofstream fout("Log.txt", ios::app);
    fout << "GameBoard[" << idx << "]:" << endl <<
         //print headline to file
         //fout << "------------POSITION DATA:----------------" << endl;
         fout << endl << "    +---+---+---+---+---+---+---+---+" << endl <<
         "8 | " << D[0] << " | " << D[1] << " | " << D[2] << " | " <<
         D[3] << " | " << D[4] << " | " << D[5] << " | " << D[6] <<
         " | " << D[7] << " |" << endl;
    fout << "    +---+---+---+---+---+---+---+---+" << endl <<
         "7 | " << D[8] << " | " << D[9] << " | " << D[10] << " | " <<
         D[11] << " | " << D[12] << " | " << D[13] << " | " << D[14] <<
         " | " << D[15] << " |" << endl;
    fout << "    +---+---+---+---+---+---+---+---+" << endl <<
         "6 | " << D[16] << " | " << D[17] << " | " << D[18] << " | " <<
         D[19] << " | " << D[20] << " | " << D[21] << " | " << D[22] <<
         " | " << D[23] << " |" << endl;
    fout << "    +---+---+---+---+---+---+---+---+" << endl <<
         "5 | " << D[24] << " | " << D[25] << " | " << D[26] << " | " <<
         D[27] << " | " << D[28] << " | " << D[29] << " | " << D[30] <<
         " | " << D[31] << " |" << endl;
    fout << "    +---+---+---+---+---+---+---+---+" << endl <<
         "4 | " << D[32] << " | " << D[33] << " | " << D[34] << " | " <<
         D[35] << " | " << D[36] << " | " << D[37] << " | " << D[38] <<
         " | " << D[39] << " |" << endl;
    fout << "    +---+---+---+---+---+---+---+---+" << endl <<
         "3 | " << D[40] << " | " << D[41] << " | " << D[42] << " | " <<
         D[43] << " | " << D[44] << " | " << D[45] << " | " << D[46] <<
         " | " << D[47] << " |" << endl;
    fout << "    +---+---+---+---+---+---+---+---+" << endl <<
         "2 | " << D[48] << " | " << D[49] << " | " << D[50] << " | " <<
         D[51] << " | " << D[52] << " | " << D[53] << " | " << D[54] <<
         " | " << D[55] << " |" << endl;
    fout << "    +---+---+---+---+---+---+---+---+" << endl <<
         "1 | " << D[56] << " | " << D[57] << " | " << D[58] << " | " <<
         D[59] << " | " << D[60] << " | " << D[61] << " | " << D[62] <<
         " | " << D[63] << " |" << endl;
    fout << "    +---+---+---+---+---+---+---+---+" << endl <<
         "    a   b   c   d   e   f   g   h"  << endl << endl;
    //print footline
    //fout << "------------POSITION DATA END----------------" << endl;
  };
};
#endif //debug_version

// function prints current move
string printMove(unsigned int mymove)
{
  switch (mymove) {
    case
        0: {
        return "ZErO MOVE";
      };

    case
        1: {
        return "WHI NULL MOVE";
      };

    case
        2: {
        return "bLA NULL MOVE";
      };

    case
        3: {
        return "WHI Q NULL MOVE";
      };

    case
        4: {
        return "BLA Q NULL MOVE";
      };

    default
        : {
        ;
      };
  };

  int fs = ((mymove << 26) >> 26);

  int ts = ((mymove << 20) >> 26);

  int fp = ((mymove << 16) >> 28);

  int tp = ((mymove << 12) >> 28);

  int cp = ((mymove << 8) >> 28);

  string info = "";


  #ifdef DEBUG_VERSION
  //handle capture symbol
  if (cp != 0) {
    info += "_x";
  };

	//handle late move symbol
  if (mymove == (mymove | (1 << 29))) {
    info += "_?";
  };

  //handle check masks
  if (mymove == (mymove | (1 << 30))) {info += "_w+";};
	if (mymove == (mymove | (1 << 31))) {info += "_b+";};


  //handle unquiesent position symbol
  //if (mymove == (mymove | forced_pos_mask)) {
    //info += "*";
  //};

	//handle threat mask
  if (mymove == (mymove | (1 << 25))) {
    info += "_wt";
  };

  //handle threat mask
  if (mymove == (mymove | (1 << 24))) {
    info += "_bt";
  };

  if ((fs < 0) || (fs > 63) || (ts < 0) || (ts > 63)) {
    return "_bAD_SQUArE";
  };

  if ((fp < 0) || (fp > 12) || (tp < 0) || (tp > 12)
      || (cp < 0) || (cp > 12)) {
    return "_bAD_pIECE";
  };

  //cout<<"fs:"<<fs<<", ts:"<<ts<<", fp:"<<fp<<", tp:"<<tp<<", cp:"<<cp;

  #endif //debug_version


  //if no promotion move
  if (fp == tp) {
    if (cp == 0) {
      return COL[fs] + ROW[fs] + COL[ts] + ROW[ts] + info;
    } else {
      return COL[fs] + ROW[fs] + COL[ts] + ROW[ts] + info;
    };
  }
  //else
	else {
    //if noncapture
    if (cp == 0) {
      //enpassant
      if (((fp == 1) && (tp == 2)) || ((fp == 2) && (tp == 1))) {
        return COL[fs] + ROW[fs] + COL[ts] + ROW[ts] + info;
      }
      //promotion
      else {
        return COL[fs] + ROW[fs] + COL[ts] + ROW[ts] + Symbol[tp] + info;
      };
    }
    //promotion with capture
    else {
      return COL[fs] + ROW[fs] + COL[ts] + ROW[ts] + Symbol[tp] + info;
    };
  };
};


#ifdef DEBUG_VERSION
// function returns PATH
void printPATH(unsigned char start_ply, unsigned char stop_ply)
{
  int s = start_ply;

  if (Log == true) {
    PATH.erase();

    while (start_ply < stop_ply) {
      start_ply++;
      PATH += (Show[start_ply] + printMove(MOVES_TREE[(start_ply << 8) | cur_offs[start_ply]]));
    };

    ofstream fout("Log.txt", ios::app);

    fout << "MOVES_TREE path from ply " << s << " to ply " << stop_ply << " is:" << PATH << endl;
  };
};
#endif

string getPATH(int start_ply, int stop_ply)
{
  PATH.erase();

  while (start_ply < stop_ply) {
    start_ply++;
    PATH += (Show[start_ply] + printMove(MOVES_TREE[(start_ply << 8) | cur_offs[start_ply]]));
  };
  //note: last move may be not legal, it may be done before legality check;

  return PATH;
};

//function returns PV
void printPV()
{
  ofstream fout("Log.txt", ios::app);
  fout << "PV:" << flush;

  for (unsigned char j = 0; j < PVlen[0]; j++) {
    ofstream fout("Log.txt", ios::app);
    fout << Show[j + 1] << printMove(PV[0][j]) << flush;
  };

  fout << endl;
};


// return game principal variation before the move
string printGamePV()
{
  string s = "GamePV:";

  for (unsigned int j = 0; j < GamePVlen[GMI]; j++) {
    s.append(Show[j + 1] + printMove(GamePV[GMI][j]));
  };

  return s;
};

#ifdef DEBUG_VERSION
//function loggs ERROR message
void printError()
{
  ofstream fout("Log.txt", ios::app);
  fout << endl << "!!!!!ERROR!!!!!" << endl;
};
#endif //debug_version

#ifdef DEBUG_VERSION
#ifdef SELECTIVE_SEARCH
void printResultsTab()
{
  //cout<<"ResultsTab.txt file generated!!!!!!!!!!!!!!!!!"<<endl;
  //ofstream fout("ResultsTab.txt", ios::app);
  cout << "Game move:" << printMove(GamePV[GMI][0]) << endl;

  for (int i = 0; i < max_offs[1]; i++) {
    cout << "ROOT move nr"<<i<<":" << printMove(results_tab[i][0])
         << " search depth:" << results_tab[i][1]
				 << " search score (depth): " << flush;

    for (int j = 3; j < (results_tab[i][1] + 2); j++) {
      //if (GameWtm[GMI] == true) {
      if (results_tab[i][j] == MAX_SCORE) {
        cout << "white_mates_score (" << (j - 1) <<") "<< flush;
      }
			else {
        if (results_tab[i][j] == MIN_SCORE) {
          cout << "black_mates_score (" << (j - 1) <<") "<< flush;
        }
				else {
        	if (results_tab[i][j] == EMPTY_VAL) {
        	  cout<< "EMPTY_VAL (" << (j - 1) <<") "<< flush;
					}
					else {
            cout << (results_tab[i][j] / 100) << " (" << (j - 1) <<") "<< flush;
          };
        };
      };
    };
    cout << endl;
  };
};
#endif
#endif //debug_version

#ifdef DEBUG_VERSION
void printSearchStats()
{
  //ofstream fout("Log.txt", ios::app);
  cout
//cout<<"telluser "
      << " qDepth:" << qDepth
//<<" ply:"<<ply
#ifdef LAZY_EVAL
      << " unlazy_evals_count:" << unlazy_evals_count
      << " lazy_evals_count:" << lazy_evals_count
#endif
      << " fullply_positions_count:" << fullply_positions_count
      << " qsply_positions_count:" << qsply_positions_count
      << " restply_positions_count:" << restply_positions_count
      << " nonqs_child_count:" << nonqs_child_count
      << " qs_child_count:" << qs_child_count
      << " visited_qs_positions_count:" << visited_qs_positions_count
      << " visited_nonqs_positions_count:" << visited_nonqs_positions_count
      << " total alfabeta cuttoffs count:" << alfa_cut_count + beta_cut_count
      << " alfa:" << alfa_cut_count << " beta:" << beta_cut_count
      << " fullply_branch_count:" << fullply_branch_count
      << " empty_fullply_branch_count:" << empty_fullply_branch_count
      << " mate_fullply_branch_count:" << mate_fullply_branch_count
      << " terminal_fullply_branch_count:" << terminal_fullply_branch_count
      << " qsply_branch_count:" << qsply_branch_count
      << " mate_qsply_branch_count:" << mate_qsply_branch_count
      << " empty_qsply_branch_count:" << empty_qsply_branch_count
      << " restply_branch_count:" << restply_branch_count
      << " empty_restply_branch_count:" << empty_restply_branch_count
			<< " terminal_restply_branch_count:" << terminal_restply_branch_count
			<< " qsply_to_restply_conversion_count:" << qsply_to_restply_conversion_count
			<< " precalc_score_used_count:"<< precalc_score_used_count
			<< " ev_square_func_count:" << ev_square_func_count
			<< " ev_to_reused factor:" <<(((float)precalc_score_used_count) /
			(float) (ev_square_func_count))
      << " average qsply branch size:" << ((float) qsply_positions_count /
      (float) (qsply_branch_count - empty_qsply_branch_count))
      << " average restply branch size:" << ((float) restply_positions_count /
      (float) (restply_branch_count - empty_restply_branch_count))
      << " average fullply branch size:" << ((float) fullply_positions_count /
      (float) (fullply_branch_count - empty_fullply_branch_count))
      << " average visited branch size:" << (
			(float) (visited_qs_positions_count + visited_nonqs_positions_count) /
      (float) (qsply_branch_count - empty_qsply_branch_count
      + fullply_branch_count - empty_fullply_branch_count
      + restply_branch_count - empty_restply_branch_count))
      << "*** HASH_STATS:"
      // stored Zkey from HT["<<Hkey<<"][0]:"<<HT[Hkey][0]
      //printBinary(Hkey,true);
      //printBinary(HT[Hkey][0],true);//stored Z key
      //<<" curent Zkey:"<<Zkey
      //printBinary(Zkey,true);
			//<<" Hdepth:"<<Hdepth
      //<<" Hval:"<<Hval
      << " Hsize:" << Hsize
      << " Hkeylen:" << Hkeylen
      << " Zkeylen:" << Zkeylen
      //<<" Htrylimit:"<<Htrylimit
      //<<" Hkey:"<<Hkey
      << " H_eval_overwrites:" << H_eval_overwrites
      //<< " H_transp_overwrites:" << H_transp_overwrites
      << " H_eval_cuttoffs:" << H_eval_cuttoffs
      //<< " H_transp_cuttoffs:" << H_transp_cuttoffs
      << " HT size:" << (Hsize * 16 / 1024) << " kilobytes"   //size*bytelen/kilo
      //<<" HT effectiveness:"<<
      //(((float)(((H_eval_overwrites+H_transp_overwrites)/
      //(H_eval_cuttoffs+H_transp_cuttoffs))*100)))<<"%"

#ifdef LOST_POS_CUTTOFFS_TYPE1
      << " lost_pos_cuttoffs_type1:" << lost_pos_cuttoffs_type1
#endif
      << " ***" << endl;
};
#endif

#ifdef DEBUG_VERSION
//function loggs VALS
void printVals()
{
  //ofstream fout("Log.txt", ios::app);
  cout << "Vals[ply]: " << flush;
  int i = 0;

  while (i <= SHOW_TO_PLY) {
    cout << "[" << i << "]=" << val[i] << ",";
    i++;
  };

  cout << endl;

//fout<<"alfa:"<<alfa<<" beta:"<<beta<<endl;
};
#endif //debug_eval

#ifdef DEBUG_VERSION
//print evals from the tree root to curent tree leave
void printEvals(unsigned char ply)
{
  ofstream fout("Log.txt", ios::app);
//fout<<"Correct MOVE eval[ply]==score (at offset x):"<<endl;
  int i = 0;
  string s;

  while (i <= SHOW_TO_PLY) {
    unsigned int m = MOVES_TREE[(i << 8) | cur_offs[i]];

    if (m != 0) {
      if (ply == i) {
        if (i <= qDepth) {
          fout << "PLY_N:" << flush;
        } else {
          fout << "PLY_Q:" << flush;
        };
      } else {
        if (i <= qDepth) {
          fout << "ply_n:" << flush;
        } else {
          fout << "ply_q:" << flush;
        };
      };

      fout << i << flush;

      if (GameWtm[GMI + i] == false) {
        fout << " MAX: " << flush;
      } else {
        fout << " MIN: " << flush;
      };

      fout << printMove(m) << " EVAL:"
           << ((VALS_TREE[(i << 8) | cur_offs[i]]) / 100)
           << " move:" << cur_offs[i] + 1 << "/" << (max_offs[i])
           << " val:" << val[ply] << "(" << (val[ply] / 100) << ")" << " PV:" << flush;

      for (int j = 0; j < PVlen[i]; j++) {
        if (PV[i][j] == 0) {
          s = "zero";
        } else {
          s = printMove(PV[i][j]);
        };

        fout << Show[j + 1] << s << flush;
      };

      fout << endl;

      if (i == 1) {
        fout << "moves fully searched:" << flush;

        for (int j = 0; j < cur_offs[i]; j++) {
          fout << printMove(MOVES_TREE[(i << 8) | j]) << " " << flush;
        };

        fout << endl;
      };
    };

    i++;
  };
};
#endif //debug_version

#ifdef DEBUG_VERSION
void printWtm()
{
  ofstream fout("Log.txt", ios::app);
  fout << "Wtm[ply]: " << flush;
  int i = 0;

  while (i <= SHOW_TO_PLY) {
    fout << "[" << i << "]=" << GameWtm[GMI + i] << ",";
    i++;
  };

  fout << endl;
};
#endif //debug_version

#ifdef DEBUG_VERSION
void printGameEnpassant()
{
  ofstream fout("Log.txt", ios::app);
  fout << "Game enpassant status: " << flush;

  if (GameEnpassant[GMI] == 0) {
    fout << "-" << endl;
  } else {
    fout << COL[GameEnpassant[GMI]] << ROW[GameEnpassant[GMI]] << endl;
  };
};
#endif //debug_version

#ifdef DEBUG_VERSION
void printExtras(string note)
{
  ;
  cout << note << endl;
  cout << "GameMove:" << printMove(GameMoves[GMI]) << endl;
//cout<<"gl_move:"<<printMove(gl_move)<<endl;
  printGameBoard(GMI);
//printB("B[]:");
  /*
  cout<<"Game Data: enp:"<<enpassant
  <<" castle_dat:"<<flush; printBinary(castle_dat,false);

  if (castle_dat == (castle_dat | castle_lost_WKK_mask)) {
    cout<<"castle_lost_WKK==true"<<endl;
  }
  else {
    cout<<"castle_lost_WKK==false"<<endl;
  };
  if (castle_dat == (castle_dat | castle_lost_WKQ_mask)) {
    cout<<"castle_lost_WKQ==true"<<endl;
  }
  else {
    cout<<"castle_lost_WKQ==false"<<endl;
  };
  if (castle_dat == (castle_dat | castle_lost_BKK_mask)) {
    cout<<"castle_lost_BKK==true"<<endl;
  }
  else {
    cout<<"castle_lost_BKK==false"<<endl;
  };
  if (castle_dat == (castle_dat | castle_lost_BKQ_mask)) {
    cout<<"castle_lost_BKQ==true"<<endl;
  }
  else {
    cout<<"castle_lost_BKQ==false"<<endl;
  };
  if (castle_dat == (castle_dat | castle_done_WKK_mask)) {
    cout<<"castle_done_WKK==true"<<endl;
  }
  else {
    cout<<"castle_done_WKK==false"<<endl;
  };
  if (castle_dat == (castle_dat | castle_done_WKQ_mask)) {
    cout<<"castle_done_WKQ==true"<<endl;
  }
  else {
    cout<<"castle_done_WKQ==false"<<endl;
  };
  if (castle_dat == (castle_dat | castle_done_BKK_mask)) {
    cout<<"castle_done_BKK==true"<<endl;
  }
  else {
    cout<<"castle_done_BKK==false"<<endl;
  };
  if (castle_dat == (castle_dat | castle_done_BKQ_mask)) {
    cout<<"castle_done_BKQ==true"<<endl;
  }
  else {
    cout<<"castle_done_BKQ==false"<<endl;
  };
  */
//cout<<"Zkey:"<<Zkey<<endl;
  cout << "retract:" << retract << endl;
};
#endif //debug_version

