//half of 20bit score == 19 bit number
const signed int MIN_SCORE =
//-524288;
//-262144;
-262140; //little more than the smallest 19 bit signed number
const signed int MAX_SCORE =
//524288;
//262144;
262140; //little less than the gratest 19 bit signed number

const signed int EMPTY_VAL = (MAX_SCORE + 2);
const signed int DRAW_SCORE = 0;

