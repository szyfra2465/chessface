int Bioskey();
void setGameStartTime();
//always save if known
void saveInitialTimeSettings();
//use when new or setboard command
void getTimeSettings();   //in "go" after "new" command
//reset move start timer before making each move
void setMoveStartTime();
//assign proper time to the move.
//function should be used before incremental search
void setWhiTimePerMove();
//assign proper time to the move.
//function should be used before incremental search
void setBlaTimePerMove();
void setClockBase(double base);
void setClockExact(bool st);
//update global time variables, measure time used
//function should be just used after the game move
void updateTimeVariables();
