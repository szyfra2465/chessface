//global first check in the ply
//static unsigned int first_check_depth;


bool isAttByWhi(unsigned char sq);
bool isAttByBla(unsigned char sq);
//function returns true if:
//double check on sq
//or checking piece is supported by self piece
//or checking piece is not attacked
bool isWhiCheckGood(unsigned char sq);
//function returns true if:
//double check on sq
//or checking piece is supported by self piece
//or checking piece is not attacked
bool isBlaCheckGood(unsigned char sq);

//if mate - return true
//first anayze king area if every square:
//- occupied by self piece or
//- is out of board or
//- is attacked by opponent
//than if double check or
//if supported check or
//opponent attacker is not covered by self piece
//opponent attacker is covered by self piece but self piece
//is pinned to the king on other vector
//all squares between opponent attacker and self king are not covered by self piece
//squares between opponent attacker and self king are covered by self piece but self piece
//is pinned to the king
//assumes king is being checked
bool isBkiMated();
//assumes king is being checked
bool isWkiMated();
//returns square index of least valuable piece square sq
unsigned char LeastValuableBlaAttFrom(unsigned char sq);
//returns square index of least valuable piece square sq
unsigned char LeastValuableWhiAttFrom(unsigned char sq);
signed int SEE(int attacked_sq_index, bool myside);
//Function EVAL() returns eval score and sets extension masks which is later
//saved into last 8 bits of gl_move
//put on move i.e. gl_move |= ((range:1-255)<<24)
//extensions are used in position with many complicated threats (checks, forks, pins)
//at limited search depth in search.
//Takes global ev_fs as argument


/*
free ideas:
we have pinned squares
resolve pins by extending moves that increase/decrease pin pressure for proper side
//find out if a piece which has just moved attacks pinned square
//or the piece which has just moved reveals other piece attacking pinned square
//or the piece which has just moved stays between pinner and pin
//or pins the piece which is pinning the square (find out if attacker after the move stays on pinned square)
//make single reply extension (extend always if there is only one legal response)
//extend PV node one ply
//ev_pin_extension = 0;
//pin extensions are evaluated in EVAL
//set eval_Pinned[] elements == 64
//for (ev_fs=0; ev_fs<10; ev_fs++) {eval_Pinned[ev_fs] = 64;};
//loop through the board and find pinned pieces,
//loop again and set attacks_to map (pinned pieces have none or weeker impact on attack map)
//calculate square
*/


//signed int SEE(int attacked_sq_index, bool myside);



/*sets is_quiescent*/

//must return values used properly for sorting moves
//mates, checks, captures, etc

////////////////////////////////////////
//while normal evaluation we can mark which pieces are pinned, which pieces are hanging


// uses global ev_fs as argument
// changes global ev_score /use carefully/ , memorize ev_score before the function to further restore
/*
// sets __uint64 "attacked" board to determine occupied squares attacked by opponent
// this data is cleared before board eval loop.
// after looping through square evals we get fresh "attacked" data
// than we examine attacked squares with see function.
// if the position is lost for attacked by see and
// if the attacked piece is on move we give see_lost_but_but_better_side small bonus
// such position is NOT EXAMINED BY QS but it should be examined deeper
// if the attacked piece is not on move we give see_lost_and_wrong_side big bonus to evaluation
// alternativly we let qs work to inflate the score.

// GENERALLY SPEAKING
//WE CAN SAFELY REDUCE SEARCH DEPTH:
IF BOTH:
- MOVES WHICH DONT CHANGE "ATTACKED" STATUS
- MOVES WHICH DONT AFFECT KING SAFETY
...

WE SAVE INFORMATION ABOUT KING SAFETY IN WHI_KING_SAFETY_SCORE[DEPTH] TABLE
WE SAVE INFORMATION ABOUT KING SAFETY IN BLA_KING_SAFETY_SCORE[DEPTH] TABLE
WE SAVE INFORMATION ABOUT CENTER CONTROL IN WHI_CENTER_CONTROL_SCORE[DEPTH] TABLE
WE SAVE INFORMATION ABOUT CENTER CONTROL IN BLA_CENTER_CONTROL_SCORE[DEPTH] TABLE
WE SAVE INFORMATION ABOUT MOVE_TYPE IN WHI_MOVETYPE_SCORE[DEPTH] TABLE:
MOVETYPES: CAPTURE,NONCAPTURE,PROMOTION, CENTER_STRENGTHENING, CENTER_NEUTRAL,
CENTER_WEAKENING, ATTACKING, RETREATING, ATTACK-RETREAT-NEUTRAL,
DEFENDING ATTACKED PIECE.
IF POSITION IS WON MATERIALLY AND GOOD KING SAFETY SCORING,
AND IF SEE FOR ALL ATTACKED SQUARES IS NOT WORSE THAN BEFORE
CENTER POSITION SCORING - DO SHALLOWER SEARCH DEPENDING HOW DEEP WE ARE.
RESEARCH TO NORMAL DEPTH IF SEARCH REVEALS SOMETHING BAD.

IF POSITION IS EQUAL MATERIALLY AND WON POSITIONALLY, KONG SAFETY IS NOT TOO WEAK,
SEE IS NOT WORSE THAN BEFORE
NOTHING LOOKS TOO BAD IN MOVE HISTORY- DO SHALLOWER SEARCH,


*/

/*
//search order in curent code:
//captures (even bad ones) are examined first - this may not be optimal
//but sometimes bad capture is a good sacrifice
//evaluation: qs returns proper estimated result after bad capture
//evaluation: robust score - no sse score tuning
*/

/*
in EVAL() we create dynamically Ballance[] table
in this table we write number ow white attacks minus black attacks
We can use this information for multiple purposes:
- to eval king safety scores
- to eval center-possesion scores,
- to find hanging pieces, better sorting of escaping moves,
- to score attacks on pinned pieces
- to score mobility


*/

void EV_SQUARE ();

bool usesVec(unsigned char Startsquare, unsigned char Endsquare);

signed int EVAL();

/*
Static Exchange Evaluation. this should improve move ordering,
because EVAL() sorts move only by means of static evaluation (i.e. it
doesnt see bad trades). The more important implementation is that
it can give some info to set search depth. This rough heuristic SEE move
evaluation is examined only for last moved piece.
In another implementation it can be used for all pieces
which are attacked by opponent. SEE is imperfect beacause it doesnt see
threats, pins, checks etc. Scoring of these is done somewhere else.
More precise score than SEE is returned in QS.
Implementation:
-find least valuable opponent attacker of attacked_sq_index,
-temporarily remove it (save it on the A list to further add it back)
-find least valuable self attacked_sq_index defender,
-temporarily remove it (save it on the B list to further add it back)
-continue the above procedure in a loop and save see_Eval[exchange level]
-save material pseudoleaf score at see_Score
-go up exchange levels and do minimax with see_Score, if see_Eval[] is better,
replace see_Score with this value.
Usage:
- do a little change of static score on basis of SEE,
- set SEE flag for probable loss of material to *exclude* (!) some lines from deeper search
- dont do SEE in leaf nodes (if only QS works better)
*/


//takes as argument global side
signed int SEE(int attacked_sq_index, bool myside);

//////////////////////
#ifdef REUSE_EVAL
//table containing vectors
//static unsigned int (*getVec) = new unsigned int[64*64];
const unsigned char getVec[64*64] =
{9,15,4,4,4,4,4,4,21,11,8,10,10,10,10,10,6,17,0,10,10,10,10,10,6,19,10,0,10,10,10,10,6,19,10,10,0,10,10,10,6,19,

10,10,10,0,10,10,6,19,10,10,10,10,0,10,6,19,10,10,10,10,10,0,16,9,15,4,4,4,4,4,14,21,11,8,10,10,10,10,17,6,17,0,

10,10,10,10,19,6,19,10,0,10,10,10,19,6,19,10,10,0,10,10,19,6,19,10,10,10,0,10,19,6,19,10,10,10,10,0,19,6,19,10,
10,10,10,10,5,16,9,15,4,4,4,4,8,14,21,11,8,10,10,10,3,17,6,17,0,10,10,10,10,19,6,19,10,0,10,10,10,19,6,19,10,10,0

,10,10,19,6,19,10,10,10,0,10,19,6,19,10,10,10,10,10,19,6,19,10,10,10,10,5,5,16,9,15,4,4,4,10,8,14,21,11,8,10,10,

10,3,17,6,17,0,10,10,3,10,19,6,19,10,0,10,10,10,19,6,19,10,10,0,10,10,19,6,19,10,10,10,10,10,19,6,19,10,10,10,10

,10,19,6,19,10,10,10,5,5,5,16,9,15,4,4,10,10,8,14,21,11,8,10,10,10,3,17,6,17,0,10,10,3,10,19,6,19,10,0,3,10,10,
19,6,19,10,10,10,10,10,19,6,19,10,10,10,10,10,19,6,19,10,10,10,10,10,19,6,19,10,10,5,5,5,5,16,9,15,4,10,10,10,8,
14,21,11,8,10,10,10,3,17,6,17,0,10,10,3,10,19,6,19,10,10,3,10,10,19,6,19,10,3,10,10,10,19,6,19,10,10,10,10,10,19,
6,19,10,10,10,10,10,19,6,19,10,5,5,5,5,5,16,9,15,10,10,10,10,8,14,21,11,10,10,10,10,3,17,6,17,10,10,10,3,10,19,6

,19,10,10,3,10,10,19,6,19,10,3,10,10,10,19,6,19,3,10,10,10,10,19,6,19,10,10,10,10,10,19,6,19,5,5,5,5,5,5,16,9,10

,10,10,10,10,8,14,21,10,10,10,10,10,3,17,6,10,10,10,10,3,10,19,6,10,10,10,3,10,10,19,6,10,10,3,10,10,10,19,6,10,

3,10,10,10,10,19,6,3,10,10,10,10,10,19,6,22,13,8,10,10,10,10,10,9,15,4,4,4,4,4,4,21,11,8,10,10,10,10,10,6,17,0,10,10,10,10,10,6,19,10,0,10,10,10,10,6,19,10,10,0,10,10,10,6,19,10,10,10,0,10,10,6,19,10,10,10,10,0,10,12,22,13,8

,10,10,10,10,16,9,15,4,4,4,4,4,14,21,11,8,10,10,10,10,17,6,17,0,10,10,10,10,19,6,19,10,0,10,10,10,19,6,19,10,10,

0,10,10,19,6,19,10,10,10,0,10,19,6,19,10,10,10,10,0,8,12,22,13,8,10,10,10,5,16,9,15,4,4,4,4,8,14,21,11,8,10,10,10,3,17,6,17,0,10,10,10,10,19,6,19,10,0,10,10,10,19,6,19,10,10,0,10,10,19,6,19,10,10,10,0,10,19,6,19,10,10,10,10,

10,8,12,22,13,8,10,10,5,5,16,9,15,4,4,4,10,8,14,21,11,8,10,10,10,3,17,6,17,0,10,10,3,10,19,6,19,10,0,10,10,10,19

,6,19,10,10,0,10,10,19,6,19,10,10,10,10,10,19,6,19,10,10,10,10,10,8,12,22,13,8,10,5,5,5,16,9,15,4,4,10,10,8,14,
21,11,8,10,10,10,3,17,6,17,0,10,10,3,10,19,6,19,10,0,3,10,10,19,6,19,10,10,10,10,10,19,6,19,10,10,10,10,10,19,6,
19,10,10,10,10,10,8,12,22,13,8,5,5,5,5,16,9,15,4,10,10,10,8,14,21,11,8,10,10,10,3,17,6,17,0,10,10,3,10,19,6,19,10

,10,3,10,10,19,6,19,10,3,10,10,10,19,6,19,10,10,10,10,10,19,6,19,10,10,10,10,10,8,12,22,13,5,5,5,5,5,16,9,15,10,

10,10,10,8,14,21,11,10,10,10,10,3,17,6,17,10,10,10,3,10,19,6,19,10,10,3,10,10,19,6,19,10,3,10,10,10,19,6,19,3,10

,10,10,10,19,6,19,10,10,10,10,10,8,12,22,5,5,5,5,5,5,16,9,10,10,10,10,10,8,14,21,10,10,10,10,10,3,17,6,10,10,10,

10,3,10,19,6,10,10,10,3,10,10,19,6,10,10,3,10,10,10,19,6,10,3,10,10,10,10,19,6,7,18,2,10,10,10,10,10,22,13,8,10,

10,10,10,10,9,15,4,4,4,4,4,4,21,11,8,10,10,10,10,10,6,17,0,10,10,10,10,10,6,19,10,0,10,10,10,10,6,19,10,10,0,10,

10,10,6,19,10,10,10,0,10,10,18,7,18,2,10,10,10,10,12,22,13,8,10,10,10,10,16,9,15,4,4,4,4,4,14,21,11,8,10,10,10,
10,17,6,17,0,10,10,10,10,19,6,19,10,0,10,10,10,19,6,19,10,10,0,10,10,19,6,19,10,10,10,0,10,1,18,7,18,2,10,10,10,8

,12,22,13,8,10,10,10,5,16,9,15,4,4,4,4,8,14,21,11,8,10,10,10,3,17,6,17,0,10,10,10,10,19,6,19,10,0,10,10,10,19,6,

19,10,10,0,10,10,19,6,19,10,10,10,0,10,1,18,7,18,2,10,10,10,8,12,22,13,8,10,10,5,5,16,9,15,4,4,4,10,8,14,21,11,8

,10,10,10,3,17,6,17,0,10,10,3,10,19,6,19,10,0,10,10,10,19,6,19,10,10,0,10,10,19,6,19,10,10,10,10,10,1,18,7,18,2,

10,10,10,8,12,22,13,8,10,5,5,5,16,9,15,4,4,10,10,8,14,21,11,8,10,10,10,3,17,6,17,0,10,10,3,10,19,6,19,10,0,3,10,

10,19,6,19,10,10,10,10,10,19,6,19,10,10,10,10,10,1,18,7,18,2,10,10,10,8,12,22,13,8,5,5,5,5,16,9,15,4,10,10,10,8,

14,21,11,8,10,10,10,3,17,6,17,0,10,10,3,10,19,6,19,10,10,3,10,10,19,6,19,10,3,10,10,10,19,6,19,10,10,10,10,10,1,

18,7,18,10,10,10,10,8,12,22,13,5,5,5,5,5,16,9,15,10,10,10,10,8,14,21,11,10,10,10,10,3,17,6,17,10,10,10,3,10,19,6

,19,10,10,3,10,10,19,6,19,10,3,10,10,10,19,6,19,10,10,10,10,10,1,18,7,10,10,10,10,10,8,12,22,5,5,5,5,5,5,16,9,10

,10,10,10,10,8,14,21,10,10,10,10,10,3,17,6,10,10,10,10,3,10,19,6,10,10,10,3,10,10,19,6,10,10,3,10,10,10,19,6,7,
20,10,2,10,10,10,10,7,18,2,10,10,10,10,10,22,13,8,10,10,10,10,10,9,15,4,4,4,4,4,4,21,11,8,10,10,10,10,10,6,17,0,
10,10,10,10,10,6,19,10,0,10,10,10,10,6,19,10,10,0,10,10,10,20,7,20,10,2,10,10,10,18,7,18,2,10,10,10,10,12,22,13,8

,10,10,10,10,16,9,15,4,4,4,4,4,14,21,11,8,10,10,10,10,17,6,17,0,10,10,10,10,19,6,19,10,0,10,10,10,19,6,19,10,10,

0,10,10,10,20,7,20,10,2,10,10,1,18,7,18,2,10,10,10,8,12,22,13,8,10,10,10,5,16,9,15,4,4,4,4,8,14,21,11,8,10,10,10

,3,17,6,17,0,10,10,10,10,19,6,19,10,0,10,10,10,19,6,19,10,10,0,10,1,10,20,7,20,10,2,10,10,1,18,7,18,2,10,10,10,8

,12,22,13,8,10,10,5,5,16,9,15,4,4,4,10,8,14,21,11,8,10,10,10,3,17,6,17,0,10,10,3,10,19,6,19,10,0,10,10,10,19,6,
19,10,10,0,10,1,10,20,7,20,10,2,10,10,1,18,7,18,2,10,10,10,8,12,22,13,8,10,5,5,5,16,9,15,4,4,10,10,8,14,21,11,8,
10,10,10,3,17,6,17,0,10,10,3,10,19,6,19,10,0,3,10,10,19,6,19,10,10,10,10,1,10,20,7,20,10,10,10,10,1,18,7,18,2,10,

10,10,8,12,22,13,8,5,5,5,5,16,9,15,4,10,10,10,8,14,21,11,8,10,10,10,3,17,6,17,0,10,10,3,10,19,6,19,10,10,3,10,10

,19,6,19,10,10,10,10,1,10,20,7,20,10,10,10,10,1,18,7,18,10,10,10,10,8,12,22,13,5,5,5,5,5,16,9,15,10,10,10,10,8,
14,21,11,10,10,10,10,3,17,6,17,10,10,10,3,10,19,6,19,10,10,3,10,10,19,6,19,10,10,10,10,1,10,20,7,10,10,10,10,10,1

,18,7,10,10,10,10,10,8,12,22,5,5,5,5,5,5,16,9,10,10,10,10,10,8,14,21,10,10,10,10,10,3,17,6,10,10,10,10,3,10,19,6

,10,10,10,3,10,10,19,6,7,20,10,10,2,10,10,10,7,20,10,2,10,10,10,10,7,18,2,10,10,10,10,10,22,13,8,10,10,10,10,10,

9,15,4,4,4,4,4,4,21,11,8,10,10,10,10,10,6,17,0,10,10,10,10,10,6,19,10,0,10,10,10,10,20,7,20,10,10,2,10,10,20,7,
20,10,2,10,10,10,18,7,18,2,10,10,10,10,12,22,13,8,10,10,10,10,16,9,15,4,4,4,4,4,14,21,11,8,10,10,10,10,17,6,17,0,

10,10,10,10,19,6,19,10,0,10,10,10,10,20,7,20,10,10,2,10,10,20,7,20,10,2,10,10,1,18,7,18,2,10,10,10,8,12,22,13,8,

10,10,10,5,16,9,15,4,4,4,4,8,14,21,11,8,10,10,10,3,17,6,17,0,10,10,10,10,19,6,19,10,0,10,10,10,10,20,7,20,10,10,

2,1,10,20,7,20,10,2,10,10,1,18,7,18,2,10,10,10,8,12,22,13,8,10,10,5,5,16,9,15,4,4,4,10,8,14,21,11,8,10,10,10,3,
17,6,17,0,10,10,3,10,19,6,19,10,0,10,1,10,10,20,7,20,10,10,10,1,10,20,7,20,10,2,10,10,1,18,7,18,2,10,10,10,8,12,
22,13,8,10,5,5,5,16,9,15,4,4,10,10,8,14,21,11,8,10,10,10,3,17,6,17,0,10,10,3,10,19,6,19,10,0,10,1,10,10,20,7,20,
10,10,10,1,10,20,7,20,10,10,10,10,1,18,7,18,2,10,10,10,8,12,22,13,8,5,5,5,5,16,9,15,4,10,10,10,8,14,21,11,8,10,10

,10,3,17,6,17,0,10,10,3,10,19,6,19,10,10,10,1,10,10,20,7,20,10,10,10,1,10,20,7,20,10,10,10,10,1,18,7,18,10,10,10

,10,8,12,22,13,5,5,5,5,5,16,9,15,10,10,10,10,8,14,21,11,10,10,10,10,3,17,6,17,10,10,10,3,10,19,6,19,10,10,10,1,
10,10,20,7,10,10,10,10,1,10,20,7,10,10,10,10,10,1,18,7,10,10,10,10,10,8,12,22,5,5,5,5,5,5,16,9,10,10,10,10,10,8,
14,21,10,10,10,10,10,3,17,6,10,10,10,10,3,10,19,6,7,20,10,10,10,2,10,10,7,20,10,10,2,10,10,10,7,20,10,2,10,10,10,

10,7,18,2,10,10,10,10,10,22,13,8,10,10,10,10,10,9,15,4,4,4,4,4,4,21,11,8,10,10,10,10,10,6,17,0,10,10,10,10,10,20

,7,20,10,10,10,2,10,20,7,20,10,10,2,10,10,20,7,20,10,2,10,10,10,18,7,18,2,10,10,10,10,12,22,13,8,10,10,10,10,16,

9,15,4,4,4,4,4,14,21,11,8,10,10,10,10,17,6,17,0,10,10,10,10,10,20,7,20,10,10,10,2,10,20,7,20,10,10,2,10,10,20,7,

20,10,2,10,10,1,18,7,18,2,10,10,10,8,12,22,13,8,10,10,10,5,16,9,15,4,4,4,4,8,14,21,11,8,10,10,10,3,17,6,17,0,10,

10,10,10,10,20,7,20,10,10,10,10,10,20,7,20,10,10,2,1,10,20,7,20,10,2,10,10,1,18,7,18,2,10,10,10,8,12,22,13,8,10,

10,5,5,16,9,15,4,4,4,10,8,14,21,11,8,10,10,10,3,17,6,17,0,10,10,10,10,10,20,7,20,10,10,1,10,10,20,7,20,10,10,10,

1,10,20,7,20,10,2,10,10,1,18,7,18,2,10,10,10,8,12,22,13,8,10,5,5,5,16,9,15,4,4,10,10,8,14,21,11,8,10,10,10,3,17,

6,17,0,10,1,10,10,10,20,7,20,10,10,1,10,10,20,7,20,10,10,10,1,10,20,7,20,10,10,10,10,1,18,7,18,2,10,10,10,8,12,
22,13,8,5,5,5,5,16,9,15,4,10,10,10,8,14,21,11,8,10,10,10,3,17,6,17,0,10,1,10,10,10,20,7,20,10,10,1,10,10,20,7,20,

10,10,10,1,10,20,7,20,10,10,10,10,1,18,7,18,10,10,10,10,8,12,22,13,5,5,5,5,5,16,9,15,10,10,10,10,8,14,21,11,10,
10,10,10,3,17,6,17,10,10,1,10,10,10,20,7,10,10,10,1,10,10,20,7,10,10,10,10,1,10,20,7,10,10,10,10,10,1,18,7,10,10,

10,10,10,8,12,22,5,5,5,5,5,5,16,9,10,10,10,10,10,8,14,21,10,10,10,10,10,3,17,6,7,20,10,10,10,10,2,10,7,20,10,10,

10,2,10,10,7,20,10,10,2,10,10,10,7,20,10,2,10,10,10,10,7,18,2,10,10,10,10,10,22,13,8,10,10,10,10,10,9,15,4,4,4,4

,4,4,21,11,8,10,10,10,10,10,20,7,20,10,10,10,10,2,20,7,20,10,10,10,2,10,20,7,20,10,10,2,10,10,20,7,20,10,2,10,10

,10,18,7,18,2,10,10,10,10,12,22,13,8,10,10,10,10,16,9,15,4,4,4,4,4,14,21,11,8,10,10,10,10,10,20,7,20,10,10,10,10

,10,20,7,20,10,10,10,2,10,20,7,20,10,10,2,10,10,20,7,20,10,2,10,10,1,18,7,18,2,10,10,10,8,12,22,13,8,10,10,10,5,

16,9,15,4,4,4,4,8,14,21,11,8,10,10,10,10,10,20,7,20,10,10,10,10,10,20,7,20,10,10,10,10,10,20,7,20,10,10,2,1,10,
20,7,20,10,2,10,10,1,18,7,18,2,10,10,10,8,12,22,13,8,10,10,5,5,16,9,15,4,4,4,10,8,14,21,11,8,10,10,10,10,10,20,7,

20,10,10,10,10,10,20,7,20,10,10,1,10,10,20,7,20,10,10,10,1,10,20,7,20,10,2,10,10,1,18,7,18,2,10,10,10,8,12,22,13

,8,10,5,5,5,16,9,15,4,4,10,10,8,14,21,11,8,10,10,10,10,10,20,7,20,10,1,10,10,10,20,7,20,10,10,1,10,10,20,7,20,10

,10,10,1,10,20,7,20,10,10,10,10,1,18,7,18,2,10,10,10,8,12,22,13,8,5,5,5,5,16,9,15,4,10,10,10,8,14,21,11,8,1,10,
10,10,10,20,7,20,10,1,10,10,10,20,7,20,10,10,1,10,10,20,7,20,10,10,10,1,10,20,7,20,10,10,10,10,1,18,7,18,10,10,10

,10,8,12,22,13,5,5,5,5,5,16,9,15,10,10,10,10,8,14,21,11,10,1,10,10,10,10,20,7,10,10,1,10,10,10,20,7,10,10,10,1,
10,10,20,7,10,10,10,10,1,10,20,7,10,10,10,10,10,1,18,7,10,10,10,10,10,8,12,22,5,5,5,5,5,5,16,9,10,10,10,10,10,8,
14,21,7,20,10,10,10,10,10,2,7,20,10,10,10,10,2,10,7,20,10,10,10,2,10,10,7,20,10,10,2,10,10,10,7,20,10,2,10,10,10,

10,7,18,2,10,10,10,10,10,22,13,8,10,10,10,10,10,9,15,4,4,4,4,4,4,20,7,20,10,10,10,10,10,20,7,20,10,10,10,10,2,20

,7,20,10,10,10,2,10,20,7,20,10,10,2,10,10,20,7,20,10,2,10,10,10,18,7,18,2,10,10,10,10,12,22,13,8,10,10,10,10,16,

9,15,4,4,4,4,4,10,20,7,20,10,10,10,10,10,20,7,20,10,10,10,10,10,20,7,20,10,10,10,2,10,20,7,20,10,10,2,10,10,20,7

,20,10,2,10,10,1,18,7,18,2,10,10,10,8,12,22,13,8,10,10,10,5,16,9,15,4,4,4,4,10,10,20,7,20,10,10,10,10,10,20,7,20

,10,10,10,10,10,20,7,20,10,10,10,10,10,20,7,20,10,10,2,1,10,20,7,20,10,2,10,10,1,18,7,18,2,10,10,10,8,12,22,13,8

,10,10,5,5,16,9,15,4,4,4,10,10,10,20,7,20,10,10,10,10,10,20,7,20,10,10,10,10,10,20,7,20,10,10,1,10,10,20,7,20,10

,10,10,1,10,20,7,20,10,2,10,10,1,18,7,18,2,10,10,10,8,12,22,13,8,10,5,5,5,16,9,15,4,4,10,10,10,10,20,7,20,10,10,

10,10,10,20,7,20,10,1,10,10,10,20,7,20,10,10,1,10,10,20,7,20,10,10,10,1,10,20,7,20,10,10,10,10,1,18,7,18,2,10,10

,10,8,12,22,13,8,5,5,5,5,16,9,15,4,10,10,10,10,10,20,7,20,1,10,10,10,10,20,7,20,10,1,10,10,10,20,7,20,10,10,1,10

,10,20,7,20,10,10,10,1,10,20,7,20,10,10,10,10,1,18,7,18,10,10,10,10,8,12,22,13,5,5,5,5,5,16,9,15,1,10,10,10,10,
10,20,7,10,1,10,10,10,10,20,7,10,10,1,10,10,10,20,7,10,10,10,1,10,10,20,7,10,10,10,10,1,10,20,7,10,10,10,10,10,1,

18,7,10,10,10,10,10,8,12,22,5,5,5,5,5,5,16,9};
#endif



