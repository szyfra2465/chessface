
//new ply globals
extern unsigned char np_i;
//static unsigned char np_j;
extern unsigned char np_offs;
extern unsigned char np_t;
extern unsigned char np_c;
extern unsigned char np_v;
extern bool np_allow;
extern unsigned short shifted_np_ply;

// access ply to save moves properly in the tree
unsigned char FULL_WHI_PLY(unsigned char ply);
@add other new ply functions here

