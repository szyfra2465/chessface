//global hash code////////////////////////////////////////

//Zobrist key gen
//about 780 keys per position
static unsigned __int64 ZRandomNumbers[1000] = {0};
//pieces placement keys
static unsigned __int64 ZWpa[64] = {0};
static unsigned __int64 ZBpa[64] = {0};
static unsigned __int64 ZWro[64] = {0};
static unsigned __int64 ZBro[64] = {0};
static unsigned __int64 ZWbi[64] = {0};
static unsigned __int64 ZBbi[64] = {0};
static unsigned __int64 ZWkn[64] = {0};
static unsigned __int64 ZBkn[64] = {0};
static unsigned __int64 ZWki[64] = {0};
static unsigned __int64 ZBki[64] = {0};
static unsigned __int64 ZWqu[64] = {0};
static unsigned __int64 ZBqu[64] = {0};

//side key
static unsigned __int64 ZWtm = 0;

//4 castle right keys
static unsigned __int64 ZWkk = 0;
static unsigned __int64 ZBkk = 0;
static unsigned __int64 ZWkq = 0;
static unsigned __int64 ZBkq = 0;

//16 enpassant keys
static unsigned __int64 ZWe1 = 0;
static unsigned __int64 ZWe2 = 0;
static unsigned __int64 ZWe3 = 0;
static unsigned __int64 ZWe4 = 0;
static unsigned __int64 ZWe5 = 0;
static unsigned __int64 ZWe6 = 0;
static unsigned __int64 ZWe7 = 0;
static unsigned __int64 ZWe8 = 0;
static unsigned __int64 ZBe1 = 0;
static unsigned __int64 ZBe2 = 0;
static unsigned __int64 ZBe3 = 0;
static unsigned __int64 ZBe4 = 0;
static unsigned __int64 ZBe5 = 0;
static unsigned __int64 ZBe6 = 0;
static unsigned __int64 ZBe7 = 0;
static unsigned __int64 ZBe8 = 0;

//overall position key
static unsigned __int64 Zkey = 0;
//hashkey table
static unsigned __int64 Zkey_tab[64] = {0};//of the ply
//game keys history
static unsigned __int64 Game_Zkey_tab[512] = {0};

//hashtable
//HT==
//[Zkey(64bits)]
//[score(20bits)-val(20bits)-ply(6bits)-qDepth(6bits)-BestMovefromto(12bits)]
static unsigned __int64(*HT) [2] = new unsigned __int64[Hsize][2];
//make zeros?!

#ifdef CUTTOFF_MOVE_HASH_REORDER
//coords of the move which caused a cuttoff
static unsigned char cut_move_coords = 0;
#endif

//hashtable ~16 to 32bit-long key
static unsigned __int64 Hkey = 0;

/*hashtable statistical data*/
static unsigned __int64 H_eval_overwrites = 0;
//static unsigned __int64 H_transp_overwrites = 0; //unused
static unsigned __int64 H_eval_cuttoffs = 0;
//static unsigned __int64 H_transp_cuttoffs = 0; //unused

//function clears global hash
void clearHash()
{
  unsigned __int64 i = 0;

  while (i <= Hsize) {
    HT[i][0] = 0;
    HT[i][1] = 0;
    i++;
  };
};

//function initializes global Zkeys using random key generation
//and Game[GMI] data. Key length (bitlen) is 64 by default
void setGameZkey(unsigned short bitlen)
{
//srand(time(NULL));
  srand((unsigned int) "Pentium");
  int j;

  for (int k = 0; k < 1000; k++) {
    string s("");
    int i = 0;

    while (i < bitlen) {
      int random_int = rand();

      if ((random_int | 1) == random_int) {
        s += "1";
      } else {
        s += "0";
      };

      i++;
    };

    unsigned __int64 result = 0;

    for (i = 0; i < bitlen; i++) {
      result += (((unsigned __int64)(s[i] - '0')) << (bitlen - i - 1));
    };

    //cout<<result<<" "<<k<<endl;
    //remove duplicates
    bool dup = false;

    j = k - 1;

    while (j >= 0) {
      if (result == ZRandomNumbers[j]) {
        dup = true;
        break;
      }

      j--;
    };

    if (dup == true) {
      k--;

			#ifdef DEBUG_VERSION
      cout << "hash duplicate being replaced:" << result << endl;
      #endif

    } else {
      ZRandomNumbers[k] = result;
    };
  };

/////////////////////////////////////
//copy unique numbers to proper key tables
//piece-square keys
  for (j = 0; j < 64; j++) {
    ZWpa[j] = ZRandomNumbers[j];
    ZBpa[j] = ZRandomNumbers[j + (64 * 1) ];
    ZWro[j] = ZRandomNumbers[j + (64 * 2) ];
    ZBro[j] = ZRandomNumbers[j + (64 * 3) ];
    ZWbi[j] = ZRandomNumbers[j + (64 * 4) ];
    ZBbi[j] = ZRandomNumbers[j + (64 * 5) ];
    ZWkn[j] = ZRandomNumbers[j + (64 * 6) ];
    ZBkn[j] = ZRandomNumbers[j + (64 * 7) ];
    ZWki[j] = ZRandomNumbers[j + (64 * 8) ];
    ZBki[j] = ZRandomNumbers[j + (64 * 9) ];
    ZWqu[j] = ZRandomNumbers[j + (64 * 10) ];
    ZBqu[j] = ZRandomNumbers[j + (64 * 11) ];
  };

//1 side to move keys
  ZWtm = ZRandomNumbers[1 + (64 * 12) ];

//4 castle right keys
  ZWkk = ZRandomNumbers[2 + (64 * 12) ];

  ZBkk = ZRandomNumbers[3 + (64 * 12) ];

  ZWkq = ZRandomNumbers[4 + (64 * 12) ];

  ZBkq = ZRandomNumbers[5 + (64 * 12) ];

//16 enpassant keys
  ZWe1 = ZRandomNumbers[6 + (64 * 12) ];

  ZWe2 = ZRandomNumbers[7 + (64 * 12) ];

  ZWe3 = ZRandomNumbers[8 + (64 * 12) ];

  ZWe4 = ZRandomNumbers[9 + (64 * 12) ];

  ZWe5 = ZRandomNumbers[10 + (64 * 12) ];

  ZWe6 = ZRandomNumbers[11 + (64 * 12) ];

  ZWe7 = ZRandomNumbers[12 + (64 * 12) ];

  ZWe8 = ZRandomNumbers[13 + (64 * 12) ];

  ZBe1 = ZRandomNumbers[14 + (64 * 12) ];

  ZBe2 = ZRandomNumbers[15 + (64 * 12) ];

  ZBe3 = ZRandomNumbers[16 + (64 * 12) ];

  ZBe4 = ZRandomNumbers[17 + (64 * 12) ];

  ZBe5 = ZRandomNumbers[18 + (64 * 12) ];

  ZBe6 = ZRandomNumbers[19 + (64 * 12) ];

  ZBe7 = ZRandomNumbers[20 + (64 * 12) ];

  ZBe8 = ZRandomNumbers[21 + (64 * 12) ];

//get initial hash key of Board
  Zkey = 0;

  for (j = 0; j < 64; j++) {
    switch (GameBoard[GMI][j]) {
      case
          sWpa: {
          Zkey ^= ZWpa[j];
        };

        break;
      case
          sBpa: {
          Zkey ^= ZBpa[j];
        };

        break;
      case
          sWro: {
          Zkey ^= ZWro[j];
        };

        break;
      case
          sBro: {
          Zkey ^= ZBro[j];
        };

        break;
      case
          sWbi: {
          Zkey ^= ZWbi[j];
        };

        break;
      case
          sBbi: {
          Zkey ^= ZBbi[j];
        };

        break;
      case
          sWkn: {
          Zkey ^= ZWkn[j];
        };

        break;
      case
          sBkn: {
          Zkey ^= ZBkn[j];
        };

        break;
      case
          sWki: {
          Zkey ^= ZWki[j];
        };

        break;
      case
          sBki: {
          Zkey ^= ZBki[j];
        };

        break;
      case
          sWqu: {
          Zkey ^= ZWqu[j];
        };

        break;
      case
          sBqu: {
          Zkey ^= ZBqu[j];
        };

        break;
    };
  };

//side to move
  if (GameWtm[GMI] == true) {
    Zkey ^= ZWtm;
  };

//castle rights
  if (Game_castle_data[GMI]
      == (Game_castle_data[GMI] | castle_lost_WKK_mask)) {
    Zkey ^= ZWkk;
  };

  if (Game_castle_data[GMI]
      == (Game_castle_data[GMI] | castle_lost_WKQ_mask)) {
    Zkey ^= ZWkq;
  };

  if (Game_castle_data[GMI]
      == (Game_castle_data[GMI] | castle_lost_BKK_mask)) {
    Zkey ^= ZBkk;
  };

  if (Game_castle_data[GMI]
      == (Game_castle_data[GMI] | castle_lost_BKQ_mask)) {
    Zkey ^= ZBkq;
  };

//enpassant
  switch (GameEnpassant[GMI]) {
    case
        16: {
        Zkey ^= ZBe1;
      };

      break;
    case
        17: {
        Zkey ^= ZBe2;
      };

      break;
    case
        18: {
        Zkey ^= ZBe3;
      };

      break;
    case
        19: {
        Zkey ^= ZBe4;
      };

      break;
    case
        20: {
        Zkey ^= ZBe5;
      };

      break;
    case
        21: {
        Zkey ^= ZBe6;
      };

      break;
    case
        22: {
        Zkey ^= ZBe7;
      };

      break;
    case
        23: {
        Zkey ^= ZBe8;
      };

      break;
    case
        40: {
        Zkey ^= ZWe1;
      };

      break;
    case
        41: {
        Zkey ^= ZWe2;
      };

      break;
    case
        42: {
        Zkey ^= ZWe3;
      };

      break;
    case
        43: {
        Zkey ^= ZWe4;
      };

      break;
    case
        44: {
        Zkey ^= ZWe5;
      };

      break;
    case
        45: {
        Zkey ^= ZWe6;
      };

      break;
    case
        46: {
        Zkey ^= ZWe7;
      };

      break;
    case
        47: {
        Zkey ^= ZWe8;
      };

      break;
    default
        : {
        ;
      };
  };
};


