/*
const unsigned short Check = 33;
const unsigned short Promotion = 32;
const unsigned short PawnQueenCap = 31;
const unsigned short KnightQueenCap = 30;
const unsigned short BishopQueenCap = 29;
const unsigned short RookQueenCap = 28;
const unsigned short PawnRookCap = 27;
const unsigned short BishopRookCap = 26;
const unsigned short KnightRookCap = 25;
const unsigned short PawnBishopCap = 23;
const unsigned short PawnKnightCap = 22;
const unsigned short KingQueenCap = 21;
const unsigned short KingRookCap = 20;
const unsigned short KingKnightCap = 19;
const unsigned short KingBishopCap = 18;
const unsigned short KingPawnCap = 17;
const unsigned short QueenQueenCap = 16;
const unsigned short RookRookCap = 15;
const unsigned short KnightBishopCap = 14;
const unsigned short BishopBishopCap = 13;
const unsigned short KnightKnightCap = 12;
const unsigned short BishopKnightCap = 11;
const unsigned short PawnPawnCap = 10;
const unsigned short RookBishopCap = 9;
const unsigned short RookKnightCap = 8;
const unsigned short KnightPawnCap = 7;
const unsigned short BishopPawnCap = 6;
const unsigned short QueenRookCap = 5;
const unsigned short QueenBishopCap = 4;
const unsigned short QueenKnightCap = 3;
const unsigned short RookPawnCap = 2;
const unsigned short QueenPawnCap = 1;
*/
/*
order captures

32 promotions

  gain-type caps, estimated gain in pawns-if attacked piece defended or not
31 +++Pq 8-9
30 ++Nq 6-9
29 ++Bq 6-9
28 ++Rq 5-9
27 +Pr 4-5
26 +Br 2-5
25 +Nr 2-5
23 +Pb 2-3
22 +Pn 2-3

! impossible if attacked piece defended
14 !Kq 9
13 !Kr 5
12 !Kn 3
11 !Kb 3
10 !Kp 1

   = gain/equal caps
21 =Qq 0-9
20 =Rr 0-5
19 =Nb 0-3
18 =Bb 0-3
17 =Nn 0-3
16 =Bn 0-3
15 =Pp 0-1

  ? rather poor if attacked piece defended (order by gained piece if undefended)
9 ?Rb
8 ?Rn
7 ?Np
6 ?Bp
5 ?Qr
4 ???Qn
3 ???Qb
2 ???Rp
1 ????Qp
*/


//piece eval statics

static unsigned char ev_v, ev_c, ev_j, ev_fs, ev_temp, ev_test;
static signed int ev_score;
static signed int ev_tempsc; //used by reuse_eval code mainly
#ifdef DEBUG_EVAL
static signed int ev_tempscore;
static signed int E[64] = {0};
static bool display_eval_details = false; //show internal data of function to improve and debug it better
#endif

#ifdef REUSE_EVAL
static bool do_reuse_eval;
//SC[(ply<<6)|sq]
static signed int SC[64] = {0};
//static bool display_eval_details = false; //show internal data of function to improve and debug it better
#endif

static signed int ev_mat_score;

#ifdef MAT_POS_PRUNNING
static int ev_pos_score;
#endif

//boards with king area to speedup eval
static unsigned char WkiArea[65] = {0}; //last i dummy to handle out of board
static unsigned char BkiArea[65] = {0};

//static exchange evaluation globals
#ifdef S_E_E
static unsigned char see_n; //counter, zero breaks search
static unsigned char see_from; //fromsquare
static unsigned char see_AttackerPieceType[20]; //capture store
static unsigned char see_AttacksFrom[20]; //attackfrom store
static signed int see_Score[20]; //pseudominimax exchange score[depth](at [0] is always 0)
static signed int see_val;
#endif

//isAttacked, isCheckGood, countAttacks globals
static unsigned char at_i;
//static unsigned char at_j;
static unsigned char at_v;
static unsigned char at_s;
static unsigned char ma_i;
static unsigned char ma_j;
static unsigned char ma_v;
static unsigned char ma_x;
static unsigned char ma_y;
static unsigned char ma_def;
static unsigned char pnum;
static unsigned char ma_check_from;
static unsigned char ma_testv;
static unsigned char ma_dist;
static unsigned char ma_Pinned[8] = {0};

//generates in EVAL() bitboards(Whi and BlaAttackedMap) of attacked pieces.
//Next to each attacked piece SSE is conducted to generate SSE score.
//SEE score should affect evaluation score
//or/and should guide search depth.
//this should work unless lazy eval is used.

#ifdef ATTACKS_MAP
static unsigned __int64 WhiAttackedMap = 0;
static unsigned __int64 BlaAttackedMap = 0;
//bit nr 26 flag - WHITE THREAT flag (1 << 25)
static unsigned int whi_threat_mask = 0;
//bit nr 25 - BLACK THREAT flag (1 << 24)
static unsigned int bla_threat_mask = 0;
#ifdef DEBUG_VERSION
unsigned __int64 WhiAttackedMapCount = 0;
unsigned __int64 WhiUnattackedMapCount = 0;
unsigned __int64 BlaAttackedMapCount = 0;
unsigned __int64 BlaUnattackedMapCount = 0;
#endif
#endif

/*
bool isOccByWhi(int sq) {
  switch (B[sq]) {
    case sWpa: return true;
    case sWro: return true;
    case sWbi: return true;
    case sWkn: return true;
    case sWki: return true;
    case sWqu: return true;
    default: return false;
 };
};

bool isOccByBla(int sq) {
  switch (B[sq]) {
    case sBpa: return true;
    case sBro: return true;
    case sBbi: return true;
    case sBkn: return true;
    case sBki: return true;
    case sBqu: return true;
    default: return false;
 };
};
*/

/*
the idea to speedup the function is to analyse the coordinates of from- and to-square.
-analyse only selected vectors if:
if attacked_piece_sq < attacker_from_sq
if attacked_piece_sq > attacker_from_sq
if attacked_piece_sq < attacker_to_sq
if attacked_piece_sq > attacker_to_sq

-selected vectors according to mathematical features of square difference
(ie. if difference is multiplication of 8 - use only NS and SN vectors)
m. 9 - NW-SE, SE-NW
m. 7 - NE-SW, SW-NE
difference less than 8 - checkup EW and WE vectors

-selected vectors of to_square according to piece type


int main()
{
    int a, b, iloczyn;
    cout << "Podaj pierwsza liczbe: ";
    cin >> a;
    cout << "Podaj druga liczbe: ";
    cin >> b;

    iloczyn = a*b;

    do
    {
        if(a>b) a=a-b;
        else b=b-a;
    }
    while(a!=b);

    cout << "Najmniejsza wspolna wielokrotnosc: " << iloczyn/a << endl;

    system("PAUSE");

    return 0;
}


*/
/*
//function takses gl_move as argument
//it analyses:
//- vector between move from_square and sq
//- influence of piece on to-square on sq

bool isMoveAttacking(unsigned int sq) {

};
*/


bool isAttByWhi(unsigned char sq)
{
//pawns
  if (B[LBPCaps[sq]] == sWpa) {
    return true;
  }

  if (B[RBPCaps[sq]] == sWpa) {
    return true;
  }

//rook-like v
  //analyse vectors in order of probability
	for (at_i = 0; at_i < 8; at_i++) {
    switch (B[Vec[NtoSvec][sq][at_i]]) {
      case
          sEmp: {
          ;
        };

        break;
      case
          sWro: {
          return true;
        };

      case
          sWqu: {
          return true;
        };

      default
          : {
          at_i = 8;
        };
    };
  };

  for (at_i = 0; at_i < 8; at_i++) {
    switch (B[Vec[EtoWvec][sq][at_i]]) {
      case
          sEmp: {
          ;
        };

        break;
      case
          sWro: {
          return true;
        };

      case
          sWqu: {
          return true;
        };

      default
          : {
          at_i = 8;
        };
    };
  };

  for (at_i = 0; at_i < 8; at_i++) {
    switch (B[Vec[WtoEvec][sq][at_i]]) {
      case
          sEmp: {
          ;
        };

        break;
      case
          sWro: {
          return true;
        };

      case
          sWqu: {
          return true;
        };

      default
          : {
          at_i = 8;
        };
    };
  };
  for (at_i = 0; at_i < 8; at_i++) {
    switch (B[Vec[StoNvec][sq][at_i]]) {
      case
          sEmp: {
          ;
        };

        break;
      case
          sWro: {
          return true;
        };

      case
          sWqu: {
          return true;
        };

      default
          : {
          at_i = 8;
        };
    };
  };


//bishop-like v
  for (at_i = 0; at_i < 8; at_i++) {
    switch (B[Vec[NEtoSWvec][sq][at_i]]) {
      case
        sEmp: {
          ;
        };

        break;
      case
        sWbi: {
          return true;
        };

      case
        sWqu: {
          return true;
        };
      default
          : {
          at_i = 8;
      };
    };
  };

  for (at_i = 0; at_i < 8; at_i++) {
    switch (B[Vec[NWtoSEvec][sq][at_i]]) {
      case
        sEmp: {
          ;
        };

        break;
      case
        sWbi: {
          return true;
        };

      case
        sWqu: {
          return true;
        };
      default
          : {
          at_i = 8;
      };
    };
  };

  for (at_i = 0; at_i < 8; at_i++) {
    switch (B[Vec[SEtoNWvec][sq][at_i]]) {
      case
        sEmp: {
          ;
        };

        break;
      case
        sWbi: {
          return true;
        };

      case
        sWqu: {
          return true;
        };
      default
          : {
          at_i = 8;
      };
    };
  };

  for (at_i = 0; at_i < 8; at_i++) {
    switch (B[Vec[SWtoNEvec][sq][at_i]]) {
      case
        sEmp: {
          ;
        };

        break;
      case
        sWbi: {
          return true;
        };

      case
        sWqu: {
          return true;
        };
      default
          : {
          at_i = 8;
      };
    };
  };

  for (at_i = 0; at_i < 8; at_i++) {
    if (B[increasingKnightMap[sq][at_i]] == sWkn) {
      return true;
    }
  };

  for (at_v = 0; at_v < 8; at_v++) {
    if (B[Vec[at_v][sq][0]] == sWki) {
      return true;
    }
  };

  return false;
};



/*
bool OLDisAttByWhi(int sq)
{
//pawns
  if (B[LBPCaps[sq]] == sWpa) {
    return true;
  }

  if (B[RBPCaps[sq]] == sWpa) {
    return true;
  }

//rook-like v
  for (at_v = 4; at_v < 8; at_v++) {
    for (at_i = 0; at_i < 8; at_i++) {
      switch (B[Vec[at_v][sq][at_i]]) {
        case
            sEmp: {
            ;
          };

          break;
        case
            sWro: {
            return true;
          };

        case
            sWqu: {
            return true;
          };

        default
            : {
            at_i = 8;
          };
      };
    };
  };

//bishop-like v
  for (at_v = 0; at_v < 4; at_v++) {
    for (at_i = 0; at_i < 8; at_i++) {
      switch (B[Vec[at_v][sq][at_i]]) {
        case
            sEmp: {
            ;
          };

          break;
        case
            sWbi: {
            return true;
          };

        case
            sWqu: {
            return true;
          };

        default
            : {
            at_i = 8;
          };
      };
    };
  };

  for (at_i = 0; at_i < 8; at_i++) {
    if (B[KnightMap[sq][at_i]] == sWkn) {
      return true;
    }
  };

  for (at_v = 0; at_v < 8; at_v++) {
    if (B[Vec[at_v][sq][0]] == sWki) {
      return true;
    }
  };

  return false;
};
*/




bool isAttByBla(unsigned char sq)
{
//pawns
  if (B[LWPCaps[sq]] == sBpa) {
    return true;
  }

  if (B[RWPCaps[sq]] == sBpa) {
    return true;
  }

//rook-like v
  //analyse vectors in order of probability
  for (at_i = 0; at_i < 8; at_i++) {
    switch (B[Vec[StoNvec][sq][at_i]]) {
      case
          sEmp: {
          ;
        };

        break;
      case
          sBro: {
          return true;
        };

      case
          sBqu: {
          return true;
        };

      default
          : {
          at_i = 8;
        };
    };
  };

  for (at_i = 0; at_i < 8; at_i++) {
    switch (B[Vec[EtoWvec][sq][at_i]]) {
      case
          sEmp: {
          ;
        };

        break;
      case
          sBro: {
          return true;
        };

      case
          sBqu: {
          return true;
        };

      default
          : {
          at_i = 8;
        };
    };
  };

  for (at_i = 0; at_i < 8; at_i++) {
    switch (B[Vec[WtoEvec][sq][at_i]]) {
      case
          sEmp: {
          ;
        };

        break;
      case
          sBro: {
          return true;
        };

      case
          sBqu: {
          return true;
        };

      default
          : {
          at_i = 8;
        };
    };
  };

  for (at_i = 0; at_i < 8; at_i++) {
    switch (B[Vec[NtoSvec][sq][at_i]]) {
      case
          sEmp: {
          ;
        };

        break;
      case
          sBro: {
          return true;
        };

      case
          sBqu: {
          return true;
        };

      default
          : {
          at_i = 8;
        };
    };
  };

//bishop-like v
  for (at_i = 0; at_i < 8; at_i++) {
    switch (B[Vec[SWtoNEvec][sq][at_i]]) {
      case
        sEmp: {
          ;
        };

        break;
      case
        sBbi: {
          return true;
        };

      case
        sBqu: {
          return true;
        };
      default
          : {
          at_i = 8;
      };
    };
  };

  for (at_i = 0; at_i < 8; at_i++) {
    switch (B[Vec[SEtoNWvec][sq][at_i]]) {
      case
        sEmp: {
          ;
        };

        break;
      case
        sBbi: {
          return true;
        };

      case
        sBqu: {
          return true;
        };
      default
          : {
          at_i = 8;
      };
    };
  };

  for (at_i = 0; at_i < 8; at_i++) {
    switch (B[Vec[NWtoSEvec][sq][at_i]]) {
      case
        sEmp: {
          ;
        };

        break;
      case
        sBbi: {
          return true;
        };

      case
        sBqu: {
          return true;
        };
      default
          : {
          at_i = 8;
      };
    };
  };

  for (at_i = 0; at_i < 8; at_i++) {
    switch (B[Vec[NEtoSWvec][sq][at_i]]) {
      case
        sEmp: {
          ;
        };

        break;
      case
        sBbi: {
          return true;
        };

      case
        sBqu: {
          return true;
        };
      default
          : {
          at_i = 8;
      };
    };
  };

  for (at_i = 0; at_i < 8; at_i++) {
    if (B[decreasingKnightMap[sq][at_i]] == sBkn) {
      return true;
    }
  };

  for (at_v = 0; at_v < 8; at_v++) {
    if (B[Vec[at_v][sq][0]] == sBki) {
      return true;
    }
  };

  return false;
};

//function returns true if:
//double check on sq
//or checking piece is supported by self piece
//or checking piece is not attacked

bool isWhiCheckGood(unsigned char sq)
{
//erase checking square
  at_s = 97;

//pawns
  if (B[LBPCaps[sq]] == sWpa) {
    if (at_s == 97) {
      at_s = LBPCaps[sq];
    };
  };

  if (B[RBPCaps[sq]] == sWpa) {
    if (at_s == 97) {
      at_s = RBPCaps[sq];
    } else {
      return true;
    }; //double check
  };

//rook-like v
  for (at_v = 4; at_v < 8; at_v++) {
    for (at_i = 0; at_i < 8; at_i++) {
      switch (B[Vec[at_v][sq][at_i]]) {
        case
            sEmp: {
            ;
          };

          break;
        case
            sWro: {
            if (at_s == 97) {
              at_s = Vec[at_v][sq][at_i];
            } else {
              return true;
            }; //double check
          };

          break;
        case
            sWqu: {
            if (at_s == 97) {
              at_s = Vec[at_v][sq][at_i];
            } else {
              return true;
            }; //double check
          };

          break;
        default
            : {
            at_i = 8;
          };
      };
    };
  };

//bishop-like v
  for (at_v = 0; at_v < 4; at_v++) {
    for (at_i = 0; at_i < 8; at_i++) {
      switch (B[Vec[at_v][sq][at_i]]) {
        case
            sEmp: {
            ;
          };

          break;
        case
            sWbi: {
            if (at_s == 97) {
              at_s = Vec[at_v][sq][at_i];
            } else {
              return true;
            }; //double check
          };

          break;
        case
            sWqu: {
            if (at_s == 97) {
              at_s = Vec[at_v][sq][at_i];
            } else {
              return true;
            }; //double check
          };

          break;
        default
            : {
            at_i = 8;
          };
      };
    };
  };

  for (at_i = 0; at_i < 8; at_i++) {
    if (B[decreasingKnightMap[sq][at_i]] == sWkn) {
      if (at_s == 97) {
        at_s = decreasingKnightMap[sq][at_i];
      } else {
        return true;
      }; //double check
    };
  };

  int at_ss = at_s;

  int at_sss = at_s;

  if (at_s == 97) {
    return false;
  }; //no check

  if (isAttByWhi(at_ss) == true) {
    return true;
  }; //supported piece check

  if (isAttByBla(at_sss) == false) {
    return true;
  }; //checking piece not attacked

  return false;
};

//function returns true if:
//double check on sq
//or checking piece is supported by self piece
//or checking piece is not attacked
bool isBlaCheckGood(unsigned char sq)
{
//erase checking square
  at_s = 97;

//pawns
  if (B[LWPCaps[sq]] == sBpa) {
    if (at_s == 97) {
      at_s = LWPCaps[sq];
    };
  };

  if (B[RWPCaps[sq]] == sBpa) {
    if (at_s == 97) {
      at_s = RWPCaps[sq];
    } else {
      return true;
    }; //double check
  };

//rook-like v
  for (at_v = 4; at_v < 8; at_v++) {
    for (at_i = 0; at_i < 8; at_i++) {
      switch (B[Vec[at_v][sq][at_i]]) {
        case
            sEmp: {
            ;
          };

          break;
        case
            sBro: {
            if (at_s == 97) {
              at_s = Vec[at_v][sq][at_i];
            } else {
              return true;
            }; //double check
          };

          break;
        case
            sBqu: {
            if (at_s == 97) {
              at_s = Vec[at_v][sq][at_i];
            } else {
              return true;
            }; //double check
          };

          break;
        default
            : {
            at_i = 8;
          };
      };
    };
  };

//bishop-like v
  for (at_v = 0; at_v < 4; at_v++) {
    for (at_i = 0; at_i < 8; at_i++) {
      switch (B[Vec[at_v][sq][at_i]]) {
        case
            sEmp: {
            ;
          };

          break;
        case
            sBbi: {
            if (at_s == 97) {
              at_s = Vec[at_v][sq][at_i];
            } else {
              return true;
            }; //double check
          };

          break;
        case
            sBqu: {
            if (at_s == 97) {
              at_s = Vec[at_v][sq][at_i];
            } else {
              return true;
            }; //double check
          };

          break;
        default
            : {
            at_i = 8;
          };
      };
    };
  };

  for (at_i = 0; at_i < 8; at_i++) {
    if (B[increasingKnightMap[sq][at_i]] == sBkn) {
      if (at_s == 97) {
        at_s = increasingKnightMap[sq][at_i];
      } else {
        return true;
      }; //double check
    };
  };

  int at_ss = at_s;

  int at_sss = at_s;

  if (at_s == 97) {
    return false;
  }; //no check

  if (isAttByBla(at_ss) == true) {
    return true;
  }; //supported piece check

  if (isAttByWhi(at_sss) == false) {
    return true;
  }; //checking piece not attacked

  return false;
};

//if mate - return true
//first anayze king area if every square:
//- occupied by self piece or
//- is out of board or
//- is attacked by opponent
//than if double check or
//if supported check or
//opponent attacker is not covered by self piece
//opponent attacker is covered by self piece but self piece
//is pinned to the king on other vector
//all squares between opponent attacker and self king are not covered by self piece
//squares between opponent attacker and self king are covered by self piece but self piece
//is pinned to the king


//assumes king is being checked
bool isBkiMated()
{
//if (isAttByWhi(BkiPos)==false) {return false;};

//find if king can escape from check (analyze all king one step moves)
//if king can escape: return false
  for (ma_v = 0; ma_v < 8; ma_v++) {
    switch (B[Vec[ma_v][BkiPos][0]]) {
      case
          sEmp: {
          if (isAttByWhi(Vec[ma_v][BkiPos][0]) == false) {
            return false;
          };
        };

        break;
      case
          sWpa: {
          if (isAttByWhi(Vec[ma_v][BkiPos][0]) == false) {
            return false;
          };
        };

        break;
      case
          sWro: {
          if (isAttByWhi(Vec[ma_v][BkiPos][0]) == false) {
            return false;
          };
        };

        break;
      case
          sWbi: {
          if (isAttByWhi(Vec[ma_v][BkiPos][0]) == false) {
            return false;
          };
        };

        break;
      case
          sWkn: {
          if (isAttByWhi(Vec[ma_v][BkiPos][0]) == false) {
            return false;
          };
        };

        break;
      case
          sWqu: {
          if (isAttByWhi(Vec[ma_v][BkiPos][0]) == false) {
            return false;
          };
        };

        break;
    };
  };

//now detect double check, find reversed check vector and check_from sq
//erase check_from square number
  ma_check_from = 99;

//erase reversed vector of check (used by sliding pieces)
  ma_testv = 99;

//pawns
  if (B[LBPCaps[BkiPos]] == sWpa) {
    ma_check_from = LBPCaps[BkiPos]; //double check impossible
  } else
    if (B[RBPCaps[BkiPos]] == sWpa) {
      ma_check_from = RBPCaps[BkiPos]; //double check impossible
    } else {
      //bishop-like v
      for (ma_v = 0; ma_v < 4; ma_v++) {
        for (ma_i = 0; ma_i < 8; ma_i++) {
          switch (B[Vec[ma_v][BkiPos][ma_i]]) {
            case
                sEmp: {
                ;
              };

              break;
            case
                sWbi: {
                if (ma_check_from == 99) {
                  ma_testv = ma_v;
                  ma_dist = ma_i;
                  ma_check_from = Vec[ma_v][BkiPos][ma_i]; //single check
                  //now we should stop investigating curent ma_v vector
                  //because i.e. doubled rooks dont cause mate
                  ma_i = 8;
                } else {
                  return true;
                }; //double check==mate
              };

              break;
            case
                sWqu: {
                if (ma_check_from == 99) {
                  ma_testv = ma_v;
                  ma_dist = ma_i;
                  ma_check_from = Vec[ma_v][BkiPos][ma_i]; //single check
                  ma_i = 8;
                } else {
                  return true;
                }; //double check==mate
              };

              break;
            default
                : {
                ma_i = 8;
              };
          };
        };
      };

      //rook-like v
      for (ma_v = 4; ma_v < 8; ma_v++) {
        for (ma_i = 0; ma_i < 8; ma_i++) {
          switch (B[Vec[ma_v][BkiPos][ma_i]]) {
            case
                sEmp: {
                ;
              };

              break;
            case
                sWro: {
                if (ma_check_from == 99) {
                  ma_testv = ma_v;
                  ma_dist = ma_i;
                  ma_check_from = Vec[ma_v][BkiPos][ma_i]; //single check
                  ma_i = 8;
                } else {
                  return true;
                }; //double check==mate
              };

              break;
            case
                sWqu: {
                if (ma_check_from == 99) {
                  ma_testv = ma_v;
                  ma_dist = ma_i;
                  ma_check_from = Vec[ma_v][BkiPos][ma_i]; //single check
                  ma_i = 8;
                } else {
                  return true;
                }; //double check==mate
              };

              break;
            default
                : {
                ma_i = 8;
              };
          };
        };
      };

      for (ma_i = 0; ma_i < 8; ma_i++) {
        if (B[decreasingKnightMap[BkiPos][ma_i]] == sWkn) {
          if (ma_check_from == 99) {
            ma_check_from = decreasingKnightMap[BkiPos][ma_i]; //single check
          } else {
            return true;
          }; //double check
        };
      };
    };

/////////////////////////////////////////////////////////
//we have single piece check
//find on which squares are self pieces pinned to self king
//first analyse bishop-like vectors
  pnum = 0;

  for (ma_v = 0; ma_v < 4; ma_v++) {
    for (ma_i = 0; ma_i < 8; ma_i++) {
      switch (B[Vec[ma_v][BkiPos][ma_i]]) {
        case
            sEmp: {
            ;
          };

          break;
        case
            sBpa: {
            for (ma_j = (ma_i + 1); ma_j < 8; ma_j++) {
              switch (B[Vec[ma_v][BkiPos][ma_j]]) {
                case
                    sEmp: {
                    ;
                  };

                  break;
                case
                    sWbi: {
                    ma_Pinned[pnum] = Vec[ma_v][BkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                case
                    sWqu: {
                    ma_Pinned[pnum] = Vec[ma_v][BkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                default
                    : {
                    ma_i = 8;
                    break;
                  };
              };
            };
          };

          break;
        case
            sBro: {
            for (ma_j = (ma_i + 1); ma_j < 8; ma_j++) {
              switch (B[Vec[ma_v][BkiPos][ma_j]]) {
                case
                    sEmp: {
                    ;
                  };

                  break;
                case
                    sWbi: {
                    ma_Pinned[pnum] = Vec[ma_v][BkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                case
                    sWqu: {
                    ma_Pinned[pnum] = Vec[ma_v][BkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                default
                    : {
                    ma_i = 8;
                    break;
                  };
              };
            };
          };

          break;
        case
            sBbi: {
            for (ma_j = (ma_i + 1); ma_j < 8; ma_j++) {
              switch (B[Vec[ma_v][BkiPos][ma_j]]) {
                case
                    sEmp: {
                    ;
                  };

                  break;
                case
                    sWbi: {
                    ma_Pinned[pnum] = Vec[ma_v][BkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                case
                    sWqu: {
                    ma_Pinned[pnum] = Vec[ma_v][BkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                default
                    : {
                    ma_i = 8;
                    break;
                  };
              };
            };
          };

          break;
        case
            sBkn: {
            for (ma_j = (ma_i + 1); ma_j < 8; ma_j++) {
              switch (B[Vec[ma_v][BkiPos][ma_j]]) {
                case
                    sEmp: {
                    ;
                  };

                  break;
                case
                    sWbi: {
                    ma_Pinned[pnum] = Vec[ma_v][BkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                case
                    sWqu: {
                    ma_Pinned[pnum] = Vec[ma_v][BkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                default
                    : {
                    ma_i = 8;
                    break;
                  };
              };
            };
          };

          break;
        case
            sBqu: {
            for (ma_j = (ma_i + 1); ma_j < 8; ma_j++) {
              switch (B[Vec[ma_v][BkiPos][ma_j]]) {
                case
                    sEmp: {
                    ;
                  };

                  break;
                case
                    sWbi: {
                    ma_Pinned[pnum] = Vec[ma_v][BkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                case
                    sWqu: {
                    ma_Pinned[pnum] = Vec[ma_v][BkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                default
                    : {
                    ma_i = 8;
                    break;
                  };
              };
            };
          };

          break;
        default
            : {
            ma_i = 8;
            break;
          };
      };
    };
  };

//now analyse rook-like vectors
  for (ma_v = 4; ma_v < 8; ma_v++) {
    for (ma_i = 0; ma_i < 8; ma_i++) {
      switch (B[Vec[ma_v][BkiPos][ma_i]]) {
        case
            sEmp: {
            ;
          };

          break;
        case
            sBpa: {
            for (ma_j = (ma_i + 1); ma_j < 8; ma_j++) {
              switch (B[Vec[ma_v][BkiPos][ma_j]]) {
                case
                    sEmp: {
                    ;
                  };

                  break;
                case
                    sWro: {
                    ma_Pinned[pnum] = Vec[ma_v][BkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                case
                    sWqu: {
                    ma_Pinned[pnum] = Vec[ma_v][BkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                default
                    : {
                    ma_i = 8;
                    break;
                  };
              };
            };
          };

          break;
        case
            sBro: {
            for (ma_j = (ma_i + 1); ma_j < 8; ma_j++) {
              switch (B[Vec[ma_v][BkiPos][ma_j]]) {
                case
                    sEmp: {
                    ;
                  };

                  break;
                case
                    sWro: {
                    ma_Pinned[pnum] = Vec[ma_v][BkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                case
                    sWqu: {
                    ma_Pinned[pnum] = Vec[ma_v][BkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                default
                    : {
                    ma_i = 8;
                    break;
                  };
              };
            };
          };

          break;
        case
            sBbi: {
            for (ma_j = (ma_i + 1); ma_j < 8; ma_j++) {
              switch (B[Vec[ma_v][BkiPos][ma_j]]) {
                case
                    sEmp: {
                    ;
                  };

                  break;
                case
                    sWro: {
                    ma_Pinned[pnum] = Vec[ma_v][BkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                case
                    sWqu: {
                    ma_Pinned[pnum] = Vec[ma_v][BkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                default
                    : {
                    ma_i = 8;
                    break;
                  };
              };
            };
          };

          break;
        case
            sBkn: {
            for (ma_j = (ma_i + 1); ma_j < 8; ma_j++) {
              switch (B[Vec[ma_v][BkiPos][ma_j]]) {
                case
                    sEmp: {
                    ;
                  };

                  break;
                case
                    sWro: {
                    ma_Pinned[pnum] = Vec[ma_v][BkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                case
                    sWqu: {
                    ma_Pinned[pnum] = Vec[ma_v][BkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                default
                    : {
                    ma_i = 8;
                    break;
                  };
              };
            };
          };

          break;
        case
            sBqu: {
            for (ma_j = (ma_i + 1); ma_j < 8; ma_j++) {
              switch (B[Vec[ma_v][BkiPos][ma_j]]) {
                case
                    sEmp: {
                    ;
                  };

                  break;
                case
                    sWro: {
                    ma_Pinned[pnum] = Vec[ma_v][BkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                case
                    sWqu: {
                    ma_Pinned[pnum] = Vec[ma_v][BkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                default
                    : {
                    ma_i = 8;
                    break;
                  };
              };
            };
          };

          break;
        default
            : {
            ma_i = 8;
            break;
          };
      };
    };
  };

////////////////////////////////////////////////////
//now we have single check being done by piece standing
//on ma_check_from and king has nowwhere to go.
//we also have pinned-squares-list

//analyze if checking piece can be legally captured or
//analyze if squares on vector can be legally occupied by self piece
//(these are only noncapture moves).
//The move is legal if it is not being made from Pinned[] square.
//if one of the above moves is made from non-pinned square - return false
//if analysis end: return mate=true (function assumes king in check)
/////////////////////////////////

//now analyse attacks to white checking piece - try to legally kill it
//by black move pawn-capture
  if (B[LWPCaps[ma_check_from]] == sBpa) {
    ma_def = LWPCaps[ma_check_from];

    for (ma_j = 0; ma_j < pnum; ma_j++) {
      if (ma_def == ma_Pinned[ma_j]) {
        break;
      };
    };

    if (ma_j == pnum) {
      return false;
    };
  };

  if (B[RWPCaps[ma_check_from]] == sBpa) {
    ma_def = RWPCaps[ma_check_from];

    for (ma_j = 0; ma_j < pnum; ma_j++) {
      if (ma_def == ma_Pinned[ma_j]) {
        break;
      };
    };

    if (ma_j == pnum) {
      return false;
    };
  };

//by self bishop or queen at bishoplike vec
  for (ma_v = 0; ma_v < 4; ma_v++) {
    for (ma_i = 0; ma_i < 8; ma_i++) {
      switch (B[Vec[ma_v][ma_check_from][ma_i]]) {
        case
            sEmp: {
            ;
          };

          break;
        case
            sBbi: {
            ma_def = Vec[ma_v][ma_check_from][ma_i];

            for (ma_j = 0; ma_j < pnum; ma_j++) {
              if (ma_def == ma_Pinned[ma_j]) {
                break;
              };
            };

            if (ma_j == pnum) {
              return false;
            };

            break;
          };

        case
            sBqu: {
            ma_def = Vec[ma_v][ma_check_from][ma_i];

            for (ma_j = 0; ma_j < pnum; ma_j++) {
              if (ma_def == ma_Pinned[ma_j]) {
                break;
              };
            };

            if (ma_j == pnum) {
              return false;
            };

            break;
          };

        default
            : {
            break;
          };
      };
    };
  };

//by self rook or queen at rooklike vec
  for (ma_v = 4; ma_v < 8; ma_v++) {
    for (ma_i = 0; ma_i < 8; ma_i++) {
      switch (B[Vec[ma_v][ma_check_from][ma_i]]) {
        case
            sEmp: {
            ;
          };

          break;
        case
            sBro: {
            ma_def = Vec[ma_v][ma_check_from][ma_i];

            for (ma_j = 0; ma_j < pnum; ma_j++) {
              if (ma_def == ma_Pinned[ma_j]) {
                break;
              };
            };

            if (ma_j == pnum) {
              return false;
            };

            break;
          };

        case
            sBqu: {
            ma_def = Vec[ma_v][ma_check_from][ma_i];

            for (ma_j = 0; ma_j < pnum; ma_j++) {
              if (ma_def == ma_Pinned[ma_j]) {
                break;
              };
            };

            if (ma_j == pnum) {
              return false;
            };

            break;
          };

        default
            : {
            break;
          };
      };
    };
  };

//try to kill checking piece by self knight
  for (ma_i = 0; ma_i < 8; ma_i++) {
    if (B[increasingKnightMap[ma_check_from][ma_i]] == sBkn) {
      ma_def = increasingKnightMap[ma_check_from][ma_i];

      for (ma_j = 0; ma_j < pnum; ma_j++) {
        if (ma_def == ma_Pinned[ma_j]) {
          break;
        };
      };

      if (ma_j == pnum) {
        return false;
      };
    };
  };

//now analyze attacks to enpassant square if king attacked by
//long pawn move  - try to legally enpassant-capture it by black pawn
  if (enpassant == (ma_check_from + 8)) {
    if (B[LWPCaps[enpassant]] == sBpa) {
      ma_def = LWPCaps[enpassant];

      for (ma_j = 0; ma_j < pnum; ma_j++) {
        if (ma_def == ma_Pinned[ma_j]) {
          break;
        };
      };

      if (ma_j == pnum) {
        return false;
      };
    };

    if (B[RWPCaps[enpassant]] == sBpa) {
      ma_def = RWPCaps[enpassant];

      for (ma_j = 0; ma_j < pnum; ma_j++) {
        if (ma_def == ma_Pinned[ma_j]) {
          break;
        };
      };

      if (ma_j == pnum) {
        return false;
      };
    };
  };

//king captures analysed at the beginning

////////////////////////////////////////////////////////////////
//now analyse noncapture moves (putting self piece between
//attacker and the king)

//looping squares on the way between checking piece and king
  for (ma_y = 0; ma_y < ma_dist; ma_y++) {
    ma_x = Vec[ma_testv][BkiPos][ma_y]; //square (x)

    //now analyse pawn noncaptures
    //2-square move from initial pos
    if ((ma_x > 23) && (ma_x < 32) && (B[ma_x - 16] == sBpa) && (B[ma_x - 8] == sEmp)) {
      ma_def = ma_x - 16;

      for (ma_j = 0; ma_j < pnum; ma_j++) {
        if (ma_def == ma_Pinned[ma_j]) {
          break;
        };
      };

      if (ma_j == pnum) {
        return false;
      };
    };

    //1-square move
    if ((ma_x > 7) && (B[ma_x - 8] == sBpa)) {
      ma_def = ma_x - 8;

      for (ma_j = 0; ma_j < pnum; ma_j++) {
        if (ma_def == ma_Pinned[ma_j]) {
          break;
        };
      };

      if (ma_j == pnum) {
        return false;
      };
    };

    //try defend check by moving self bishop or queen along bishoplike vec
    for (ma_v = 0; ma_v < 4; ma_v++) {
      for (ma_i = 0; ma_i < 8; ma_i++) {
        switch (B[Vec[ma_v][ma_x][ma_i]]) {
          case
              sEmp: {
              ;
            };

            break;
          case
              sBbi: {
              ma_def = Vec[ma_v][ma_x][ma_i];

              for (ma_j = 0; ma_j < pnum; ma_j++) {
                if (ma_def == ma_Pinned[ma_j]) {
                  break;
                };
              };

              if (ma_j == pnum) {
                return false;
              };

              break;
            };

          case
              sBqu: {
              ma_def = Vec[ma_v][ma_x][ma_i];

              for (ma_j = 0; ma_j < pnum; ma_j++) {
                if (ma_def == ma_Pinned[ma_j]) {
                  break;
                };
              };

              if (ma_j == pnum) {
                return false;
              };

              break;
            };

          default
              : {
              break;
            };
        };
      };
    };

    //try defend check by moving self rook or queen along rooklike vec
    for (ma_v = 4; ma_v < 8; ma_v++) {
      for (ma_i = 0; ma_i < 8; ma_i++) {
        switch (B[Vec[ma_v][ma_x][ma_i]]) {
          case
              sEmp: {
              ;
            };

            break;
          case
              sBro: {
              ma_def = Vec[ma_v][ma_x][ma_i];

              for (ma_j = 0; ma_j < pnum; ma_j++) {
                if (ma_def == ma_Pinned[ma_j]) {
                  break;
                };
              };

              if (ma_j == pnum) {
                return false;
              };

              break;
            };

          case
              sBqu: {
              ma_def = Vec[ma_v][ma_x][ma_i];

              for (ma_j = 0; ma_j < pnum; ma_j++) {
                if (ma_def == ma_Pinned[ma_j]) {
                  break;
                };
              };

              if (ma_j == pnum) {
                return false;
              };

              break;
            };

          default
              : {
              break;
            };
        };
      };
    };

    //try to defend check by putting self knight on check vector
    for (ma_i = 0; ma_i < 8; ma_i++) {
      if (B[decreasingKnightMap[ma_x][ma_i]] == sBkn) {
        ma_def = decreasingKnightMap[ma_x][ma_i];

        for (ma_j = 0; ma_j < pnum; ma_j++) {
          if (ma_def == ma_Pinned[ma_j]) {
            break;
          };
        };

        if (ma_j == pnum) {
          return false;
        };
      };
    };
  };

  /*
    //debug-start
    cout<<"black MATED by move "<<printMove(gl_move)<<endl;
    printB("mate board:");
    //cout<<getPATH(0,60)<<endl;
  for (ma_j=0;ma_j<pnum;ma_j++) {
  cout<<"ma_Pinned["<<ma_j<<"]:"<<ma_Pinned[ma_j]<<endl;
  };
  cout<<"MATE_ends"<<endl;
    //debug-end
    */
  return true;
};


//assumes king is being checked
bool isWkiMated()
{
//if (isAttByBla(WkiPos)==false) {return false;};

//find if king can escape from check (analyze all king one step moves)
//if king can escape: return false
  for (ma_v = 0; ma_v < 8; ma_v++) {
    switch (B[Vec[ma_v][WkiPos][0]]) {
      case
          sEmp: {
          if (isAttByBla(Vec[ma_v][WkiPos][0]) == false) {
            return false;
          };
        };

        break;
      case
          sBpa: {
          if (isAttByBla(Vec[ma_v][WkiPos][0]) == false) {
            return false;
          };
        };

        break;
      case
          sBro: {
          if (isAttByBla(Vec[ma_v][WkiPos][0]) == false) {
            return false;
          };
        };

        break;
      case
          sBbi: {
          if (isAttByBla(Vec[ma_v][WkiPos][0]) == false) {
            return false;
          };
        };

        break;
      case
          sBkn: {
          if (isAttByBla(Vec[ma_v][WkiPos][0]) == false) {
            return false;
          };
        };

        break;
      case
          sBqu: {
          if (isAttByBla(Vec[ma_v][WkiPos][0]) == false) {
            return false;
          };
        };

        break;
    };
  };

//now detect double check, find reversed check vec and check_from sq
//erase check_from square number
  ma_check_from = 99;

//erase reversed vector of check (used by sliding pieces)
  ma_testv = 99;

//pawns
  if (B[LWPCaps[WkiPos]] == sBpa) {
    ma_check_from = LWPCaps[WkiPos]; //double check impossible
  } else
    if (B[RWPCaps[WkiPos]] == sBpa) {
      ma_check_from = RWPCaps[WkiPos]; //double check impossible
    } else {
      //bishop-like v
      for (ma_v = 0; ma_v < 4; ma_v++) {
        for (ma_i = 0; ma_i < 8; ma_i++) {
          switch (B[Vec[ma_v][WkiPos][ma_i]]) {
            case
                sEmp: {
                ;
              };

              break;
            case
                sBbi: {
                if (ma_check_from == 99) {
                  ma_testv = ma_v;
                  ma_dist = ma_i;
                  ma_check_from = Vec[ma_v][WkiPos][ma_i]; //single check
                  ma_i = 8;
                } else {
                  return true;
                }; //double check==mate
              };

              break;
            case
                sBqu: {
                if (ma_check_from == 99) {
                  ma_testv = ma_v;
                  ma_dist = ma_i;
                  ma_check_from = Vec[ma_v][WkiPos][ma_i]; //single check
                  ma_i = 8;
                } else {
                  return true;
                }; //double check==mate
              };

              break;
            default
                : {
                ma_i = 8;
              };
          };
        };
      };

      //rook-like v
      for (ma_v = 4; ma_v < 8; ma_v++) {
        for (ma_i = 0; ma_i < 8; ma_i++) {
          switch (B[Vec[ma_v][WkiPos][ma_i]]) {
            case
                sEmp: {
                ;
              };

              break;
            case
                sBro: {
                if (ma_check_from == 99) {
                  ma_testv = ma_v;
                  ma_dist = ma_i;
                  ma_check_from = Vec[ma_v][WkiPos][ma_i]; //single check
                  ma_i = 8;
                } else {
                  return true;
                }; //double check==mate
              };

              break;
            case
                sBqu: {
                if (ma_check_from == 99) {
                  ma_testv = ma_v;
                  ma_dist = ma_i;
                  ma_check_from = Vec[ma_v][WkiPos][ma_i]; //single check
                  ma_i = 8;
                } else {
                  return true;
                }; //double check==mate
              };

              break;
            default
                : {
                ma_i = 8;
              };
          };
        };
      };

      for (ma_i = 0; ma_i < 8; ma_i++) {
        if (B[decreasingKnightMap[WkiPos][ma_i]] == sBkn) {
          if (ma_check_from == 99) {
            ma_check_from = decreasingKnightMap[WkiPos][ma_i]; //single check
          } else {
            return true;
          }; //double check
        };
      };
    };

/////////////////////////////////////////////////////////
//we have single piece check
//find on which squares are self pieces pinned to self king
//first analyse bishop-like vectors
  pnum = 0;

  for (ma_v = 0; ma_v < 4; ma_v++) {
    for (ma_i = 0; ma_i < 8; ma_i++) {
      switch (B[Vec[ma_v][WkiPos][ma_i]]) {
        case
            sEmp: {
            ;
          };

          break;
        case
            sWpa: {
            for (ma_j = (ma_i + 1); ma_j < 8; ma_j++) {
              switch (B[Vec[ma_v][WkiPos][ma_j]]) {
                case
                    sEmp: {
                    ;
                  };

                  break;
                case
                    sBbi: {
                    ma_Pinned[pnum] = Vec[ma_v][WkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                case
                    sBqu: {
                    ma_Pinned[pnum] = Vec[ma_v][WkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                default
                    : {
                    ma_i = 8;
                    break;
                  };
              };
            };
          };

          break;
        case
            sWro: {
            for (ma_j = (ma_i + 1); ma_j < 8; ma_j++) {
              switch (B[Vec[ma_v][WkiPos][ma_j]]) {
                case
                    sEmp: {
                    ;
                  };

                  break;
                case
                    sBbi: {
                    ma_Pinned[pnum] = Vec[ma_v][WkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                case
                    sBqu: {
                    ma_Pinned[pnum] = Vec[ma_v][WkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                default
                    : {
                    ma_i = 8;
                    break;
                  };
              };
            };
          };

          break;
        case
            sWbi: {
            for (ma_j = (ma_i + 1); ma_j < 8; ma_j++) {
              switch (B[Vec[ma_v][WkiPos][ma_j]]) {
                case
                    sEmp: {
                    ;
                  };

                  break;
                case
                    sBbi: {
                    ma_Pinned[pnum] = Vec[ma_v][WkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                case
                    sBqu: {
                    ma_Pinned[pnum] = Vec[ma_v][WkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                default
                    : {
                    ma_i = 8;
                    break;
                  };
              };
            };
          };

          break;
        case
            sWkn: {
            for (ma_j = (ma_i + 1); ma_j < 8; ma_j++) {
              switch (B[Vec[ma_v][WkiPos][ma_j]]) {
                case
                    sEmp: {
                    ;
                  };

                  break;
                case
                    sBbi: {
                    ma_Pinned[pnum] = Vec[ma_v][WkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                case
                    sBqu: {
                    ma_Pinned[pnum] = Vec[ma_v][WkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                default
                    : {
                    ma_i = 8;
                    break;
                  };
              };
            };
          };

          break;
        case
            sWqu: {
            for (ma_j = (ma_i + 1); ma_j < 8; ma_j++) {
              switch (B[Vec[ma_v][WkiPos][ma_j]]) {
                case
                    sEmp: {
                    ;
                  };

                  break;
                case
                    sBbi: {
                    ma_Pinned[pnum] = Vec[ma_v][WkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                case
                    sBqu: {
                    ma_Pinned[pnum] = Vec[ma_v][WkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                default
                    : {
                    ma_i = 8;
                    break;
                  };
              };
            };
          };

          break;
        default
            : {
            ma_i = 8;
            break;
          };
      };
    };
  };

//now analyse rook-like vectors
  for (ma_v = 4; ma_v < 8; ma_v++) {
    for (ma_i = 0; ma_i < 8; ma_i++) {
      switch (B[Vec[ma_v][WkiPos][ma_i]]) {
        case
            sEmp: {
            ;
          };

          break;
        case
            sWpa: {
            for (ma_j = (ma_i + 1); ma_j < 8; ma_j++) {
              switch (B[Vec[ma_v][WkiPos][ma_j]]) {
                case
                    sEmp: {
                    ;
                  };

                  break;
                case
                    sBro: {
                    ma_Pinned[pnum] = Vec[ma_v][WkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                case
                    sBqu: {
                    ma_Pinned[pnum] = Vec[ma_v][WkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                default
                    : {
                    ma_i = 8;
                    break;
                  };
              };
            };
          };

          break;
        case
            sWro: {
            for (ma_j = (ma_i + 1); ma_j < 8; ma_j++) {
              switch (B[Vec[ma_v][WkiPos][ma_j]]) {
                case
                    sEmp: {
                    ;
                  };

                  break;
                case
                    sBro: {
                    ma_Pinned[pnum] = Vec[ma_v][WkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                case
                    sBqu: {
                    ma_Pinned[pnum] = Vec[ma_v][WkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                default
                    : {
                    ma_i = 8;
                    break;
                  };
              };
            };
          };

          break;
        case
            sWbi: {
            for (ma_j = (ma_i + 1); ma_j < 8; ma_j++) {
              switch (B[Vec[ma_v][WkiPos][ma_j]]) {
                case
                    sEmp: {
                    ;
                  };

                  break;
                case
                    sBro: {
                    ma_Pinned[pnum] = Vec[ma_v][WkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                case
                    sBqu: {
                    ma_Pinned[pnum] = Vec[ma_v][WkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                default
                    : {
                    ma_i = 8;
                    break;
                  };
              };
            };
          };

          break;
        case
            sWkn: {
            for (ma_j = (ma_i + 1); ma_j < 8; ma_j++) {
              switch (B[Vec[ma_v][WkiPos][ma_j]]) {
                case
                    sEmp: {
                    ;
                  };

                  break;
                case
                    sBro: {
                    ma_Pinned[pnum] = Vec[ma_v][WkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                case
                    sBqu: {
                    ma_Pinned[pnum] = Vec[ma_v][WkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                default
                    : {
                    ma_i = 8;
                    break;
                  };
              };
            };
          };

          break;
        case
            sWqu: {
            for (ma_j = (ma_i + 1); ma_j < 8; ma_j++) {
              switch (B[Vec[ma_v][WkiPos][ma_j]]) {
                case
                    sEmp: {
                    ;
                  };

                  break;
                case
                    sBro: {
                    ma_Pinned[pnum] = Vec[ma_v][WkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                case
                    sBqu: {
                    ma_Pinned[pnum] = Vec[ma_v][WkiPos][ma_i];
                    pnum++;
                    ma_i = 8;
                    break;
                  };

                default
                    : {
                    ma_i = 8;
                    break;
                  };
              };
            };
          };

          break;
        default
            : {
            ma_i = 8;
            break;
          };
      };
    };
  };

////////////////////////////////////////////////////
//now we have single check being done by piece standing
//on ma_check_from and king has nowwhere to go.
//we also have pinned-squares-list

//analyze if checking piece can be legally captured or
//analyze if squares on vector can be legally occupied by self piece
//(these are only noncapture moves).
//The move is legal if it is not being made from Pinned[] square.
//if one of the above moves is made from non-pinned square - return false
//if analysis end: return mate=true (function assumes king in check)
/////////////////////////////////

//now analyse attacks to white checking piece - try to legally kill it
//by black move pawn-capture
  if (B[LBPCaps[ma_check_from]] == sWpa) {
    ma_def = LBPCaps[ma_check_from];

    for (ma_j = 0; ma_j < pnum; ma_j++) {
      if (ma_def == ma_Pinned[ma_j]) {
        break;
      };
    };

    if (ma_j == pnum) {
      return false;
    };
  };

  if (B[RBPCaps[ma_check_from]] == sWpa) {
    ma_def = RBPCaps[ma_check_from];

    for (ma_j = 0; ma_j < pnum; ma_j++) {
      if (ma_def == ma_Pinned[ma_j]) {
        break;
      };
    };

    if (ma_j == pnum) {
      return false;
    };
  };

//by self bishop or queen at bishoplike vec
  for (ma_v = 0; ma_v < 4; ma_v++) {
    for (ma_i = 0; ma_i < 8; ma_i++) {
      switch (B[Vec[ma_v][ma_check_from][ma_i]]) {
        case
            sEmp: {
            ;
          };

          break;
        case
            sWbi: {
            ma_def = Vec[ma_v][ma_check_from][ma_i];

            for (ma_j = 0; ma_j < pnum; ma_j++) {
              if (ma_def == ma_Pinned[ma_j]) {
                break;
              };
            };

            if (ma_j == pnum) {
              return false;
            };

            break;
          };

        case
            sWqu: {
            ma_def = Vec[ma_v][ma_check_from][ma_i];

            for (ma_j = 0; ma_j < pnum; ma_j++) {
              if (ma_def == ma_Pinned[ma_j]) {
                break;
              };
            };

            if (ma_j == pnum) {
              return false;
            };

            break;
          };

        default
            : {
            break;
          };
      };
    };
  };

//by self rook or queen at rooklike vec
  for (ma_v = 4; ma_v < 8; ma_v++) {
    for (ma_i = 0; ma_i < 8; ma_i++) {
      switch (B[Vec[ma_v][ma_check_from][ma_i]]) {
        case
            sEmp: {
            ;
          };

          break;
        case
            sWro: {
            ma_def = Vec[ma_v][ma_check_from][ma_i];

            for (ma_j = 0; ma_j < pnum; ma_j++) {
              if (ma_def == ma_Pinned[ma_j]) {
                break;
              };
            };

            if (ma_j == pnum) {
              return false;
            };

            break;
          };

        case
            sWqu: {
            ma_def = Vec[ma_v][ma_check_from][ma_i];

            for (ma_j = 0; ma_j < pnum; ma_j++) {
              if (ma_def == ma_Pinned[ma_j]) {
                break;
              };
            };

            if (ma_j == pnum) {
              return false;
            };

            break;
          };

        default
            : {
            break;
          };
      };
    };
  };

//try to kill checking piece by self knight
  for (ma_i = 0; ma_i < 8; ma_i++) {
    if (B[decreasingKnightMap[ma_check_from][ma_i]] == sWkn) {
      ma_def = decreasingKnightMap[ma_check_from][ma_i];

      for (ma_j = 0; ma_j < pnum; ma_j++) {
        if (ma_def == ma_Pinned[ma_j]) {
          break;
        };
      };

      if (ma_j == pnum) {
        return false;
      };
    };
  };

//now analyze attacks to enpassant square if king attacked by
//long pawn move  - try to legally enpassant-capture it by black pawn
  if (enpassant == (ma_check_from - 8)) {
    if (B[LBPCaps[enpassant]] == sWpa) {
      ma_def = LBPCaps[enpassant];

      for (ma_j = 0; ma_j < pnum; ma_j++) {
        if (ma_def == ma_Pinned[ma_j]) {
          break;
        };
      };

      if (ma_j == pnum) {
        return false;
      };
    };

    if (B[RBPCaps[enpassant]] == sWpa) {
      ma_def = RBPCaps[enpassant];

      for (ma_j = 0; ma_j < pnum; ma_j++) {
        if (ma_def == ma_Pinned[ma_j]) {
          break;
        };
      };

      if (ma_j == pnum) {
        return false;
      };
    };
  };

//king captures analysed at the beginning

////////////////////////////////////////////////////////////////
//now analyse noncapture moves (putting self piece between
//attacker and the king)

//looping squares on the way between checking piece and king
  for (ma_y = 0; ma_y < ma_dist; ma_y++) {
    ma_x = Vec[ma_testv][WkiPos][ma_y]; //square (x)

    //now analyse pawn noncaptures
    //2-square move from initial pos
    if ((ma_x > 31) && (ma_x < 40) && (B[ma_x + 16] == sWpa) && (B[ma_x + 8] == sEmp)) {
      ma_def = ma_x + 16;

      for (ma_j = 0; ma_j < pnum; ma_j++) {
        if (ma_def == ma_Pinned[ma_j]) {
          break;
        };
      };

      if (ma_j == pnum) {
        return false;
      };
    };

    //1-square move
    if ((ma_x < 56) && (B[ma_x + 8] == sWpa)) {
      ma_def = ma_x + 8;

      for (ma_j = 0; ma_j < pnum; ma_j++) {
        if (ma_def == ma_Pinned[ma_j]) {
          break;
        };
      };

      if (ma_j == pnum) {
        return false;
      };
    };

    //try defend check by moving self bishop or queen along bishoplike vec
    for (ma_v = 0; ma_v < 4; ma_v++) {
      for (ma_i = 0; ma_i < 8; ma_i++) {
        switch (B[Vec[ma_v][ma_x][ma_i]]) {
          case
              sEmp: {
              ;
            };

            break;
          case
              sWbi: {
              ma_def = Vec[ma_v][ma_x][ma_i];

              for (ma_j = 0; ma_j < pnum; ma_j++) {
                if (ma_def == ma_Pinned[ma_j]) {
                  break;
                };
              };

              if (ma_j == pnum) {
                return false;
              };

              break;
            };

          case
              sWqu: {
              ma_def = Vec[ma_v][ma_x][ma_i];

              for (ma_j = 0; ma_j < pnum; ma_j++) {
                if (ma_def == ma_Pinned[ma_j]) {
                  break;
                };
              };

              if (ma_j == pnum) {
                return false;
              };

              break;
            };

          default
              : {
              break;
            };
        };
      };
    };

    //try defend check by moving self rook or queen along rooklike vec
    for (ma_v = 4; ma_v < 8; ma_v++) {
      for (ma_i = 0; ma_i < 8; ma_i++) {
        switch (B[Vec[ma_v][ma_x][ma_i]]) {
          case
              sEmp: {
              ;
            };

            break;
          case
              sWro: {
              ma_def = Vec[ma_v][ma_x][ma_i];

              for (ma_j = 0; ma_j < pnum; ma_j++) {
                if (ma_def == ma_Pinned[ma_j]) {
                  break;
                };
              };

              if (ma_j == pnum) {
                return false;
              };

              break;
            };

          case
              sWqu: {
              ma_def = Vec[ma_v][ma_x][ma_i];

              for (ma_j = 0; ma_j < pnum; ma_j++) {
                if (ma_def == ma_Pinned[ma_j]) {
                  break;
                };
              };

              if (ma_j == pnum) {
                return false;
              };

              break;
            };

          default
              : {
              break;
            };
        };
      };
    };

    //try to defend check by putting self knight on check vector
    for (ma_i = 0; ma_i < 8; ma_i++) {
      if (B[increasingKnightMap[ma_x][ma_i]] == sWkn) {
        ma_def = increasingKnightMap[ma_x][ma_i];

        for (ma_j = 0; ma_j < pnum; ma_j++) {
          if (ma_def == ma_Pinned[ma_j]) {
            break;
          };
        };

        if (ma_j == pnum) {
          return false;
        };
      };
    };
  };

  /*
  //debug-start
  cout<<"white MATED by move "<<printMove(gl_move)<<endl;
  printB("mate board:");
  //cout<<getPATH(0,60)<<endl;
  for (ma_j=0;ma_j<pnum;ma_j++) {
    cout<<"ma_Pinned["<<ma_j<<"]:"<<ma_Pinned[ma_j]<<endl;
  };
  cout<<"MATE_ends"<<endl;
  //debug-end
  */
  return true;
};

/*
//returns attack count. handles same line multiple attacks
unsigned int countAttByWhi(unsigned int sq) {

  at_n = 0;

 if (B[LBPCaps[sq]] == sWpa) {at_n++;};
 if (B[RBPCaps[sq]] == sWpa) {at_n++;};

  //rook-like v
  for (at_v=4;at_v<8;at_v++) {
    for (at_c=0;at_c<8;at_c++) {
     switch (B[Vec[at_v][sq][at_c]]) {
     case sEmp: {;}; break;
     case sWro: {at_n++;}; break;
     case sWqu: {at_n++;}; break;
     default: {at_c=8;};
   };
  };
  };

  //bishop-like v
 for (at_v=0;at_v<4;at_v++) {
    for (at_c=0;at_c<8;at_c++) {
      switch (B[Vec[at_v][sq][at_c]]) {
     case sEmp: {;}; break;
     case sWbi: {at_n++;}; break;
     case sWqu: {at_n++;}; break;
     default: {at_c=8;};
   };
  };
  };

  for(at_c=0;at_c<8;at_c++) {
    if (B[KnightMap[sq][at_c]]==sWkn) {at_n++;};
  };

  for (at_v=0;at_v<8;at_v++) {
    if (B[Vec[at_v][sq][0]]==sWki) {at_n++;};
  };

 return at_n;
};


//return attack count on square attacked by black pieces
unsigned int countAttByBla(int sq) {

  at_n=0;

 if (B[LWPCaps[sq]] == sBpa) {at_n++;};
  if (B[RWPCaps[sq]] == sBpa) {at_n++;};

 for (at_v=4;at_v<8;at_v++) {
    for (at_c=0;at_c<8;at_c++) {
     switch (B[Vec[at_v][sq][at_c]]) {
     case sEmp: {;}; break;
     case sBro: {at_n++;}; break;
     case sBqu: {at_n++;}; break;
     default: {at_c=8;};
   };
    };
  };
  for (at_v=0;at_v<4;at_v++) {
    for (at_c=0;at_c<8;at_c++) {
      switch (B[Vec[at_v][sq][at_c]]) {
     case sEmp: {;}; break;
     case sBbi: {at_n++;}; break;
     case sBqu: {at_n++;}; break;
     default: {at_c=8;};
   };
  };
  };

 for(at_c=0;at_c<8;at_c++) {
    if (B[KnightMap[sq][at_c]]==sBkn) {at_n++;};
  };

  for (at_v=0;at_v<8;at_v++) {
    if (B[Vec[at_v][sq][0]]==sBki) {at_n++;};
  };

  return at_n;
};
*/




//returns square index of least valuable piece square sq
unsigned char LeastValuableBlaAttFrom(unsigned char sq)
{
//pawn
  if (B[LWPCaps[sq]] == sBpa) {
    return (LWPCaps[sq]);
  }

  if (B[RWPCaps[sq]] == sBpa) {
    return (RWPCaps[sq]);
  }

//knight
  for (int c = 0; c < 8; c++) {
    if (B[decreasingKnightMap[sq][c]] == sBkn) {
      return (decreasingKnightMap[sq][c]);
    }
  };

//bishop
  for (int at_v = 0; at_v < 4; at_v++) {
    for (int c = 0; c < 8; c++) {
      switch (B[Vec[at_v][sq][c]]) {
        case
            sEmp: {
            ;
          };

          break;
        case
            sBbi: {
            return (Vec[at_v][sq][c]);
          };

        default
            : {
            c = 8;
          };
      };
    };
  };

//rook
  for (int at_v = 4; at_v < 8; at_v++) {
    for (int c = 0; c < 8; c++) {
      switch (B[Vec[at_v][sq][c]]) {
        case
            sEmp: {
            ;
          };

          break;
        case
            sBro: {
            return (Vec[at_v][sq][c]);
          };

        default
            : {
            c = 8;
          };
      };
    };
  };

//queen
  for (int at_v = 0; at_v < 8; at_v++) {
    for (int c = 0; c < 8; c++) {
      switch (B[Vec[at_v][sq][c]]) {
        case
            sEmp: {
            ;
          };

          break;
        case
            sBqu: {
            return Vec[at_v][sq][c];
          };

        default
            : {
            c = 8;
          };
      };
    };
  };

//king
  for (int at_v = 0; at_v < 8; at_v++) {
    if (B[Vec[at_v][sq][0]] == sBki) {
      return (Vec[at_v][sq][0]);
    }
  };

//none
  return 64;
};

//returns square index of least valuable piece square sq
unsigned char LeastValuableWhiAttFrom(unsigned char sq)
{
//pawn
  if (B[LBPCaps[sq]] == sWpa) {
    return (LBPCaps[sq]);
  }

  if (B[RBPCaps[sq]] == sWpa) {
    return (RBPCaps[sq]);
  }

//knight
  for (int c = 0; c < 8; c++) {
    if (B[increasingKnightMap[sq][c]] == sWkn) {
      return (increasingKnightMap[sq][c]);
    }
  };

//bishop
  for (int at_v = 0; at_v < 4; at_v++) {
    for (int c = 0; c < 8; c++) {
      switch (B[Vec[at_v][sq][c]]) {
        case
            sEmp: {
            ;
          };

          break;
        case
            sWbi: {
            return (Vec[at_v][sq][c]);
          };

        default
            : {
            c = 8;
          };
      };
    };
  };

//rook
  for (int at_v = 4; at_v < 8; at_v++) {
    for (int c = 0; c < 8; c++) {
      switch (B[Vec[at_v][sq][c]]) {
        case
            sEmp: {
            ;
          };

          break;
        case
            sWro: {
            return (Vec[at_v][sq][c]);
          };

        default
            : {
            c = 8;
          };
      };
    };
  };

//queen
  for (int at_v = 0; at_v < 8; at_v++) {
    for (int c = 0; c < 8; c++) {
      switch (B[Vec[at_v][sq][c]]) {
        case
            sEmp: {
            ;
          };

          break;
        case
            sWqu: {
            return Vec[at_v][sq][c];
          };

        default
            : {
            c = 8;
          };
      };
    };
  };

//king
  for (int at_v = 0; at_v < 8; at_v++) {
    if (B[Vec[at_v][sq][0]] == sWki) {
      return (Vec[at_v][sq][0]);
    }
  };

//none
  return 64;
};




void EV_SQUARE () {

	#ifdef DEBUG_VERSION
	ev_square_func_count++;
	#endif

	ev_score = 0;
  switch (B[ev_fs]) {
        //evaluate pawn. this code penalizes rank pawns
      case
        sWpa: {
          //update count of white pawns on dark squares
          ev_WpaBsqNum += BLACK_SQUARE_MATCH[ev_fs];

					ev_v = 0; //count attacks on pieces

					/*left pawn caps*/
          ev_temp = LWPCaps[ev_fs];

					//1) update attacks balance
          //Ballance[ev_temp]++;

          //2) award empty squares and opponent pieces coverage
          switch (B[ev_temp]) {
            case
              sEmp: {

                ev_score += evPawnEmptyCoverage;
                #ifdef DEBUG_EVAL
                if (display_eval_details==true) {
								  cout<<COL[ev_fs]<<ROW[ev_fs]
									<<": evPawnEmptyCoverage :"<<evPawnEmptyCoverage<<endl;
								};
								#endif
              };

              break;
            case
                sWpa: {

                ev_score += evPawnSelfPawnCoverage;
                #ifdef DEBUG_EVAL
								if (display_eval_details==true) {
      	          cout<<COL[ev_fs]<<ROW[ev_fs]
			            <<": evPawnSelfPawnCoverage :"<<evPawnSelfPawnCoverage<<endl;
								};
								#endif
              };

              break;
            case
                sBpa: {
                ev_score += evPawnOpponentPawnCoverage;
                #ifdef DEBUG_EVAL
								if (display_eval_details==true) {
      	          cout<<COL[ev_fs]<<ROW[ev_fs]
			            <<": evPawnOpponentPawnCoverage :"<<evPawnOpponentPawnCoverage<<endl;
								};
								#endif
                #ifdef ATTACKS_MAP
                BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								#endif
              };

              break;
            case
                sWro: {
                ;
              };

              break;
            case
                sBro: {
                ev_v++;
                ev_score += evPawnRookCoverage;
                #ifdef DEBUG_EVAL
								if (display_eval_details==true) {
      	          cout<<COL[ev_fs]<<ROW[ev_fs]
			            <<": evPawnRookCoverage :"<<evPawnRookCoverage<<endl;
								};
								#endif
								#ifdef ATTACKS_MAP
								BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								#endif
              };

              break;
            case
                sWbi: {
                ;
              };

              break;
            case
                sBbi: {
                ev_v++;
                ev_score += evPawnOpponentBishopCoverage;
                #ifdef DEBUG_EVAL
								if (display_eval_details==true) {
      	          cout<<COL[ev_fs]<<ROW[ev_fs]
			            <<": evPawnOpponentBishopCoverage :"<<evPawnOpponentBishopCoverage<<endl;
								};
								#endif
								#ifdef ATTACKS_MAP
								BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								#endif
              };

              break;
            case
                sWkn: {
                ;
              };

              break;
            case
                sBkn: {
                ev_v++;
                ev_score += evPawnKnightCoverage;
                #ifdef DEBUG_EVAL
								if (display_eval_details==true) {
      	          cout<<COL[ev_fs]<<ROW[ev_fs]
			            <<": evPawnKnightCoverage :"<<evPawnKnightCoverage<<endl;
								};
								#endif
								#ifdef ATTACKS_MAP
								BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								#endif
              };

              break;
            case
                sWki: {
                ;
              };

              break;
            case
                sBki: {
                ev_v++;
								ev_BkiSafetyScore -= evPawnCheck;

								//todo
								//attacks on king area, checks, double checks are handled in EVAL()
								// by analysing king area

                #ifdef DEBUG_EVAL
								if (display_eval_details==true) {
      	          cout<<COL[ev_fs]<<ROW[ev_fs]
			            <<":bki safety score evPawnCheck is :"<<-evPawnCheck<<endl;
								};
								#endif
								#ifdef ATTACKS_MAP
								BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								#endif

              };

              break; //Pk check
            case
                sWqu: {
                ;
              };

              break;
            case
                sBqu: {
                ev_v++;
                ev_score += evPawnQueenCoverage;
                #ifdef DEBUG_EVAL
								if (display_eval_details==true) {
      	          cout<<COL[ev_fs]<<ROW[ev_fs]
			            <<": evPawnQueenCoverage :"<<evPawnQueenCoverage<<endl;
								};
								#endif

								#ifdef ATTACKS_MAP
								BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								#endif
              };

              break;
          };

          // 3) score attack on king area
          ev_BkiSafetyScore -= (evPawnKingAreaCoverage * BkiArea[ev_temp]);

          //4) award centrality of board coverage
          ev_score += (CenterShortProximity[ev_temp] * evPawnCoverageCenterProximityScale);
          #ifdef DEBUG_EVAL
					if (display_eval_details==true) {
						cout<<COL[ev_fs]<<ROW[ev_fs]
					  <<": score of centrality of board coverage: "
					  <<(CenterShortProximity[ev_temp] * evPawnCoverageCenterProximityScale)<<endl;
				  };
					#endif

          /*right pawn caps*/
          ev_temp = RWPCaps[ev_fs];

          //1) update attacks balance
          //Ballance[ev_temp]++;

          //2) award empty squares and opponent pieces coverage
          switch (B[ev_temp]) {
            case
                sEmp: {
                ev_score += evPawnEmptyCoverage;
                #ifdef DEBUG_EVAL
                if (display_eval_details==true) {
								  cout<<COL[ev_fs]<<ROW[ev_fs]
									<<": evPawnEmptyCoverage :"<<evPawnEmptyCoverage<<endl;
								};
								#endif
              };

              break;
            case
                sWpa: {
                ev_score += evPawnSelfPawnCoverage;
                #ifdef DEBUG_EVAL
								if (display_eval_details==true) {
      	          cout<<COL[ev_fs]<<ROW[ev_fs]
			            <<": evPawnSelfPawnCoverage :"<<evPawnSelfPawnCoverage<<endl;
								};
								#endif
              };

              break;
            case
                sBpa: {
                ev_score += evPawnOpponentPawnCoverage;
                #ifdef DEBUG_EVAL
								if (display_eval_details==true) {
      	          cout<<COL[ev_fs]<<ROW[ev_fs]
			            <<": evPawnOpponentPawnCoverage :"<<evPawnOpponentPawnCoverage<<endl;
								};
								#endif
								#ifdef ATTACKS_MAP
								BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								#endif
              };

              break;
            case
                sWro: {
                ;
              };

              break;
            case
                sBro: {
                ev_v++;
                ev_score += evPawnRookCoverage;
                #ifdef DEBUG_EVAL
								if (display_eval_details==true) {
      	          cout<<COL[ev_fs]<<ROW[ev_fs]
			            <<": evPawnRookCoverage :"<<evPawnRookCoverage<<endl;
								};
								#endif
								#ifdef ATTACKS_MAP
								BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								#endif
              };

              break;
            case
                sWbi: {
                ;
              };

              break;
            case
                sBbi: {
                ev_v++;
                ev_score += evPawnOpponentBishopCoverage;
                #ifdef DEBUG_EVAL
								if (display_eval_details==true) {
      	          cout<<COL[ev_fs]<<ROW[ev_fs]
			            <<": evPawnOpponentBishopCoverage :"<<evPawnOpponentBishopCoverage<<endl;
								};
								#endif
								#ifdef ATTACKS_MAP
								BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								#endif
              };

              break;
            case
                sWkn: {
                ;
              };

              break;
            case
                sBkn: {
                ev_v++;
                ev_score += evPawnKnightCoverage;
                #ifdef DEBUG_EVAL
								if (display_eval_details==true) {
      	          cout<<COL[ev_fs]<<ROW[ev_fs]
			            <<": evPawnKnightCoverage :"<<evPawnKnightCoverage<<endl;
								};
								#endif
								#ifdef ATTACKS_MAP
								BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								#endif
              };

              break;
            case
                sWki: {
                ;
              };

              break;
            case
                sBki: {
                ev_v++;
								ev_BkiSafetyScore -= evPawnCheck;

								//todo:
								//attacks on king area, checks, double checks are handled in EVAL()
								// by analysing king area

                #ifdef DEBUG_EVAL
								if (display_eval_details==true) {
      	          cout<<COL[ev_fs]<<ROW[ev_fs]
			            <<": bki safety score evPawnCheck is :"<<-evPawnCheck<<endl;
								};
								#endif
								#ifdef ATTACKS_MAP
								BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								#endif
              };

              break; //Pk check
            case
                sWqu: {
                ;
              };

              break;
            case
                sBqu: {
                ev_v++;
                ev_score += evPawnQueenCoverage;
                #ifdef DEBUG_EVAL
								if (display_eval_details==true) {
      	          cout<<COL[ev_fs]<<ROW[ev_fs]
			            <<": evPawnQueenCoverage :"<<evPawnQueenCoverage<<endl;
								};
								#endif
								#ifdef ATTACKS_MAP
								BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								#endif

              };

              break;
          };

          //3) score attack on king area
          ev_BkiSafetyScore -= (evPawnKingAreaCoverage * BkiArea[ev_temp]);

          //4) award centrality of board coverage
          ev_score += (CenterShortProximity[ev_temp] * evPawnCoverageCenterProximityScale);
          #ifdef DEBUG_EVAL
          if (display_eval_details==true) {
					  cout<<COL[ev_fs]<<ROW[ev_fs]
					  <<": score of centrality of board coverage: "
					  <<(CenterShortProximity[ev_temp] * evPawnCoverageCenterProximityScale)<<endl;
				  };
					#endif
          ///////////////
					// **do some soffistic pawn evaluation**

					/*1) score pawn forks*/
          //award pawn if it attacks two pieces
          if (ev_v > 1) {
            ev_score += evPawnForks;
            #ifdef DEBUG_EVAL
            if (display_eval_details==true) {
 	            cout<<COL[ev_fs]<<ROW[ev_fs]
              <<": evPawnForks :"<<evPawnForks<<endl;
            };
						#endif
          };

          /*
           2) penalize blocked pawn. the pawn is blocked if there is no empty square
           just in front of it.
          */
          if ((B[Vec[StoNvec][ev_fs][0]]) != sEmp) {
            ev_score -= evPawnBlocked;
            #ifdef DEBUG_EVAL
						if (display_eval_details==true) {
  	          cout<<COL[ev_fs]<<ROW[ev_fs]
	            <<": evPawnBlocked :"<<evPawnBlocked<<endl;
						};
						#endif
          };

          /*
          3) award passed pawn - analyse center, left and right column in front of the pawn
          (use StoN vector). if the column is occupied by opponent PAWN - break,
                  else - award ev_score.
                  TODO - add bonus if no piece in front line of the passed pawn
          */
          ev_c = 1;

          ev_j = Vec[StoNvec][ev_fs][0];

          while (ev_j != 64) {
            if (B[ev_j] == sBpa) {
              ev_c = 0;
              break;
            };

            ev_j = Vec[StoNvec][ev_j][0];
          };

          if (ev_c == 1) {
            ev_j = Vec[SEtoNWvec][ev_fs][0];

            while (ev_j != 64) {
              if (B[ev_j] == sBpa) {
                ev_c = 0;
                break;
              };

              ev_j = Vec[StoNvec][ev_j][0];
            };

            if (ev_c == 1) {
              ev_j = Vec[SWtoNEvec][ev_fs][0];

              while (ev_j != 64) {
                if (B[ev_j] == sBpa) {
                  ev_c = 0;
                  break;
                };

                ev_j = Vec[StoNvec][ev_j][0];
              };
            };
          };

          //passed pawn found
          if (ev_c == 1) {
            ev_test = 0;
            //find if passed pawn is supported by self rook
            ev_j = Vec[NtoSvec][ev_fs][0];

            while (ev_j != 64) {
              if (B[ev_j] == sEmp) {
                ev_j = Vec[NtoSvec][ev_j][0];
                continue;
              };

              if (B[ev_j] == sWro) {
                //award rook-protected passed pawn
                ev_test = 1;
                ev_score += evPassedPawnRookProtection;

								#ifdef DEBUG_EVAL
								if (display_eval_details==true) {
      	          cout<<COL[ev_fs]<<ROW[ev_fs]
			            <<": evPassedPawnRookProtection :"<<evPassedPawnRookProtection<<endl;
								};
								#endif

                ev_score += (WpaAdv[ev_fs] * evPassedPawnAdvanceScale);

								#ifdef DEBUG_EVAL
								if (display_eval_details==true) {
      	          cout<<COL[ev_fs]<<ROW[ev_fs]
			            <<": score of rook protected passed pawn advance :"<<(WpaAdv[ev_fs] * evPassedPawnAdvanceScale)<<endl;
								};
								#endif

								break;
              } else {
                break;
              };
            };

            //award passed but rook-unprotected pawn advance
            if (ev_test == 0) {
              ev_score += (WpaAdv[ev_fs] * evPassedPawnAdvanceScale);
              #ifdef DEBUG_EVAL
							if (display_eval_details==true) {
    	          cout<<COL[ev_fs]<<ROW[ev_fs]
		            <<": score of passed but rook-unprotected pawn advance :"<<(WpaAdv[ev_fs] * evPassedPawnAdvanceScale)<<endl;
							};
							#endif
            };
          } else {
            //award pawn advance
            ev_score += (WpaAdv[ev_fs] * evPawnAdvanceScale);
            #ifdef DEBUG_EVAL
						if (display_eval_details==true) {
  	          cout<<COL[ev_fs]<<ROW[ev_fs]
	            <<": score of unpassed pawn advance :"<<(WpaAdv[ev_fs] * evPawnAdvanceScale)<<endl;
						};
						#endif

          };

          /*
            4) penalize weak pawn. pawn is weak if it cannot be defended by self pawn
           (no friendly pawn in left or right column on the pawn level
                    and one level beneath)
          */
          //west squares
          ev_j = Vec[EtoWvec][ev_fs][0];

          if (ev_j != 64) {
            if (B[ev_j] != sWpa) {
              ev_j = Vec[NtoSvec][ev_j][0];

              if (B[ev_j] != sWpa) {
                //east squares
                ev_j = Vec[WtoEvec][ev_fs][0];

                if (ev_j != 64) {
                  if (B[ev_j] != sWpa) {
                    ev_j = Vec[NtoSvec][ev_j][0];

                    if (B[ev_j] != sWpa) {
                      ev_score -= evWeakPawn;
                      #ifdef DEBUG_EVAL
											if (display_eval_details==true) {
     					          cout<<COL[ev_fs]<<ROW[ev_fs]
	            				  <<": evWeakPawn :"<<evWeakPawn<<endl;
											};
											#endif

											//specially penalize weak pawn located in the king area
	                    ev_WkiSafetyScore -= (WkiArea[ev_fs] * evWeakPawnInKingAreaPenalty);
	                    //this code should be sensitive to
											//material and king tropism scores
											//This is to do in the end of EVAL()


											#ifdef DEBUG_EVAL
											if (display_eval_details==true) {
											  if (WkiArea[ev_fs]==1) {
          	              cout<<COL[ev_fs]<<ROW[ev_fs]
    				  	          <<": evWeakPawnInKingAreaPenalty :"<<-evWeakPawnInKingAreaPenalty<<endl;
											  };
											};
									    #endif

                    };
                  };
                };
              };
            };
          };

          //5) award pawn proximity to self king
          ev_WkiSafetyScore += (ShortProximity[ev_fs][WkiPos] * evPawnSelfKingProximityScale);

					#ifdef DEBUG_EVAL
					if (display_eval_details==true) {
            cout<<COL[ev_fs]<<ROW[ev_fs]
	          <<": wki safety score of pawn proximity to self king :"<<(ShortProximity[ev_fs][WkiPos] * evPawnSelfKingProximityScale)<<endl;
				  };
				  #endif

					//award pawn proximity to opponent king
          //ev_score += (ShortProximity[ev_fs][BkiPos] * evPawnOpponentKingProximityScale);

					//6) award pawn to center proximity;
          ev_score += (CenterShortProximity[ev_fs] * evPawnCenterProximityScale);
					#ifdef DEBUG_EVAL
					if (display_eval_details==true) {
            cout<<COL[ev_fs]<<ROW[ev_fs]
	          <<": score of pawn to center proximity :"<<(CenterShortProximity[ev_fs] * evPawnCenterProximityScale)<<endl;
				  };
				  #endif

				};

        break;
      case
          sBpa: {
          //update count of black pawns on dark squares
          ev_BpaBsqNum += BLACK_SQUARE_MATCH[ev_fs];

					ev_v = 0; //count attacks on pieces

					/*left pawn caps*/
          ev_temp = LBPCaps[ev_fs];

          //1) update attacks ballance
          //Ballance[ev_temp]--;

          //2) award empty squares and opponent pieces coverage
          switch (B[ev_temp]) {
            case
                sEmp: {
                ev_score -= evPawnEmptyCoverage;
                #ifdef DEBUG_EVAL
            		if (display_eval_details==true) {
 	            	  cout<<COL[ev_fs]<<ROW[ev_fs]
              		<<": evPawnEmptyCoverage :"<<evPawnEmptyCoverage<<endl;
            		};
								#endif
              };
              break;
            case
                sBpa: {
                ev_score -= evPawnSelfPawnCoverage;
                #ifdef DEBUG_EVAL
            		if (display_eval_details==true) {
 	            	  cout<<COL[ev_fs]<<ROW[ev_fs]
              		<<": evPawnSelfPawnCoverage :"<<evPawnSelfPawnCoverage<<endl;
            		};
								#endif

              };
              break;
            case
                sWpa: {
                ev_score -= evPawnOpponentPawnCoverage;
                #ifdef DEBUG_EVAL
            		if (display_eval_details==true) {
 	            	  cout<<COL[ev_fs]<<ROW[ev_fs]
              		<<": evPawnOpponentPawnCoverage :"<<evPawnOpponentPawnCoverage<<endl;
            		};
								#endif
								#ifdef ATTACKS_MAP
                WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								#endif
              };

              break;
            case
                sBro: {
                ;
              };

              break;
            case
                sWro: {
                ev_v++;
                ev_score -= evPawnRookCoverage;
                #ifdef DEBUG_EVAL
            		if (display_eval_details==true) {
 	            	  cout<<COL[ev_fs]<<ROW[ev_fs]
              		<<": evPawnRookCoverage :"<<evPawnRookCoverage<<endl;
            		};
								#endif
								#ifdef ATTACKS_MAP
                WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								#endif
              };

              break;
            case
                sBbi: {
                ;
              };
              break;
            case
                sWbi: {
                ev_v++;
                ev_score -= evPawnOpponentBishopCoverage;
                #ifdef DEBUG_EVAL
            		if (display_eval_details==true) {
 	            	  cout<<COL[ev_fs]<<ROW[ev_fs]
              		<<": evPawnOpponentBishopCoverage :"<<evPawnOpponentBishopCoverage<<endl;
            		};
								#endif
								#ifdef ATTACKS_MAP
                WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								#endif
              };

              break;
            case
                sBkn: {
                ;
              };

              break;
            case
                sWkn: {
                ev_v++;
                ev_score -= evPawnKnightCoverage;
                #ifdef DEBUG_EVAL
            		if (display_eval_details==true) {
 	            	  cout<<COL[ev_fs]<<ROW[ev_fs]
              		<<": evPawnKnightCoverage :"<<evPawnKnightCoverage<<endl;
            		};
								#endif
								#ifdef ATTACKS_MAP
                WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								#endif
              };

              break;
            case
                sBki: {
                ;
              };

              break;
            case
                sWki: {
                ev_v++;
								ev_WkiSafetyScore -= evPawnCheck;

								//todo
								//attacks on king area, checks, double checks are handled in EVAL()
								// by analysing king area

                #ifdef DEBUG_EVAL
            		if (display_eval_details==true) {
 	            	  cout<<COL[ev_fs]<<ROW[ev_fs]
              		<<": ev wki safety score due to evPawnCheck :"<<-evPawnCheck<<endl;
            		};
								#endif
								#ifdef ATTACKS_MAP
                WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								#endif
              };

              break; //pK check
            case
                sBqu: {
                ;
              };

              break;
            case
                sWqu: {
                ev_v++;
                ev_score -= evPawnQueenCoverage;
                #ifdef DEBUG_EVAL
            		if (display_eval_details==true) {
 	            	  cout<<COL[ev_fs]<<ROW[ev_fs]
              		<<": evPawnQueenCoverage :"<<evPawnQueenCoverage<<endl;
            		};
								#endif
								#ifdef ATTACKS_MAP
                WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								#endif
              };

              break;
          };

          //3) score attack on king area
          ev_WkiSafetyScore -= (evPawnKingAreaCoverage * WkiArea[ev_temp]);

          //4) award centrality of board coverage
          ev_score -= (CenterShortProximity[ev_temp] * evPawnCoverageCenterProximityScale);
          #ifdef DEBUG_EVAL
          if (display_eval_details==true) {
 	          cout<<COL[ev_fs]<<ROW[ev_fs]
            <<": centrality of board coverage :"
						<<(CenterShortProximity[ev_temp] * evPawnCoverageCenterProximityScale)<<endl;
          };
					#endif

          /*right pawn caps*/
          ev_temp = RBPCaps[ev_fs];

          //1) update attacks ballance
          //Ballance[ev_temp]--;
          //todo - handle enpassant square to update ballance

          //2) award empty squares and opponent pieces coverage
          switch (B[ev_temp]) {
            case
                sEmp: {
                ev_score -= evPawnEmptyCoverage;
                #ifdef DEBUG_EVAL
            		if (display_eval_details==true) {
 	            	  cout<<COL[ev_fs]<<ROW[ev_fs]
              		<<": evPawnEmptyCoverage :"<<evPawnEmptyCoverage<<endl;
            		};
								#endif
              };
              break;
            case
                sBpa: {
                ev_score -= evPawnSelfPawnCoverage;
                #ifdef DEBUG_EVAL
            		if (display_eval_details==true) {
 	            	  cout<<COL[ev_fs]<<ROW[ev_fs]
              		<<": evPawnSelfPawnCoverage :"<<evPawnSelfPawnCoverage<<endl;
            		};
								#endif
              };
              break;
            case
                sWpa: {
                ev_score -= evPawnOpponentPawnCoverage;
                #ifdef DEBUG_EVAL
            		if (display_eval_details==true) {
 	            	  cout<<COL[ev_fs]<<ROW[ev_fs]
              		<<": evPawnOpponentPawnCoverage :"<<evPawnOpponentPawnCoverage<<endl;
            		};
								#endif
								#ifdef ATTACKS_MAP
                WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								#endif
              };

              break;
            case
                sBro: {
                ;
              };

              break;
            case
                sWro: {
                ev_v++;
                ev_score -= evPawnRookCoverage;
                #ifdef DEBUG_EVAL
            		if (display_eval_details==true) {
 	            	  cout<<COL[ev_fs]<<ROW[ev_fs]
              		<<": evPawnRookCoverage :"<<evPawnRookCoverage<<endl;
            		};
								#endif
								#ifdef ATTACKS_MAP
                WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								#endif
              };

              break;
            case
                sBbi: {
                ;
              };
              break;
            case
                sWbi: {
                ev_v++;
                ev_score -= evPawnOpponentBishopCoverage;
                #ifdef DEBUG_EVAL
            		if (display_eval_details==true) {
 	            	  cout<<COL[ev_fs]<<ROW[ev_fs]
              		<<": evPawnOpponentBishopCoverage :"<<evPawnOpponentBishopCoverage<<endl;
            		};
								#endif
								#ifdef ATTACKS_MAP
                WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								#endif
              };

              break;
            case
                sBkn: {
                ;
              };

              break;
            case
                sWkn: {
                ev_v++;
                ev_score -= evPawnKnightCoverage;
                #ifdef DEBUG_EVAL
            		if (display_eval_details==true) {
 	            	  cout<<COL[ev_fs]<<ROW[ev_fs]
              		<<": evPawnKnightCoverage :"<<evPawnKnightCoverage<<endl;
            		};
								#endif
								#ifdef ATTACKS_MAP
                WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								#endif
              };

              break;
            case
                sBki: {
                ;
              };

              break;
            case
                sWki: {
                ev_v++;

                //initially score pawn check
								ev_WkiSafetyScore -= evPawnCheck;
								//todo
								//attacks on king area, checks, double checks are handled in EVAL()
								// by analysing king area

                #ifdef DEBUG_EVAL
            		if (display_eval_details==true) {
 	            	  cout<<COL[ev_fs]<<ROW[ev_fs]
              		<<": ev wki safety score due to evPawnCheck :"<<-evPawnCheck<<endl;
            		};
								#endif
								#ifdef ATTACKS_MAP
                WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								#endif
              };

              break; //pK check
            case
                sBqu: {
                ;
              };

              break;
            case
                sWqu: {
                ev_v++;
                ev_score -= evPawnQueenCoverage;
                #ifdef DEBUG_EVAL
            		if (display_eval_details==true) {
 	            	  cout<<COL[ev_fs]<<ROW[ev_fs]
              		<<": evPawnQueenCoverage :"<<evPawnQueenCoverage<<endl;
            		};
								#endif
								#ifdef ATTACKS_MAP
                WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								#endif
              };

              break;
          };

          //3) score attack on king area
          ev_WkiSafetyScore -= (evPawnKingAreaCoverage * WkiArea[ev_temp]);

          //4) award centrality of board coverage
          ev_score -= (CenterShortProximity[ev_temp] * evPawnCoverageCenterProximityScale);
          #ifdef DEBUG_EVAL
          if (display_eval_details==true) {
 	          cout<<COL[ev_fs]<<ROW[ev_fs]
            <<": centrality of board coverage :"
						<<(CenterShortProximity[ev_temp] * evPawnCoverageCenterProximityScale)<<endl;
          };
					#endif
					///////////
					//* do some sophisticated pawn evaluation*//

          //1) score pawn forks. award pawn if it attacks two pieces
          if (ev_v > 1) {
            ev_score -= evPawnForks;
            #ifdef DEBUG_EVAL
        		if (display_eval_details==true) {
          	  cout<<COL[ev_fs]<<ROW[ev_fs]
          		<<": evPawnForks :"<<evPawnForks<<endl;
        		};
						#endif
          };

          /*
           2) penalize blocked pawn. the pawn is blocked if there is no empty square
           just in front of it.
          */
          if (B[Vec[NtoSvec][ev_fs][0]] != sEmp) {
            ev_score += evPawnBlocked;
            #ifdef DEBUG_EVAL
        		if (display_eval_details==true) {
          	  cout<<COL[ev_fs]<<ROW[ev_fs]
          		<<": evPawnBlocked :"<<evPawnBlocked<<endl;
        		};
						#endif
          };

          /*
          3) award passed pawn - analyse center, left and right column in front of the pawn
          (use NtoS vector). if the column is occupied by opponent pawn - break, else - award ev_score.
          */
          ev_c = 1;

          ev_j = Vec[NtoSvec][ev_fs][0];

          while (ev_j != 64) {
            if (B[ev_j] == sWpa) {
              ev_c = 0;
              break;
            };

            ev_j = Vec[NtoSvec][ev_j][0];
          };

          if (ev_c == 1) {
            ev_j = Vec[NWtoSEvec][ev_fs][0];

            while (ev_j != 64) {
              if (B[ev_j] == sWpa) {
                ev_c = 0;
                break;
              };

              ev_j = Vec[NtoSvec][ev_j][0];
            };

            if (ev_c == 1) {
              ev_j = Vec[NEtoSWvec][ev_fs][0];

              while (ev_j != 64) {
                if (B[ev_j] == sWpa) {
                  ev_c = 0;
                  break;
                };

                ev_j = Vec[NtoSvec][ev_j][0];
              };
            };
          };

          //passed pawn found
          if (ev_c == 1) {
            ev_test = 0;
            //find if passed pawn is supported by self rook
            ev_j = Vec[StoNvec][ev_fs][0];

            while (ev_j != 64) {
              if (B[ev_j] == sEmp) {
                ev_j = Vec[StoNvec][ev_j][0];
                continue;
              };

              if (B[ev_j] == sBro) {
                //award rook-protected passed pawn
                ev_test = 1;
                ev_score -= evPassedPawnRookProtection;

								#ifdef DEBUG_EVAL
            		if (display_eval_details==true) {
 	            	  cout<<COL[ev_fs]<<ROW[ev_fs]
              		<<": evPassedPawnRookProtection :"<<evPassedPawnRookProtection<<endl;
            		};
								#endif

								ev_score -= (BpaAdv[ev_fs] * evPassedPawnAdvanceScale);

								#ifdef DEBUG_EVAL
            		if (display_eval_details==true) {
 	            	  cout<<COL[ev_fs]<<ROW[ev_fs]
              		<<": rook-protected passed pawn advance score :"<<(BpaAdv[ev_fs] * evPassedPawnAdvanceScale)<<endl;
            		};
								#endif

                break;
              } else {
                break;
              };
            };

            //award passed but rook-unprotected pawn advance
            if (ev_test == 0) {
              ev_score -= (BpaAdv[ev_fs] * evPassedPawnAdvanceScale);
              #ifdef DEBUG_EVAL
          		if (display_eval_details==true) {
            	  cout<<COL[ev_fs]<<ROW[ev_fs]
            		<<": rook-unprotected passed pawn advance score :"<<(BpaAdv[ev_fs] * evPassedPawnAdvanceScale)<<endl;
          		};
							#endif
            };
          } else {
            //award pawn advance
            ev_score -= (BpaAdv[ev_fs] * evPawnAdvanceScale);
            #ifdef DEBUG_EVAL
        		if (display_eval_details==true) {
          	  cout<<COL[ev_fs]<<ROW[ev_fs]
          		<<": unpassed pawn advance score :"<<(BpaAdv[ev_fs] * evPawnAdvanceScale)<<endl;
        		};
						#endif
          };

          /*
            4) penalize weak pawn. pawn is weak if it cannot be defended by self pawn
           (no friendly pawn in left or right column on the pawn level
                    and one level beneath)
          */
          //west squares
          ev_j = Vec[EtoWvec][ev_fs][0];

          if (ev_j != 64) {
            if (B[ev_j] != sBpa) {
              ev_j = Vec[StoNvec][ev_j][0];

              if (B[ev_j] != sBpa) {
                //east squares
                ev_j = Vec[WtoEvec][ev_fs][0];

                if (ev_j != 64) {
                  if (B[ev_j] != sBpa) {
                    ev_j = Vec[StoNvec][ev_j][0];

                    if (B[ev_j] != sBpa) {

                      ev_score += evWeakPawn;
                      #ifdef DEBUG_EVAL
        							if (display_eval_details==true) {
          	  					cout<<COL[ev_fs]<<ROW[ev_fs]
          							<<": evWeakPawn :"<<evWeakPawn<<endl;
        							};
											#endif

											//specially penalize weak pawns in the king area
											ev_BkiSafetyScore -= (BkiArea[ev_fs] * evWeakPawnInKingAreaPenalty);

                      #ifdef DEBUG_EVAL
											if (display_eval_details==true) {
												if (BkiArea[ev_fs]==1) {
          	  					  cout<<COL[ev_fs]<<ROW[ev_fs]
          							  <<": bki safety score evWeakPawnInKingAreaPenalty :"<<-evWeakPawnInKingAreaPenalty<<endl;
        							  };
        							};
										  #endif
                    };
                  };
                };
              };
            };
          };

          //5) award pawn proximity to self king
          ev_BkiSafetyScore += (ShortProximity[ev_fs][BkiPos] * evPawnSelfKingProximityScale);

					#ifdef DEBUG_EVAL
				  if (display_eval_details==true) {
					  cout<<COL[ev_fs]<<ROW[ev_fs]
					  <<": bki score of pawn proximity to self king :"
						<<(ShortProximity[ev_fs][BkiPos] * evPawnSelfKingProximityScale)<<endl;
				  };
				  #endif

          //award pawn proximity to opponent king
          //ev_score -= (ShortProximity[ev_fs][WkiPos] * evPawnOpponentKingProximityScale);

					//6) award pawn to center proximity;
					ev_score -= (CenterShortProximity[ev_fs] * evPawnCenterProximityScale);
					#ifdef DEBUG_EVAL
				  if (display_eval_details==true) {
					  cout<<COL[ev_fs]<<ROW[ev_fs]
					  <<": score of pawn to center proximity :"
						<<(CenterShortProximity[ev_fs] * evPawnCenterProximityScale)<<endl;
				  };
				  #endif
        };

        break;

        //evaluate white rook
      case
          sWro: {
          //find possible rook moves
          for (ev_v = 4; ev_v < 8; ev_v++) {
            for (ev_c = 0; ev_c < 8; ev_c++) {
              ev_temp = Vec[ev_v][ev_fs][ev_c];

              if (ev_temp == 64) {
                break; // break if rank
              };

              //1) update attack ballance
              //Ballance[ev_temp]++;

              //2) initially score coverage of opponent king area
              ev_BkiSafetyScore += (BkiArea[ev_temp] * evRookKingAreaCoverage);

              //3) award centrality of board coverage
              ev_score += (CenterShortProximity[ev_temp] * evRookCoverageCenterProximityScale);
              #ifdef DEBUG_EVAL
				      if (display_eval_details==true) {
					      cout<<COL[ev_fs]<<ROW[ev_fs]
					      <<": score of centrality of board coverage of "<<COL[ev_temp]<<ROW[ev_temp]<<": "
						    <<(CenterShortProximity[ev_fs] * evRookCoverageCenterProximityScale)<<endl;
				      };
				      #endif

							//score coverage of pieces
              switch (B[ev_temp]) {
                case
                  sEmp: {
                    ev_score += evRookEmptyCoverage;
                    #ifdef DEBUG_EVAL
							      if (display_eval_details==true) {
								      cout<<COL[ev_fs]<<ROW[ev_fs]
								      <<": evRookEmptyCoverage : "<<evRookEmptyCoverage<<endl;
							      };
							      #endif
                  };
                  break;
                case
                  sWpa: {
                  	//todo: eventuallny add reveal threat for pawn sliding move
                  	//or pawn capture move
                    ev_score -= evRookSelfPawnCoveragePenalty; //turned off
                    ev_c = 8;
										#ifdef DEBUG_EVAL
							      if (display_eval_details==true) {
								      cout<<COL[ev_fs]<<ROW[ev_fs]
								      <<": evRookSelfPawnCoveragePenalty : "<<evRookSelfPawnCoveragePenalty<<endl;
							      };
							      #endif

                  };

                  break; //RP
                case
                    sBpa: {
                    //if rook is now to move - the result is from qs
                    ev_score += evRookPawnCoverage;
                    ev_c = 8;
                    #ifdef DEBUG_EVAL
							      if (display_eval_details==true) {
								      cout<<COL[ev_fs]<<ROW[ev_fs]
								      <<": evRookPawnCoverage : "<<evRookPawnCoverage<<endl;
							      };
							      #endif
							      #ifdef ATTACKS_MAP
										BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								    #endif
                  };

                  break;  //Rp
                case
                    sWro: {
                    ev_score += evRookSelfRookCoverage;
                    #ifdef DEBUG_EVAL
							      if (display_eval_details==true) {
								      cout<<COL[ev_fs]<<ROW[ev_fs]
								      <<": evRookSelfRookCoverage : "<<evRookSelfRookCoverage<<endl;
							      };
							      #endif

                    //handle double RR king area attack
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      };

											//1) update Ballance for x-ray attack
											//Ballance[ev_temp]++;

                      //2) score x-ray attack on king area
											//evBkiSafetyScore -= (RookRookKingAreaCoverage * BkiArea[ev_temp]);
											#ifdef DEBUG_EVAL
							        if (display_eval_details==true) {
								        cout<<COL[ev_fs]<<ROW[ev_fs]
								        <<": evBkiSafetyScore due to evRookRookKingAreaCoverage : "<<-evRookRookKingAreaCoverage<<endl;
							        };
							        #endif

											//3) score x-ray pieces coverage
                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBki: {
                            ev_c = 8;

                          };

                          break;
                        case
                            sWqu: {
                            //handle xray tripple RRQ king area attack
                            //( !!! dont award too much because RQ attack awards already)
                            ev_c++;

                            for (; ev_c < 8; ev_c++) {
                              ev_temp = Vec[ev_v][ev_fs][ev_c];

                              if (ev_temp == 64) {
                                break;
                              };

                              //1) update Ballance for x-ray attack
											        //Ballance[ev_temp]++;

                              //2) score x-ray attack on king area
											        //evBkiSafetyScore -= (RookRookQueenKingAreaCoverage * BkiArea[ev_temp]);
											        #ifdef DEBUG_EVAL
							                if (display_eval_details==true) {
								                cout<<COL[ev_fs]<<ROW[ev_fs]
								                <<": evBkiSafetyScore due to evRookRookQueenKingAreaCoverage : "<<-evRookRookQueenKingAreaCoverage<<endl;
							                };
							                #endif

                              switch (B[ev_temp]) {
                                case
                                    sEmp: {
                                    ;
                                  };

                                  break;
                                case
                                    sWpa: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBpa: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sWro: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBro: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sWbi: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBbi: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sWkn: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBkn: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sWki: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBki: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sWqu: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBqu: {
                                    ev_c = 8;
                                  };

                                  break;
                              };
                            };
                          };

                          break;
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break;
                      };
                    };
                  };

                  break; //RR
                case
                    sBro: {
                    ev_score += evRookOpponentRookCoverage;
                    ev_c = 8;

                    #ifdef DEBUG_EVAL
							      if (display_eval_details==true) {
								      cout<<COL[ev_fs]<<ROW[ev_fs]
								      <<": evRookOpponentRookCoverage : "<<evRookOpponentRookCoverage<<endl;
							      };
							      #endif
										#ifdef ATTACKS_MAP
										BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								    #endif
                  };

                  break; //Rr
                case
                    sWbi: { //RB

										//handle reveal threat
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      }

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break; //RBP
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break; //RBp
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break; //RBR
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break; //RBr
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break; //RBB
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break; //RBb
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break; //RBN
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break; //RBn
                        case
                            sWki: {
                            ev_c = 8;
                          };

                          break; //RBK
                        case
                            sBki: {                  //RBk reveal threat
                            ev_BkiSafetyScore -= evRookBishopKingRevealThreat;
                            ev_c = 8;

														#ifdef DEBUG_EVAL
							      				if (display_eval_details==true) {
								      				cout<<COL[ev_fs]<<ROW[ev_fs]
								      				<<":  ev_BkiSafetyScore due to evRookBishopKingRevealThreat : "<<-evRookBishopKingRevealThreat<<endl;
							      				};
							      				#endif
                          };

                          break;
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break; //RBQ
                        case
                            sBqu: {                  //RBq reveal threat
                            ev_score += evRookBishopQueenRevealThreat;
                            ev_c = 8;
                            #ifdef DEBUG_EVAL
							      				if (display_eval_details==true) {
								      				cout<<COL[ev_fs]<<ROW[ev_fs]
								      				<<": evRookBishopQueenRevealThreat : "<<evRookBishopQueenRevealThreat<<endl;
							      				};
							      				#endif
                          };
                          break;
                      };
                    };
                  };

                  break;
                case
                    sBbi: { //Rb
                    ev_score += evRookBishopCoverage;
                    #ifdef DEBUG_EVAL
			      				if (display_eval_details==true) {
				      				cout<<COL[ev_fs]<<ROW[ev_fs]
				      				<<": evRookBishopCoverage : "<<evRookBishopCoverage<<endl;
			      				};
			      				#endif
			      				#ifdef ATTACKS_MAP
										BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								    #endif

                    //handle pin
                    ev_test = ev_c;

                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      }

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break; //RbP
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break; //Rbp
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break; //RbR
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break; //Rbr
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break; //RbB
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break; //Rbb
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break; //RbN
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break; //Rbn
                        case
                            sWki: {
                            ev_c = 8;
                          };

                          break; //RbK
                        case
                            sBki: {
                            //award pin
                            ev_BkiSafetyScore -= evRookBishopKingPin;

														#ifdef DEBUG_EVAL
							      				if (display_eval_details==true) {
								      				cout<<COL[ev_fs]<<ROW[ev_fs]
								      				<<": ev_BkiSafetyScore due to evRookBishopKingPin : "<<-evRookBishopKingPin<<endl;
							      				};
							      				#endif

                            //if pinned piece is attacked by opponent pawn
                            ev_c = Vec[NEtoSWvec][ev_test][0];

                            if (B[ev_c] == sWpa) {
                              ev_BkiSafetyScore -= evRookBishopKingPinAttByPawn;

														  //todo: in EVAL() use Balance[] data to award number of attacks on pinned pieces
														  //and number of defences of pinned pieces.
														  //this may be implemented by defining a list of king-pinned squares
															//and non-king-pinned squares (king pin is better than i.e. queen pin)
														  //If Balance is won some extra scoring should be used because there is
														  //huge chance of winning the material.
														  //If attacker is also pinned everything looks more complicated,
														  //however the above code should be a good estimate.
														  //The above code will stimulate both defending of pinned pieces and bulding pin advantage

                              #ifdef DEBUG_EVAL
							      					if (display_eval_details==true) {
								      					cout<<COL[ev_fs]<<ROW[ev_fs]
								      					<<": evBkiSafetyScore due to evRookBishopKingPinAttByPawn : "<<-evRookBishopKingPinAttByPawn<<endl;
							      					};
							      					#endif
                            };

                            ev_c = Vec[NWtoSEvec][ev_test][0];

                            if (B[ev_c] == sWpa) {
															ev_BkiSafetyScore -= evRookBishopKingPinAttByPawn;

                              #ifdef DEBUG_EVAL
							      					if (display_eval_details==true) {
								      					cout<<COL[ev_fs]<<ROW[ev_fs]
								      					<<": evBkiSafetyScore due to evRookBishopKingPinAttByPawn : "<<-evRookBishopKingPinAttByPawn<<endl;
							      					};
							      					#endif
                            };

                            ev_c = 8;
                          };

                          break; //Rbk pin
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break; //RbQ
                        case
                            sBqu: {
                            //award pin
                            ev_score += evRookBishopQueenPin;
                            #ifdef DEBUG_EVAL
						      					if (display_eval_details==true) {
							      					cout<<COL[ev_fs]<<ROW[ev_fs]
							      					<<": evRookBishopQueenPin : "<<evRookBishopQueenPin<<endl;
						      					};
						      					#endif

                            //if pinned piece is attacked by opponent pawn
                            ev_c = Vec[NEtoSWvec][ev_test][0];

                            if (B[ev_c] == sWpa) {
                              ev_score += evRookBishopQueenPinAttByPawn;
                              #ifdef DEBUG_EVAL
							      					if (display_eval_details==true) {
								      					cout<<COL[ev_fs]<<ROW[ev_fs]
								      					<<": evRookBishopQueenPinAttByPawn : "<<evRookBishopQueenPinAttByPawn<<endl;
							      					};
							      					#endif
                            };

                            ev_c = Vec[NWtoSEvec][ev_test][0];

                            if (B[ev_c] == sWpa) {
                              ev_score += evRookBishopQueenPinAttByPawn;
                              #ifdef DEBUG_EVAL
							      					if (display_eval_details==true) {
								      					cout<<COL[ev_fs]<<ROW[ev_fs]
								      					<<": evRookBishopQueenPinAttByPawn : "<<evRookBishopQueenPinAttByPawn<<endl;
							      					};
							      					#endif
                            };

                            ev_c = 8;
                          };

                          break; //Rbq pin
                      };
                    };
                  };

                  break;
                case
                    sWkn: { //RN
                    //handle reveal threat
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      }

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break; //RNP
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break; //RNp
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break; //RNR
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break; //RNr
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break; //RNB
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break; //RNb
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break; //RNN
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break; //RNn
                        case
                            sWki: {
                            ev_c = 8;
                          };

                          break; //RNK
                        case
                            sBki: {
												    ev_BkiSafetyScore -= evRookKnightKingRevealThreat;

														#ifdef DEBUG_EVAL
						      					if (display_eval_details==true) {
							      					cout<<COL[ev_fs]<<ROW[ev_fs]
							      					<<": ev_BkiSafetyScore due to evRookKnightKingRevealThreat : "<<-evRookKnightKingRevealThreat<<endl;
						      					};
						      					#endif
                            ev_c = 8;
                          };

                          break; //RNk reveal threat
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break; //RNQ
                        case
                            sBqu: {
                            ev_score += evRookKnightQueenRevealThreat;


														#ifdef DEBUG_EVAL
						      					if (display_eval_details==true) {
							      					cout<<COL[ev_fs]<<ROW[ev_fs]
							      					<<": evRookKnightQueenRevealThreat : "<<evRookKnightQueenRevealThreat<<endl;
						      					};
						      					#endif
                            ev_c = 8;
                          };

                          break; //RNq reveal threat
                      };
                    };
                  };

                  break;
                case
                    sBkn: { //Rn
                    ev_score += evRookKnightCoverage;
                    #ifdef DEBUG_EVAL
		      					if (display_eval_details==true) {
			      					cout<<COL[ev_fs]<<ROW[ev_fs]
			      					<<": evRookKnightCoverage : "<<evRookKnightCoverage<<endl;
		      					};
		      					#endif
		      					#ifdef ATTACKS_MAP
										BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								    #endif

                    //handle pin
                    ev_test = ev_c;

                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      }

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break; //RnP
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break; //Rnp
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break; //RnR
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break; //Rnr
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break; //RnB
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break; //Rnb
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break; //RnN
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break; //Rnn
                        case
                            sWki: {
                            ev_c = 8;
                          };

                          break; //RnK
                        case
                            sBki: {
                            //award pin
												    ev_BkiSafetyScore -= evRookKnightKingPin;

														#ifdef DEBUG_EVAL
						      					if (display_eval_details==true) {
							      					cout<<COL[ev_fs]<<ROW[ev_fs]
							      					<<": ev_BkiSafetyScore due to evRookKnightKingPin : "<<-evRookKnightKingPin<<endl;
						      					};
						      					#endif

                            //if pinned piece is attacked by opponent pawn
                            ev_c = Vec[NEtoSWvec][ev_test][0];

                            if (B[ev_c] == sWpa) {

								              ev_BkiSafetyScore -= evRookKnightKingPinAttByPawn;

                              #ifdef DEBUG_EVAL
							      					if (display_eval_details==true) {
								      					cout<<COL[ev_fs]<<ROW[ev_fs]
								      					<<": ev_BkiSafetyScore due to evRookKnightKingPinAttByPawn : "<<-evRookKnightKingPinAttByPawn<<endl;
							      					};
							      					#endif
                            };

                            ev_c = Vec[NWtoSEvec][ev_test][0];

                            if (B[ev_c] == sWpa) {

															ev_BkiSafetyScore -= evRookKnightKingPinAttByPawn;

                              #ifdef DEBUG_EVAL
							      					if (display_eval_details==true) {
								      					cout<<COL[ev_fs]<<ROW[ev_fs]
								      					<<": ev_BkiSafetyScore due to evRookKnightKingPinAttByPawn : "<<-evRookKnightKingPinAttByPawn<<endl;
							      					};
							      					#endif
                            };

                            ev_c = 8;
                          };

                          break; //Rnk pin
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break; //RnQ
                        case
                            sBqu: {
                            //award pin
                            ev_score += evRookKnightQueenPin;

														#ifdef DEBUG_EVAL
						      					if (display_eval_details==true) {
							      					cout<<COL[ev_fs]<<ROW[ev_fs]
							      					<<": evRookKnightQueenPin : "<<evRookKnightQueenPin<<endl;
						      					};
						      					#endif

                            //if pinned piece is attacked by opponent pawn
                            ev_c = Vec[NEtoSWvec][ev_test][0];
                            //todo:
                            //instead of searching the pawn we should find least valuable attacker
                            //we should add some extra bonus in EVAL() if this attacker is not pinned.
                            //if this attacker is pinned - use next one.

                            if (B[ev_c] == sWpa) {
                              ev_score += evRookKnightQueenPinAttByPawn;
                              #ifdef DEBUG_EVAL
							      					if (display_eval_details==true) {
								      					cout<<COL[ev_fs]<<ROW[ev_fs]
								      					<<": evRookKnightQueenPinAttByPawn : "<<evRookKnightQueenPinAttByPawn<<endl;
							      					};
							      					#endif
                            };

                            ev_c = Vec[NWtoSEvec][ev_test][0];

                            if (B[ev_c] == sWpa) {
                              ev_score += evRookKnightQueenPinAttByPawn;
                              #ifdef DEBUG_EVAL
							      					if (display_eval_details==true) {
								      					cout<<COL[ev_fs]<<ROW[ev_fs]
								      					<<": evRookKnightQueenPinAttByPawn : "<<evRookKnightQueenPinAttByPawn<<endl;
							      					};
							      					#endif
                            };

                            ev_c = 8;
                          };

                          break; //Rnq pin
                      };
                    };
                  };

                  break;
                case
                    sWki: {
                    ev_c = 8;
                  };

                  break; //RK
                case
                    sBki: {

		                ev_BkiSafetyScore -= evRookCheck;

                    #ifdef DEBUG_EVAL
		      					if (display_eval_details==true) {
			      					cout<<COL[ev_fs]<<ROW[ev_fs]
			      					<<": ev_BkiSafetyScore due to evRookCheck : "<<-evRookCheck<<endl;
		      					};
		      					#endif
                    ev_c = 8;
                    #ifdef ATTACKS_MAP
										BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								    #endif

                  };

                  break; //Rk check
                case
                    sWqu: {
                    ev_score += evRookSelfQueenCoverage;
                    #ifdef DEBUG_EVAL
		      					if (display_eval_details==true) {
			      					cout<<COL[ev_fs]<<ROW[ev_fs]
			      					<<": evRookSelfQueenCoverage : "<<evRookSelfQueenCoverage<<endl;
		      					};
		      					#endif

                    //handle double RQ king area attack
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      };

                      //@@@@@@@


                      //update coverage of opponent king area
											if (BkiArea[ev_temp]==1) {
											  AttackedBkiAreaCounter[ev_temp]++;
                        //set king safety scores
											  ev_BkiSafetyScore -= evRookQueenKingAreaCoverage;

                        #ifdef DEBUG_EVAL
		      					    if (display_eval_details==true) {
			      					    cout<<COL[ev_fs]<<ROW[ev_fs]
			      					    <<": ev_BkiSafetyScore due to evRookQueenKingAreaCoverage : "<<-evRookQueenKingAreaCoverage<<endl;
		      					    };
		      					    #endif
                      };


                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWro: {

                            //handle tripple RQR king area attack
                            ev_c++;

                            for (; ev_c < 8; ev_c++) {
                              ev_temp = Vec[ev_v][ev_fs][ev_c];

                              if (ev_temp == 64) {
                                break;
                              };

                              //update coverage of opponent king area
                              AttackedBkiAreaCounter[ev_temp] += BkiArea[ev_temp];

                              //set king safety scores
											        ev_BkiSafetyScore -= evRookQueenRookKingAreaCoverage;

                              #ifdef DEBUG_EVAL
		      					          if (display_eval_details==true) {
			      					          cout<<COL[ev_fs]<<ROW[ev_fs]
			      					      <<": ev_BkiSafetyScore due to evRookQueenKingAreaCoverage : "<<-evRookQueenKingAreaCoverage<<endl;
		      					  };
		      					  #endif

                              switch (B[ev_temp]) {
                                case
                                    sEmp: {
                                    ;
                                  };

                                  break;
                                case
                                    sWpa: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBpa: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sWro: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBro: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sWbi: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBbi: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sWkn: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBkn: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sWki: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBki: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sWqu: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBqu: {
                                    ev_c = 8;
                                  };

                                  break;
                              };
                            };
                          };

                          break;
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break;
                      };
                    };
                  };

                  break; //RQ
                case
                    sBqu: {
                    ev_score += evRookQueenCoverage;
                    #ifdef DEBUG_EVAL
		      					if (display_eval_details==true) {
			      					cout<<COL[ev_fs]<<ROW[ev_fs]
			      					<<": evRookQueenCoverage : "<<evRookQueenCoverage<<endl;
		      					};
		      					#endif
		      					#ifdef ATTACKS_MAP
										BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								    #endif

                    //handle pin
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      }

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break; //RqP
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break; //Rqp
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break; //RqR
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break; //Rqr
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break; //RqB
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break; //Rqb
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break; //RqN
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break; //Rqn
                        case
                            sWki: {
                            ev_c = 8;
                          };

                          break; //RqK
                        case
                            sBki: {
                            ev_score += evRookQueenKingPin;

                            #ifdef GET_KING_SAFETY_SCORE
		                        ev_BkiSafetyScore += evRookQueenKingPin;
		                        #endif



														//detect pawn check
                            //detect pawn coverage of opponent king area
                            //detect weak pawn located in the king area (no friendly pawn
                            //    in left or right column on the pawn level and one level beneath)
                            //rate pawn proximity to self king
                            //detect RRk coverage of opponent king area
                            //detect RRQk coverage of opponent king area
                            //detect RBk reveal threat
                            //detect Rbk pin
                            //detect Rbk pin supported by pawn attack
                            //detect RNk reveal threat
                            //detect Rnk pin
                            //detect Rnk pin supported by pawn attack
                            //detect rook check
                            //detect double RQ king area attack
                            //detect tripple RQR king area attack
                            //detect Rqk pin

														#ifdef DEBUG_EVAL
						      					if (display_eval_details==true) {
							      					cout<<COL[ev_fs]<<ROW[ev_fs]
							      					<<": evRookQueenKingPin : "<<evRookQueenKingPin<<endl;
						      					};
						      					#endif
                            ev_c = 8;
                          };

                          break; //Rqk pin
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break; //RqQ
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break; //Rqq
                      };
                    };
                  };

                  break;
              };
            };
          };


					//award opponent king Proximity - dummy
          ev_score += (ShortProximity[ev_fs][BkiPos] * evRookOpponentKingProximityScale);

					#ifdef DEBUG_EVAL
					if (display_eval_details==true) {
  					cout<<COL[ev_fs]<<ROW[ev_fs]
  					<<": score of rook proximity to opponent king : "
						<<(ShortProximity[ev_fs][BkiPos] * evRookOpponentKingProximityScale)<<endl;
					};
					#endif

          //award self king Proximity - dummy
          ev_score += (ShortProximity[ev_fs][WkiPos] * evRookSelfKingProximityScale);
          #ifdef DEBUG_EVAL
					if (display_eval_details==true) {
  					cout<<COL[ev_fs]<<ROW[ev_fs]
  					<<": score of rook proximity to self king : "
						<<(ShortProximity[ev_fs][WkiPos] * evRookSelfKingProximityScale)<<endl;
					};
					#endif


          //award rook on seventh row placement
          if (rownum[ev_fs] == 7) {
            ev_score += evRookOnSeventh;
            #ifdef DEBUG_EVAL
						if (display_eval_details==true) {
	  					cout<<COL[ev_fs]<<ROW[ev_fs]
	  					<<": evRookOnSeventh : "<<evRookOnSeventh<<endl;
						};
						#endif
          };

          //award center Proximity
          ev_score += (CenterShortProximity[ev_fs] * evRookCenterProximityScale);
          #ifdef DEBUG_EVAL
					if (display_eval_details==true) {
  					cout<<COL[ev_fs]<<ROW[ev_fs]
  					<<": score of rook proximity to center : "
						<<(CenterShortProximity[ev_fs] * evRookCenterProximityScale)<<endl;
					};
					#endif
        };
        break;

        ////////////
        //evaluate black rook
      case
          sBro: {
          //award coverage
          //at first eval only some vectors!! @
          for (ev_v = 4; ev_v < 8; ev_v++) {
            for (ev_c = 0; ev_c < 8; ev_c++) {
              ev_temp = Vec[ev_v][ev_fs][ev_c];

              if (ev_temp == 64) {
                break; // break if rank
              };

              //update coverage of opponent king area
              AttackedWkiAreaCounter[ev_temp] += WkiArea[ev_temp];

              //award centrality of board coverage
              ev_score -= (CenterShortProximity[ev_temp] * evRookCoverageCenterProximityScale);
              //evBlaRookCoverageCenterProximityCnt += (CenterShortProximity[ev_temp] * evRookCoverageCenterProximityScale);

              switch (B[ev_temp]) {
                case
                    sEmp: {
                    ev_score -= evRookEmptyCoverage;
                    //evBlaRookEmptyCoverageCnt++;
                  };

                  break;

                case
                    sWpa: {
                    //if rook is now to move - the result is from qs
                    ev_score -= evRookPawnCoverage;
                    //evBlaRookPawnCoverageCnt++;
										#ifdef ATTACKS_MAP
                    WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								    #endif
                    ev_c = 8;
                  };

                break;  //rP

								case sBpa: {
										ev_score += evRookSelfPawnCoveragePenalty;
                    ev_c = 8;
										#ifdef DEBUG_EVAL
							      if (display_eval_details==true) {
								      cout<<COL[ev_fs]<<ROW[ev_fs]
								      <<": evRookSelfPawnCoveragePenalty : "<<evRookSelfPawnCoveragePenalty<<endl;
							      };
							      #endif
							    };
                  break; //rp

                //rR:
                case
                    sWro: {
                    ev_score -= evRookOpponentRookCoverage;
                    ev_c = 8;
                    #ifdef ATTACKS_MAP
                    WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								    #endif
                  };

                  break;
                //rr:
                case
                    sBro: {
                    ev_score -= evRookSelfRookCoverage;
                    //handle double rr king area attack
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      };

                      //update coverage of opponent king area
                      AttackedWkiAreaCounter[ev_temp] += WkiArea[ev_temp];

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBqu: {
                            //handle tripple rrq king area attack
                            ev_c++;

                            for (; ev_c < 8; ev_c++) {
                              ev_temp = Vec[ev_v][ev_fs][ev_c];

                              if (ev_temp == 64) {
                                break;
                              };

                              //update coverage of opponent king area
                              AttackedWkiAreaCounter[ev_temp] += WkiArea[ev_temp];

                              switch (B[ev_temp]) {
                                case
                                    sEmp: {
                                    ;
                                  };

                                  break;
                                case
                                    sWpa: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBpa: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sWro: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBro: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sWbi: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBbi: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sWkn: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBkn: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sWki: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBki: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sWqu: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBqu: {
                                    ev_c = 8;
                                  };

                                  break;
                              };
                            };
                          };

                          break;
                      };
                    };
                  };

                  break; //rr
                case
                    sWbi: { //rB
                    ev_score -= evRookBishopCoverage;

                    #ifdef ATTACKS_MAP
                    WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								    #endif

                    //handle pin
                    ev_test = ev_c;

                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      }

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break; //rBP
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break; //rBp
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break; //rBR
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break; //rBr
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break; //rBB
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break; //rBb
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break; //rBN
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break; //rBn

                          //rBK:
                        case
                            sWki: {
                            //award pin
                            ev_score -= evRookBishopKingPin;

                            //if pinned piece is attacked by opponent pawn
                            ev_c = Vec[SWtoNEvec][ev_test][0];

                            if (B[ev_c] == sBpa) {
                              ev_score -= evRookBishopKingPinAttByPawn;
                            };

                            ev_c = Vec[SEtoNWvec][ev_test][0];

                            if (B[ev_c] == sBpa) {
                              ev_score -= evRookBishopKingPinAttByPawn;
                            };

                            ev_c = 8;
                          };

                          break; //rBK pin
                        case
                            sBki: {
                            ev_c = 8;
                          };

                          break; //rBk

                          //rBQ
                        case
                            sWqu: {
                            //award pin
                            ev_score -= evRookBishopQueenPin;
                            //if pinned piece is attacked by opponent pawn
                            ev_c = Vec[SWtoNEvec][ev_test][0];

                            if (B[ev_c] == sBpa) {
                              ev_score -= evRookBishopQueenPinAttByPawn;
                            };

                            ev_c = Vec[SEtoNWvec][ev_test][0];

                            if (B[ev_c] == sBpa) {
                              ev_score -= evRookBishopQueenPinAttByPawn;
                            };

                            ev_c = 8;
                          };

                          break; //rBQ
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break; //rBq pin
                      };
                    };
                  };

                  break;
                case
                    sBbi: { //rb
                    //handle reveal threat
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      };

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWki: {
                            //rbK reveal threat
                            ev_score -= evRookBishopKingRevealThreat;
                            ev_c = 8;

                          };

                          break; //rbK
                        case
                            sBki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWqu: {
                            ev_score -= evRookBishopQueenRevealThreat;
                            ev_c = 8;

                            //@todo: bonus threat only if rook is protected enough?
                            //what if rook is protected but is attacked by other piece
                            //what if side of move changed
                            //when qs comes into play
                          };

                          break; //rbQ
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break;
                      };
                    };
                  };

                  break;
                case
                    sWkn: { //rN
                    ev_score -= evRookKnightCoverage;

                    #ifdef ATTACKS_MAP
                    WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								    #endif

                    //handle pin
                    ev_test = ev_c;

                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      };

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break; //rNP
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break; //rNp
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break; //rNR
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break; //rNr
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break; //rNB
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break; //rNb
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break; //rNN
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break; //rNn
                        case
                            sWki: {
                            //award pin rNK
                            ev_score -= evRookKnightKingPin;

                            //if pinned piece is attacked by opponent pawn
                            ev_c = Vec[SWtoNEvec][ev_test][0];

                            if (B[ev_c] == sBpa) {
                              ev_score -= evRookKnightKingPinAttByPawn;
                            };

                            ev_c = Vec[SEtoNWvec][ev_test][0];

                            if (B[ev_c] == sBpa) {
                              ev_score -= evRookKnightKingPinAttByPawn;
                            };

                            ev_c = 8;
                          };

                          break;
                        case
                            sBki: {
                            ev_c = 8;
                          };

                          break; //rNk

                          //rNQ pin:
                        case
                            sWqu: {
                            //award pin
                            ev_score -= evRookKnightQueenPin;

                            //if pinned piece is attacked by opponent pawn
                            ev_c = Vec[SWtoNEvec][ev_test][0];

                            if (B[ev_c] == sBpa) {
                              ev_score -= evRookKnightQueenPinAttByPawn;
                            };

                            ev_c = Vec[SEtoNWvec][ev_test][0];

                            if (B[ev_c] == sBpa) {
                              ev_score -= evRookKnightQueenPinAttByPawn;
                            };

                            ev_c = 8;
                          };

                          break; //rNQ
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break; //rnq
                      };
                    };
                  };

                  break;
                case
                    sBkn: { //rN
                    //handle reveal threat
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      }

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break; //rnP
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break; //rnp
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break; //rnR
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break; //rnr
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break; //rnB
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break; //rnb
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break; //rnN
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break; //rnn
                        case
                            sWki: {
                            ev_score -= evRookKnightKingRevealThreat;
                            ev_c = 8;
                          };

                          break; //rnK reveal threat
                        case
                            sBki: {
                            ev_c = 8;
                          };

                          break; //rnK
                        case
                            sWqu: {
                            ev_score -= evRookKnightQueenRevealThreat;
                            ev_c = 8;
                          };

                          break; //rnQ reveal threat
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break; //rnq
                      };
                    };
                  };

                  break;
                case
                    sWki: {
                    ev_score -= evCheck;
                    ev_c = 8;

                  };

                  break;
                case
                    sBki: {
                    ev_c = 8;
                  };

                  break; //rk

                  //rQ:
                case
                    sWqu: {
                    ev_score -= evRookQueenCoverage;

                    #ifdef ATTACKS_MAP
                    WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								    #endif

                    //handle pin
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      };

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break; //rQP
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break; //rQp
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break; //rQR
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break; //rQr
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break; //rQB
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break; //rQb
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break; //rQN
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break; //rQn
                        case
                            sWki: {
                            ev_score -= evRookQueenKingPin;
                            ev_c = 8;
                          };

                          break; //rQK pin
                        case
                            sBki: {
                            ev_c = 8;
                          };

                          break; //rQk
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break; //RqQ
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break; //Rqq
                      };
                    };
                  };

                  break;

                  //bqu
                case
                    sBqu: {
                    ev_score -= evRookSelfQueenCoverage;
                    //handle double rq king area attack
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      };

                      //update coverage of opponent king area
                      AttackedWkiAreaCounter[ev_temp] += WkiArea[ev_temp];

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBro: {
                            //handle tripple rqr king area attack
                            ev_c++;

                            for (; ev_c < 8; ev_c++) {
                              ev_temp = Vec[ev_v][ev_fs][ev_c];

                              if (ev_temp == 64) {
                                break;
                              };

                              //update coverage of opponent king area
                              AttackedWkiAreaCounter[ev_temp] += WkiArea[ev_temp];

                              switch (B[ev_temp]) {
                                case
                                    sEmp: {
                                    ;
                                  };

                                  break;
                                case
                                    sWpa: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBpa: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sWro: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBro: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sWbi: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBbi: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sWkn: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBkn: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sWki: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBki: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sWqu: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBqu: {
                                    ev_c = 8;
                                  };

                                  break;
                              };
                            };
                          };

                          break;
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break;
                      };
                    };
                  };

                  break; //rq
              };
            };
          };

          //award opponent king Proximity
          ev_score -= (ShortProximity[ev_fs][WkiPos] * evRookOpponentKingProximityScale);

          //award self king Proximity
          ev_score -= (ShortProximity[ev_fs][BkiPos] * evRookSelfKingProximityScale);

          //award rook on seventh row
          if (rownum[ev_fs] == 2) {
            ev_score -= evRookOnSeventh;
          };

          //award center
          ev_score -= (CenterShortProximity[ev_fs] * evRookCenterProximityScale);
        };

        break;

/////////////////////
//evaluate bishop
      case
			  sWbi: {
          //set flag for bishop squarecolour
          if (BLACK_SQUARE_MATCH[ev_fs]) {
            ev_WbiOnBsq = true;
          } else {
            ev_WbiOnWsq = true;
          };

          //award empty squares and opponent pieces coverage
          for (ev_v = 0; ev_v < 4; ev_v++) {
            for (ev_c = 0; ev_c < 8; ev_c++) {
              ev_temp = Vec[ev_v][ev_fs][ev_c];

              if (ev_temp == 64) {
                break; // break if rank
              };

              //update coverage of opponent king area
              AttackedBkiAreaCounter[ev_temp] += BkiArea[ev_temp];


              //award centrality of board coverage
              ev_score += (CenterShortProximity[ev_temp] * evBishopCoverageCenterProximityScale);

              switch (B[ev_temp]) {
                case
                    sEmp: {
                    ev_score += evBishopEmptyCoverage;
                  };

                  break;
                case
                    sWpa: {
                    ev_score -= evBishopSelfPawnCoveragePenalty;
                    ev_c = 8;
                  };

                  break; //BP
                case
                    sBpa: {
                    ev_score += evBishopPawnCoverage;
                    #ifdef ATTACKS_MAP
										BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								    #endif

                    ev_c = 8;
                  };

                  break;  //Bp
                case
                    sWro: {
                    //handle reveal threat BR
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      };

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break; //BRP
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break; //BRp
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break; //BRR
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break; //BRr
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break; //BRB
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break; //BRb
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break; //BRN
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break; //BRn
                        case
                            sWki: {
                            ev_c = 8;
                          };

                          break; //BRK
                        case
                            sBki: {
                            ev_score += evBishopRookKingRevealThreat;
                            ev_c = 8;
                          };

                          break; //BRk reveal threat
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break; //BRQ
                        case
                            sBqu: {
                            ev_score += evBishopRookQueenRevealThreat;
                            ev_c = 8;
                          };

                          break; //BRq reveal threat
                      };
                    };
                  };

                  break; //BR
                case
                    sBro: { //Br
                    ev_score += evBishopRookCoverage;

                    #ifdef ATTACKS_MAP
										BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								    #endif

                    //handle pin
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      };

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break; //BrP
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break; //Brp
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break; //BrR
                        case
                            sBro: {
                            ev_score += evBishopRookRookPin;
                            ev_c = 8;
                          };

                          break; //Brr pin
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break; //BrB
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break; //Brb
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break; //BrN
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break; //Brn
                        case
                            sWki: {
                            ev_c = 8;
                          };

                          break; //BrK
                        case
                            sBki: {
                            ev_score += evBishopRookKingPin;
                            ev_c = 8;
                          };

                          break; //Brk pin
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break; //BrQ
                        case
                            sBqu: {
                            ev_score += evBishopRookQueenPin;
                            ev_c = 8;
                          };

                          break; //Brq pin
                      };
                    };
                  };

                  break;
                case
                    sWbi: {
                    ev_c = 8;
                  };

                  break; //BB
                case
                    sBbi: {
                    ev_score += evBishopBishopCoverage;
										#ifdef ATTACKS_MAP
										BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								    #endif
                    ev_c = 8;
                  };

                  break; //Bb
                case
                    sWkn: {
                    ev_c = 8;
                  };

                  break; //BN
                case
                    sBkn: { //Bn
                    ev_score += evBishopKnightCoverage;
										#ifdef ATTACKS_MAP
										BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								    #endif
                    //handle pin
                    ev_test = ev_c;
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      };

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break; //BnP
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break; //Bnp
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break; //BnR
                        case
                            sBro: {
                            //award pin
                            ev_score += evBishopKnightRookPin;
                            //if pinned piece is attacked by opponent pawn
                            ev_c = Vec[NEtoSWvec][ev_test][0];

                            if (B[ev_c] == sWpa) {
                              ev_score += evBishopKnightRookPinAttByPawn;
                            };

                            ev_c = Vec[NWtoSEvec][ev_test][0];

                            if (B[ev_c] == sWpa) {
                              ev_score += evBishopKnightRookPinAttByPawn;
                            };

                            ev_c = 8;
                          };

                          break; //Bnr pin
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break; //BnB
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break; //Bnb
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break; //BnN
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break; //Bnn
                        case
                            sWki: {
                            ev_c = 8;
                          };

                          break; //BnK
                        case
                            sBki: {
                            //award pin
                            ev_score += evBishopKnightKingPin;
                            //if pinned piece is attacked by opponent pawn
                            ev_c = Vec[NEtoSWvec][ev_test][0];

                            if (B[ev_c] == sWpa) {
                              ev_score += evBishopKnightKingPinAttByPawn;
                            };

                            ev_c = Vec[NWtoSEvec][ev_test][0];

                            if (B[ev_c] == sWpa) {
                              ev_score += evBishopKnightKingPinAttByPawn;
                            };

                            ev_c = 8;
                          };

                          break; //Bnk pin
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break; //BnQ
                        case
                            sBqu: {
                            ev_score += evBishopKnightQueenPin;
                            //if pinned piece is attacked by opponent pawn
                            ev_c = Vec[NEtoSWvec][ev_test][0];

                            if (B[ev_c] == sWpa) {
                              ev_score += evBishopKnightQueenPinAttByPawn;
                            };

                            ev_c = Vec[NWtoSEvec][ev_test][0];

                            if (B[ev_c] == sWpa) {
                              ev_score += evBishopKnightQueenPinAttByPawn;
                            };

                            ev_c = 8;
                          };

                          break; //Bnq pin
                      };
                    };
                  };

                  break;
                case
                    sWki: {
                    ev_c = 8;
                  };

                  break; //BK
                case
                    sBki: {
                    ev_score += evCheck;
                    ev_c = 8;
										#ifdef ATTACKS_MAP
										BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								    #endif
                  };

                  break; //Bk check
                case
                    sWqu: {
                    ev_score += evBishopSelfQueenCoverage;
                    //handle BQ tandem coverage of king area
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      };

                      //update coverage of opponent king area
                      AttackedBkiAreaCounter[ev_temp] += BkiArea[ev_temp];

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break;
                      };
                    };
                  };

                  break; //BQ
                case
                    sBqu: { //Bq
                    ev_score += evBishopQueenCoverage;

                    #ifdef ATTACKS_MAP
										BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								    #endif

										//handle pin
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      }

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break; //BqP
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break; //Bqp
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break; //BqR
                        case
                            sBro: {
                            ev_score += evBishopQueenRookPin;
                            ev_c = 8;
                          };

                          break; //Bqr pin
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break; //BqB
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break; //Bqb
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break; //BqN
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break; //Bqn
                        case
                            sWki: {
                            ev_c = 8;
                          };

                          break; //BqK
                        case
                            sBki: {
                            ev_score += evBishopQueenKingPin;
                            ev_c = 8;
                          };

                          break; //Bqk pin
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break; //BqQ
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break; //Bqq
                      };
                    };
                  };

                  break;
              };
            };
          };

          //award opponent king Proximity
          ev_score += (ShortProximity[ev_fs][BkiPos] * evBishopOpponentKingProximityScale);

          //award self king Proximity
          ev_score += (ShortProximity[ev_fs][WkiPos] * evBishopSelfKingProximityScale);

          //award center
          ev_score += (CenterShortProximity[ev_fs] * evBishopCenterProximityScale);
        };

        break;
      case
          sBbi: {
          //set flag for bishop squarecolour
          if (BLACK_SQUARE_MATCH[ev_fs]) {
            ev_BbiOnBsq = true;
          } else {
            ev_BbiOnWsq = true;
          };

          //award empty squares and opponent pieces coverage
          for (ev_v = 0; ev_v < 4; ev_v++) {
            for (ev_c = 0; ev_c < 8; ev_c++) {
              ev_temp = Vec[ev_v][ev_fs][ev_c];

              if (ev_temp == 64) {
                break; // break if rank
              };

              //update coverage of opponent king area
              AttackedWkiAreaCounter[ev_temp] += WkiArea[ev_temp];


              //award centrality of board coverage
              ev_score -= (CenterShortProximity[ev_temp] * evBishopCoverageCenterProximityScale);

              switch (B[ev_temp]) {
                case
                    sEmp: {
                    ev_score -= evBishopEmptyCoverage;
                  };

                  break;
                case
                    sWpa: {
                    ev_score -= evBishopPawnCoverage;

										#ifdef ATTACKS_MAP
                    WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								    #endif

                    ev_c = 8;
                  };

                  break;  //bP
                case
                    sBpa: {
                    ev_score += evBishopSelfPawnCoveragePenalty;
                    ev_c = 8;
                  };

                  break; //bp
                case
                    sWro: { //bR
                    ev_score -= evBishopRookCoverage;
                    #ifdef ATTACKS_MAP
                    WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								    #endif

                    //handle pin
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      }

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWro: {
                            ev_score -= evBishopRookRookPin;
                            ev_c = 8;
                          };

                          break; //bRR pin
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWki: {
                            ev_score -= evBishopRookKingPin;
                            ev_c = 8;
                          };

                          break; //bRK pin
                        case
                            sBki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWqu: {
                            ev_score -= evBishopRookQueenPin;
                            ev_c = 8;
                          };

                          break; //bRQ pin
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break;
                      };
                    };
                  };

                  break;
                case
                    sBro: {
                    //handle br reveal threat
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      };

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break; //brP
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break; //brp
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break; //brR
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break; //brr
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break; //brB
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break; //brb
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break; //brN
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break; //brn
                        case
                            sWki: {
                            ev_score -= evBishopRookKingRevealThreat;
                            ev_c = 8;
                          };

                          break; //brK reveal threat
                        case
                            sBki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWqu: {
                            ev_score -= evBishopRookQueenRevealThreat;
                            ev_c = 8;
                          };

                          break; //brQ reveal threat
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break; //brq
                      };
                    };
                  };

                  break; //br
                case
                    sWbi: {
                    ev_score -= evBishopBishopCoverage;
										#ifdef ATTACKS_MAP
                    WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								    #endif
                    ev_c = 8;
                  };

                  break; //bB
                case
                    sBbi: {
                    ev_c = 8;
                  };

                  break;
                case
                    sWkn: { //bN
                    ev_score -= evBishopKnightCoverage;

                    #ifdef ATTACKS_MAP
                    WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								    #endif

                    //handle pin
                    ev_test = ev_c;
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      }

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWro: {
                            //award pin
                            ev_score -= evBishopKnightRookPin;
                            //if pinned piece is attacked by opponent pawn
                            ev_c = Vec[SEtoNWvec][ev_test][0];

                            if (B[ev_c] == sBpa) {
                              ev_score -= evBishopKnightRookPinAttByPawn;
                            };

                            ev_c = Vec[SWtoNEvec][ev_test][0];

                            if (B[ev_c] == sBpa) {
                              ev_score -= evBishopKnightRookPinAttByPawn;
                            };

                            ev_c = 8;
                          };

                          break; //bNR pin
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWki: {
                            //award pin
                            ev_score -= evBishopKnightKingPin;
                            //if pinned piece is attacked by opponent pawn
                            ev_c = Vec[SEtoNWvec][ev_test][0];

                            if (B[ev_c] == sBpa) {
                              ev_score -= evBishopKnightKingPinAttByPawn;
                            };

                            ev_c = Vec[SWtoNEvec][ev_test][0];

                            if (B[ev_c] == sBpa) {
                              ev_score -= evBishopKnightKingPinAttByPawn;
                            };

                            ev_c = 8;
                          };

                          break; //bNK pin
                        case
                            sBki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWqu: {
                            //award pin
                            ev_score -= evBishopKnightQueenPin;
                            //if pinned piece is attacked by opponent pawn
                            ev_c = Vec[SEtoNWvec][ev_test][0];

                            if (B[ev_c] == sBpa) {
                              ev_score -= evBishopKnightQueenPinAttByPawn;
                            };

                            ev_c = Vec[SWtoNEvec][ev_test][0];

                            if (B[ev_c] == sBpa) {
                              ev_score -= evBishopKnightQueenPinAttByPawn;
                            };

                            ev_c = 8;
                          };

                          break; //bNQ pin
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break;
                      };
                    };
                  };

                  break;
                case
                    sBkn: {
                    ev_c = 8;
                  };

                  break; //bn
                case
                    sWki: {
                    ev_score -= evCheck;
                    ev_c = 8;
										#ifdef ATTACKS_MAP
                    WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								    #endif
                  };

                  break; //bK check
                case
                    sBki: {
                    ev_c = 8;
                  };

                  break;
                case
                    sWqu: { //bQ
                    ev_score -= evBishopQueenCoverage;
                    #ifdef ATTACKS_MAP
                    WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
								    #endif

                    //handle pin
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      }

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWro: {
                            ev_score -= evBishopQueenRookPin;
                            ev_c = 8;
                          };

                          break; //bQR pin
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWki: {
                            ev_score -= evBishopQueenKingPin;
                            ev_c = 8;
                          };

                          break; //bQK pin
                        case
                            sBki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break;
                      };
                    };
                  };

                  break;
                case
                    sBqu: {
                    ev_score -= evBishopSelfQueenCoverage;
                    //handle bq tandem coverage of king area
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      };

                      //update coverage of opponent king area
                      AttackedWkiAreaCounter[ev_temp] += WkiArea[ev_temp];

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break;
                      };
                    };
                  };

                  break;
              };
            };
          };

          //award opponent king Proximity
          ev_score -= (ShortProximity[ev_fs][WkiPos] * evBishopOpponentKingProximityScale);

          //award self king Proximity
          ev_score -= (ShortProximity[ev_fs][BkiPos] * evBishopSelfKingProximityScale);

          //award center
          ev_score -= (CenterShortProximity[ev_fs] * evBishopCenterProximityScale);
        };

        break;

//evaluate knight
      case
          sWkn: {
          ev_v = 0; //attack count

          for (ev_c = 0; ev_c < 8; ev_c++) {
            ev_temp = decreasingKnightMap[ev_fs][ev_c];

            if (ev_temp == 64) {
							ev_score -= evKnightOutOfBoardCoverage;
              continue;
            };

            //update coverage of opponent king area
            AttackedBkiAreaCounter[ev_temp] += BkiArea[ev_temp];

            //award centrality of board coverage
            ev_score += (CenterShortProximity[ev_temp] * evKnightCoverageCenterProximityScale);

            switch (B[ev_temp]) {
              case
                  sEmp: {
                  ev_score += evKnightEmptyCoverage;
                };

                break;
              case
                  sWpa: {
                  ev_score -= evKnightSelfPawnCoveragePenalty;
                };

                break;
              case
                  sBpa: {
                  ev_v++;
                  ev_score += evKnightPawnCoverage;
                  #ifdef ATTACKS_MAP
									BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                  #endif
                };

                break;
              case
                  sWro: {
                  ;
                };

                break;
              case
                  sBro: {
                  ev_v++;
                  ev_score += evKnightRookCoverage;
                  #ifdef ATTACKS_MAP
									BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                  #endif
                };

                break;
              case
                  sWbi: {
                  ;
                };

                break;
              case
                  sBbi: {
                  ev_v++;
                  ev_score += evKnightBishopCoverage;
                  #ifdef ATTACKS_MAP
									BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                  #endif
                };

                break;
              case
                  sWkn: {
                  ;
                };

                break;
              case
                  sBkn: {
                  ev_score += evKnightKnightCoverage;
                  #ifdef ATTACKS_MAP
									BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                  #endif
                };

                break; //dont count Nn
              case
                  sWki: {
                  ;
                };

                break;
              case
                  sBki: {
                  ev_v++;
                  ev_score += evCheck;
									#ifdef ATTACKS_MAP
									BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                  #endif
                };

                break; //Nk check
              case
                  sWqu: {
                  ;
                };

                break;
              case
                  sBqu: {
                  ev_v++;
                  ev_score += evKnightQueenCoverage;
                  #ifdef ATTACKS_MAP
									BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                  #endif
                };

                break;
            };
          };

          //forks
          if (ev_v > 1) {
            ev_score += evKnightForks;
            //todo: create scalable knight forks scale
            //if a forking piece has already moved - set extention
            //if (gl_ts==ev_temp) {
            //};
          };

          //award opponent king Proximity
          ev_score += (ShortProximity[ev_fs][BkiPos] * evKnightOpponentKingProximityScale);

          //award self king Proximity
          ev_score += (ShortProximity[ev_fs][WkiPos] * evKnightSelfKingProximityScale);

          //award center
          ev_score += (CenterShortProximity[ev_fs] * evKnightCenterProximityScale);

          /*
          //add penalty if knight on its initial square
          if ((ev_fs==57) || (ev_fs==62)) {
          ev_score -= 10;
          };
          */
        };

        break;
      case
          sBkn: {
          ev_v = 0;

          for (ev_c = 0; ev_c < 8; ev_c++) {
            ev_temp = increasingKnightMap[ev_fs][ev_c];

            if (ev_temp == 64) {
              ev_score += evKnightOutOfBoardCoverage;
              continue;
            };

            //update coverage of opponent king area
            AttackedWkiAreaCounter[ev_temp] += WkiArea[ev_temp];

            //award centrality of board coverage
            ev_score -= (CenterShortProximity[ev_temp] * evKnightCoverageCenterProximityScale);

            switch (B[ev_temp]) {
              case
                  sEmp: {
                  ev_score -= evKnightEmptyCoverage;
                };

                break;
              case
                  sWpa: {
                  ev_v++;

                  #ifdef ATTACKS_MAP
                  WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                  #endif

                  ev_score -= evKnightPawnCoverage;
                };

                break;
              case
                  sBpa: {
                  ev_score += evKnightSelfPawnCoveragePenalty;
                };

                break;
              case
                  sWro: {
                  ev_v++;
									#ifdef ATTACKS_MAP
                  WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                  #endif
                  ev_score -= evKnightRookCoverage;
                };

                break;
              case
                  sBro: {
                  ;
                };

                break;
              case
                  sWbi: {
                  ev_v++;
                  ev_score -= evKnightBishopCoverage;
                  #ifdef ATTACKS_MAP
                  WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                  #endif
                };

                break;
              case
                  sBbi: {
                  ;
                };

                break;
              case
                  sWkn: {
									#ifdef ATTACKS_MAP
                  WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                  #endif
                  ev_score -= evKnightKnightCoverage;
                };

                break; //dont count nN
              case
                  sBkn: {
                  ;
                };

                break;
              case
                  sWki: {
                  ev_v++;
                  ev_score -= evCheck;
									#ifdef ATTACKS_MAP
                  WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                  #endif
                };

                break; //nK check
              case
                  sBki: {
                  ;
                };

                break;
              case
                  sWqu: {
                  ev_v++;
									#ifdef ATTACKS_MAP
                  WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                  #endif
                  ev_score -= evKnightQueenCoverage;
                };

                break;
              case
                  sBqu: {
                  ;
                };

                break;
            };
          };

          //forks
          if (ev_v > 1) {
            ev_score -= evKnightForks;
            //if a forking piece has already moved - set extention
            //if (gl_ts==ev_temp) {
            //};
          };

          //award opponent king Proximity
          ev_score -= (ShortProximity[ev_fs][WkiPos] * evKnightOpponentKingProximityScale);

          //award self king Proximity
          ev_score -= (ShortProximity[ev_fs][BkiPos] * evKnightSelfKingProximityScale);

          //award center
          ev_score -= (CenterShortProximity[ev_fs] * evKnightCenterProximityScale);
        };

        break;

//evaluate king
      case
          sWki: {
          //if opponent out of queen
          if (BquNum == 0) {
            //award king center
            ev_score += (CenterShortProximity[ev_fs] * evKingCenterProximityScale);
          }
          //if opponent has queen
          else {
            //penalize king center proximity
            ev_score -= (CenterShortProximity[ev_fs] * evKingCenterProximityScale);

            //analyze king shelter

            //award pawns in the king area
            //penalize attacks on the king area
            for (ev_v = 0; ev_v < 8; ev_v++) {
              ev_c = Vec[ev_v][ev_fs][0];

              if (ev_c == 64) {
                continue;
              };

              if (B[ev_c] == sWpa) {
                ev_score += evKingSelfPawnCoverage;
              };
            };

            //award castle or preserving castle right
            if ((castle_dat == (castle_dat | castle_done_WKK_mask)) ||
                (castle_dat == (castle_dat | castle_done_WKQ_mask))) {
              ev_score += evKingCastled;
            } else {
              if (castle_dat == (castle_dat | castle_lost_WKK_mask)) {
                ev_score -= evKingSideCastleRight;
              };

              if (castle_dat == (castle_dat | castle_lost_WKQ_mask)) {
                ev_score -= evQueenSideCastleRight;
              };
            };
          };
        };

        break;

//evaluate king
      case
          sBki: {
          //if opponent out of queen
          if (WquNum == 0) {
            //award king center
            ev_score -= (CenterShortProximity[ev_fs] * evKingCenterProximityScale);
          }
          //if opponent has queen
          else {
            //penalize king piece center proximity
            ev_score += (CenterShortProximity[ev_fs] * evKingCenterProximityScale);

            //award pawn in the king area
            //penalize attacks on the king area
            for (ev_v = 0; ev_v < 8; ev_v++) {
              ev_c = Vec[ev_v][ev_fs][0];

              if (ev_c == 64) {
                continue;
              };

              if (B[ev_c] == sBpa) {
                ev_score -= evKingSelfPawnCoverage;
              };
            };

            //award castle or preserving castle right
            if ((castle_dat == (castle_dat | castle_done_BKK_mask)) ||
                (castle_dat == (castle_dat | castle_done_BKQ_mask))) {
              ev_score -= evKingCastled;
            } else {
              if (castle_dat == (castle_dat | castle_lost_BKK_mask)) {
                ev_score += evKingSideCastleRight;
              };

              if (castle_dat == (castle_dat | castle_lost_WKQ_mask)) {
                ev_score += evQueenSideCastleRight;
              };
            };
          };
        };

        break;

//evaluate queen
      case
          sWqu: {
          //occupancy
          for (ev_v = 0; ev_v < 4; ev_v++)
            //analyse bishop-like moves!
          {
            for (ev_c = 0; ev_c < 8; ev_c++) {
              ev_temp = Vec[ev_v][ev_fs][ev_c];

              if (ev_temp == 64) {
                break; // break if rank
              };

              //update coverage of opponent king area - bishoplike moves
              AttackedBkiAreaCounter[ev_temp] += BkiArea[ev_temp];

              //award centrality of board coverage
              ev_score += (CenterShortProximity[ev_temp] * evQueenCoverageCenterProximityScale);

              switch (B[ev_temp]) {
                case
                    sEmp: {
                    ev_score += evQueenEmptyCoverage;
                  };

                  break;
                case
                    sWpa: {
                    ev_score -= evQueenSelfPawnCoveragePenalty; //default zero
                    ev_c = 8;
                  };

                  break;
                case
                    sBpa: {
                    ev_score += evQueenPawnCoverage;
                    #ifdef ATTACKS_MAP
										BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                    #endif
                    ev_c = 8;
                  };

                  break;
                case
                    sWro: {
                    //handle revealed attack bishoplike QR threat
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      }

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBki: {
                            //handle revealed check threat
                            ev_score += evQueenRookKingRevealedCheckThreat;
                            ev_c = 8;
                          };

                          break;
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break;
                      };
                    };
                  };

                  break;
                case
                    sBro: { //Qr
                    ev_score += evQueenRookBishoplikeCoverage;
                    #ifdef ATTACKS_MAP
										BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                    #endif

                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      }

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBki: {
                            ev_score += evQueenRookKingBishoplikePin;

                            ev_c = 8;
                          };

                          break; //Qrk pin
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break;
                      };
                    };
                  };

                  break;
                case
                    sWbi: {
                    //handle bishoplike attack on kingarea QB
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      };

                      //update coverage of opponent king area - bishoplike moves
                      AttackedBkiAreaCounter[ev_temp] += BkiArea[ev_temp];

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break;
                      };
                    };
                  };

                  break;
                case
                    sBbi: {
                    ev_c = 8;
                  };

                  break;
                case
                    sWkn: {
                    //handle revealed attack QN bishoplike threat
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      }

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBki: {
                            //handle revealed check QNk threat
                            ev_score += evQueenKnightKingRevealedCheckThreat;
                            ev_c = 8;
                          };

                          break;
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break;
                      };
                    };
                  };

                  break;
                case
                    sBkn: { //Qn
                    ev_score += evQueenKnightCoverage;

										#ifdef ATTACKS_MAP
										BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                    #endif

                    //handle pin
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      }

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBki: {
                            ev_score += evQueenKnightKingPin;

                            ev_c = 8;
                          };

                          break; //Qnk pin
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break;
                      };
                    };
                  };

                  break;
                case
                    sWki: {
                    ev_c = 8;
                  };

                  break;
                case
                    sBki: {
                    ev_score += evCheck;
										#ifdef ATTACKS_MAP
										BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                    #endif
                    ev_c = 8;
                  };

                  break; //Qk check
                case
                    sWqu: {
                    ev_c = 8;
                  };

                  break;
                case
                    sBqu: {
										#ifdef ATTACKS_MAP
										BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                    #endif
                    ev_c = 8;
                  };

                  break;
              };
            };
          };

          for (ev_v = 4; ev_v < 8; ev_v++)
            //analyse rook-like moves!
          {
            for (ev_c = 0; ev_c < 8; ev_c++) {
              ev_temp = Vec[ev_v][ev_fs][ev_c];

              if (ev_temp == 64) {
                break; // break if rank
              }

              //update coverage of opponent king area - bishoplike moves
              AttackedBkiAreaCounter[ev_temp] += BkiArea[ev_temp];

              switch (B[ev_temp]) {
                case
                    sEmp: {
                    ev_score += evQueenEmptyCoverage;
                  };

                  break;
                case
                    sWpa: {
                    ev_score += evQueenSelfPawnCoveragePenalty; //default zero
                    ev_c = 8;
                  };

                  break;
                case
                    sBpa: {
                    ev_score += evQueenPawnCoverage;
										#ifdef ATTACKS_MAP
										BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                    #endif


                    ev_c = 8;
                  };

                  break;
                case
                    sWro: {
                    //handle QR rooklike attack on king area
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      };

                      //update coverage of opponent king area
                      AttackedBkiAreaCounter[ev_temp] += BkiArea[ev_temp];

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWro: {
                            //handle tripple RRQ king area attack
                            ev_c++;

                            for (; ev_c < 8; ev_c++) {
                              ev_temp = Vec[ev_v][ev_fs][ev_c];

                              if (ev_temp == 64) {
                                break;
                              };

                              //update coverage of opponent king area
                              AttackedBkiAreaCounter[ev_temp] += BkiArea[ev_temp];

                              switch (B[ev_temp]) {
                                case
                                    sEmp: {
                                    ;
                                  };

                                  break;
                                case
                                    sWpa: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBpa: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sWro: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBro: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sWbi: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBbi: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sWkn: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBkn: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sWki: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBki: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sWqu: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBqu: {
                                    ev_c = 8;
                                  };

                                  break;
                              };
                            };
                          };

                          break;
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break;
                      };
                    };
                  };

                  break;
                case
                    sBro: {
										#ifdef ATTACKS_MAP
										BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                    #endif
                    ev_c = 8;
                  };

                  break;
                case
                    sWbi: {
                    //handle QB reveal threat at rooklike vector
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      }

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBki: {
                            //handle revealed check QBk threat
                            ev_score += evQueenBishopKingRevealedCheckThreat;
                            ev_c = 8;
                          };

                          break;
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break;
                      };
                    };
                  };

                  break;
                case
                    sBbi: { //Qb
                    ev_score += evQueenBishopRooklikeCoverage;

										#ifdef ATTACKS_MAP
										BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                    #endif

                    //handle pin at rook-like move vector
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      }

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBki: {
                            ev_score += evQueenBishopKingRooklikePin;

                            ev_c = 8;
                          };

                          break; //Qbk pin
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break;
                      };
                    };
                  };

                  break;
                case
                    sWkn: {
                    //handle revealed attack QN rooklike threat
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      }

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBki: {
                            //handle revealed check rooklike QNk threat
                            ev_score += evQueenKnightKingRevealedCheckThreat;
                            ev_c = 8;
                          };

                          break;
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break;
                      };
                    };
                  };

                  break;
                case
                    sBkn: { //Qn
                    ev_score += evQueenKnightCoverage;

										#ifdef ATTACKS_MAP
										BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                    #endif

                    //handle pin
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      }

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBki: {
                            ev_score += evQueenKnightKingPin;

                            ev_c = 8;
                          };

                          break; //Qnk pin
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break;
                      };
                    };
                  };

                  break;
                case
                    sWki: {
                    ev_c = 8;
                  };

                  break;
                case
                    sBki: {
                    ev_score += evCheck;
										#ifdef ATTACKS_MAP
										BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                    #endif
                    ev_c = 8;
                  };

                  break; //Qk check
                case
                    sWqu: {
                    ev_c = 8;
                  };

                  break;
                case
                    sBqu: {
										#ifdef ATTACKS_MAP
										BlaAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                    #endif
                    ev_c = 8;
                  };

                  break;
              };
            };
          };

          //award opponent king Proximity
          ev_score += (ShortProximity[ev_fs][BkiPos] * evQueenOpponentKingProximityScale);

          //award self king Proximity
          ev_score += (ShortProximity[ev_fs][WkiPos] * evQueenSelfKingProximityScale);

          //award queen on seventh row
          if (rownum[ev_fs] == 7) {
            ev_score += evQueenOnSeventh;

          };

          //award center
          ev_score += (CenterShortProximity[ev_fs] * evQueenCenterProximityScale);
        };

        break;
      case
          sBqu: {
          for (ev_v = 0; ev_v < 4; ev_v++)
            //analyse bishop-like moves
          {
            for (ev_c = 0; ev_c < 8; ev_c++) {
              ev_temp = Vec[ev_v][ev_fs][ev_c];

              if (ev_temp == 64) {
                break; // break if rank
              }

              //update coverage of opponent king area - bishoplike moves
              AttackedWkiAreaCounter[ev_temp] += WkiArea[ev_temp];
              //award centrality of board coverage
              ev_score -= (CenterShortProximity[ev_temp] * evQueenCoverageCenterProximityScale);

              switch (B[ev_temp]) {
                case
                    sEmp: {
                    ev_score -= evQueenEmptyCoverage;
                  };

                  break;
                case
                    sWpa: {
                    ev_score -= evQueenPawnCoverage;

										#ifdef ATTACKS_MAP
                    WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                    #endif

                    ev_c = 8;
                  };

                  break;
                case
                    sBpa: {
                    ev_score += evQueenSelfPawnCoveragePenalty;
                    ev_c = 8;
                  };

                  break;
                case
                    sWro: { //qR
                    ev_score -= evQueenRookBishoplikeCoverage;

										#ifdef ATTACKS_MAP
                    WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                    #endif

                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      }

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWki: {
                            ev_score -= evQueenRookKingBishoplikePin;

                            ev_c = 8;
                          };

                          break; //qRK pin
                        case
                            sBki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break;
                      };
                    };
                  };

                  break;
                case
                    sBro: {
                    //handle revealed attack bishoplike qr threat
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      }

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWki: {
                            //handle bishoplike revealed check threat qrK
                            ev_score -= evQueenRookKingRevealedCheckThreat;
                            ev_c = 8;
                          };

                          break;
                        case
                            sBki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break;
                      };
                    };
                  };

                  break;
                case
                    sWbi: {
										#ifdef ATTACKS_MAP
                    WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                    #endif
                    ev_c = 8;
                  };

                  break;
                case
                    sBbi: {
                    //handle bishoplike qb attack on kingarea
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      };

                      //update coverage of opponent king area - bishoplike moves
                      AttackedWkiAreaCounter[ev_temp] += WkiArea[ev_temp];

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break;
                      };
                    };
                  };

                  break;
                case
                    sWkn: { //qN
                    ev_score -= evQueenKnightCoverage;

										#ifdef ATTACKS_MAP
                    WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                    #endif

                    //handle pin
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      }

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWki: {
                            ev_score -= evQueenKnightKingPin;

                            ev_c = 8;
                          };

                          break; //qNK pin
                        case
                            sBki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break;
                      };
                    };
                  };

                  break;
                case
                    sBkn: {
                    //handle bishoplike reveal threat qn
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      };

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWki: {
                            ev_score -= evQueenKnightKingRevealedCheckThreat;
                            ev_c = 8;
                          };

                          break;
                        case
                            sBki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break;
                      };
                    };
                  };

                  break;
                case
                    sWki: {
                    ev_score -= evCheck;
										#ifdef ATTACKS_MAP
                    WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                    #endif
                    ev_c = 8;
                  };

                  break; //qK check
                case
                    sBki: {
                    ev_c = 8;
                  };

                  break;
                case
                    sWqu: {
										#ifdef ATTACKS_MAP
                    WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                    #endif
                    ev_c = 8;
                  };

                  break;
                case
                    sBqu: {
                    ev_c = 8;
                  };

                  break;
              };
            };
          };

          for (ev_v = 4; ev_v < 8; ev_v++)
            //analyse rook-like moves!
          {
            for (ev_c = 0; ev_c < 8; ev_c++) {
              ev_temp = Vec[ev_v][ev_fs][ev_c];

              if (ev_temp == 64) {
                break; // break if rank
              };

              //update coverage of opponent king area - rooklike moves
              AttackedWkiAreaCounter[ev_temp] += WkiArea[ev_temp];

              switch (B[ev_temp]) {
                case
                    sEmp: {
                    ev_score -= evQueenEmptyCoverage;
                  };

                  break;
                case
                    sWpa: {
                    ev_score -= evQueenPawnCoverage;
										#ifdef ATTACKS_MAP
                    WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                    #endif
                    ev_c = 8;
                  };

                  break;
                case
                    sBpa: {
                    ev_score += evQueenSelfPawnCoveragePenalty;
                    ev_c = 8;
                  };

                  break;
                case
                    sWro: {
										#ifdef ATTACKS_MAP
                    WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                    #endif
                    ev_c = 8;
                  };

                  break;
                case
                    sBro: {
                    //handle double qr rooklike attack on kingarea
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      };

                      //update coverage of opponent king area
                      AttackedWkiAreaCounter[ev_temp] += WkiArea[ev_temp];

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBro: {
                            //handle tripple RRQ king area attack
                            ev_c++;

                            for (; ev_c < 8; ev_c++) {
                              ev_temp = Vec[ev_v][ev_fs][ev_c];

                              if (ev_temp == 64) {
                                break;
                              };

                              //update coverage of opponent king area
                              AttackedWkiAreaCounter[ev_temp] += WkiArea[ev_temp];

                              switch (B[ev_temp]) {
                                case
                                    sEmp: {
                                    ;
                                  };

                                  break;
                                case
                                    sWpa: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBpa: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sWro: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBro: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sWbi: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBbi: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sWkn: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBkn: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sWki: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBki: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sWqu: {
                                    ev_c = 8;
                                  };

                                  break;
                                case
                                    sBqu: {
                                    ev_c = 8;
                                  };

                                  break;
                              };
                            };
                          };

                          break;
                        case
                            sWbi: {
                            ev_c = 8;

                          };

                          break;
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWkn: {
                            ev_c = 8;

                          };

                          break;
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWki: {
                            ev_c = 8;

                          };

                          break;
                        case
                            sBki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWqu: {
                            ev_c = 8;

                          };

                          break;
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break;
                      };
                    };
                  };

                  break;
                case
                    sWbi: { //qB
                    ev_score -= evQueenBishopRooklikeCoverage;
										#ifdef ATTACKS_MAP
                    WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                    #endif


                    //handle pin at rook-like move vector
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      }

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWki: {
                            ev_score -= evQueenBishopKingRooklikePin;

                            ev_c = 8;
                          };

                          break; //qBK pin
                        case
                            sBki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break;
                      };
                    };
                  };

                  break;
                case
                    sBbi: {
                    //handle qb rooklike revealed check
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      }

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWki: {
                            //handle revealed check QBk threat
                            ev_score -= evQueenBishopKingRevealedCheckThreat;
                            ev_c = 8;
                          };

                          break;
                        case
                            sBki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break;
                      };
                    };
                  };

                  break;
                case
                    sWkn: { //qN rooklike
                    ev_score -= evQueenKnightCoverage;

										#ifdef ATTACKS_MAP
                    WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                    #endif

                    //handle pin
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      }

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWki: {
                            ev_score -= evQueenKnightKingPin;

                            ev_c = 8;
                          };

                          break; //qNK pin
                        case
                            sBki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break;
                      };
                    };
                  };

                  break;
                case
                    sBkn: {
                    //handle qn reveal rooklike threat
                    ev_c++;

                    for (; ev_c < 8; ev_c++) {
                      ev_temp = Vec[ev_v][ev_fs][ev_c];

                      if (ev_temp == 64) {
                        break;
                      }

                      switch (B[ev_temp]) {
                        case
                            sEmp: {
                            ;
                          };

                          break;
                        case
                            sWpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBpa: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBro: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBbi: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBkn: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWki: {
                            //handle revealed check rooklike qnK threat
                            ev_score -= evQueenKnightKingRevealedCheckThreat;
                            ev_c = 8;
                          };

                          break;
                        case
                            sBki: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sWqu: {
                            ev_c = 8;
                          };

                          break;
                        case
                            sBqu: {
                            ev_c = 8;
                          };

                          break;
                      };
                    };
                  };

                  break;
                case
                    sWki: {
                    ev_score -= evCheck;
                    #ifdef ATTACKS_MAP
                    WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                    #endif

                    ev_c = 8;
                  };

                  break; //qK check
                case
                    sBki: {
                    ev_c = 8;
                  };

                  break;
                case
                    sWqu: {
                    ev_c = 8;
                    #ifdef ATTACKS_MAP
                    WhiAttackedMap |= (((unsigned __int64)1)<<ev_temp);
                    #endif
                  };

                  break;
                case
                    sBqu: {
                    ev_c = 8;
                  };

                  break;
              };
            };
          };

          //award opponent king Proximity
          ev_score -= (ShortProximity[ev_fs][WkiPos] * evQueenOpponentKingProximityScale);

          //award self king Proximity
          ev_score -= (ShortProximity[ev_fs][BkiPos] * evQueenSelfKingProximityScale);

          //award rook on second row
          if (rownum[ev_fs] == 2) {
            ev_score -= evQueenOnSeventh;

          };

          //award center ev_forced = true;
          ev_score -= (CenterShortProximity[ev_fs] * evQueenCenterProximityScale);
        };

        break;

        default : {
        	//change ev_score to 0 if empty square
        	ev_score = 0;
				}; break;


    };

		//function changes global ev_score as the result

};

//vectors
/*
const short NWtoSEvec = 0;
const short SEtoNWvec = 1;
const short SWtoNEvec = 2;
const short NEtoSWvec = 3;
const short WtoEvec = 4;
const short EtoWvec = 5;
const short NtoSvec = 6;
const short StoNvec = 7;
//v:8 knight jump squares
//v:9 same squares
//v:10 no match
//
*/

//symbols
/*
const short sWpa = 1;
const short sBpa = 2;
const short sWro = 3;
const short sBro = 4;
const short sWbi = 5;
const short sBbi = 6;
const short sWkn = 7;
const short sBkn = 8;
const short sWki = 9;
const short sBki = 10;
const short sWqu = 11;
const short sBqu = 12;
const short sEmp = 13;
const short sOut = 14;
*/


#ifdef REUSE_EVAL
//return true if piece standing on Startsquare uses vector in evaluation to Endsquare .
//if this vector is used it means that there is a chance of influencing evaluation of
//piece standing on Startsquare by making empty or occupying Endsquare.
bool usesVec(unsigned char Startsquare, unsigned char Endsquare) {

	//ev_v = getVec[(Startsquare<<6) | Endsquare];

	switch (getVec[(Startsquare<<6) | Endsquare]) {
  	case 0: { //nw to se more than one square vec
		  switch (B[Startsquare]) {
			  case sWpa: {return false;}; break;
			  case sBpa: {return false;}; break;
			  case sWro: {return false;}; break;
			  case sBro: {return false;}; break;
			  case sWbi: {
			  	ev_c = 1;
			  	ev_j = 0;
			  	while (true) {
			  		ev_temp = Vec[0][Startsquare][ev_c];
			  		if (ev_temp==Endsquare) {return true;};
			  	  if (B[ev_temp]!=sEmp) {
						  ev_j++;
						  if (ev_j==2) {
						  	//cout<<"success aaa"<<endl;
							  return false;
							};
						};
			  	  ev_c++;
					};
				}; break;
				case sBbi: {
				  ev_c = 1;
			  	ev_j = 0;
			  	while (true) {
			  		ev_temp = Vec[0][Startsquare][ev_c];
			  		if (ev_temp==Endsquare) {return true;};
			  	  if (B[ev_temp]!=sEmp) {
						  ev_j++;
						  if (ev_j==2) {
						  	//cout<<"success bbb"<<endl;
							  return false;
							};
						};
			  	  ev_c++;
					};
				}; break;
			  case sWkn: {return false;}; break;
			  case sBkn: {return false;}; break;
			  case sWki: {return false;}; break;
			  case sBki: {return false;}; break;
			  case sWqu: {
				  ev_c = 1;
			  	ev_j = 0;
			  	while (true) {
			  		ev_temp = Vec[0][Startsquare][ev_c];
			  		if (ev_temp==Endsquare) {return true;};
			  	  if (B[ev_temp]!=sEmp) {
						  ev_j++;
						  if (ev_j==2) {
						  	//cout<<"success ccc"<<endl;
							  return false;
							};
						};
			  	  ev_c++;
			    };
				}; break;
			  case sBqu: {
			  	ev_c = 1;
			  	ev_j = 0;
			  	while (true) {
			  		ev_temp = Vec[0][Startsquare][ev_c];
			  		if (ev_temp==Endsquare) {return true;};
			  	  if (B[ev_temp]!=sEmp) {
						  ev_j++;
						  if (ev_j==2) {
						  	//cout<<"success ddd"<<endl;
							  return false;
							};
						};
			  	  ev_c++;
			    };
				}; break;
			  default: {cout<<"print error00000000:"<<B[Startsquare]<<endl;};
			};
		}; break;
		case 1: { //se to nw more than one square vec
		  switch (B[Startsquare]) {
			  case sWpa: {return false;}; break;
			  case sBpa: {return false;}; break;
			  case sWro: {return false;}; break;
			  case sBro: {return false;}; break;
			  case sWbi: {
			  	ev_c = 1;
			  	ev_j = 0;
			  	while (true) {
			  		ev_temp = Vec[1][Startsquare][ev_c];
			  		if (ev_temp==Endsquare) {return true;};
			  	  if (B[ev_temp]!=sEmp) {
						  ev_j++;
						  if (ev_j==2) {
						  	//cout<<"success aaa"<<endl;
							  return false;
							};
						};
			  	  ev_c++;
					};
				}; break;
				case sBbi: {
				  ev_c = 1;
			  	ev_j = 0;
			  	while (true) {
			  		ev_temp = Vec[1][Startsquare][ev_c];
			  		if (ev_temp==Endsquare) {return true;};
			  	  if (B[ev_temp]!=sEmp) {
						  ev_j++;
						  if (ev_j==2) {
						  	//cout<<"success bbb"<<endl;
							  return false;
							};
						};
			  	  ev_c++;
					};
				}; break;
			  case sWkn: {return false;}; break;
			  case sBkn: {return false;}; break;
			  case sWki: {return false;}; break;
			  case sBki: {return false;}; break;
			  case sWqu: {
				  ev_c = 1;
			  	ev_j = 0;
			  	while (true) {
			  		ev_temp = Vec[1][Startsquare][ev_c];
			  		if (ev_temp==Endsquare) {return true;};
			  	  if (B[ev_temp]!=sEmp) {
						  ev_j++;
						  if (ev_j==2) {
						  	//cout<<"success ccc"<<endl;
							  return false;
							};
						};
			  	  ev_c++;
			    };
				}; break;
			  case sBqu: {
			  	ev_c = 1;
			  	ev_j = 0;
			  	while (true) {
			  		ev_temp = Vec[1][Startsquare][ev_c];
			  		if (ev_temp==Endsquare) {return true;};
			  	  if (B[ev_temp]!=sEmp) {
						  ev_j++;
						  if (ev_j==2) {
						  	//cout<<"success ddd"<<endl;
							  return false;
							};
						};
			  	  ev_c++;
			    };
				}; break;
			  default: {cout<<"print error11111111:"<<B[Startsquare]<<endl;};
			};
		}; break;
		case 2: { //sw to ne more than one square vec
		  switch (B[Startsquare]) {
			  case sWpa: {return false;}; break;
			  case sBpa: {return false;}; break;
			  case sWro: {return false;}; break;
			  case sBro: {return false;}; break;
			  case sWbi: {
			  	ev_c = 1;
			  	ev_j = 0;
			  	while (true) {
			  		ev_temp = Vec[2][Startsquare][ev_c];
			  		if (ev_temp==Endsquare) {return true;};
			  	  if (B[ev_temp]!=sEmp) {
						  ev_j++;
						  if (ev_j==2) {
						  	//cout<<"success aaa"<<endl;
							  return false;
							};
						};
			  	  ev_c++;
					};
				}; break;
				case sBbi: {
				  ev_c = 1;
			  	ev_j = 0;
			  	while (true) {
			  		ev_temp = Vec[2][Startsquare][ev_c];
			  		if (ev_temp==Endsquare) {return true;};
			  	  if (B[ev_temp]!=sEmp) {
						  ev_j++;
						  if (ev_j==2) {
						  	//cout<<"success bbb"<<endl;
							  return false;
							};
						};
			  	  ev_c++;
					};
				}; break;
			  case sWkn: {return false;}; break;
			  case sBkn: {return false;}; break;
			  case sWki: {return false;}; break;
			  case sBki: {return false;}; break;
			  case sWqu: {
				  ev_c = 1;
			  	ev_j = 0;
			  	while (true) {
			  		ev_temp = Vec[2][Startsquare][ev_c];
			  		if (ev_temp==Endsquare) {return true;};
			  	  if (B[ev_temp]!=sEmp) {
						  ev_j++;
						  if (ev_j==2) {
						  	//cout<<"success ccc"<<endl;
							  return false;
							};
						};
			  	  ev_c++;
			    };
				}; break;
			  case sBqu: {
			  	ev_c = 1;
			  	ev_j = 0;
			  	while (true) {
			  		ev_temp = Vec[2][Startsquare][ev_c];
			  		if (ev_temp==Endsquare) {return true;};
			  	  if (B[ev_temp]!=sEmp) {
						  ev_j++;
						  if (ev_j==2) {
						  	//cout<<"success ddd"<<endl;
							  return false;
							};
						};
			  	  ev_c++;
			    };
				}; break;
			  default: {cout<<"print error222222222:"<<B[Startsquare]<<endl;};
			};
		}; break;
		case 3: { //ne to sw more than one vec
		  switch (B[Startsquare]) {
			  case sWpa: {return false;}; break;
			  case sBpa: {return false;}; break;
			  case sWro: {return false;}; break;
			  case sBro: {return false;}; break;
			  case sWbi: {
			  	ev_c = 1;
			  	ev_j = 0;
			  	while (true) {
			  		ev_temp = Vec[3][Startsquare][ev_c];
			  		if (ev_temp==Endsquare) {return true;};
			  	  if (B[ev_temp]!=sEmp) {
						  ev_j++;
						  if (ev_j==2) {
						  	//cout<<"success aaa"<<endl;
							  return false;
							};
						};
			  	  ev_c++;
					};
				}; break;
				case sBbi: {
				  ev_c = 1;
			  	ev_j = 0;
			  	while (true) {
			  		ev_temp = Vec[3][Startsquare][ev_c];
			  		if (ev_temp==Endsquare) {return true;};
			  	  if (B[ev_temp]!=sEmp) {
						  ev_j++;
						  if (ev_j==2) {
						  	//cout<<"success bbb"<<endl;
							  return false;
							};
						};
			  	  ev_c++;
					};
				}; break;
			  case sWkn: {return false;}; break;
			  case sBkn: {return false;}; break;
			  case sWki: {return false;}; break;
			  case sBki: {return false;}; break;
			  case sWqu: {
				  ev_c = 1;
			  	ev_j = 0;
			  	while (true) {
			  		ev_temp = Vec[3][Startsquare][ev_c];
			  		if (ev_temp==Endsquare) {return true;};
			  	  if (B[ev_temp]!=sEmp) {
						  ev_j++;
						  if (ev_j==2) {
						  	//cout<<"success ccc"<<endl;
							  return false;
							};
						};
			  	  ev_c++;
			    };
				}; break;
			  case sBqu: {
			  	ev_c = 1;
			  	ev_j = 0;
			  	while (true) {
			  		ev_temp = Vec[3][Startsquare][ev_c];
			  		if (ev_temp==Endsquare) {return true;};
			  	  if (B[ev_temp]!=sEmp) {
						  ev_j++;
						  if (ev_j==2) {
						  	//cout<<"success ddd"<<endl;
							  return false;
							};
						};
			  	  ev_c++;
			    };
				}; break;
			  default: {cout<<"print error333333333:"<<B[Startsquare]<<endl;};
			};
		}; break;
		case 4: { //w to e more than one vec
		  switch (B[Startsquare]) {
			  case sWpa: {return false;}; break;
			  case sBpa: {return false;}; break;
			  case sWro: {
			  	ev_c = 1;
			  	ev_j = 0;
			  	while (true) {
			  		ev_temp = Vec[4][Startsquare][ev_c];
			  		if (ev_temp==Endsquare) {return true;};
			  	  if (B[ev_temp]!=sEmp) {
						  ev_j++;
						  if (ev_j==2) {
							  return false;
							};
						};
			  	  ev_c++;
			    };
				}; break;
				case sBro: {
			  	ev_c = 1;
			  	ev_j = 0;
			  	while (true) {
			  		ev_temp = Vec[4][Startsquare][ev_c];
			  		if (ev_temp==Endsquare) {return true;};
			  	  if (B[ev_temp]!=sEmp) {
						  ev_j++;
						  if (ev_j==2) {
							  return false;
							};
						};
			  	  ev_c++;
			    };
				}; break;
			  case sWbi: {return false;}; break;
			  case sBbi: {return false;}; break;
			  case sWkn: {return false;}; break;
			  case sBkn: {return false;}; break;
			  case sWki: {return true;}; break; //long king castle (can rook attack?)
			  case sBki: {return true;}; break; //long king castle
			  case sWqu: {
			  	ev_c = 1;
			  	ev_j = 0;
			  	while (true) {
			  		ev_temp = Vec[4][Startsquare][ev_c];
			  		if (ev_temp==Endsquare) {return true;};
			  	  if (B[ev_temp]!=sEmp) {
						  ev_j++;
						  if (ev_j==2) {
							  return false;
							};
						};
			  	  ev_c++;
			    };
				}; break;
			  case sBqu: {
			    ev_c = 1;
			  	ev_j = 0;
			  	while (true) {
			  		ev_temp = Vec[4][Startsquare][ev_c];
			  		if (ev_temp==Endsquare) {return true;};
			  	  if (B[ev_temp]!=sEmp) {
						  ev_j++;
						  if (ev_j==2) {
							  return false;
							};
						};
			  	  ev_c++;
			    };
				}; break;
			  default: {cout<<"print error4444444444:"<<B[Startsquare]<<endl;};
			};
		}; break;
		case 5: {//e to w more than one vec
			switch (B[Startsquare]) {
			  case sWpa: {return false;}; break;
			  case sBpa: {return false;}; break;
			  case sWro: {
			  	ev_c = 1;
			  	ev_j = 0;
			  	while (true) {
			  		ev_temp = Vec[5][Startsquare][ev_c];
			  		if (ev_temp==Endsquare) {return true;};
			  	  if (B[ev_temp]!=sEmp) {
						  ev_j++;
						  if (ev_j==2) {
							  return false;
							};
						};
			  	  ev_c++;
			    };
				}; break;
				case sBro: {
			  	ev_c = 1;
			  	ev_j = 0;
			  	while (true) {
			  		ev_temp = Vec[5][Startsquare][ev_c];
			  		if (ev_temp==Endsquare) {return true;};
			  	  if (B[ev_temp]!=sEmp) {
						  ev_j++;
						  if (ev_j==2) {
							  return false;
							};
						};
			  	  ev_c++;
			    };
				}; break;
			  case sWbi: {return false;}; break;
			  case sBbi: {return false;}; break;
			  case sWkn: {return false;}; break;
			  case sBkn: {return false;}; break;
			  case sWki: {return true;}; break; //king castle
			  case sBki: {return true;}; break; //king castle
			  case sWqu: {
			  	ev_c = 1;
			  	ev_j = 0;
			  	while (true) {
			  		ev_temp = Vec[5][Startsquare][ev_c];
			  		if (ev_temp==Endsquare) {return true;};
			  	  if (B[ev_temp]!=sEmp) {
						  ev_j++;
						  if (ev_j==2) {
							  return false;
							};
						};
			  	  ev_c++;
			    };
				}; break;
				case sBqu: {
			  	ev_c = 1;
			  	ev_j = 0;
			  	while (true) {
			  		ev_temp = Vec[5][Startsquare][ev_c];
			  		if (ev_temp==Endsquare) {return true;};
			  	  if (B[ev_temp]!=sEmp) {
						  ev_j++;
						  if (ev_j==2) {
							  return false;
							};
						};
			  	  ev_c++;
			    };
				}; break;
			  default: {cout<<"print error555555555:"<<B[Startsquare]<<endl;};
			};
	  }; break;
	  case 6: {//n to s more than one vec
	    switch (B[Startsquare]) {
			  case sWpa: {return false;}; break;
			  case sBpa: {return true;}; break;
			  case sWro: {
			  	ev_c = 1;
			  	ev_j = 0;
			  	while (true) {
			  		ev_temp = Vec[6][Startsquare][ev_c];
			  		if (ev_temp==Endsquare) {return true;};
			  	  if (B[ev_temp]!=sEmp) {
						  ev_j++;
						  if (ev_j==2) {
							  return false;
							};
						};
			  	  ev_c++;
			    };
				}; break;
			  case sBro: {
			  	ev_c = 1;
			  	ev_j = 0;
			  	while (true) {
			  		ev_temp = Vec[6][Startsquare][ev_c];
			  		if (ev_temp==Endsquare) {return true;};
			  	  if (B[ev_temp]!=sEmp) {
						  ev_j++;
						  if (ev_j==2) {
							  return false;
							};
						};
			  	  ev_c++;
			    };
				}; break;
			  case sWbi: {return false;}; break;
			  case sBbi: {return false;}; break;
			  case sWkn: {return false;}; break;
			  case sBkn: {return false;}; break;
			  case sWki: {return false;}; break;
			  case sBki: {return false;}; break;
			  case sWqu: {
			  	ev_c = 1;
			  	ev_j = 0;
			  	while (true) {
			  		ev_temp = Vec[6][Startsquare][ev_c];
			  		if (ev_temp==Endsquare) {return true;};
			  	  if (B[ev_temp]!=sEmp) {
						  ev_j++;
						  if (ev_j==2) {
							  return false;
							};
						};
			  	  ev_c++;
			    };
				}; break;
			  case sBqu: {
			  	ev_c = 1;
			  	ev_j = 0;
			  	while (true) {
			  		ev_temp = Vec[6][Startsquare][ev_c];
			  		if (ev_temp==Endsquare) {return true;};
			  	  if (B[ev_temp]!=sEmp) {
						  ev_j++;
						  if (ev_j==2) {
							  return false;
							};
						};
			  	  ev_c++;
			    };
				}; break;
			  default: {cout<<"print error6666666666:"<<B[Startsquare]<<endl;};
			};
	  }; break;
	  case 7: {//s to n more than one vector
	    switch (B[Startsquare]) {
			  case sWpa: {return true;}; break;
			  case sBpa: {return false;}; break;
			  case sWro: {
			  	ev_c = 1;
			  	ev_j = 0;
			  	while (true) {
			  		ev_temp = Vec[7][Startsquare][ev_c];
			  		if (ev_temp==Endsquare) {return true;};
			  	  if (B[ev_temp]!=sEmp) {
						  ev_j++;
						  if (ev_j==2) {
							  return false;
							};
						};
			  	  ev_c++;
			    };
				}; break;
			  case sBro: {
			  	ev_c = 1;
			  	ev_j = 0;
			  	while (true) {
			  		ev_temp = Vec[7][Startsquare][ev_c];
			  		if (ev_temp==Endsquare) {return true;};
			  	  if (B[ev_temp]!=sEmp) {
						  ev_j++;
						  if (ev_j==2) {
							  return false;
							};
						};
			  	  ev_c++;
			    };
				}; break;
			  case sWbi: {return false;}; break;
			  case sBbi: {return false;}; break;
			  case sWkn: {return false;}; break;
			  case sBkn: {return false;}; break;
			  case sWki: {return false;}; break;
			  case sBki: {return false;}; break;
			  case sWqu: {
			  	ev_c = 1;
			  	ev_j = 0;
			  	while (true) {
			  		ev_temp = Vec[7][Startsquare][ev_c];
			  		if (ev_temp==Endsquare) {return true;};
			  	  if (B[ev_temp]!=sEmp) {
						  ev_j++;
						  if (ev_j==2) {
							  return false;
							};
						};
			  	  ev_c++;
			    };
				}; break;
			  case sBqu: {
			  	ev_c = 1;
			  	ev_j = 0;
			  	while (true) {
			  		ev_temp = Vec[7][Startsquare][ev_c];
			  		if (ev_temp==Endsquare) {return true;};
			  	  if (B[ev_temp]!=sEmp) {
						  ev_j++;
						  if (ev_j==2) {
							  return false;
							};
						};
			  	  ev_c++;
			    };
				}; break;
			  default: {cout<<"print error77777777777:"<<B[Startsquare]<<endl;};
			};
	  }; break;
	  case 8: {//some knight jump separate from pawn eval vec
	    switch (B[Startsquare]) {
			  case 1: {return false;}; break;
			  case 2: {return false;}; break;
			  case 3: {return false;}; break;
			  case 4: {return false;}; break;
			  case 5: {return false;}; break;
			  case 6: {return false;}; break;
			  case 7: {return true;}; break;
			  case 8: {return true;}; break;
			  case 9: {return false;}; break;
			  case 10: {return false;}; break;
			  case 11: {return false;}; break;
			  case 12: {return false;}; break;
			  default: {cout<<"print error8888888888:"<<B[Startsquare]<<endl;};
			};
	  }; break;
	  case 9: { //same squares 9
	    switch (B[Startsquare]) {
			  case 1: {return true;}; break;
			  case 2: {return true;}; break;
			  case 3: {return true;}; break;
			  case 4: {return true;}; break;
			  case 5: {return true;}; break;
			  case 6: {return true;}; break;
			  case 7: {return true;}; break;
			  case 8: {return true;}; break;
			  case 9: {return true;}; break;
			  case 10: {return true;}; break;
			  case 11: {return true;}; break;
			  case 12: {return true;}; break;
			  default: {cout<<"print error99999999999:"<<B[Startsquare]<<endl;};
			};
	  }; break;
	  case 10: {
	    switch (B[Startsquare]) {
			  case 1: {return false;}; break;
			  case 2: {return false;}; break;
			  case 3: {return false;}; break;
			  case 4: {return false;}; break;
			  case 5: {return false;}; break;
			  case 6: {return false;}; break;
			  case 7: {return false;}; break;
			  case 8: {return false;}; break;
			  case 9: {return false;}; break;
			  case 10: {return false;}; break;
			  case 11: {return false;}; break;
			  case 12: {return false;}; break;
			  default: {cout<<"print error10:"<<B[Startsquare]<<endl;};
			};
	  }; break;
		case 11: { //nw to se single square vec
		  switch (B[Startsquare]) {
			  case sWpa: {return true;}; break;
			  case sBpa: {return true;}; break;
			  case sWro: {return false;}; break;
			  case sBro: {return false;}; break;
			  case sWbi: {return true;}; break;
			  case sBbi: {return true;}; break;
			  case sWkn: {return false;}; break;
			  case sBkn: {return false;}; break;
			  case sWki: {return true;}; break;
			  case sBki: {return true;}; break;
			  case sWqu: {return true;}; break;
			  case sBqu: {return true;}; break;
			  default: {cout<<"print error11:"<<B[Startsquare]<<endl;};
			};
		}; break;
		case 12: { //se to nw single square vec
		  switch (B[Startsquare]) {
			  case sWpa: {return true;}; break;
			  case sBpa: {return true;}; break;
			  case sWro: {return false;}; break;
			  case sBro: {return false;}; break;
			  case sWbi: {return true;}; break;
			  case sBbi: {return true;}; break;
			  case sWkn: {return false;}; break;
			  case sBkn: {return false;}; break;
			  case sWki: {return true;}; break;
			  case sBki: {return true;}; break;
			  case sWqu: {return true;}; break;
			  case sBqu: {return true;}; break;
			  default: {cout<<"print error12:"<<B[Startsquare]<<endl;};
			};
		}; break;
		case 13: { //sw to ne single square vec
		  switch (B[Startsquare]) {
			  case sWpa: {return true;}; break;
			  case sBpa: {return true;}; break;
			  case sWro: {return false;}; break;
			  case sBro: {return false;}; break;
			  case sWbi: {return true;}; break;
			  case sBbi: {return true;}; break;
			  case sWkn: {return false;}; break;
			  case sBkn: {return false;}; break;
			  case sWki: {return true;}; break;
			  case sBki: {return true;}; break;
			  case sWqu: {return true;}; break;
			  case sBqu: {return true;}; break;
			  default: {cout<<"print error13:"<<B[Startsquare]<<endl;};
			};
		}; break;
		case 14: { //ne to sw single square vec
		  switch (B[Startsquare]) {
			  case sWpa: {return true;}; break;
			  case sBpa: {return true;}; break;
			  case sWro: {return false;}; break;
			  case sBro: {return false;}; break;
			  case sWbi: {return true;}; break;
			  case sBbi: {return true;}; break;
			  case sWkn: {return false;}; break;
			  case sBkn: {return false;}; break;
			  case sWki: {return true;}; break;
			  case sBki: {return true;}; break;
			  case sWqu: {return true;}; break;
			  case sBqu: {return true;}; break;
			  default: {cout<<"print error14:"<<B[Startsquare]<<endl;};
			};
		}; break;
		case 15: { //w to e single square vec
		  switch (B[Startsquare]) {
			  case sWpa: {return true;}; break;
			  case sBpa: {return true;}; break;
			  case sWro: {return true;}; break;
			  case sBro: {return true;}; break;
			  case sWbi: {return false;}; break;
			  case sBbi: {return false;}; break;
			  case sWkn: {return false;}; break;
			  case sBkn: {return false;}; break;
			  case sWki: {return true;}; break;
			  case sBki: {return true;}; break;
			  case sWqu: {return true;}; break;
			  case sBqu: {return true;}; break;
			  default: {cout<<"print error15:"<<B[Startsquare]<<endl;};
			};
		}; break;
		case 16: {//e to w single square vec
			switch (B[Startsquare]) {
			  case sWpa: {return true;}; break;
			  case sBpa: {return true;}; break;
			  case sWro: {return true;}; break;
			  case sBro: {return true;}; break;
			  case sWbi: {return false;}; break;
			  case sBbi: {return false;}; break;
			  case sWkn: {return false;}; break;
			  case sBkn: {return false;}; break;
			  case sWki: {return true;}; break;
			  case sBki: {return true;}; break;
			  case sWqu: {return true;}; break;
			  case sBqu: {return true;}; break;
			  default: {cout<<"print error16:"<<B[Startsquare]<<endl;};
			};
	  }; break;
	  case 17: {//vector 17 (n to s two knight squares)
			switch (B[Startsquare]) {
			  case sWpa: {return false;}; break;
			  case sBpa: {return true;}; break;
			  case sWro: {return false;}; break;
			  case sBro: {return false;}; break;
			  case sWbi: {return false;}; break;
			  case sBbi: {return false;}; break;
			  case sWkn: {return true;}; break;
			  case sBkn: {return true;}; break;
			  case sWki: {return false;}; break;
			  case sBki: {return false;}; break;
			  case sWqu: {return false;}; break;
			  case sBqu: {return false;}; break;
			  default: {cout<<"print error17:"<<B[Startsquare]<<endl;};
			};
	  }; break;
	  case 18: {//vector 18 (s to n two knight squares)
			switch (B[Startsquare]) {
			  case sWpa: {return true;}; break;
			  case sBpa: {return false;}; break;
			  case sWro: {return false;}; break;
			  case sBro: {return false;}; break;
			  case sWbi: {return false;}; break;
			  case sBbi: {return false;}; break;
			  case sWkn: {return true;}; break;
			  case sBkn: {return true;}; break;
			  case sWki: {return false;}; break;
			  case sBki: {return false;}; break;
			  case sWqu: {return false;}; break;
			  case sBqu: {return false;}; break;
			  default: {cout<<"print error18:"<<B[Startsquare]<<endl;};
			};
	  }; break;
	  case 19: {//vector 19 (n to s below two knight squares)
	    switch (B[Startsquare]) {
			  case sWpa: {return false;}; break;
			  case sBpa: {return true;}; break;
			  case sWro: {return false;}; break;
			  case sBro: {return false;}; break;
			  case sWbi: {return false;}; break;
			  case sBbi: {return false;}; break;
			  case sWkn: {return false;}; break;
			  case sBkn: {return false;}; break;
			  case sWki: {return false;}; break;
			  case sBki: {return false;}; break;
			  case sWqu: {return false;}; break;
			  case sBqu: {return false;}; break;
			  default: {cout<<"print error19:"<<B[Startsquare]<<endl;};
			};
	  }; break;
	  case 20: {//vector 20 (s to n over two knight squares)
	    switch (B[Startsquare]) {
			  case sWpa: {return true;}; break;
			  case sBpa: {return false;}; break;
			  case sWro: {return false;}; break;
			  case sBro: {return false;}; break;
			  case sWbi: {return false;}; break;
			  case sBbi: {return false;}; break;
			  case sWkn: {return false;}; break;
			  case sBkn: {return false;}; break;
			  case sWki: {return false;}; break;
			  case sBki: {return false;}; break;
			  case sWqu: {return false;}; break;
			  case sBqu: {return false;}; break;
			  default: {cout<<"print error20:"<<B[Startsquare]<<endl;};
			};
	  }; break;
		case 21: {//n to s one square vec
	    switch (B[Startsquare]) {
			  case sWpa: {return false;}; break;
			  case sBpa: {return true;}; break;
			  case sWro: {return true;}; break;
			  case sBro: {return true;}; break;
			  case sWbi: {return false;}; break;
			  case sBbi: {return false;}; break;
			  case sWkn: {return false;}; break;
			  case sBkn: {return false;}; break;
			  case sWki: {return true;}; break;
			  case sBki: {return true;}; break;
			  case sWqu: {return true;}; break;
			  case sBqu: {return true;}; break;
			  default: {cout<<"print error21:"<<B[Startsquare]<<endl;};
			};
	  }; break;
	  case 22: {//s to n one square vec
	    switch (B[Startsquare]) {
			  case sWpa: {return true;}; break;
			  case sBpa: {return false;}; break;
			  case sWro: {return true;}; break;
			  case sBro: {return true;}; break;
			  case sWbi: {return false;}; break;
			  case sBbi: {return false;}; break;
			  case sWkn: {return false;}; break;
			  case sBkn: {return false;}; break;
			  case sWki: {return true;}; break;
			  case sBki: {return true;}; break;
			  case sWqu: {return true;}; break;
			  case sBqu: {return true;}; break;
			  default: {cout<<"print error22:"<<B[Startsquare]<<endl;};
			};
	  }; break;
	  default: {cout<<"print error wrong_vec:"<<ev_v<<endl;};
	};
};
#endif

signed int EVAL()
{
  #ifdef LAZY_EVAL
  //always erase lazy eval mask if new eval
  le_mask = 0;
  #endif

  //analyse if pos is quiesent
  wki_checked_mask = 0;
	bki_checked_mask = 0;

  if (isAttByWhi(BkiPos) == true) {

    if (isBkiMated() == true) {
    	#ifdef DEBUG_VERSION
    	#ifdef LAZY_EVAL
			unlazy_evals_count++;
			#endif
			#endif
			return MAX_SCORE; //return mate score
      /*
      cout<<"mating gl_move:"<<printMove(gl_move)<<endl;
      <<" path: "<<getPATH(0,60)<<endl;
          printB("black mated:");
          */
    };

    bki_checked_mask = (1 << 30);
  };

  if (isAttByBla(WkiPos) == true) {

    if (isWkiMated() == true) {
    	#ifdef DEBUG_VERSION
      #ifdef LAZY_EVAL
			unlazy_evals_count++;
			#endif
			#endif
			return MIN_SCORE;
    };

    wki_checked_mask = (1 << 31);
  };

  ev_score = MaterialScore;

  /*
              + (WpaNum * evPawnMaterialValue)
              - (BpaNum * evPawnMaterialValue)
              + (WroNum * evRookMaterialValue)
              - (BroNum * evRookMaterialValue)
              + (WbiNum * evBishopMaterialValue)
              - (BbiNum * evBishopMaterialValue)
              + (WknNum * evKnightMaterialValue)
              - (BknNum * evKnightMaterialValue)
              + (WquNum * evQueenMaterialValue)
              - (BquNum * evQueenMaterialValue));
  */

  ev_mat_score = ev_score;

#ifdef DEBUG_VERSION
  //if white king is not being checked in this position
  //if (wki_checked_mask == 0) {
    //retain safe ev_score bounds
    if (ev_score > MAX_SCORE) {
    	printB("bug: out of max bound before full evaluation!!!!!!!!");
    	printPATH(0,20);
    	cout<<"(ev_score== "<<ev_score<<") > (MAX_SCORE=="<<MAX_SCORE<<")"<<endl;
      return MAX_SCORE - 1;
    };

  //};

  //if black king is not being checked in this position
  //if (bki_checked_mask == 0) {
    if (ev_score < MIN_SCORE) {
    	printB("bug: out of min bound before full evaluation!!!!!!!!");
			printPATH(0,20);
			cout<<"(ev_score== "<<ev_score<<") < (MIN_SCORE=="<<MIN_SCORE<<")"<<endl;
			return MIN_SCORE + 1;
    };
  //};
#endif //debug_version

  #ifdef LAZY_EVAL
  //Never do le if escaping from check or making check. Not many such positions.

	//Generally we do lazy eval only if material score differs from the compared
	//value because lazy eval score is only a rough material score -
	//-its precision is a value of one pawn.

  //At shallow depth(ply<qDepth) we only need to sort moves and doing le to this
	//moves cannot affect final score. However it spoils move ordering here and
	//the whole search would probably take much time. Not as many nodes here comparing
	//with grater depths.

  //If we are at qDepth normally we generate static score with full evaluation -
	//this evaluation allways may affect search score and search result.
	//Assuming that material score is the gratest part of eval:
	//if the move has worse material score than the root search score  -
	//it is sufficient to do simple material lazy eval here. Mates are found earlier.
	//The same should work with qs nodes.

	//And vice versa - if the move has better material score than the root search score  -
	//it is sufficient to do simple material lazy eval here. Mates are found earlier.


	if (se_ply >= qDepth) { //if we are at qDepth or deeper
	  if (wki_checked_mask==bki_checked_mask) { //if no check or check evasion
			//if root score has been updated in given search depth
      if (val[0] != EMPTY_VAL) {
      	if ((ev_mat_score  < (val[0] - (evPawnMaterialValue * 0.6))) ||
						(ev_mat_score  > (val[0] + (evPawnMaterialValue * 0.6)))) {

					#ifdef DEBUG_VERSION
					//lower and upper bounds together
          lazy_evals_count++;
          #endif

					//set lazy eval mask
          le_mask = (1 << 26);
          return ev_mat_score;

				};
		  };
	  };
  };

  #endif //LAZY_EVAL



  /*
  - extend positions which have threat (pieces under attack of minor attackers
  have sometimes nowwhere to go, if piece is attacked by equal or greater piece
  - but is undefended - use the same procedure).

  if two moves in a row
  */

  //clear counters used in king safety evaluation - only the data near the kings


	AttackedWkiAreaCounter[WkiPos] = 0;

  for (ev_v = 0; ev_v < 8; ev_v++) {
    AttackedWkiAreaCounter[Vec[ev_v][WkiPos][0]] = 0;
  };

  AttackedBkiAreaCounter[BkiPos] = 0;

  for (ev_v = 0; ev_v < 8; ev_v++) {
    AttackedBkiAreaCounter[Vec[ev_v][BkiPos][0]] = 0;
  };

	#ifdef GET_KING_SAFETY_SCORE
	ev_WkiSafetyScore = 0;
	ev_BkiSafetyScore = 0;
	#endif

  ev_WpaBsqNum = 0; //white pawns on black squares for bishop code

  ev_BpaBsqNum = 0; //black pawns on black squares for bishop code

  ev_BbiOnBsq = false;  //black darksquare bishop

  ev_WbiOnBsq = false;  //white darksquare bishop

  ev_BbiOnWsq = false;  //black lightsquare bishop

  ev_WbiOnWsq = false;  //white lightsquare bishop


	#ifdef ATTACKS_MAP
	//clear attacked pieces bitmaps before each EVAL.
	//this information is generated in eval and used only to influence EVAL
	//and / or to be saved in SSE_results[depth] table to guide search depth
	WhiAttackedMap = 0;
	BlaAttackedMap = 0;
	#endif


  #ifdef DEBUG_VERSION
	//memorize initial score value before iteration through the board
	//it is used used in debugging positional scores generated by the pieces
	#ifdef DEBUG_EVAL
	ev_tempscore = ev_score;
  #endif
  #endif

  //memorize initial score value before iteration through the board
	ev_tempsc = ev_score;

	//add all square scores to get basic final score
  for (ev_fs = 0; ev_fs < 64; ev_fs++) {

    #ifdef REUSE_EVAL
    /*
    if vector 10 - use precalc value
    if on vector but pieces are not liking vector - use precalc value
    analyse the whole vector- every square (because of possible threats , pins)
		most common case - continue if empty square
		usesVec(from, to), getVec[(from<<6)|to]
		*/

		//Use precalculated data of ev_fs piece
		//if we use proper table of square-scores
		if (do_reuse_eval == true) {

			switch (B[ev_fs]) {
				case sEmp: {continue;}; break;
				case sWki: {if (side==true) {EV_SQUARE(); goto REUSE_END;};}; break;
				case sBki: {if (side==false) {EV_SQUARE(); goto REUSE_END;};}; break;
				default: {;};
		  };

		  switch (gl_fp) {
			  case sWki: {EV_SQUARE(); goto REUSE_END;}; break;
			  case sBki: {EV_SQUARE(); goto REUSE_END;}; break;
			};


			//if making empty gl_fs square doesnt affect ev_fs piece eval
			if ((usesVec(ev_fs, gl_fs))==false) {
			  //if occupying gl_ts square doesnt affect ev_fs piece eval
        if ((usesVec(ev_fs, gl_ts))==false) {

					//use precalculated ev_fs score
					ev_score = SC[ev_fs];
			    precalc_score_used_count++;

					/*
					//debug-start - affects performance!


					//calculate ev_score using EV_SQUARE(), than compare:
					EV_SQUARE();

					if (SC[ev_fs]!=ev_score) {
						cout<<"reuse eval test failed: gl_move " << printMove(gl_move)
						<< " affects ev_fs sq eval:" << COL[ev_fs] << ROW[ev_fs] << ". Calculated ev_score:"
						<< ev_score << " SC[ev_fs]:" << SC[ev_fs]
						<<" path(0-10): "<<getPATH(0,10) << " Zkey_tab[se_ply-1]:"
						<< Zkey_tab[se_ply-1] << flush;
						printB("reuse eval test fail chessboard:");
					}
					else {
						//cout<<" reuse eval test pass. SC[] value could be used instead of (more?) expensive EV_SQUARE() function"<<endl;
					};

					//debug-end
			    */

					goto REUSE_END;


			  };
	    };
	  };

		//calculate ev_score with (more?) expensive function if cannot jump it over
		EV_SQUARE();

		//jump here if eval data of ev_fs square can be reused
		REUSE_END:{;};
    #endif

	  #ifndef REUSE_EVAL //if not defined
		//function takes reads global ev_fs and changes global ev_score by calculating positional score (!)
		//use carefully
		EV_SQUARE();
	  #endif

	  #ifdef DEBUG_VERSION
	  #ifdef DEBUG_EVAL
	  E[ev_fs] = ev_score;
		#endif
	  #endif

	  ev_tempsc += ev_score;
  };

  ev_score = ev_tempsc;

  //add right to move score
  if (side == false)
    //if position after white move
  {
    ev_score -= evSide; // add side bonus for black
  } else {
    ev_score += evSide;// else add side bonus for white
  };

//award bishop pair (easy code - not checking square color)
  if (WbiNum > 1) {
    ev_score += evSecondBishop;
  };

  if (BbiNum > 1) {
    ev_score -= evSecondBishop;
  };


//calculation of data for this code will be probably moved to movegen
//score white bishop square colour - ability to attack pawns
  if (ev_WbiOnBsq == true) {
    ev_score += (ev_BpaBsqNum * evBishopOpponentPawnSquareColourMatch);
  };

  if (ev_WbiOnWsq == true) {
    ev_score += ((BpaNum - ev_BpaBsqNum) * evBishopOpponentPawnSquareColourMatch);
  };

//score black bishop square colour - ability to attack pawns
  if (ev_BbiOnBsq == true) {
    ev_score -= (ev_WpaBsqNum * evBishopOpponentPawnSquareColourMatch);
  };

  if (ev_BbiOnWsq == true) {
    ev_score -= ((WpaNum - ev_WpaBsqNum) * evBishopOpponentPawnSquareColourMatch);
  };


/*
  //temporarily turned off code to create and debug REUSE_EVAL code
  //eval black king safety - attack on king area
  if (WquNum > 0) {
    ev_score += (AttackedBkiAreaCounter[BkiPos] * evKingAttackCooperation);
  };

  //eval white king safety - attack on king area
  if (BquNum > 0) {ki
    ev_score -= (AttackedWkiAreaCounter[WkiPos] * evKingAttackCooperation);
  };
*/
#ifdef DEBUG_VERSION
//retain safe ev_score bounds after tweaking positional score
  if (ev_score >
	(signed int)
	MAX_SCORE) {
		printB("bug: out of max bound after tweaking positional score!!!!!!!!");
		printPATH(0,20);
		return (MAX_SCORE - 1);
  };

  if (ev_score <
	 (signed int)
	 MIN_SCORE) {
    printB("bug: out of min bound after tweaking positional score!!!!!!!!");
		printPATH(0,20);
		return (MIN_SCORE + 1);
  };

	#ifdef DEBUG_EVAL
  //cout<<"forced_pos:"<<forced_pos<<endl;
  if (display_eval_details == true) {
		cout << "in the end of EVAL()" << endl <<
         "* +---+---+---+---+---+---+---+---+" << endl <<
         "8 | " << E[0] << " | " << E[1] << " | " << E[2] << " | " <<
         E[3] << " | " << E[4] << " | " << E[5] << " | " << E[6] <<
         " | " << E[7] << " |" << endl;
    cout << "* +---+---+---+---+---+---+---+---+" << endl <<
         "7 | " << E[8] << " | " << E[9] << " | " << E[10] << " | " <<
         E[11] << " | " << E[12] << " | " << E[13] << " | " << E[14] <<
         " | " << E[15] << " |" << endl;
    cout << "* +---+---+---+---+---+---+---+---+" << endl <<
         "6 | " << E[16] << " | " << E[17] << " | " << E[18] << " | " <<
         E[19] << " | " << E[20] << " | " << E[21] << " | " << E[22] <<
         " | " << E[23] << " |" << endl;
    cout << "* +---+---+---+---+---+---+---+---+" << endl <<
         "5 | " << E[24] << " | " << E[25] << " | " << E[26] << " | " <<
         E[27] << " | " << E[28] << " | " << E[29] << " | " << E[30] <<
         " | " << E[31] << " |" << endl;
    cout << "* +---+---+---+---+---+---+---+---+" << endl <<
         "4 | " << E[32] << " | " << E[33] << " | " << E[34] << " | " <<
         E[35] << " | " << E[36] << " | " << E[37] << " | " << E[38] <<
         " | " << E[39] << " |" << endl;
    cout << "* +---+---+---+---+---+---+---+---+" << endl <<
         "3 | " << E[40] << " | " << E[41] << " | " << E[42] << " | " <<
         E[43] << " | " << E[44] << " | " << E[45] << " | " << E[46] <<
         " | " << E[47] << " |" << endl;
    cout << "* +---+---+---+---+---+---+---+---+" << endl <<
         "2 | " << E[48] << " | " << E[49] << " | " << E[50] << " | " <<
         E[51] << " | " << E[52] << " | " << E[53] << " | " << E[54] <<
         " | " << E[55] << " |" << endl;
    cout << "* +---+---+---+---+---+---+---+---+" << endl <<
         "1 | " << E[56] << " | " << E[57] << " | " << E[58] << " | " <<
         E[59] << " | " << E[60] << " | " << E[61] << " | " << E[62] <<
         " | " << E[63] << " |" << endl;
    cout << "* +---+---+---+---+---+---+---+---+" << endl <<
         "*   a   b   c   d   e   f   g   h"  << endl;
  };
  #endif

//return score
  #ifdef LAZY_EVAL
	unlazy_evals_count++;
  #endif
  #endif //debug_version

  #ifdef ATTACKS_MAP

	#ifdef DEBUG_VERSION
	//find out if attacked pieces bitmaps are nonzero after each EVAL.
	//this information is generated in eval and used only to influence EVAL
	//and / or to be saved in SSE_results[depth] table to guide search depth
	//The code may not work properly if reuse eval code used or check or lazy eval
	//because bitmaps are not filled in above code snippets!.
	if (WhiAttackedMap == 0) {WhiAttackedMapCount++;}
	else {WhiUnattackedMapCount++;};
	if (BlaAttackedMap == 0) {BlaAttackedMapCount++;}
	else {BlaUnattackedMapCount++;};
	#endif

	//set white attack mask
	if (BlaAttackedMap == 0) {
	  whi_threat_mask = 0;
  }
	else {
		whi_threat_mask = (1 << 25);
	};

	//set black attack mask
	if (WhiAttackedMap == 0) {
	  bla_threat_mask = 0;
	}
	else {
		bla_threat_mask = (1 << 24);
	};
  #endif

  //todo@
	//modify evaluation by analysing threat scores
	//the closer threat is located to the king area or to the center of the board
	//or to the opponent side
	//the better threat score affects the score

	//todo
	//modify evaluation by analysing piece-development scores
	//the closer self pieces to the opponent side - the better score
	//the closer to the back of the board the opponent pieces - the better score


  return ev_score;
};

/*
Static Exchange Evaluation. this should improve move ordering,
because EVAL() sorts move only by means of static evaluation (i.e. it
doesnt see bad trades). The more important implementation is that
it can give some info to set search depth. This rough heuristic SEE move
evaluation is examined only for last moved piece.
In another implementation it can be used for all pieces
which are attacked by opponent. SEE is imperfect beacause it doesnt see
threats, pins, checks etc. Scoring of these is done somewhere else.
More precise score than SEE is returned in QS.
Implementation:
-find least valuable opponent attacker of attacked_sq_index,
-temporarily remove it (save it on the A list to further add it back)
-find least valuable self attacked_sq_index defender,
-temporarily remove it (save it on the B list to further add it back)
-continue the above procedure in a loop and save see_Eval[exchange level]
-save material pseudoleaf score at see_Score
-go up exchange levels and do minimax with see_Score, if see_Eval[] is better,
replace see_Score with this value.
Usage:
- do a little change of static score on basis of SEE,
- set SEE flag for probable loss of material to *exclude* (!) some lines from deeper search
- dont do SEE in leaf nodes (if only QS works better)
*/

#ifdef S_E_E

//takes as argument global side
signed int SEE(int attacked_sq_index, bool myside)
{
  //if white to move
  if (myside == true) {

  	//show or hide debugging output
  	//#define DBG_SEE

  	#ifdef DBG_SEE
		cout << "telluser procccccessing \"wtm==true\" code, white to move" << endl;
		#endif

		see_n = 0; //zero index remains if no opponent attack on attacked_sq_index
    see_val = 0;
    see_Score[0] = 0; //set initial score before checking if capture is possible

    //find white attacker square
    see_from = LeastValuableWhiAttFrom(attacked_sq_index);

    //return zero if no attack (this should never happen unless debugging)
    if (see_from == 64) {return 0;};

    see_AttacksFrom[see_n] = see_from; //save white attacker square

    see_AttackerPieceType[see_n] = B[see_from]; //save white attacker piece

    //assign initial advantage of black attacked_sq_index piece value
    see_val = UnsignedMaterialValue[B[attacked_sq_index]];

    see_Score[see_n] = see_val; //save initial score if capture possible

    B[see_from] = sEmp; //erase white attacker square

		#ifdef DBG_SEE
		cout<<"telluser whi captures: see_Score["<<see_n<<"]: "<<see_Score[see_n]
    <<" see_AttacksFrom["<<see_n<<"]: "<<SQUARE[see_AttacksFrom[see_n]]
    <<" see_AttackerPieceType["<<see_n<<"]: "<<printPiece(see_AttackerPieceType[see_n])
    <<endl;
    #endif

    while (true) {
    	//black recapture in loop:

      //find black attacker square
	    see_from = LeastValuableBlaAttFrom(attacked_sq_index);

	    //break loop if no attack
	    if (see_from == 64) {break;};

	    see_n++; //increment table index

	    see_AttacksFrom[see_n] = see_from; //save black attacker square

	    see_AttackerPieceType[see_n] = B[see_from]; //save black attacker piece

	    //gain white attacker piece value
     	see_val -= UnsignedMaterialValue[see_AttackerPieceType[see_n-1]];

	    see_Score[see_n] = see_val; //save score after black capture move

	    B[see_from] = sEmp; //erase black attacker square

			#ifdef DBG_SEE
			cout<<"telluser bla recaptures in loop: see_Score["<<see_n<<"]: "<<see_Score[see_n]
      <<" see_AttacksFrom["<<see_n<<"]: "<<SQUARE[see_AttacksFrom[see_n]]
      <<" see_AttackerPieceType["<<see_n<<"]: "<<printPiece(see_AttackerPieceType[see_n])
      <<endl;
      #endif

      //white recapture in loop:

     	//find white attacker square
	    see_from = LeastValuableWhiAttFrom(attacked_sq_index);

	    //break loop if no attack
	    if (see_from == 64) {break;};

	    see_n++; //increment table index

	    see_AttacksFrom[see_n] = see_from; //save white attacker square

	    see_AttackerPieceType[see_n] = B[see_from]; //save white attacker piece

	    //gain black attacker piece value
     	see_val += UnsignedMaterialValue[see_AttackerPieceType[see_n-1]];

	    see_Score[see_n] = see_val; //save score after white capture move

	    B[see_from] = sEmp; //erase white attacker square

			#ifdef DBG_SEE
      cout<<"telluser whi recaptures in loop: see_Score["<<see_n<<"]: "<<see_Score[see_n]
      <<" see_AttacksFrom["<<see_n<<"]: "<<SQUARE[see_AttacksFrom[see_n]]
      <<" see_AttackerPieceType["<<see_n<<"]: "<<printPiece(see_AttackerPieceType[see_n])
      <<endl;
      #endif

    };
  }
	else {

		#ifdef DBG_SEE
		cout << "telluser processing \"btm==true\" code, black to move" << endl;
		#endif

		see_n = 0; //zero index remains if no opponent attack on attacked_sq_index
    see_val = 0;
    see_Score[0] = 0; //set initial score before checking if capture is possible

    //find white attacker square
    see_from = LeastValuableBlaAttFrom(attacked_sq_index);

    //return zero if no attack (this should never happen unless debugging)
    if (see_from == 64) {return 0;};

    see_AttacksFrom[see_n] = see_from; //save black attacker square

    see_AttackerPieceType[see_n] = B[see_from]; //save black attacker piece

    //assign initial advantage of white attacked_sq_index piece value
    see_val = -(UnsignedMaterialValue[B[attacked_sq_index]]);

    see_Score[see_n] = see_val; //save initial score if capture possible

    B[see_from] = sEmp; //erase black attacker square

		#ifdef DBG_SEE
    cout<<"telluser bla captures: see_Score["<<see_n<<"]: "<<see_Score[see_n]
    <<" see_AttacksFrom["<<see_n<<"]: "<<SQUARE[see_AttacksFrom[see_n]]
    <<" see_AttackerPieceType["<<see_n<<"]: "<<printPiece(see_AttackerPieceType[see_n])
    <<endl;
    #endif

    while (true) {
    	//white recapture in loop:

      //find white attacker square
	    see_from = LeastValuableWhiAttFrom(attacked_sq_index);

	    //break loop if no attack
	    if (see_from == 64) {break;};

	    see_n++; //increment table index

	    see_AttacksFrom[see_n] = see_from; //save white attacker square

	    see_AttackerPieceType[see_n] = B[see_from]; //save white attacker piece

	    //gain black attacker piece value
     	see_val += UnsignedMaterialValue[see_AttackerPieceType[see_n-1]];

	    see_Score[see_n] = see_val; //save score after white capture move

	    B[see_from] = sEmp; //erase white attacker square

			#ifdef DBG_SEE
      cout<<"telluser whi recaptures in loop: see_Score["<<see_n<<"]: "<<see_Score[see_n]
      <<" see_AttacksFrom["<<see_n<<"]: "<<SQUARE[see_AttacksFrom[see_n]]
      <<" see_AttackerPieceType["<<see_n<<"]: "<<printPiece(see_AttackerPieceType[see_n])
      <<endl;
      #endif

      //black recapture in loop:

     	//find black attacker square
	    see_from = LeastValuableBlaAttFrom(attacked_sq_index);

	    //break loop if no attack
	    if (see_from == 64) {break;};

	    see_n++; //increment table index

	    see_AttacksFrom[see_n] = see_from; //save black attacker square

	    see_AttackerPieceType[see_n] = B[see_from]; //save black attacker piece

	    //gain white attacker piece value
     	see_val -= UnsignedMaterialValue[see_AttackerPieceType[see_n-1]];

	    see_Score[see_n] = see_val; //save score after black capture move

	    B[see_from] = sEmp; //erase black attacker square

			#ifdef DBG_SEE
      cout<<"telluser bla recaptures in loop: see_Score["<<see_n<<"]: "<<see_Score[see_n]
      <<" see_AttacksFrom["<<see_n<<"]: "<<SQUARE[see_AttacksFrom[see_n]]
      <<" see_AttackerPieceType["<<see_n<<"]: "<<printPiece(see_AttackerPieceType[see_n])
      <<endl;
      #endif
    };
	};


  //after the loop we have "leaf" value see_val
  //cout << "PSEUDO-LEAF see_val: " << see_val <<endl;

  //restore attackers and defenders on the board in reverse order and
  //simulate minimax search. Additionally take into account: possibility
  //of not capturing in every step.

  //if we takeback white-takes-black move (simulates wtm side move)
  if (see_Score[see_n-1] < see_Score[see_n]) {
    while (see_n > 0) {

      //restore attacker
      B[see_AttacksFrom[see_n]] = see_AttackerPieceType[see_n];

			#ifdef DBG_SEE
      cout<<"telluser IN QUASI-MINIMAX TAKEBACK LOOP: "
			<< printPiece(see_AttackerPieceType[see_n])
      <<" restored on square "<<SQUARE[see_AttacksFrom[see_n]]<<endl;
      #endif

      //if value of parent is worse than child - use child value (maximize parent)
      if (see_Score[see_n-1] < see_Score[see_n]) {

				#ifdef DBG_SEE
				cout<<"telluser IN QUASI-MINIMAX TAKEBACK LOOP: see_Score["<<see_n-1
        <<"] updated from "<< see_Score[see_n-1] <<" to "<<see_Score[see_n]<<endl;
				#endif

				see_Score[see_n-1] = see_Score[see_n];
			};

			//simulate going up, break if on top
			see_n--;
			if (see_n == 0) break;

			//restore attacker
      B[see_AttacksFrom[see_n]] = see_AttackerPieceType[see_n];

			#ifdef DBG_SEE
      cout<<"telluser IN QUASI-MINIMAX TAKEBACK LOOP: " <<
      printPiece(see_AttackerPieceType[see_n])
      <<" restored on square "<<SQUARE[see_AttacksFrom[see_n]]<<endl;
      #endif

			//if value of parent is worse than child - use child value (minimize parent)
      if (see_Score[see_n-1] > see_Score[see_n]) {

				#ifdef DBG_SEE
				cout<<"telluser IN QUASI-MINIMAX TAKEBACK LOOP: see_Score["<<see_n-1
        <<"] updated from "<< see_Score[see_n-1] <<" to "<<see_Score[see_n]<<endl;
        #endif

				see_Score[see_n-1] = see_Score[see_n];
			};

			//simulate going up, break if on top
			see_n--;
			if (see_n == 0) break;

    };
  }
  ////////////
  else {
  	while (see_n > 0) {

      //restore attacker
      B[see_AttacksFrom[see_n]] = see_AttackerPieceType[see_n];

			#ifdef DBG_SEE
      cout<<"telluser IN QUASI-MINIMAX TAKEBACK LOOP: "
			<< printPiece(see_AttackerPieceType[see_n])
      <<" restored on square "<<SQUARE[see_AttacksFrom[see_n]]<<endl;
			#endif

      //if value of parent is worse than child - use child value (minimize parent)
      if (see_Score[see_n-1] > see_Score[see_n]) {
				#ifdef DBG_SEE
				cout<<"telluser IN QUASI-MINIMAX TAKEBACK LOOP: see_Score["<<see_n-1
        <<"] updated from "<< see_Score[see_n-1] <<" to "<<see_Score[see_n]<<endl;
        #endif

				see_Score[see_n-1] = see_Score[see_n];
			};

			//simulate going up, break if on top
			see_n--;
			if (see_n == 0) break;

			//restore attacker
      B[see_AttacksFrom[see_n]] = see_AttackerPieceType[see_n];

			#ifdef DBG_SEE
      cout<<"telluser IN QUASI-MINIMAX TAKEBACK LOOP: " <<
      printPiece(see_AttackerPieceType[see_n])
      <<" restored on square "<<SQUARE[see_AttacksFrom[see_n]]<<endl;
      #endif

			//if value of parent is worse than child - use child value (maximize parent)
      if (see_Score[see_n-1] < see_Score[see_n]) {

				#ifdef DBG_SEE
      	cout<<"telluser IN QUASI-MINIMAX TAKEBACK LOOP: see_Score["<<see_n-1
        <<"] updated from "<< see_Score[see_n-1] <<" to "<<see_Score[see_n]<<endl;
      	#endif

			  see_Score[see_n-1] = see_Score[see_n];
			};

			//simulate going up, break if on top
			see_n--;
			if (see_n == 0) break;

    };

	};

	#ifdef DBG_SEE
  cout<<"telluser Final see_Score[0]: "<<see_Score[0]<<endl;
  #endif

	return see_Score[0];

};
#endif

/*
//function to discover check or attack - return true if square attacked by white piece
bool SmartIsAttByWhi(int from_sq, int to_sq, bool full_check) {
 //return false;

 int v;

 //if king on from square not in check
 if (full_check==false) {

  v = getVec[from_sq][to_sq]; //king square, i
   //if not on vector
   if (v==64) {return false;}
    //rook-like v
   else if (v>3) {
    for (int c=0;c<8;c++) {
       switch (B[Vec[v][from_sq][c]]) {
       case sEmp: {;}; break;
       case sWro: {return true;};
       case sWqu: {return true;};
       default: {c=8;};
     };
    };
    }
   //bishop-like v
   else {
      for (int c=0;c<8;c++) {
        switch (B[Vec[v][from_sq][c]]) {
       case sEmp: {;}; break;
       case sWbi: {return true;};
       case sWqu: {return true;};
       default: {c=8;};
     };
    };
    };
  return false;
  }
  //else if full to_sq attack checking
 else {

  //pawn atacks
   if ((B[LBPCaps[from_sq]] == sWpa) || (B[RBPCaps[from_sq]] == sWpa)) return true;

  //rook-like v-s
   for (int v=4;v<8;v++) {
     for (int c=0;c<8;c++) {
      switch (B[Vec[v][from_sq][c]]) {
      case sEmp: {;}; break;
      case sWro: {return true;};
      case sWqu: {return true;};
      default: {c=8;};
    };
   };
   };

   //bishop-like v-s
  for (int v=0;v<4;v++) {
     for (int c=0;c<8;c++) {
       switch (B[Vec[v][from_sq][c]]) {
      case sEmp: {;}; break;
      case sWbi: {return true;};
      case sWqu: {return true;};
      default: {c=8;};
    };
   };
   };

  //knight attacks
   for(int c=0;c<8;c++) {
     if (B[KnightMap[from_sq][c]]==sWkn) return true;
   };

   //king attacks
   for (int v=0;v<8;v++) {
     if (B[Vec[v][from_sq][0]]==sWki) return true;
   };

  return false;
 };

};


//return true if to_square is attacked by black piece
bool SmartIsAttByBla(int from_sq, int to_sq, bool full_check) {
 //return false;

 int v;
 //i.e. if king on to_sq not in check
 if (full_check==false) {
  v = getVec[from_sq][to_sq];
   //if not on vector
   if (v==64) {return false;}
    //rook-like v
   else if (v>3) {
    for (int c=0;c<8;c++) {
       switch (B[Vec[v][from_sq][c]]) {
       case sEmp: {;}; break;
       case sBro: {return true;};
       case sBqu: {return true;};
       default: {c=8;};
     };
    };
    }
   //bishop-like v
   else {
      for (int c=0;c<8;c++) {
        switch (B[Vec[v][from_sq][c]]) {
       case sEmp: {;}; break;
       case sBbi: {return true;};
       case sBqu: {return true;};
       default: {c=8;};
     };
    };
    };
  return false;
  }
  //else if full attack checking on from_sq
 else {

  if ((B[LWPCaps[from_sq]] == sBpa) || (B[RWPCaps[from_sq]] == sBpa)) return true;

  for (int v=4;v<8;v++) {
     for (int c=0;c<8;c++) {
      switch (B[Vec[v][from_sq][c]]) {
      case sEmp: {;}; break;
      case sBro: {return true;};
      case sBqu: {return true;};
      default: {c=8;};
    };
     };
   };
   for (int v=0;v<4;v++) {
     for (int c=0;c<8;c++) {
       switch (B[Vec[v][from_sq][c]]) {
      case sEmp: {;}; break;
      case sBbi: {return true;};
      case sBqu: {return true;};
      default: {c=8;};
    };
   };
   };

  for(int c=0;c<8;c++) {
     if (B[KnightMap[from_sq][c]]==sBkn) return true;
   };

   for (int v=0;v<8;v++) {
     if (B[Vec[v][from_sq][0]]==sBki) return true;
   };

   return false;
 };

};
*/

#ifdef REUSE_EVAL
//generate table containing vector direction numbers from square i to j
//function uses static unsigned short (*getVec) = new unsigned short[64*64];
//v:0-3 bishop vector squares
//v:4-7 rook vector squares
//v:8 knight jump squares
//v:9 same squares
//v:10 no match
/*
void generateGetVec() {
  unsigned int i, j, v, c, z;
  //loop from squares
	for (i=0; i<64; i++) {
    //loop to squares
		for (j=0; j<64; j++) {
		  //if same square set v=9
      if (i==j) {getVec[(i<<6) | j] = 9;}
			else {
			  //erase vector board (v=10)
			  getVec[(i<<6) | j] = 10;
		  };
    };
  };

  //loop from squares
	for (i=0; i<64; i++) {
    //if knight jump set v=8
    for (c=0; c<8; c++) {
      if (increasingKnightMap[i][c] == 64) {break;};
      j = increasingKnightMap[i][c];
      getVec[(i<<6) | j] = 8;
			//assign special common vectors both for pawn eval and knight eval
			if (((colnum[j]+1) == colnum[i]) || ((colnum[j]-1) == colnum[i])) {
			  if (i < j) {
			  	//assign vector 17 (n to s two knight squares)
			    getVec[(i<<6) | j] = 17;
			    //cout<<"17"<<endl;
					//assign vector 19 n to s like vec 6
					for (z=0; z<8; z++) {
            v = Vec[6][j][z]; //get v square
            if (v == 64) {break;}; //break if out of board
            getVec[(i<<6) | v] = 19;
				  };
				}
				else {
				  //assign vector 18 (s to n two knight squares)
			    getVec[(i<<6) | j] = 18;
					//assign vector 20 s to n like vec 7
					for (z=0; z<8; z++) {
            v = Vec[7][j][z]; //get v square
            if (v == 64) {break;}; //break if out of board
            getVec[(i<<6) | v] = 20;
				  };
				};
		  };
    };
  };



  //save vector number from Vec[direction][from][to] into getVec[(from<<6)|to]
  for (i=0; i<64; i++) {
    for (v=0; v<8; v++) {
      for (c=0; c<8; c++) {
        j = Vec[v][i][c]; //get j square
        if (j == 64) {break;}; //break if out of board
        getVec[(i<<6) | j] = v; //the later result will be more than one square vectors
        if ((v >= 0) && (v <= 5)) {
				  if (c == 0) {
				  	//add vectors 11 to 16 (single square vecs)
					  getVec[(i<<6) | j] = (v + 11);
					};
				}
				else if (v == 6) {
				  if (c == 0) {
				  	//add vector 21 (single square vec n to s)
					  getVec[(i<<6) | j] = 21;
					};
				}
				else if (v == 7) {
				  if (c == 0) {
				  	//add vector 22 (single square vec s to n)
					  getVec[(i<<6) | j] = 22;
					};
				}
      };
    };
  };


  //debug-start
  cout<<"getVec.txt file created!!!"<<endl;
	ofstream fout("getVec.txt");
  for (i=0;i<64;i++) {
    for (j=0;j<64;j++) {
    	//fout<<COL[i]<<ROW[i]<<" --> "<<COL[j]<<ROW[j]<<": "<<getVec[(i<<6) | j]<<endl;
    	//fout<<((i<<6) | j)<<":"<<getVec[(i<<6) | j]<<endl;
    	fout<<getVec[(i<<6) | j]<<","<<flush;
    };
  };
  //debug-end

};
*/
#endif




