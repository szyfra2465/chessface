//hashtable size in == Hsize*Hlen
//possible 1, 2, 4, 8, 16, 32 Mb etc. //0-9 index
//         0  1  2  3   4   5  bit extensions (power of 2)
const unsigned short Hash_Mb_Size[] = {1, 2, 4, 8, 16, 32, 64, 128, 256, 512}; //size in Mb
//const unsigned Hash_Size_Idx = 0;
const unsigned char Hash_Size_Idx = 5; //32Mb
//2^16 = 65536 (that is why 16 bit key len for base hash)
//max 1 byte number = 256
//max 1 Mbyte number = 256 * 1024 * 1024
//8 byte number == unsigned __int64
//8 byte number * 2 = 16 bytes per 1 hash slot
//16 bytes * Hsize = (1024*1024) bytes
//Hsize = 1024*1024 / 16 = 65536
const unsigned __int64 Hsize = (65536 * Hash_Mb_Size[Hash_Size_Idx]);   //1 Megabyte / 16 bytes width = 65535 bytes
//long hashkey length
const unsigned char Zkeylen = 64; //[64 bit hash key]
//short hash length, 16 bit len for 1 Mb
const unsigned char Hkeylen = (16 + Hash_Size_Idx);
//limit of tries to put entry into hashtable - not implemented
//const unsigned short Htrylimit = 3;

//function clears global hash
void clearHash();
//function initializes global Zkeys using random key generation
//and Game[GMI] data. Key length (bitlen) is 64 by default
void setGameZkey(unsigned short bitlen);
